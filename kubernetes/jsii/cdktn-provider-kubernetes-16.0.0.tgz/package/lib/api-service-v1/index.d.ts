/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiServiceV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#id ApiServiceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#metadata ApiServiceV1#metadata}
    */
    readonly metadata: ApiServiceV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#spec ApiServiceV1#spec}
    */
    readonly spec: ApiServiceV1Spec;
}
export interface ApiServiceV1Metadata {
    /**
    * An unstructured key value map stored with the api_service that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#annotations ApiServiceV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#generate_name ApiServiceV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the api_service. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#labels ApiServiceV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the api_service, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#name ApiServiceV1#name}
    */
    readonly name?: string;
}
export declare function apiServiceV1MetadataToTerraform(struct?: ApiServiceV1MetadataOutputReference | ApiServiceV1Metadata): any;
export declare function apiServiceV1MetadataToHclTerraform(struct?: ApiServiceV1MetadataOutputReference | ApiServiceV1Metadata): any;
export declare class ApiServiceV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiServiceV1Metadata | undefined;
    set internalValue(value: ApiServiceV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface ApiServiceV1SpecService {
    /**
    * Name is the name of the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#name ApiServiceV1#name}
    */
    readonly name: string;
    /**
    * Namespace is the namespace of the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#namespace ApiServiceV1#namespace}
    */
    readonly namespace: string;
    /**
    * If specified, the port on the service that is hosting the service. Defaults to 443 for backward compatibility. Should be a valid port number (1-65535, inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#port ApiServiceV1#port}
    */
    readonly port?: number;
}
export declare function apiServiceV1SpecServiceToTerraform(struct?: ApiServiceV1SpecServiceOutputReference | ApiServiceV1SpecService): any;
export declare function apiServiceV1SpecServiceToHclTerraform(struct?: ApiServiceV1SpecServiceOutputReference | ApiServiceV1SpecService): any;
export declare class ApiServiceV1SpecServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiServiceV1SpecService | undefined;
    set internalValue(value: ApiServiceV1SpecService | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface ApiServiceV1Spec {
    /**
    * CABundle is a PEM encoded CA bundle which will be used to validate an API server's serving certificate. If unspecified, system trust roots on the apiserver are used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#ca_bundle ApiServiceV1#ca_bundle}
    */
    readonly caBundle?: string;
    /**
    * Group is the API group name this server hosts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#group ApiServiceV1#group}
    */
    readonly group: string;
    /**
    * GroupPriorityMinimum is the priority this group should have at least. Higher priority means that the group is preferred by clients over lower priority ones. Note that other versions of this group might specify even higher GroupPriorityMininum values such that the whole group gets a higher priority. The primary sort is based on GroupPriorityMinimum, ordered highest number to lowest (20 before 10). The secondary sort is based on the alphabetical comparison of the name of the object. (v1.bar before v1.foo) We'd recommend something like: *.k8s.io (except extensions) at 18000 and PaaSes (OpenShift, Deis) are recommended to be in the 2000s.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#group_priority_minimum ApiServiceV1#group_priority_minimum}
    */
    readonly groupPriorityMinimum: number;
    /**
    * InsecureSkipTLSVerify disables TLS certificate verification when communicating with this server. This is strongly discouraged. You should use the CABundle instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#insecure_skip_tls_verify ApiServiceV1#insecure_skip_tls_verify}
    */
    readonly insecureSkipTlsVerify?: boolean | cdktn.IResolvable;
    /**
    * Version is the API version this server hosts. For example, `v1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#version ApiServiceV1#version}
    */
    readonly version: string;
    /**
    * VersionPriority controls the ordering of this API version inside of its group. Must be greater than zero. The primary sort is based on VersionPriority, ordered highest to lowest (20 before 10). Since it's inside of a group, the number can be small, probably in the 10s. In case of equal version priorities, the version string will be used to compute the order inside a group. If the version string is `kube-like`, it will sort above non `kube-like` version strings, which are ordered lexicographically. `Kube-like` versions start with a `v`, then are followed by a number (the major version), then optionally the string `alpha` or `beta` and another number (the minor version). These are sorted first by GA > `beta` > `alpha` (where GA is a version with no suffix such as `beta` or `alpha`), and then by comparing major version, then minor version. An example sorted list of versions: `v10`, `v2`, `v1`, `v11beta2`, `v10beta3`, `v3beta1`, `v12alpha1`, `v11alpha2`, `foo1`, `foo10`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#version_priority ApiServiceV1#version_priority}
    */
    readonly versionPriority: number;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#service ApiServiceV1#service}
    */
    readonly service?: ApiServiceV1SpecService;
}
export declare function apiServiceV1SpecToTerraform(struct?: ApiServiceV1SpecOutputReference | ApiServiceV1Spec): any;
export declare function apiServiceV1SpecToHclTerraform(struct?: ApiServiceV1SpecOutputReference | ApiServiceV1Spec): any;
export declare class ApiServiceV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiServiceV1Spec | undefined;
    set internalValue(value: ApiServiceV1Spec | undefined);
    private _caBundle?;
    get caBundle(): string;
    set caBundle(value: string);
    resetCaBundle(): void;
    get caBundleInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _groupPriorityMinimum?;
    get groupPriorityMinimum(): number;
    set groupPriorityMinimum(value: number);
    get groupPriorityMinimumInput(): number | undefined;
    private _insecureSkipTlsVerify?;
    get insecureSkipTlsVerify(): boolean | cdktn.IResolvable;
    set insecureSkipTlsVerify(value: boolean | cdktn.IResolvable);
    resetInsecureSkipTlsVerify(): void;
    get insecureSkipTlsVerifyInput(): boolean | cdktn.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _versionPriority?;
    get versionPriority(): number;
    set versionPriority(value: number);
    get versionPriorityInput(): number | undefined;
    private _service;
    get service(): ApiServiceV1SpecServiceOutputReference;
    putService(value: ApiServiceV1SpecService): void;
    resetService(): void;
    get serviceInput(): ApiServiceV1SpecService | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1 kubernetes_api_service_v1}
*/
export declare class ApiServiceV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_api_service_v1";
    /**
    * Generates CDKTN code for importing a ApiServiceV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiServiceV1 to import
    * @param importFromId The id of the existing ApiServiceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiServiceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/api_service_v1 kubernetes_api_service_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiServiceV1Config
    */
    constructor(scope: Construct, id: string, config: ApiServiceV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): ApiServiceV1MetadataOutputReference;
    putMetadata(value: ApiServiceV1Metadata): void;
    get metadataInput(): ApiServiceV1Metadata | undefined;
    private _spec;
    get spec(): ApiServiceV1SpecOutputReference;
    putSpec(value: ApiServiceV1Spec): void;
    get specInput(): ApiServiceV1Spec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
