/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsList;
    private _matchFields;
    get matchFields(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsList;
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined);
    private _preference;
    get preference(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceList;
    get weight(): number;
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsList;
    private _matchFields;
    get matchFields(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsList;
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined);
    private _nodeSelectorTerm;
    get nodeSelectorTerm(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermList;
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityNodeAffinity {
}
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityToTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinity): any;
export declare function dataKubernetesPodV1SpecAffinityNodeAffinityToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityNodeAffinity): any;
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityNodeAffinity | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityNodeAffinity | undefined);
    private _preferredDuringSchedulingIgnoredDuringExecution;
    get preferredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodV1SpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionList;
    private _requiredDuringSchedulingIgnoredDuringExecution;
    get requiredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodV1SpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionList;
}
export declare class DataKubernetesPodV1SpecAffinityNodeAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityNodeAffinityOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined);
    private _podAffinityTerm;
    get podAffinityTerm(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList;
    get weight(): number;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAffinity {
}
export declare function dataKubernetesPodV1SpecAffinityPodAffinityToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinity): any;
export declare function dataKubernetesPodV1SpecAffinityPodAffinityToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAffinity): any;
export declare class DataKubernetesPodV1SpecAffinityPodAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAffinity | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAffinity | undefined);
    private _preferredDuringSchedulingIgnoredDuringExecution;
    get preferredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodV1SpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionList;
    private _requiredDuringSchedulingIgnoredDuringExecution;
    get requiredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodV1SpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionList;
}
export declare class DataKubernetesPodV1SpecAffinityPodAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAffinityOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined);
    private _podAffinityTerm;
    get podAffinityTerm(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList;
    get weight(): number;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodV1SpecAffinityPodAntiAffinity {
}
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityToTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinity): any;
export declare function dataKubernetesPodV1SpecAffinityPodAntiAffinityToHclTerraform(struct?: DataKubernetesPodV1SpecAffinityPodAntiAffinity): any;
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinityPodAntiAffinity | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinityPodAntiAffinity | undefined);
    private _preferredDuringSchedulingIgnoredDuringExecution;
    get preferredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodV1SpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionList;
    private _requiredDuringSchedulingIgnoredDuringExecution;
    get requiredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodV1SpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionList;
}
export declare class DataKubernetesPodV1SpecAffinityPodAntiAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityPodAntiAffinityOutputReference;
}
export interface DataKubernetesPodV1SpecAffinity {
}
export declare function dataKubernetesPodV1SpecAffinityToTerraform(struct?: DataKubernetesPodV1SpecAffinity): any;
export declare function dataKubernetesPodV1SpecAffinityToHclTerraform(struct?: DataKubernetesPodV1SpecAffinity): any;
export declare class DataKubernetesPodV1SpecAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecAffinity | undefined;
    set internalValue(value: DataKubernetesPodV1SpecAffinity | undefined);
    private _nodeAffinity;
    get nodeAffinity(): DataKubernetesPodV1SpecAffinityNodeAffinityList;
    private _podAffinity;
    get podAffinity(): DataKubernetesPodV1SpecAffinityPodAffinityList;
    private _podAntiAffinity;
    get podAntiAffinity(): DataKubernetesPodV1SpecAffinityPodAntiAffinityList;
}
export declare class DataKubernetesPodV1SpecAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecAffinityOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRef {
}
export declare function dataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRefToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRef): any;
export declare function dataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRefToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRef): any;
export declare class DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRefOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvValueFromFieldRef {
}
export declare function dataKubernetesPodV1SpecContainerEnvValueFromFieldRefToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromFieldRef): any;
export declare function dataKubernetesPodV1SpecContainerEnvValueFromFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromFieldRef): any;
export declare class DataKubernetesPodV1SpecContainerEnvValueFromFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvValueFromFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvValueFromFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodV1SpecContainerEnvValueFromFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvValueFromFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRef {
}
export declare function dataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRefToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRef): any;
export declare function dataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRef): any;
export declare class DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRef {
}
export declare function dataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRefToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRef): any;
export declare function dataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRefToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRef): any;
export declare class DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRefOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvValueFrom {
}
export declare function dataKubernetesPodV1SpecContainerEnvValueFromToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFrom): any;
export declare function dataKubernetesPodV1SpecContainerEnvValueFromToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvValueFrom): any;
export declare class DataKubernetesPodV1SpecContainerEnvValueFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvValueFrom | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvValueFrom | undefined);
    private _configMapKeyRef;
    get configMapKeyRef(): DataKubernetesPodV1SpecContainerEnvValueFromConfigMapKeyRefList;
    private _fieldRef;
    get fieldRef(): DataKubernetesPodV1SpecContainerEnvValueFromFieldRefList;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodV1SpecContainerEnvValueFromResourceFieldRefList;
    private _secretKeyRef;
    get secretKeyRef(): DataKubernetesPodV1SpecContainerEnvValueFromSecretKeyRefList;
}
export declare class DataKubernetesPodV1SpecContainerEnvValueFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvValueFromOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnv {
}
export declare function dataKubernetesPodV1SpecContainerEnvToTerraform(struct?: DataKubernetesPodV1SpecContainerEnv): any;
export declare function dataKubernetesPodV1SpecContainerEnvToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnv): any;
export declare class DataKubernetesPodV1SpecContainerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnv | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnv | undefined);
    get name(): string;
    get value(): string;
    private _valueFrom;
    get valueFrom(): DataKubernetesPodV1SpecContainerEnvValueFromList;
}
export declare class DataKubernetesPodV1SpecContainerEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvFromConfigMapRef {
}
export declare function dataKubernetesPodV1SpecContainerEnvFromConfigMapRefToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvFromConfigMapRef): any;
export declare function dataKubernetesPodV1SpecContainerEnvFromConfigMapRefToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvFromConfigMapRef): any;
export declare class DataKubernetesPodV1SpecContainerEnvFromConfigMapRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvFromConfigMapRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvFromConfigMapRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecContainerEnvFromConfigMapRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvFromConfigMapRefOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvFromSecretRef {
}
export declare function dataKubernetesPodV1SpecContainerEnvFromSecretRefToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvFromSecretRef): any;
export declare function dataKubernetesPodV1SpecContainerEnvFromSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvFromSecretRef): any;
export declare class DataKubernetesPodV1SpecContainerEnvFromSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvFromSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvFromSecretRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecContainerEnvFromSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvFromSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecContainerEnvFrom {
}
export declare function dataKubernetesPodV1SpecContainerEnvFromToTerraform(struct?: DataKubernetesPodV1SpecContainerEnvFrom): any;
export declare function dataKubernetesPodV1SpecContainerEnvFromToHclTerraform(struct?: DataKubernetesPodV1SpecContainerEnvFrom): any;
export declare class DataKubernetesPodV1SpecContainerEnvFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerEnvFrom | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerEnvFrom | undefined);
    private _configMapRef;
    get configMapRef(): DataKubernetesPodV1SpecContainerEnvFromConfigMapRefList;
    get prefix(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecContainerEnvFromSecretRefList;
}
export declare class DataKubernetesPodV1SpecContainerEnvFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerEnvFromOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePostStartExec {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartExecToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartExec): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartExecToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartExec): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePostStartExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePostStartExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePostStartExecOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGet {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGet): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGet): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocket {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocket): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocket): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePostStart {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStart): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePostStartToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePostStart): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePostStart | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePostStart | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecContainerLifecyclePostStartExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecContainerLifecyclePostStartHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecContainerLifecyclePostStartTcpSocketList;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePostStartList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePostStartOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePreStopExec {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopExecToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopExec): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopExecToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopExec): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePreStopExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePreStopExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePreStopExecOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGet {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGet): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGet): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocket {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocket): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocket): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecyclePreStop {
}
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStop): any;
export declare function dataKubernetesPodV1SpecContainerLifecyclePreStopToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecyclePreStop): any;
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecyclePreStop | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecyclePreStop | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecContainerLifecyclePreStopExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecContainerLifecyclePreStopHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecContainerLifecyclePreStopTcpSocketList;
}
export declare class DataKubernetesPodV1SpecContainerLifecyclePreStopList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecyclePreStopOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLifecycle {
}
export declare function dataKubernetesPodV1SpecContainerLifecycleToTerraform(struct?: DataKubernetesPodV1SpecContainerLifecycle): any;
export declare function dataKubernetesPodV1SpecContainerLifecycleToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLifecycle): any;
export declare class DataKubernetesPodV1SpecContainerLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLifecycle | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLifecycle | undefined);
    private _postStart;
    get postStart(): DataKubernetesPodV1SpecContainerLifecyclePostStartList;
    private _preStop;
    get preStop(): DataKubernetesPodV1SpecContainerLifecyclePreStopList;
}
export declare class DataKubernetesPodV1SpecContainerLifecycleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLifecycleOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLivenessProbeExec {
}
export declare function dataKubernetesPodV1SpecContainerLivenessProbeExecToTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeExec): any;
export declare function dataKubernetesPodV1SpecContainerLivenessProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeExec): any;
export declare class DataKubernetesPodV1SpecContainerLivenessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLivenessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLivenessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecContainerLivenessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLivenessProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLivenessProbeGrpc {
}
export declare function dataKubernetesPodV1SpecContainerLivenessProbeGrpcToTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeGrpc): any;
export declare function dataKubernetesPodV1SpecContainerLivenessProbeGrpcToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeGrpc): any;
export declare class DataKubernetesPodV1SpecContainerLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLivenessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLivenessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodV1SpecContainerLivenessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLivenessProbeGrpcOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLivenessProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecContainerLivenessProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecContainerLivenessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecContainerLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLivenessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLivenessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecContainerLivenessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecContainerLivenessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLivenessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLivenessProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecContainerLivenessProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecContainerLivenessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecContainerLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLivenessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLivenessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecContainerLivenessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLivenessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecContainerLivenessProbe {
}
export declare function dataKubernetesPodV1SpecContainerLivenessProbeToTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbe): any;
export declare function dataKubernetesPodV1SpecContainerLivenessProbeToHclTerraform(struct?: DataKubernetesPodV1SpecContainerLivenessProbe): any;
export declare class DataKubernetesPodV1SpecContainerLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerLivenessProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerLivenessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecContainerLivenessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodV1SpecContainerLivenessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecContainerLivenessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecContainerLivenessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecContainerLivenessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerLivenessProbeOutputReference;
}
export interface DataKubernetesPodV1SpecContainerPort {
}
export declare function dataKubernetesPodV1SpecContainerPortToTerraform(struct?: DataKubernetesPodV1SpecContainerPort): any;
export declare function dataKubernetesPodV1SpecContainerPortToHclTerraform(struct?: DataKubernetesPodV1SpecContainerPort): any;
export declare class DataKubernetesPodV1SpecContainerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerPort | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerPort | undefined);
    get containerPort(): number;
    get hostIp(): string;
    get hostPort(): number;
    get name(): string;
    get protocol(): string;
}
export declare class DataKubernetesPodV1SpecContainerPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerPortOutputReference;
}
export interface DataKubernetesPodV1SpecContainerReadinessProbeExec {
}
export declare function dataKubernetesPodV1SpecContainerReadinessProbeExecToTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeExec): any;
export declare function dataKubernetesPodV1SpecContainerReadinessProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeExec): any;
export declare class DataKubernetesPodV1SpecContainerReadinessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerReadinessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerReadinessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecContainerReadinessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerReadinessProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecContainerReadinessProbeGrpc {
}
export declare function dataKubernetesPodV1SpecContainerReadinessProbeGrpcToTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeGrpc): any;
export declare function dataKubernetesPodV1SpecContainerReadinessProbeGrpcToHclTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeGrpc): any;
export declare class DataKubernetesPodV1SpecContainerReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerReadinessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerReadinessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodV1SpecContainerReadinessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerReadinessProbeGrpcOutputReference;
}
export interface DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecContainerReadinessProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecContainerReadinessProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecContainerReadinessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecContainerReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerReadinessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerReadinessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecContainerReadinessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecContainerReadinessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerReadinessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecContainerReadinessProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecContainerReadinessProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecContainerReadinessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecContainerReadinessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerReadinessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerReadinessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecContainerReadinessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerReadinessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecContainerReadinessProbe {
}
export declare function dataKubernetesPodV1SpecContainerReadinessProbeToTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbe): any;
export declare function dataKubernetesPodV1SpecContainerReadinessProbeToHclTerraform(struct?: DataKubernetesPodV1SpecContainerReadinessProbe): any;
export declare class DataKubernetesPodV1SpecContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerReadinessProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerReadinessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecContainerReadinessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodV1SpecContainerReadinessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecContainerReadinessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecContainerReadinessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecContainerReadinessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerReadinessProbeOutputReference;
}
export interface DataKubernetesPodV1SpecContainerResources {
}
export declare function dataKubernetesPodV1SpecContainerResourcesToTerraform(struct?: DataKubernetesPodV1SpecContainerResources): any;
export declare function dataKubernetesPodV1SpecContainerResourcesToHclTerraform(struct?: DataKubernetesPodV1SpecContainerResources): any;
export declare class DataKubernetesPodV1SpecContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerResources | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
    private _requests;
    get requests(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecContainerResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerResourcesOutputReference;
}
export interface DataKubernetesPodV1SpecContainerSecurityContextCapabilities {
}
export declare function dataKubernetesPodV1SpecContainerSecurityContextCapabilitiesToTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContextCapabilities): any;
export declare function dataKubernetesPodV1SpecContainerSecurityContextCapabilitiesToHclTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContextCapabilities): any;
export declare class DataKubernetesPodV1SpecContainerSecurityContextCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerSecurityContextCapabilities | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerSecurityContextCapabilities | undefined);
    get add(): string[];
    get drop(): string[];
}
export declare class DataKubernetesPodV1SpecContainerSecurityContextCapabilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerSecurityContextCapabilitiesOutputReference;
}
export interface DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodV1SpecContainerSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodV1SpecContainerSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodV1SpecContainerSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodV1SpecContainerSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecContainerSecurityContextSeccompProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodV1SpecContainerSecurityContext {
}
export declare function dataKubernetesPodV1SpecContainerSecurityContextToTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContext): any;
export declare function dataKubernetesPodV1SpecContainerSecurityContextToHclTerraform(struct?: DataKubernetesPodV1SpecContainerSecurityContext): any;
export declare class DataKubernetesPodV1SpecContainerSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerSecurityContext | undefined);
    get allowPrivilegeEscalation(): cdktn.IResolvable;
    private _capabilities;
    get capabilities(): DataKubernetesPodV1SpecContainerSecurityContextCapabilitiesList;
    get privileged(): cdktn.IResolvable;
    get readOnlyRootFilesystem(): cdktn.IResolvable;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktn.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodV1SpecContainerSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodV1SpecContainerSecurityContextSeccompProfileList;
}
export declare class DataKubernetesPodV1SpecContainerSecurityContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerSecurityContextOutputReference;
}
export interface DataKubernetesPodV1SpecContainerStartupProbeExec {
}
export declare function dataKubernetesPodV1SpecContainerStartupProbeExecToTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeExec): any;
export declare function dataKubernetesPodV1SpecContainerStartupProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeExec): any;
export declare class DataKubernetesPodV1SpecContainerStartupProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerStartupProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerStartupProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecContainerStartupProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerStartupProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecContainerStartupProbeGrpc {
}
export declare function dataKubernetesPodV1SpecContainerStartupProbeGrpcToTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeGrpc): any;
export declare function dataKubernetesPodV1SpecContainerStartupProbeGrpcToHclTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeGrpc): any;
export declare class DataKubernetesPodV1SpecContainerStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerStartupProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerStartupProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodV1SpecContainerStartupProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerStartupProbeGrpcOutputReference;
}
export interface DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecContainerStartupProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecContainerStartupProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecContainerStartupProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecContainerStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerStartupProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerStartupProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecContainerStartupProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecContainerStartupProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerStartupProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecContainerStartupProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecContainerStartupProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecContainerStartupProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecContainerStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerStartupProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerStartupProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecContainerStartupProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerStartupProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecContainerStartupProbe {
}
export declare function dataKubernetesPodV1SpecContainerStartupProbeToTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbe): any;
export declare function dataKubernetesPodV1SpecContainerStartupProbeToHclTerraform(struct?: DataKubernetesPodV1SpecContainerStartupProbe): any;
export declare class DataKubernetesPodV1SpecContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerStartupProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerStartupProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecContainerStartupProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodV1SpecContainerStartupProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecContainerStartupProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecContainerStartupProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecContainerStartupProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerStartupProbeOutputReference;
}
export interface DataKubernetesPodV1SpecContainerVolumeDevice {
}
export declare function dataKubernetesPodV1SpecContainerVolumeDeviceToTerraform(struct?: DataKubernetesPodV1SpecContainerVolumeDevice): any;
export declare function dataKubernetesPodV1SpecContainerVolumeDeviceToHclTerraform(struct?: DataKubernetesPodV1SpecContainerVolumeDevice): any;
export declare class DataKubernetesPodV1SpecContainerVolumeDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerVolumeDevice | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerVolumeDevice | undefined);
    get devicePath(): string;
    get name(): string;
}
export declare class DataKubernetesPodV1SpecContainerVolumeDeviceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerVolumeDeviceOutputReference;
}
export interface DataKubernetesPodV1SpecContainerVolumeMount {
}
export declare function dataKubernetesPodV1SpecContainerVolumeMountToTerraform(struct?: DataKubernetesPodV1SpecContainerVolumeMount): any;
export declare function dataKubernetesPodV1SpecContainerVolumeMountToHclTerraform(struct?: DataKubernetesPodV1SpecContainerVolumeMount): any;
export declare class DataKubernetesPodV1SpecContainerVolumeMountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainerVolumeMount | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainerVolumeMount | undefined);
    get mountPath(): string;
    get mountPropagation(): string;
    get name(): string;
    get readOnly(): cdktn.IResolvable;
    get subPath(): string;
    get subPathExpr(): string;
}
export declare class DataKubernetesPodV1SpecContainerVolumeMountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerVolumeMountOutputReference;
}
export interface DataKubernetesPodV1SpecContainer {
}
export declare function dataKubernetesPodV1SpecContainerToTerraform(struct?: DataKubernetesPodV1SpecContainer): any;
export declare function dataKubernetesPodV1SpecContainerToHclTerraform(struct?: DataKubernetesPodV1SpecContainer): any;
export declare class DataKubernetesPodV1SpecContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecContainer | undefined;
    set internalValue(value: DataKubernetesPodV1SpecContainer | undefined);
    get args(): string[];
    get command(): string[];
    private _env;
    get env(): DataKubernetesPodV1SpecContainerEnvList;
    private _envFrom;
    get envFrom(): DataKubernetesPodV1SpecContainerEnvFromList;
    get image(): string;
    get imagePullPolicy(): string;
    private _lifecycle;
    get lifecycle(): DataKubernetesPodV1SpecContainerLifecycleList;
    private _livenessProbe;
    get livenessProbe(): DataKubernetesPodV1SpecContainerLivenessProbeList;
    get name(): string;
    private _port;
    get port(): DataKubernetesPodV1SpecContainerPortList;
    private _readinessProbe;
    get readinessProbe(): DataKubernetesPodV1SpecContainerReadinessProbeList;
    private _resources;
    get resources(): DataKubernetesPodV1SpecContainerResourcesList;
    get restartPolicy(): string;
    private _securityContext;
    get securityContext(): DataKubernetesPodV1SpecContainerSecurityContextList;
    private _startupProbe;
    get startupProbe(): DataKubernetesPodV1SpecContainerStartupProbeList;
    get stdin(): cdktn.IResolvable;
    get stdinOnce(): cdktn.IResolvable;
    get terminationMessagePath(): string;
    get terminationMessagePolicy(): string;
    get tty(): cdktn.IResolvable;
    private _volumeDevice;
    get volumeDevice(): DataKubernetesPodV1SpecContainerVolumeDeviceList;
    private _volumeMount;
    get volumeMount(): DataKubernetesPodV1SpecContainerVolumeMountList;
    get workingDir(): string;
}
export declare class DataKubernetesPodV1SpecContainerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecContainerOutputReference;
}
export interface DataKubernetesPodV1SpecDnsConfigOption {
}
export declare function dataKubernetesPodV1SpecDnsConfigOptionToTerraform(struct?: DataKubernetesPodV1SpecDnsConfigOption): any;
export declare function dataKubernetesPodV1SpecDnsConfigOptionToHclTerraform(struct?: DataKubernetesPodV1SpecDnsConfigOption): any;
export declare class DataKubernetesPodV1SpecDnsConfigOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecDnsConfigOption | undefined;
    set internalValue(value: DataKubernetesPodV1SpecDnsConfigOption | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecDnsConfigOptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecDnsConfigOptionOutputReference;
}
export interface DataKubernetesPodV1SpecDnsConfig {
}
export declare function dataKubernetesPodV1SpecDnsConfigToTerraform(struct?: DataKubernetesPodV1SpecDnsConfig): any;
export declare function dataKubernetesPodV1SpecDnsConfigToHclTerraform(struct?: DataKubernetesPodV1SpecDnsConfig): any;
export declare class DataKubernetesPodV1SpecDnsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecDnsConfig | undefined;
    set internalValue(value: DataKubernetesPodV1SpecDnsConfig | undefined);
    get nameservers(): string[];
    private _option;
    get option(): DataKubernetesPodV1SpecDnsConfigOptionList;
    get searches(): string[];
}
export declare class DataKubernetesPodV1SpecDnsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecDnsConfigOutputReference;
}
export interface DataKubernetesPodV1SpecHostAliases {
}
export declare function dataKubernetesPodV1SpecHostAliasesToTerraform(struct?: DataKubernetesPodV1SpecHostAliases): any;
export declare function dataKubernetesPodV1SpecHostAliasesToHclTerraform(struct?: DataKubernetesPodV1SpecHostAliases): any;
export declare class DataKubernetesPodV1SpecHostAliasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecHostAliases | undefined;
    set internalValue(value: DataKubernetesPodV1SpecHostAliases | undefined);
    get hostnames(): string[];
    get ip(): string;
}
export declare class DataKubernetesPodV1SpecHostAliasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecHostAliasesOutputReference;
}
export interface DataKubernetesPodV1SpecImagePullSecrets {
}
export declare function dataKubernetesPodV1SpecImagePullSecretsToTerraform(struct?: DataKubernetesPodV1SpecImagePullSecrets): any;
export declare function dataKubernetesPodV1SpecImagePullSecretsToHclTerraform(struct?: DataKubernetesPodV1SpecImagePullSecrets): any;
export declare class DataKubernetesPodV1SpecImagePullSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecImagePullSecrets | undefined;
    set internalValue(value: DataKubernetesPodV1SpecImagePullSecrets | undefined);
    get name(): string;
}
export declare class DataKubernetesPodV1SpecImagePullSecretsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecImagePullSecretsOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRef {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRefToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRef): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRefToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRef): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRefOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRef {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromFieldRefToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRef): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRef): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRef {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRefToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRef): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRef): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRef {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRefToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRef): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRefToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRef): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRefOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvValueFrom {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFrom): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvValueFromToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvValueFrom): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvValueFrom | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvValueFrom | undefined);
    private _configMapKeyRef;
    get configMapKeyRef(): DataKubernetesPodV1SpecInitContainerEnvValueFromConfigMapKeyRefList;
    private _fieldRef;
    get fieldRef(): DataKubernetesPodV1SpecInitContainerEnvValueFromFieldRefList;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodV1SpecInitContainerEnvValueFromResourceFieldRefList;
    private _secretKeyRef;
    get secretKeyRef(): DataKubernetesPodV1SpecInitContainerEnvValueFromSecretKeyRefList;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvValueFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvValueFromOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnv {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnv): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnv): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnv | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnv | undefined);
    get name(): string;
    get value(): string;
    private _valueFrom;
    get valueFrom(): DataKubernetesPodV1SpecInitContainerEnvValueFromList;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRef {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvFromConfigMapRefToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRef): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvFromConfigMapRefToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRef): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRefOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvFromSecretRef {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvFromSecretRefToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvFromSecretRef): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvFromSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvFromSecretRef): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvFromSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvFromSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvFromSecretRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvFromSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvFromSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerEnvFrom {
}
export declare function dataKubernetesPodV1SpecInitContainerEnvFromToTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvFrom): any;
export declare function dataKubernetesPodV1SpecInitContainerEnvFromToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerEnvFrom): any;
export declare class DataKubernetesPodV1SpecInitContainerEnvFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerEnvFrom | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerEnvFrom | undefined);
    private _configMapRef;
    get configMapRef(): DataKubernetesPodV1SpecInitContainerEnvFromConfigMapRefList;
    get prefix(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecInitContainerEnvFromSecretRefList;
}
export declare class DataKubernetesPodV1SpecInitContainerEnvFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerEnvFromOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePostStartExec {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartExecToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartExec): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartExecToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartExec): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePostStartExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePostStartExecOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGet {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGet): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGet): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePostStart {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStart): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePostStartToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePostStart): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePostStart | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePostStart | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartTcpSocketList;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePostStartList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePostStartOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePreStopExec {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopExecToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopExec): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopExecToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopExec): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePreStopExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePreStopExecOutputReference;
}
