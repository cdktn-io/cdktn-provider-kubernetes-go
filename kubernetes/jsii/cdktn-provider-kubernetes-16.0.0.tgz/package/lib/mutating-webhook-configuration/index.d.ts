/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MutatingWebhookConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#id MutatingWebhookConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#metadata MutatingWebhookConfiguration#metadata}
    */
    readonly metadata: MutatingWebhookConfigurationMetadata;
    /**
    * webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#webhook MutatingWebhookConfiguration#webhook}
    */
    readonly webhook: MutatingWebhookConfigurationWebhook[] | cdktn.IResolvable;
}
export interface MutatingWebhookConfigurationMetadata {
    /**
    * An unstructured key value map stored with the mutating webhook configuration that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#annotations MutatingWebhookConfiguration#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#generate_name MutatingWebhookConfiguration#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the mutating webhook configuration. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#labels MutatingWebhookConfiguration#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the mutating webhook configuration, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#name MutatingWebhookConfiguration#name}
    */
    readonly name?: string;
}
export declare function mutatingWebhookConfigurationMetadataToTerraform(struct?: MutatingWebhookConfigurationMetadataOutputReference | MutatingWebhookConfigurationMetadata): any;
export declare function mutatingWebhookConfigurationMetadataToHclTerraform(struct?: MutatingWebhookConfigurationMetadataOutputReference | MutatingWebhookConfigurationMetadata): any;
export declare class MutatingWebhookConfigurationMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MutatingWebhookConfigurationMetadata | undefined;
    set internalValue(value: MutatingWebhookConfigurationMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface MutatingWebhookConfigurationWebhookClientConfigService {
    /**
    * `name` is the name of the service. Required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#name MutatingWebhookConfiguration#name}
    */
    readonly name: string;
    /**
    * `namespace` is the namespace of the service. Required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#namespace MutatingWebhookConfiguration#namespace}
    */
    readonly namespace: string;
    /**
    * `path` is an optional URL path which will be sent in any request to this service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#path MutatingWebhookConfiguration#path}
    */
    readonly path?: string;
    /**
    * If specified, the port on the service that hosting webhook. Default to 443 for backward compatibility. `port` should be a valid port number (1-65535, inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#port MutatingWebhookConfiguration#port}
    */
    readonly port?: number;
}
export declare function mutatingWebhookConfigurationWebhookClientConfigServiceToTerraform(struct?: MutatingWebhookConfigurationWebhookClientConfigServiceOutputReference | MutatingWebhookConfigurationWebhookClientConfigService): any;
export declare function mutatingWebhookConfigurationWebhookClientConfigServiceToHclTerraform(struct?: MutatingWebhookConfigurationWebhookClientConfigServiceOutputReference | MutatingWebhookConfigurationWebhookClientConfigService): any;
export declare class MutatingWebhookConfigurationWebhookClientConfigServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MutatingWebhookConfigurationWebhookClientConfigService | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookClientConfigService | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface MutatingWebhookConfigurationWebhookClientConfig {
    /**
    * `caBundle` is a PEM encoded CA bundle which will be used to validate the webhook's server certificate. If unspecified, system trust roots on the apiserver are used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#ca_bundle MutatingWebhookConfiguration#ca_bundle}
    */
    readonly caBundle?: string;
    /**
    * `url` gives the location of the webhook, in standard URL form (`scheme://host:port/path`). Exactly one of `url` or `service` must be specified.
    *
    * The `host` should not refer to a service running in the cluster; use the `service` field instead. The host might be resolved via external DNS in some apiservers (e.g., `kube-apiserver` cannot resolve in-cluster DNS as that would be a layering violation). `host` may also be an IP address.
    *
    * Please note that using `localhost` or `127.0.0.1` as a `host` is risky unless you take great care to run this webhook on all hosts which run an apiserver which might need to make calls to this webhook. Such installs are likely to be non-portable, i.e., not easy to turn up in a new cluster.
    *
    * The scheme must be "https"; the URL must begin with "https://".
    *
    * A path is optional, and if present may be any string permissible in a URL. You may use the path to pass an arbitrary string to the webhook, for example, a cluster identifier.
    *
    * Attempting to use a user or basic auth e.g. "user:password@" is not allowed. Fragments ("#...") and query parameters ("?...") are not allowed, either.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#url MutatingWebhookConfiguration#url}
    */
    readonly url?: string;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#service MutatingWebhookConfiguration#service}
    */
    readonly service?: MutatingWebhookConfigurationWebhookClientConfigService;
}
export declare function mutatingWebhookConfigurationWebhookClientConfigToTerraform(struct?: MutatingWebhookConfigurationWebhookClientConfigOutputReference | MutatingWebhookConfigurationWebhookClientConfig): any;
export declare function mutatingWebhookConfigurationWebhookClientConfigToHclTerraform(struct?: MutatingWebhookConfigurationWebhookClientConfigOutputReference | MutatingWebhookConfigurationWebhookClientConfig): any;
export declare class MutatingWebhookConfigurationWebhookClientConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MutatingWebhookConfigurationWebhookClientConfig | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookClientConfig | undefined);
    private _caBundle?;
    get caBundle(): string;
    set caBundle(value: string);
    resetCaBundle(): void;
    get caBundleInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _service;
    get service(): MutatingWebhookConfigurationWebhookClientConfigServiceOutputReference;
    putService(value: MutatingWebhookConfigurationWebhookClientConfigService): void;
    resetService(): void;
    get serviceInput(): MutatingWebhookConfigurationWebhookClientConfigService | undefined;
}
export interface MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#key MutatingWebhookConfiguration#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#operator MutatingWebhookConfiguration#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#values MutatingWebhookConfiguration#values}
    */
    readonly values?: string[];
}
export declare function mutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressionsToTerraform(struct?: MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function mutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressionsToHclTerraform(struct?: MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressionsOutputReference;
}
export interface MutatingWebhookConfigurationWebhookNamespaceSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#match_labels MutatingWebhookConfiguration#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#match_expressions MutatingWebhookConfiguration#match_expressions}
    */
    readonly matchExpressions?: MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function mutatingWebhookConfigurationWebhookNamespaceSelectorToTerraform(struct?: MutatingWebhookConfigurationWebhookNamespaceSelectorOutputReference | MutatingWebhookConfigurationWebhookNamespaceSelector): any;
export declare function mutatingWebhookConfigurationWebhookNamespaceSelectorToHclTerraform(struct?: MutatingWebhookConfigurationWebhookNamespaceSelectorOutputReference | MutatingWebhookConfigurationWebhookNamespaceSelector): any;
export declare class MutatingWebhookConfigurationWebhookNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MutatingWebhookConfigurationWebhookNamespaceSelector | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookNamespaceSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressionsList;
    putMatchExpressions(value: MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | MutatingWebhookConfigurationWebhookNamespaceSelectorMatchExpressions[] | undefined;
}
export interface MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#key MutatingWebhookConfiguration#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#operator MutatingWebhookConfiguration#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#values MutatingWebhookConfiguration#values}
    */
    readonly values?: string[];
}
export declare function mutatingWebhookConfigurationWebhookObjectSelectorMatchExpressionsToTerraform(struct?: MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function mutatingWebhookConfigurationWebhookObjectSelectorMatchExpressionsToHclTerraform(struct?: MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressionsOutputReference;
}
export interface MutatingWebhookConfigurationWebhookObjectSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#match_labels MutatingWebhookConfiguration#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#match_expressions MutatingWebhookConfiguration#match_expressions}
    */
    readonly matchExpressions?: MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function mutatingWebhookConfigurationWebhookObjectSelectorToTerraform(struct?: MutatingWebhookConfigurationWebhookObjectSelectorOutputReference | MutatingWebhookConfigurationWebhookObjectSelector): any;
export declare function mutatingWebhookConfigurationWebhookObjectSelectorToHclTerraform(struct?: MutatingWebhookConfigurationWebhookObjectSelectorOutputReference | MutatingWebhookConfigurationWebhookObjectSelector): any;
export declare class MutatingWebhookConfigurationWebhookObjectSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MutatingWebhookConfigurationWebhookObjectSelector | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookObjectSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressionsList;
    putMatchExpressions(value: MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | MutatingWebhookConfigurationWebhookObjectSelectorMatchExpressions[] | undefined;
}
export interface MutatingWebhookConfigurationWebhookRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#api_groups MutatingWebhookConfiguration#api_groups}
    */
    readonly apiGroups: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#api_versions MutatingWebhookConfiguration#api_versions}
    */
    readonly apiVersions: string[];
    /**
    * Operations is the operations the admission hook cares about - CREATE, UPDATE, DELETE, CONNECT or * for all of those operations and any future admission operations that are added. If '*' is present, the length of the slice must be one. Required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#operations MutatingWebhookConfiguration#operations}
    */
    readonly operations: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#resources MutatingWebhookConfiguration#resources}
    */
    readonly resources: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#scope MutatingWebhookConfiguration#scope}
    */
    readonly scope?: string;
}
export declare function mutatingWebhookConfigurationWebhookRuleToTerraform(struct?: MutatingWebhookConfigurationWebhookRule | cdktn.IResolvable): any;
export declare function mutatingWebhookConfigurationWebhookRuleToHclTerraform(struct?: MutatingWebhookConfigurationWebhookRule | cdktn.IResolvable): any;
export declare class MutatingWebhookConfigurationWebhookRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MutatingWebhookConfigurationWebhookRule | cdktn.IResolvable | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhookRule | cdktn.IResolvable | undefined);
    private _apiGroups?;
    get apiGroups(): string[];
    set apiGroups(value: string[]);
    get apiGroupsInput(): string[] | undefined;
    private _apiVersions?;
    get apiVersions(): string[];
    set apiVersions(value: string[]);
    get apiVersionsInput(): string[] | undefined;
    private _operations?;
    get operations(): string[];
    set operations(value: string[]);
    get operationsInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    get resourcesInput(): string[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
}
export declare class MutatingWebhookConfigurationWebhookRuleList extends cdktn.ComplexList {
    internalValue?: MutatingWebhookConfigurationWebhookRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MutatingWebhookConfigurationWebhookRuleOutputReference;
}
export interface MutatingWebhookConfigurationWebhook {
    /**
    * AdmissionReviewVersions is an ordered list of preferred `AdmissionReview` versions the Webhook expects. API server will try to use first version in the list which it supports. If none of the versions specified in this list supported by API server, validation will fail for this object. If a persisted webhook configuration specifies allowed versions and does not include any versions known to the API Server, calls to the webhook will fail and be subject to the failure policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#admission_review_versions MutatingWebhookConfiguration#admission_review_versions}
    */
    readonly admissionReviewVersions?: string[];
    /**
    * FailurePolicy defines how unrecognized errors from the admission endpoint are handled - allowed values are Ignore or Fail. Defaults to Fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#failure_policy MutatingWebhookConfiguration#failure_policy}
    */
    readonly failurePolicy?: string;
    /**
    * matchPolicy defines how the "rules" list is used to match incoming requests. Allowed values are "Exact" or "Equivalent".
    *
    * - Exact: match a request only if it exactly matches a specified rule. For example, if deployments can be modified via apps/v1, apps/v1beta1, and extensions/v1beta1, but "rules" only included `apiGroups:["apps"], apiVersions:["v1"], resources: ["deployments"]`, a request to apps/v1beta1 or extensions/v1beta1 would not be sent to the webhook.
    *
    * - Equivalent: match a request if modifies a resource listed in rules, even via another API group or version. For example, if deployments can be modified via apps/v1, apps/v1beta1, and extensions/v1beta1, and "rules" only included `apiGroups:["apps"], apiVersions:["v1"], resources: ["deployments"]`, a request to apps/v1beta1 or extensions/v1beta1 would be converted to apps/v1 and sent to the webhook.
    *
    * Defaults to "Equivalent"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#match_policy MutatingWebhookConfiguration#match_policy}
    */
    readonly matchPolicy?: string;
    /**
    * The name of the admission webhook. Name should be fully qualified, e.g., imagepolicy.kubernetes.io, where "imagepolicy" is the name of the webhook, and kubernetes.io is the name of the organization. Required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#name MutatingWebhookConfiguration#name}
    */
    readonly name: string;
    /**
    * reinvocationPolicy indicates whether this webhook should be called multiple times as part of a single admission evaluation. Allowed values are "Never" and "IfNeeded".
    *
    * Never: the webhook will not be called more than once in a single admission evaluation.
    *
    * IfNeeded: the webhook will be called at least one additional time as part of the admission evaluation if the object being admitted is modified by other admission plugins after the initial webhook call. Webhooks that specify this option *must* be idempotent, able to process objects they previously admitted. Note: * the number of additional invocations is not guaranteed to be exactly one. * if additional invocations result in further modifications to the object, webhooks are not guaranteed to be invoked again. * webhooks that use this option may be reordered to minimize the number of additional invocations. * to validate an object after all mutations are guaranteed complete, use a validating admission webhook instead.
    *
    * Defaults to "Never".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#reinvocation_policy MutatingWebhookConfiguration#reinvocation_policy}
    */
    readonly reinvocationPolicy?: string;
    /**
    * SideEffects states whether this webhook has side effects. Acceptable values are: None, NoneOnDryRun (webhooks created via v1beta1 may also specify Some or Unknown). Webhooks with side effects MUST implement a reconciliation system, since a request may be rejected by a future step in the admission chain and the side effects therefore need to be undone. Requests with the dryRun attribute will be auto-rejected if they match a webhook with sideEffects == Unknown or Some.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#side_effects MutatingWebhookConfiguration#side_effects}
    */
    readonly sideEffects?: string;
    /**
    * TimeoutSeconds specifies the timeout for this webhook. After the timeout passes, the webhook call will be ignored or the API call will fail based on the failure policy. The timeout value must be between 1 and 30 seconds. Default to 10 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#timeout_seconds MutatingWebhookConfiguration#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * client_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#client_config MutatingWebhookConfiguration#client_config}
    */
    readonly clientConfig: MutatingWebhookConfigurationWebhookClientConfig;
    /**
    * namespace_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#namespace_selector MutatingWebhookConfiguration#namespace_selector}
    */
    readonly namespaceSelector?: MutatingWebhookConfigurationWebhookNamespaceSelector;
    /**
    * object_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#object_selector MutatingWebhookConfiguration#object_selector}
    */
    readonly objectSelector?: MutatingWebhookConfigurationWebhookObjectSelector;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#rule MutatingWebhookConfiguration#rule}
    */
    readonly rule?: MutatingWebhookConfigurationWebhookRule[] | cdktn.IResolvable;
}
export declare function mutatingWebhookConfigurationWebhookToTerraform(struct?: MutatingWebhookConfigurationWebhook | cdktn.IResolvable): any;
export declare function mutatingWebhookConfigurationWebhookToHclTerraform(struct?: MutatingWebhookConfigurationWebhook | cdktn.IResolvable): any;
export declare class MutatingWebhookConfigurationWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MutatingWebhookConfigurationWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: MutatingWebhookConfigurationWebhook | cdktn.IResolvable | undefined);
    private _admissionReviewVersions?;
    get admissionReviewVersions(): string[];
    set admissionReviewVersions(value: string[]);
    resetAdmissionReviewVersions(): void;
    get admissionReviewVersionsInput(): string[] | undefined;
    private _failurePolicy?;
    get failurePolicy(): string;
    set failurePolicy(value: string);
    resetFailurePolicy(): void;
    get failurePolicyInput(): string | undefined;
    private _matchPolicy?;
    get matchPolicy(): string;
    set matchPolicy(value: string);
    resetMatchPolicy(): void;
    get matchPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _reinvocationPolicy?;
    get reinvocationPolicy(): string;
    set reinvocationPolicy(value: string);
    resetReinvocationPolicy(): void;
    get reinvocationPolicyInput(): string | undefined;
    private _sideEffects?;
    get sideEffects(): string;
    set sideEffects(value: string);
    resetSideEffects(): void;
    get sideEffectsInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _clientConfig;
    get clientConfig(): MutatingWebhookConfigurationWebhookClientConfigOutputReference;
    putClientConfig(value: MutatingWebhookConfigurationWebhookClientConfig): void;
    get clientConfigInput(): MutatingWebhookConfigurationWebhookClientConfig | undefined;
    private _namespaceSelector;
    get namespaceSelector(): MutatingWebhookConfigurationWebhookNamespaceSelectorOutputReference;
    putNamespaceSelector(value: MutatingWebhookConfigurationWebhookNamespaceSelector): void;
    resetNamespaceSelector(): void;
    get namespaceSelectorInput(): MutatingWebhookConfigurationWebhookNamespaceSelector | undefined;
    private _objectSelector;
    get objectSelector(): MutatingWebhookConfigurationWebhookObjectSelectorOutputReference;
    putObjectSelector(value: MutatingWebhookConfigurationWebhookObjectSelector): void;
    resetObjectSelector(): void;
    get objectSelectorInput(): MutatingWebhookConfigurationWebhookObjectSelector | undefined;
    private _rule;
    get rule(): MutatingWebhookConfigurationWebhookRuleList;
    putRule(value: MutatingWebhookConfigurationWebhookRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | MutatingWebhookConfigurationWebhookRule[] | undefined;
}
export declare class MutatingWebhookConfigurationWebhookList extends cdktn.ComplexList {
    internalValue?: MutatingWebhookConfigurationWebhook[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MutatingWebhookConfigurationWebhookOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration kubernetes_mutating_webhook_configuration}
*/
export declare class MutatingWebhookConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_mutating_webhook_configuration";
    /**
    * Generates CDKTN code for importing a MutatingWebhookConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MutatingWebhookConfiguration to import
    * @param importFromId The id of the existing MutatingWebhookConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MutatingWebhookConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/mutating_webhook_configuration kubernetes_mutating_webhook_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MutatingWebhookConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: MutatingWebhookConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): MutatingWebhookConfigurationMetadataOutputReference;
    putMetadata(value: MutatingWebhookConfigurationMetadata): void;
    get metadataInput(): MutatingWebhookConfigurationMetadata | undefined;
    private _webhook;
    get webhook(): MutatingWebhookConfigurationWebhookList;
    putWebhook(value: MutatingWebhookConfigurationWebhook[] | cdktn.IResolvable): void;
    get webhookInput(): cdktn.IResolvable | MutatingWebhookConfigurationWebhook[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
