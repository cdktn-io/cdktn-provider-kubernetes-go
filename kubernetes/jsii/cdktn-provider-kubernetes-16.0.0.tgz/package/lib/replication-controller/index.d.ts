/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { ReplicationControllerMetadata, ReplicationControllerMetadataOutputReference, ReplicationControllerSpec, ReplicationControllerSpecOutputReference, ReplicationControllerTimeouts, ReplicationControllerTimeoutsOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReplicationControllerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller#id ReplicationController#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller#metadata ReplicationController#metadata}
    */
    readonly metadata: ReplicationControllerMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller#spec ReplicationController#spec}
    */
    readonly spec: ReplicationControllerSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller#timeouts ReplicationController#timeouts}
    */
    readonly timeouts?: ReplicationControllerTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller kubernetes_replication_controller}
*/
export declare class ReplicationController extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_replication_controller";
    /**
    * Generates CDKTN code for importing a ReplicationController resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ReplicationController to import
    * @param importFromId The id of the existing ReplicationController that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ReplicationController to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/replication_controller kubernetes_replication_controller} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReplicationControllerConfig
    */
    constructor(scope: Construct, id: string, config: ReplicationControllerConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): ReplicationControllerMetadataOutputReference;
    putMetadata(value: ReplicationControllerMetadata): void;
    get metadataInput(): ReplicationControllerMetadata | undefined;
    private _spec;
    get spec(): ReplicationControllerSpecOutputReference;
    putSpec(value: ReplicationControllerSpec): void;
    get specInput(): ReplicationControllerSpec | undefined;
    private _timeouts;
    get timeouts(): ReplicationControllerTimeoutsOutputReference;
    putTimeouts(value: ReplicationControllerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ReplicationControllerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
