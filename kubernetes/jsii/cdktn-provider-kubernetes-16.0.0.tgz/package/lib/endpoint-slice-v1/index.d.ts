/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EndpointSliceV1Config extends cdktn.TerraformMetaArguments {
    /**
    * address_type specifies the type of address carried by this EndpointSlice. All addresses in this slice must be the same type. This field is immutable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#address_type EndpointSliceV1#address_type}
    */
    readonly addressType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#id EndpointSliceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#endpoint EndpointSliceV1#endpoint}
    */
    readonly endpoint: EndpointSliceV1Endpoint[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#metadata EndpointSliceV1#metadata}
    */
    readonly metadata: EndpointSliceV1Metadata;
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#port EndpointSliceV1#port}
    */
    readonly port: EndpointSliceV1Port[] | cdktn.IResolvable;
}
export interface EndpointSliceV1EndpointCondition {
    /**
    * ready indicates that this endpoint is prepared to receive traffic, according to whatever system is managing the endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#ready EndpointSliceV1#ready}
    */
    readonly ready?: boolean | cdktn.IResolvable;
    /**
    * serving is identical to ready except that it is set regardless of the terminating state of endpoints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#serving EndpointSliceV1#serving}
    */
    readonly serving?: boolean | cdktn.IResolvable;
    /**
    * terminating indicates that this endpoint is terminating.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#terminating EndpointSliceV1#terminating}
    */
    readonly terminating?: boolean | cdktn.IResolvable;
}
export declare function endpointSliceV1EndpointConditionToTerraform(struct?: EndpointSliceV1EndpointConditionOutputReference | EndpointSliceV1EndpointCondition): any;
export declare function endpointSliceV1EndpointConditionToHclTerraform(struct?: EndpointSliceV1EndpointConditionOutputReference | EndpointSliceV1EndpointCondition): any;
export declare class EndpointSliceV1EndpointConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EndpointSliceV1EndpointCondition | undefined;
    set internalValue(value: EndpointSliceV1EndpointCondition | undefined);
    private _ready?;
    get ready(): boolean | cdktn.IResolvable;
    set ready(value: boolean | cdktn.IResolvable);
    resetReady(): void;
    get readyInput(): boolean | cdktn.IResolvable | undefined;
    private _serving?;
    get serving(): boolean | cdktn.IResolvable;
    set serving(value: boolean | cdktn.IResolvable);
    resetServing(): void;
    get servingInput(): boolean | cdktn.IResolvable | undefined;
    private _terminating?;
    get terminating(): boolean | cdktn.IResolvable;
    set terminating(value: boolean | cdktn.IResolvable);
    resetTerminating(): void;
    get terminatingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface EndpointSliceV1EndpointTargetRef {
    /**
    * If referring to a piece of an object instead of an entire object, this string should contain a valid JSON/Go field access statement, such as desiredState.manifest.containers[2].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#field_path EndpointSliceV1#field_path}
    */
    readonly fieldPath?: string;
    /**
    * Name of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#name EndpointSliceV1#name}
    */
    readonly name: string;
    /**
    * Namespace of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#namespace EndpointSliceV1#namespace}
    */
    readonly namespace?: string;
    /**
    * Specific resourceVersion to which this reference is made, if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#resource_version EndpointSliceV1#resource_version}
    */
    readonly resourceVersion?: string;
    /**
    * If referring to a piece of an object instead of an entire object, this string should contain a valid JSON/Go field access statement, such as desiredState.manifest.containers[2].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#uid EndpointSliceV1#uid}
    */
    readonly uid?: string;
}
export declare function endpointSliceV1EndpointTargetRefToTerraform(struct?: EndpointSliceV1EndpointTargetRefOutputReference | EndpointSliceV1EndpointTargetRef): any;
export declare function endpointSliceV1EndpointTargetRefToHclTerraform(struct?: EndpointSliceV1EndpointTargetRefOutputReference | EndpointSliceV1EndpointTargetRef): any;
export declare class EndpointSliceV1EndpointTargetRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EndpointSliceV1EndpointTargetRef | undefined;
    set internalValue(value: EndpointSliceV1EndpointTargetRef | undefined);
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _resourceVersion?;
    get resourceVersion(): string;
    set resourceVersion(value: string);
    resetResourceVersion(): void;
    get resourceVersionInput(): string | undefined;
    private _uid?;
    get uid(): string;
    set uid(value: string);
    resetUid(): void;
    get uidInput(): string | undefined;
}
export interface EndpointSliceV1Endpoint {
    /**
    * addresses of this endpoint. The contents of this field are interpreted according to the corresponding EndpointSlice addressType field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#addresses EndpointSliceV1#addresses}
    */
    readonly addresses: string[];
    /**
    * hostname of this endpoint. This field may be used by consumers of endpoints to distinguish endpoints from each other.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#hostname EndpointSliceV1#hostname}
    */
    readonly hostname?: string;
    /**
    * nodeName represents the name of the Node hosting this endpoint. This can be used to determine endpoints local to a Node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#node_name EndpointSliceV1#node_name}
    */
    readonly nodeName?: string;
    /**
    * zone is the name of the Zone this endpoint exists in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#zone EndpointSliceV1#zone}
    */
    readonly zone?: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#condition EndpointSliceV1#condition}
    */
    readonly condition?: EndpointSliceV1EndpointCondition;
    /**
    * target_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#target_ref EndpointSliceV1#target_ref}
    */
    readonly targetRef?: EndpointSliceV1EndpointTargetRef;
}
export declare function endpointSliceV1EndpointToTerraform(struct?: EndpointSliceV1Endpoint | cdktn.IResolvable): any;
export declare function endpointSliceV1EndpointToHclTerraform(struct?: EndpointSliceV1Endpoint | cdktn.IResolvable): any;
export declare class EndpointSliceV1EndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointSliceV1Endpoint | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointSliceV1Endpoint | cdktn.IResolvable | undefined);
    private _addresses?;
    get addresses(): string[];
    set addresses(value: string[]);
    get addressesInput(): string[] | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    private _condition;
    get condition(): EndpointSliceV1EndpointConditionOutputReference;
    putCondition(value: EndpointSliceV1EndpointCondition): void;
    resetCondition(): void;
    get conditionInput(): EndpointSliceV1EndpointCondition | undefined;
    private _targetRef;
    get targetRef(): EndpointSliceV1EndpointTargetRefOutputReference;
    putTargetRef(value: EndpointSliceV1EndpointTargetRef): void;
    resetTargetRef(): void;
    get targetRefInput(): EndpointSliceV1EndpointTargetRef | undefined;
}
export declare class EndpointSliceV1EndpointList extends cdktn.ComplexList {
    internalValue?: EndpointSliceV1Endpoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointSliceV1EndpointOutputReference;
}
export interface EndpointSliceV1Metadata {
    /**
    * An unstructured key value map stored with the endpoint_slice that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#annotations EndpointSliceV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#generate_name EndpointSliceV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the endpoint_slice. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#labels EndpointSliceV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the endpoint_slice, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#name EndpointSliceV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the endpoint_slice must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#namespace EndpointSliceV1#namespace}
    */
    readonly namespace?: string;
}
export declare function endpointSliceV1MetadataToTerraform(struct?: EndpointSliceV1MetadataOutputReference | EndpointSliceV1Metadata): any;
export declare function endpointSliceV1MetadataToHclTerraform(struct?: EndpointSliceV1MetadataOutputReference | EndpointSliceV1Metadata): any;
export declare class EndpointSliceV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EndpointSliceV1Metadata | undefined;
    set internalValue(value: EndpointSliceV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface EndpointSliceV1Port {
    /**
    * The application protocol for this port. This is used as a hint for implementations to offer richer behavior for protocols that they understand.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#app_protocol EndpointSliceV1#app_protocol}
    */
    readonly appProtocol: string;
    /**
    * name represents the name of this port. All ports in an EndpointSlice must have a unique name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#name EndpointSliceV1#name}
    */
    readonly name?: string;
    /**
    * port represents the port number of the endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#port EndpointSliceV1#port}
    */
    readonly port: string;
    /**
    * protocol represents the IP protocol for this port. Must be UDP, TCP, or SCTP. Default is TCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#protocol EndpointSliceV1#protocol}
    */
    readonly protocol?: string;
}
export declare function endpointSliceV1PortToTerraform(struct?: EndpointSliceV1Port | cdktn.IResolvable): any;
export declare function endpointSliceV1PortToHclTerraform(struct?: EndpointSliceV1Port | cdktn.IResolvable): any;
export declare class EndpointSliceV1PortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointSliceV1Port | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointSliceV1Port | cdktn.IResolvable | undefined);
    private _appProtocol?;
    get appProtocol(): string;
    set appProtocol(value: string);
    get appProtocolInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class EndpointSliceV1PortList extends cdktn.ComplexList {
    internalValue?: EndpointSliceV1Port[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointSliceV1PortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1 kubernetes_endpoint_slice_v1}
*/
export declare class EndpointSliceV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_endpoint_slice_v1";
    /**
    * Generates CDKTN code for importing a EndpointSliceV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EndpointSliceV1 to import
    * @param importFromId The id of the existing EndpointSliceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EndpointSliceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/endpoint_slice_v1 kubernetes_endpoint_slice_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EndpointSliceV1Config
    */
    constructor(scope: Construct, id: string, config: EndpointSliceV1Config);
    private _addressType?;
    get addressType(): string;
    set addressType(value: string);
    get addressTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _endpoint;
    get endpoint(): EndpointSliceV1EndpointList;
    putEndpoint(value: EndpointSliceV1Endpoint[] | cdktn.IResolvable): void;
    get endpointInput(): cdktn.IResolvable | EndpointSliceV1Endpoint[] | undefined;
    private _metadata;
    get metadata(): EndpointSliceV1MetadataOutputReference;
    putMetadata(value: EndpointSliceV1Metadata): void;
    get metadataInput(): EndpointSliceV1Metadata | undefined;
    private _port;
    get port(): EndpointSliceV1PortList;
    putPort(value: EndpointSliceV1Port[] | cdktn.IResolvable): void;
    get portInput(): cdktn.IResolvable | EndpointSliceV1Port[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
