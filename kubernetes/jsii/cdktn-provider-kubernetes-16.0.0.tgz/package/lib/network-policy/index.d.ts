/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NetworkPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#id NetworkPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#metadata NetworkPolicy#metadata}
    */
    readonly metadata: NetworkPolicyMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#spec NetworkPolicy#spec}
    */
    readonly spec: NetworkPolicySpec;
}
export interface NetworkPolicyMetadata {
    /**
    * An unstructured key value map stored with the network policy that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#annotations NetworkPolicy#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#generate_name NetworkPolicy#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the network policy. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#labels NetworkPolicy#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the network policy, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#name NetworkPolicy#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the network policy must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#namespace NetworkPolicy#namespace}
    */
    readonly namespace?: string;
}
export declare function networkPolicyMetadataToTerraform(struct?: NetworkPolicyMetadataOutputReference | NetworkPolicyMetadata): any;
export declare function networkPolicyMetadataToHclTerraform(struct?: NetworkPolicyMetadataOutputReference | NetworkPolicyMetadata): any;
export declare class NetworkPolicyMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyMetadata | undefined;
    set internalValue(value: NetworkPolicyMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface NetworkPolicySpecEgressPorts {
    /**
    * endPort indicates that the range of ports from port to endPort if set, inclusive, should be allowed by the policy. This field cannot be defined if the port field is not defined or if the port field is defined as a named (string) port. The endPort must be equal or greater than port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#end_port NetworkPolicy#end_port}
    */
    readonly endPort?: number;
    /**
    * port represents the port on the given protocol. This can either be a numerical or named port on a pod. If this field is not provided, this matches all port names and numbers. If present, only traffic on the specified protocol AND port will be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#port NetworkPolicy#port}
    */
    readonly port?: string;
    /**
    * protocol represents the protocol (TCP, UDP, or SCTP) which traffic must match. If not specified, this field defaults to TCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#protocol NetworkPolicy#protocol}
    */
    readonly protocol?: string;
}
export declare function networkPolicySpecEgressPortsToTerraform(struct?: NetworkPolicySpecEgressPorts | cdktn.IResolvable): any;
export declare function networkPolicySpecEgressPortsToHclTerraform(struct?: NetworkPolicySpecEgressPorts | cdktn.IResolvable): any;
export declare class NetworkPolicySpecEgressPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecEgressPorts | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecEgressPorts | cdktn.IResolvable | undefined);
    private _endPort?;
    get endPort(): number;
    set endPort(value: number);
    resetEndPort(): void;
    get endPortInput(): number | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class NetworkPolicySpecEgressPortsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecEgressPorts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecEgressPortsOutputReference;
}
export interface NetworkPolicySpecEgressToIpBlock {
    /**
    * cidr is a string representing the IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#cidr NetworkPolicy#cidr}
    */
    readonly cidr?: string;
    /**
    * except is a slice of CIDRs that should not be included within an IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64" Except values will be rejected if they are outside the cidr range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#except NetworkPolicy#except}
    */
    readonly except?: string[];
}
export declare function networkPolicySpecEgressToIpBlockToTerraform(struct?: NetworkPolicySpecEgressToIpBlockOutputReference | NetworkPolicySpecEgressToIpBlock): any;
export declare function networkPolicySpecEgressToIpBlockToHclTerraform(struct?: NetworkPolicySpecEgressToIpBlockOutputReference | NetworkPolicySpecEgressToIpBlock): any;
export declare class NetworkPolicySpecEgressToIpBlockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecEgressToIpBlock | undefined;
    set internalValue(value: NetworkPolicySpecEgressToIpBlock | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    private _except?;
    get except(): string[];
    set except(value: string[]);
    resetExcept(): void;
    get exceptInput(): string[] | undefined;
}
export interface NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#key NetworkPolicy#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#operator NetworkPolicy#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#values NetworkPolicy#values}
    */
    readonly values?: string[];
}
export declare function networkPolicySpecEgressToNamespaceSelectorMatchExpressionsToTerraform(struct?: NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicySpecEgressToNamespaceSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicySpecEgressToNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicySpecEgressToNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecEgressToNamespaceSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicySpecEgressToNamespaceSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_labels NetworkPolicy#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_expressions NetworkPolicy#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicySpecEgressToNamespaceSelectorToTerraform(struct?: NetworkPolicySpecEgressToNamespaceSelectorOutputReference | NetworkPolicySpecEgressToNamespaceSelector): any;
export declare function networkPolicySpecEgressToNamespaceSelectorToHclTerraform(struct?: NetworkPolicySpecEgressToNamespaceSelectorOutputReference | NetworkPolicySpecEgressToNamespaceSelector): any;
export declare class NetworkPolicySpecEgressToNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecEgressToNamespaceSelector | undefined;
    set internalValue(value: NetworkPolicySpecEgressToNamespaceSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicySpecEgressToNamespaceSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicySpecEgressToNamespaceSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicySpecEgressToPodSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#key NetworkPolicy#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#operator NetworkPolicy#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#values NetworkPolicy#values}
    */
    readonly values?: string[];
}
export declare function networkPolicySpecEgressToPodSelectorMatchExpressionsToTerraform(struct?: NetworkPolicySpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicySpecEgressToPodSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicySpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicySpecEgressToPodSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicySpecEgressToPodSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecEgressToPodSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecEgressToPodSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicySpecEgressToPodSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_labels NetworkPolicy#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_expressions NetworkPolicy#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicySpecEgressToPodSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicySpecEgressToPodSelectorToTerraform(struct?: NetworkPolicySpecEgressToPodSelectorOutputReference | NetworkPolicySpecEgressToPodSelector): any;
export declare function networkPolicySpecEgressToPodSelectorToHclTerraform(struct?: NetworkPolicySpecEgressToPodSelectorOutputReference | NetworkPolicySpecEgressToPodSelector): any;
export declare class NetworkPolicySpecEgressToPodSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecEgressToPodSelector | undefined;
    set internalValue(value: NetworkPolicySpecEgressToPodSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicySpecEgressToPodSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicySpecEgressToPodSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicySpecEgressToPodSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicySpecEgressTo {
    /**
    * ip_block block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#ip_block NetworkPolicy#ip_block}
    */
    readonly ipBlock?: NetworkPolicySpecEgressToIpBlock;
    /**
    * namespace_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#namespace_selector NetworkPolicy#namespace_selector}
    */
    readonly namespaceSelector?: NetworkPolicySpecEgressToNamespaceSelector;
    /**
    * pod_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#pod_selector NetworkPolicy#pod_selector}
    */
    readonly podSelector?: NetworkPolicySpecEgressToPodSelector;
}
export declare function networkPolicySpecEgressToToTerraform(struct?: NetworkPolicySpecEgressTo | cdktn.IResolvable): any;
export declare function networkPolicySpecEgressToToHclTerraform(struct?: NetworkPolicySpecEgressTo | cdktn.IResolvable): any;
export declare class NetworkPolicySpecEgressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecEgressTo | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecEgressTo | cdktn.IResolvable | undefined);
    private _ipBlock;
    get ipBlock(): NetworkPolicySpecEgressToIpBlockOutputReference;
    putIpBlock(value: NetworkPolicySpecEgressToIpBlock): void;
    resetIpBlock(): void;
    get ipBlockInput(): NetworkPolicySpecEgressToIpBlock | undefined;
    private _namespaceSelector;
    get namespaceSelector(): NetworkPolicySpecEgressToNamespaceSelectorOutputReference;
    putNamespaceSelector(value: NetworkPolicySpecEgressToNamespaceSelector): void;
    resetNamespaceSelector(): void;
    get namespaceSelectorInput(): NetworkPolicySpecEgressToNamespaceSelector | undefined;
    private _podSelector;
    get podSelector(): NetworkPolicySpecEgressToPodSelectorOutputReference;
    putPodSelector(value: NetworkPolicySpecEgressToPodSelector): void;
    resetPodSelector(): void;
    get podSelectorInput(): NetworkPolicySpecEgressToPodSelector | undefined;
}
export declare class NetworkPolicySpecEgressToList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecEgressTo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecEgressToOutputReference;
}
export interface NetworkPolicySpecEgress {
    /**
    * ports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#ports NetworkPolicy#ports}
    */
    readonly ports?: NetworkPolicySpecEgressPorts[] | cdktn.IResolvable;
    /**
    * to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#to NetworkPolicy#to}
    */
    readonly to?: NetworkPolicySpecEgressTo[] | cdktn.IResolvable;
}
export declare function networkPolicySpecEgressToTerraform(struct?: NetworkPolicySpecEgress | cdktn.IResolvable): any;
export declare function networkPolicySpecEgressToHclTerraform(struct?: NetworkPolicySpecEgress | cdktn.IResolvable): any;
export declare class NetworkPolicySpecEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecEgress | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecEgress | cdktn.IResolvable | undefined);
    private _ports;
    get ports(): NetworkPolicySpecEgressPortsList;
    putPorts(value: NetworkPolicySpecEgressPorts[] | cdktn.IResolvable): void;
    resetPorts(): void;
    get portsInput(): cdktn.IResolvable | NetworkPolicySpecEgressPorts[] | undefined;
    private _to;
    get to(): NetworkPolicySpecEgressToList;
    putTo(value: NetworkPolicySpecEgressTo[] | cdktn.IResolvable): void;
    resetTo(): void;
    get toInput(): cdktn.IResolvable | NetworkPolicySpecEgressTo[] | undefined;
}
export declare class NetworkPolicySpecEgressList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecEgress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecEgressOutputReference;
}
export interface NetworkPolicySpecIngressFromIpBlock {
    /**
    * cidr is a string representing the IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#cidr NetworkPolicy#cidr}
    */
    readonly cidr?: string;
    /**
    * except is a slice of CIDRs that should not be included within an IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64" Except values will be rejected if they are outside the cidr range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#except NetworkPolicy#except}
    */
    readonly except?: string[];
}
export declare function networkPolicySpecIngressFromIpBlockToTerraform(struct?: NetworkPolicySpecIngressFromIpBlockOutputReference | NetworkPolicySpecIngressFromIpBlock): any;
export declare function networkPolicySpecIngressFromIpBlockToHclTerraform(struct?: NetworkPolicySpecIngressFromIpBlockOutputReference | NetworkPolicySpecIngressFromIpBlock): any;
export declare class NetworkPolicySpecIngressFromIpBlockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecIngressFromIpBlock | undefined;
    set internalValue(value: NetworkPolicySpecIngressFromIpBlock | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    private _except?;
    get except(): string[];
    set except(value: string[]);
    resetExcept(): void;
    get exceptInput(): string[] | undefined;
}
export interface NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#key NetworkPolicy#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#operator NetworkPolicy#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#values NetworkPolicy#values}
    */
    readonly values?: string[];
}
export declare function networkPolicySpecIngressFromNamespaceSelectorMatchExpressionsToTerraform(struct?: NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicySpecIngressFromNamespaceSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicySpecIngressFromNamespaceSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_labels NetworkPolicy#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_expressions NetworkPolicy#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicySpecIngressFromNamespaceSelectorToTerraform(struct?: NetworkPolicySpecIngressFromNamespaceSelectorOutputReference | NetworkPolicySpecIngressFromNamespaceSelector): any;
export declare function networkPolicySpecIngressFromNamespaceSelectorToHclTerraform(struct?: NetworkPolicySpecIngressFromNamespaceSelectorOutputReference | NetworkPolicySpecIngressFromNamespaceSelector): any;
export declare class NetworkPolicySpecIngressFromNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecIngressFromNamespaceSelector | undefined;
    set internalValue(value: NetworkPolicySpecIngressFromNamespaceSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicySpecIngressFromNamespaceSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicySpecIngressFromPodSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#key NetworkPolicy#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#operator NetworkPolicy#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#values NetworkPolicy#values}
    */
    readonly values?: string[];
}
export declare function networkPolicySpecIngressFromPodSelectorMatchExpressionsToTerraform(struct?: NetworkPolicySpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicySpecIngressFromPodSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicySpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicySpecIngressFromPodSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicySpecIngressFromPodSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecIngressFromPodSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecIngressFromPodSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicySpecIngressFromPodSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_labels NetworkPolicy#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_expressions NetworkPolicy#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicySpecIngressFromPodSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicySpecIngressFromPodSelectorToTerraform(struct?: NetworkPolicySpecIngressFromPodSelectorOutputReference | NetworkPolicySpecIngressFromPodSelector): any;
export declare function networkPolicySpecIngressFromPodSelectorToHclTerraform(struct?: NetworkPolicySpecIngressFromPodSelectorOutputReference | NetworkPolicySpecIngressFromPodSelector): any;
export declare class NetworkPolicySpecIngressFromPodSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecIngressFromPodSelector | undefined;
    set internalValue(value: NetworkPolicySpecIngressFromPodSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicySpecIngressFromPodSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicySpecIngressFromPodSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicySpecIngressFromPodSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicySpecIngressFrom {
    /**
    * ip_block block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#ip_block NetworkPolicy#ip_block}
    */
    readonly ipBlock?: NetworkPolicySpecIngressFromIpBlock;
    /**
    * namespace_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#namespace_selector NetworkPolicy#namespace_selector}
    */
    readonly namespaceSelector?: NetworkPolicySpecIngressFromNamespaceSelector;
    /**
    * pod_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#pod_selector NetworkPolicy#pod_selector}
    */
    readonly podSelector?: NetworkPolicySpecIngressFromPodSelector;
}
export declare function networkPolicySpecIngressFromToTerraform(struct?: NetworkPolicySpecIngressFrom | cdktn.IResolvable): any;
export declare function networkPolicySpecIngressFromToHclTerraform(struct?: NetworkPolicySpecIngressFrom | cdktn.IResolvable): any;
export declare class NetworkPolicySpecIngressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecIngressFrom | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecIngressFrom | cdktn.IResolvable | undefined);
    private _ipBlock;
    get ipBlock(): NetworkPolicySpecIngressFromIpBlockOutputReference;
    putIpBlock(value: NetworkPolicySpecIngressFromIpBlock): void;
    resetIpBlock(): void;
    get ipBlockInput(): NetworkPolicySpecIngressFromIpBlock | undefined;
    private _namespaceSelector;
    get namespaceSelector(): NetworkPolicySpecIngressFromNamespaceSelectorOutputReference;
    putNamespaceSelector(value: NetworkPolicySpecIngressFromNamespaceSelector): void;
    resetNamespaceSelector(): void;
    get namespaceSelectorInput(): NetworkPolicySpecIngressFromNamespaceSelector | undefined;
    private _podSelector;
    get podSelector(): NetworkPolicySpecIngressFromPodSelectorOutputReference;
    putPodSelector(value: NetworkPolicySpecIngressFromPodSelector): void;
    resetPodSelector(): void;
    get podSelectorInput(): NetworkPolicySpecIngressFromPodSelector | undefined;
}
export declare class NetworkPolicySpecIngressFromList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecIngressFrom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecIngressFromOutputReference;
}
export interface NetworkPolicySpecIngressPorts {
    /**
    * endPort indicates that the range of ports from port to endPort if set, inclusive, should be allowed by the policy. This field cannot be defined if the port field is not defined or if the port field is defined as a named (string) port. The endPort must be equal or greater than port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#end_port NetworkPolicy#end_port}
    */
    readonly endPort?: number;
    /**
    * port represents the port on the given protocol. This can either be a numerical or named port on a pod. If this field is not provided, this matches all port names and numbers. If present, only traffic on the specified protocol AND port will be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#port NetworkPolicy#port}
    */
    readonly port?: string;
    /**
    * protocol represents the protocol (TCP, UDP, or SCTP) which traffic must match. If not specified, this field defaults to TCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#protocol NetworkPolicy#protocol}
    */
    readonly protocol?: string;
}
export declare function networkPolicySpecIngressPortsToTerraform(struct?: NetworkPolicySpecIngressPorts | cdktn.IResolvable): any;
export declare function networkPolicySpecIngressPortsToHclTerraform(struct?: NetworkPolicySpecIngressPorts | cdktn.IResolvable): any;
export declare class NetworkPolicySpecIngressPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecIngressPorts | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecIngressPorts | cdktn.IResolvable | undefined);
    private _endPort?;
    get endPort(): number;
    set endPort(value: number);
    resetEndPort(): void;
    get endPortInput(): number | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class NetworkPolicySpecIngressPortsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecIngressPorts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecIngressPortsOutputReference;
}
export interface NetworkPolicySpecIngress {
    /**
    * from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#from NetworkPolicy#from}
    */
    readonly from?: NetworkPolicySpecIngressFrom[] | cdktn.IResolvable;
    /**
    * ports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#ports NetworkPolicy#ports}
    */
    readonly ports?: NetworkPolicySpecIngressPorts[] | cdktn.IResolvable;
}
export declare function networkPolicySpecIngressToTerraform(struct?: NetworkPolicySpecIngress | cdktn.IResolvable): any;
export declare function networkPolicySpecIngressToHclTerraform(struct?: NetworkPolicySpecIngress | cdktn.IResolvable): any;
export declare class NetworkPolicySpecIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecIngress | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecIngress | cdktn.IResolvable | undefined);
    private _from;
    get from(): NetworkPolicySpecIngressFromList;
    putFrom(value: NetworkPolicySpecIngressFrom[] | cdktn.IResolvable): void;
    resetFrom(): void;
    get fromInput(): cdktn.IResolvable | NetworkPolicySpecIngressFrom[] | undefined;
    private _ports;
    get ports(): NetworkPolicySpecIngressPortsList;
    putPorts(value: NetworkPolicySpecIngressPorts[] | cdktn.IResolvable): void;
    resetPorts(): void;
    get portsInput(): cdktn.IResolvable | NetworkPolicySpecIngressPorts[] | undefined;
}
export declare class NetworkPolicySpecIngressList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecIngress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecIngressOutputReference;
}
export interface NetworkPolicySpecPodSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#key NetworkPolicy#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#operator NetworkPolicy#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#values NetworkPolicy#values}
    */
    readonly values?: string[];
}
export declare function networkPolicySpecPodSelectorMatchExpressionsToTerraform(struct?: NetworkPolicySpecPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicySpecPodSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicySpecPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicySpecPodSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicySpecPodSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicySpecPodSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicySpecPodSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicySpecPodSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicySpecPodSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicySpecPodSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_labels NetworkPolicy#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#match_expressions NetworkPolicy#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicySpecPodSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicySpecPodSelectorToTerraform(struct?: NetworkPolicySpecPodSelectorOutputReference | NetworkPolicySpecPodSelector): any;
export declare function networkPolicySpecPodSelectorToHclTerraform(struct?: NetworkPolicySpecPodSelectorOutputReference | NetworkPolicySpecPodSelector): any;
export declare class NetworkPolicySpecPodSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpecPodSelector | undefined;
    set internalValue(value: NetworkPolicySpecPodSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicySpecPodSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicySpecPodSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicySpecPodSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicySpec {
    /**
    * policyTypes is a list of rule types that the NetworkPolicy relates to. Valid options are ["Ingress"], ["Egress"], or ["Ingress", "Egress"]. If this field is not specified, it will default based on the existence of ingress or egress rules; policies that contain an egress section are assumed to affect egress, and all policies (whether or not they contain an ingress section) are assumed to affect ingress. If you want to write an egress-only policy, you must explicitly specify policyTypes [ "Egress" ]. Likewise, if you want to write a policy that specifies that no egress is allowed, you must specify a policyTypes value that include "Egress" (since such a policy would not include an egress section and would otherwise default to just [ "Ingress" ]). This field is beta-level in 1.8
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#policy_types NetworkPolicy#policy_types}
    */
    readonly policyTypes: string[];
    /**
    * egress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#egress NetworkPolicy#egress}
    */
    readonly egress?: NetworkPolicySpecEgress[] | cdktn.IResolvable;
    /**
    * ingress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#ingress NetworkPolicy#ingress}
    */
    readonly ingress?: NetworkPolicySpecIngress[] | cdktn.IResolvable;
    /**
    * pod_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#pod_selector NetworkPolicy#pod_selector}
    */
    readonly podSelector: NetworkPolicySpecPodSelector;
}
export declare function networkPolicySpecToTerraform(struct?: NetworkPolicySpecOutputReference | NetworkPolicySpec): any;
export declare function networkPolicySpecToHclTerraform(struct?: NetworkPolicySpecOutputReference | NetworkPolicySpec): any;
export declare class NetworkPolicySpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicySpec | undefined;
    set internalValue(value: NetworkPolicySpec | undefined);
    private _policyTypes?;
    get policyTypes(): string[];
    set policyTypes(value: string[]);
    get policyTypesInput(): string[] | undefined;
    private _egress;
    get egress(): NetworkPolicySpecEgressList;
    putEgress(value: NetworkPolicySpecEgress[] | cdktn.IResolvable): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | NetworkPolicySpecEgress[] | undefined;
    private _ingress;
    get ingress(): NetworkPolicySpecIngressList;
    putIngress(value: NetworkPolicySpecIngress[] | cdktn.IResolvable): void;
    resetIngress(): void;
    get ingressInput(): cdktn.IResolvable | NetworkPolicySpecIngress[] | undefined;
    private _podSelector;
    get podSelector(): NetworkPolicySpecPodSelectorOutputReference;
    putPodSelector(value: NetworkPolicySpecPodSelector): void;
    get podSelectorInput(): NetworkPolicySpecPodSelector | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy kubernetes_network_policy}
*/
export declare class NetworkPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_network_policy";
    /**
    * Generates CDKTN code for importing a NetworkPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkPolicy to import
    * @param importFromId The id of the existing NetworkPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/network_policy kubernetes_network_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkPolicyConfig
    */
    constructor(scope: Construct, id: string, config: NetworkPolicyConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): NetworkPolicyMetadataOutputReference;
    putMetadata(value: NetworkPolicyMetadata): void;
    get metadataInput(): NetworkPolicyMetadata | undefined;
    private _spec;
    get spec(): NetworkPolicySpecOutputReference;
    putSpec(value: NetworkPolicySpec): void;
    get specInput(): NetworkPolicySpec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
