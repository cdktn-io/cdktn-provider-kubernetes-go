/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { JobMetadata, JobMetadataOutputReference, JobSpec, JobSpecOutputReference, JobTimeouts, JobTimeoutsOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface JobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job#wait_for_completion Job#wait_for_completion}
    */
    readonly waitForCompletion?: boolean | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job#metadata Job#metadata}
    */
    readonly metadata: JobMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job#spec Job#spec}
    */
    readonly spec: JobSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job#timeouts Job#timeouts}
    */
    readonly timeouts?: JobTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job kubernetes_job}
*/
export declare class Job extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_job";
    /**
    * Generates CDKTN code for importing a Job resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Job to import
    * @param importFromId The id of the existing Job that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Job to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/job kubernetes_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options JobConfig
    */
    constructor(scope: Construct, id: string, config: JobConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _waitForCompletion?;
    get waitForCompletion(): boolean | cdktn.IResolvable;
    set waitForCompletion(value: boolean | cdktn.IResolvable);
    resetWaitForCompletion(): void;
    get waitForCompletionInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): JobMetadataOutputReference;
    putMetadata(value: JobMetadata): void;
    get metadataInput(): JobMetadata | undefined;
    private _spec;
    get spec(): JobSpecOutputReference;
    putSpec(value: JobSpec): void;
    get specInput(): JobSpec | undefined;
    private _timeouts;
    get timeouts(): JobTimeoutsOutputReference;
    putTimeouts(value: JobTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | JobTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
