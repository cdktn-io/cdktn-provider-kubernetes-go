/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ValidatingAdmissionPolicyV1Config extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID for this terraform resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#id ValidatingAdmissionPolicyV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Standard object's metadata. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#metadata ValidatingAdmissionPolicyV1#metadata}
    */
    readonly metadata?: ValidatingAdmissionPolicyV1Metadata;
    /**
    * Rule defining a set of permissions for the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#spec ValidatingAdmissionPolicyV1#spec}
    */
    readonly spec: ValidatingAdmissionPolicyV1Spec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#timeouts ValidatingAdmissionPolicyV1#timeouts}
    */
    readonly timeouts?: ValidatingAdmissionPolicyV1Timeouts;
}
export interface ValidatingAdmissionPolicyV1Metadata {
    /**
    * Annotations is an unstructured key value map stored with a resource that may be set by external tools to store and retrieve arbitrary metadata. They are not queryable and should be preserved when modifying objects. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#annotations ValidatingAdmissionPolicyV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * GenerateName is an optional prefix, used by the server, to generate a unique name ONLY IF the Name field has not been provided. If this field is used, the name returned to the client will be different than the name passed. This value will also be combined with a unique suffix. The provided value has the same validation rules as the Name field, and may be truncated by the length of the suffix required to make the value unique on the server.
    * If this field is specified and the generated name exists, the server will return a 409.
    * Applied only if Name is not specified. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#generate_name ValidatingAdmissionPolicyV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * A sequence number representing a specific generation of the desired state. Populated by the system. Read-only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#generation ValidatingAdmissionPolicyV1#generation}
    */
    readonly generation?: number;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) objects. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#labels ValidatingAdmissionPolicyV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name must be unique within a namespace. Is required when creating resources, although some resources may allow a client to request the generation of an appropriate name automatically. Name is primarily intended for creation idempotence and configuration definition. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#name ValidatingAdmissionPolicyV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which each name must be unique. An empty namespace is equivalent to the "default" namespace, but "default" is the canonical representation. Not all objects are required to be scoped to a namespace - the value of this field for those objects will be empty.
    * Must be a DNS_LABEL. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#namespace ValidatingAdmissionPolicyV1#namespace}
    */
    readonly namespace?: string;
    /**
    * An opaque value that represents the internal version of this object that can be used by clients to determine when objects have changed. May be used for optimistic concurrency, change detection, and the watch operation on a resource or set of resources. Clients must treat these values as opaque and passed unmodified back to the server. They may only be valid for a particular resource or set of resources.
    * Populated by the system. Read-only. Value must be treated as opaque by clients and . More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#concurrency-control-and-consistency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#resource_version ValidatingAdmissionPolicyV1#resource_version}
    */
    readonly resourceVersion?: string;
    /**
    * UID is the unique in time and space value for this object. It is typically generated by the server on successful creation of a resource and is not allowed to change on PUT operations.
    * Populated by the system. Read-only. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names#uids
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#uid ValidatingAdmissionPolicyV1#uid}
    */
    readonly uid?: string;
}
export declare function validatingAdmissionPolicyV1MetadataToTerraform(struct?: ValidatingAdmissionPolicyV1Metadata | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1MetadataToHclTerraform(struct?: ValidatingAdmissionPolicyV1Metadata | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1Metadata | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1Metadata | cdktn.IResolvable | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    private _generation?;
    get generation(): number;
    set generation(value: number);
    resetGeneration(): void;
    get generationInput(): number | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _resourceVersion?;
    get resourceVersion(): string;
    set resourceVersion(value: string);
    resetResourceVersion(): void;
    get resourceVersionInput(): string | undefined;
    private _uid?;
    get uid(): string;
    set uid(value: string);
    resetUid(): void;
    get uidInput(): string | undefined;
}
export interface ValidatingAdmissionPolicyV1SpecAuditAnnotations {
    /**
    * key specifies the audit annotation key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#key ValidatingAdmissionPolicyV1#key}
    */
    readonly key: string;
    /**
    * valueExpression represents the expression which is evaluated by CEL to produce an audit annotation value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#value_expression ValidatingAdmissionPolicyV1#value_expression}
    */
    readonly valueExpression: string;
}
export declare function validatingAdmissionPolicyV1SpecAuditAnnotationsToTerraform(struct?: ValidatingAdmissionPolicyV1SpecAuditAnnotations | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecAuditAnnotationsToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecAuditAnnotations | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecAuditAnnotationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecAuditAnnotations | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecAuditAnnotations | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _valueExpression?;
    get valueExpression(): string;
    set valueExpression(value: string);
    get valueExpressionInput(): string | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecAuditAnnotationsList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecAuditAnnotations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecAuditAnnotationsOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConditions {
    /**
    * Expression represents the expression which will be evaluated by CEL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#expression ValidatingAdmissionPolicyV1#expression}
    */
    readonly expression: string;
    /**
    * Name is an identifier for this match condition, used for strategic merging of MatchConditions, as well as providing an identifier for logging purposes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#name ValidatingAdmissionPolicyV1#name}
    */
    readonly name: string;
}
export declare function validatingAdmissionPolicyV1SpecMatchConditionsToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConditions | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConditionsToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConditions | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConditions | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConditions | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecMatchConditionsList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecMatchConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecMatchConditionsOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules {
    /**
    * APIGroups is the API groups the resources belong to. '\*' is all groups. If '\*' is present, the length of the slice must be one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#api_groups ValidatingAdmissionPolicyV1#api_groups}
    */
    readonly apiGroups: string[];
    /**
    * APIVersions is the API versions the resources belong to. '\*' is all versions. If '\*' is present, the length of the slice must be one. Required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#api_versions ValidatingAdmissionPolicyV1#api_versions}
    */
    readonly apiVersions: string[];
    /**
    * Operations is the operations the admission hook cares about - CREATE, UPDATE, DELETE, CONNECT or * for all of those operations and any future admission operations that are added.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#operations ValidatingAdmissionPolicyV1#operations}
    */
    readonly operations: string[];
    /**
    * ResourceNames is an optional white list of names that the rule applies to. An empty set means that everything is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#resource_names ValidatingAdmissionPolicyV1#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * Resources is a list of resources this rule applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#resources ValidatingAdmissionPolicyV1#resources}
    */
    readonly resources: string[];
    /**
    * scope specifies the scope of this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#scope ValidatingAdmissionPolicyV1#scope}
    */
    readonly scope?: string;
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRulesToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRulesToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules | cdktn.IResolvable | undefined);
    private _apiGroups?;
    get apiGroups(): string[];
    set apiGroups(value: string[]);
    get apiGroupsInput(): string[] | undefined;
    private _apiVersions?;
    get apiVersions(): string[];
    set apiVersions(value: string[]);
    get apiVersionsInput(): string[] | undefined;
    private _operations?;
    get operations(): string[];
    set operations(value: string[]);
    get operationsInput(): string[] | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    get resourcesInput(): string[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRulesList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRulesOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions {
    /**
    * key is the label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#key ValidatingAdmissionPolicyV1#key}
    */
    readonly key?: string;
    /**
    * operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#operator ValidatingAdmissionPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#values ValidatingAdmissionPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressionsToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressionsToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressionsOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector {
    /**
    * matchExpressions is a list of label selector requirements. The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_expressions ValidatingAdmissionPolicyV1#match_expressions}
    */
    readonly matchExpressions?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * matchLabels is a map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of matchExpressions, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_labels ValidatingAdmissionPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector | cdktn.IResolvable | undefined);
    private _matchExpressions;
    get matchExpressions(): ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressionsList;
    putMatchExpressions(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorMatchExpressions[] | undefined;
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions {
    /**
    * key is the label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#key ValidatingAdmissionPolicyV1#key}
    */
    readonly key?: string;
    /**
    * operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#operator ValidatingAdmissionPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#values ValidatingAdmissionPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressionsToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressionsToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressionsOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector {
    /**
    * matchExpressions is a list of label selector requirements. The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_expressions ValidatingAdmissionPolicyV1#match_expressions}
    */
    readonly matchExpressions?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * matchLabels is a map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of matchExpressions, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_labels ValidatingAdmissionPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector | cdktn.IResolvable | undefined);
    private _matchExpressions;
    get matchExpressions(): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressionsList;
    putMatchExpressions(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorMatchExpressions[] | undefined;
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector {
    /**
    * A label query over a set of resources
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#label_selector ValidatingAdmissionPolicyV1#label_selector}
    */
    readonly labelSelector?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector;
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector | cdktn.IResolvable | undefined);
    private _labelSelector;
    get labelSelector(): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelectorOutputReference;
    putLabelSelector(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector): void;
    resetLabelSelector(): void;
    get labelSelectorInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorLabelSelector | undefined;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules {
    /**
    * APIGroups is the API groups the resources belong to. '\*' is all groups. If '\*' is present, the length of the slice must be one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#api_groups ValidatingAdmissionPolicyV1#api_groups}
    */
    readonly apiGroups: string[];
    /**
    * APIVersions is the API versions the resources belong to. '\*' is all versions. If '\*' is present, the length of the slice must be one. Required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#api_versions ValidatingAdmissionPolicyV1#api_versions}
    */
    readonly apiVersions: string[];
    /**
    * Operations is the operations the admission hook cares about - CREATE, UPDATE, DELETE, CONNECT or * for all of those operations and any future admission operations that are added.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#operations ValidatingAdmissionPolicyV1#operations}
    */
    readonly operations: string[];
    /**
    * ResourceNames is an optional white list of names that the rule applies to. An empty set means that everything is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#resource_names ValidatingAdmissionPolicyV1#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * Resources is a list of resources this rule applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#resources ValidatingAdmissionPolicyV1#resources}
    */
    readonly resources: string[];
    /**
    * scope specifies the scope of this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#scope ValidatingAdmissionPolicyV1#scope}
    */
    readonly scope?: string;
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsResourceRulesToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsResourceRulesToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules | cdktn.IResolvable | undefined);
    private _apiGroups?;
    get apiGroups(): string[];
    set apiGroups(value: string[]);
    get apiGroupsInput(): string[] | undefined;
    private _apiVersions?;
    get apiVersions(): string[];
    set apiVersions(value: string[]);
    get apiVersionsInput(): string[] | undefined;
    private _operations?;
    get operations(): string[];
    set operations(value: string[]);
    get operationsInput(): string[] | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    get resourcesInput(): string[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRulesList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRulesOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecMatchConstraints {
    /**
    * ExcludeResourceRules describes what operations on what resources/subresources the ValidatingAdmissionPolicy should not care about.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#exclude_resource_rules ValidatingAdmissionPolicyV1#exclude_resource_rules}
    */
    readonly excludeResourceRules?: ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules[] | cdktn.IResolvable;
    /**
    * matchPolicy defines how the MatchResources list is used to match incoming requests. Allowed values are Exact or Equivalent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_policy ValidatingAdmissionPolicyV1#match_policy}
    */
    readonly matchPolicy?: string;
    /**
    * NamespaceSelector decides whether to run the admission control policy on an object based on whether the namespace for that object matches the selector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#namespace_selector ValidatingAdmissionPolicyV1#namespace_selector}
    */
    readonly namespaceSelector?: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector;
    /**
    * ObjectSelector decides whether to run the validation based on if the object has matching labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#object_selector ValidatingAdmissionPolicyV1#object_selector}
    */
    readonly objectSelector?: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector;
    /**
    * ResourceRules describes what operations on what resources/subresources the ValidatingAdmissionPolicy matches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#resource_rules ValidatingAdmissionPolicyV1#resource_rules}
    */
    readonly resourceRules?: ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules[] | cdktn.IResolvable;
}
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsToTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraints | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecMatchConstraintsToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecMatchConstraints | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecMatchConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1SpecMatchConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecMatchConstraints | cdktn.IResolvable | undefined);
    private _excludeResourceRules;
    get excludeResourceRules(): ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRulesList;
    putExcludeResourceRules(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules[] | cdktn.IResolvable): void;
    resetExcludeResourceRules(): void;
    get excludeResourceRulesInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsExcludeResourceRules[] | undefined;
    private _matchPolicy?;
    get matchPolicy(): string;
    set matchPolicy(value: string);
    resetMatchPolicy(): void;
    get matchPolicyInput(): string | undefined;
    private _namespaceSelector;
    get namespaceSelector(): ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelectorOutputReference;
    putNamespaceSelector(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector): void;
    resetNamespaceSelector(): void;
    get namespaceSelectorInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsNamespaceSelector | undefined;
    private _objectSelector;
    get objectSelector(): ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelectorOutputReference;
    putObjectSelector(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector): void;
    resetObjectSelector(): void;
    get objectSelectorInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsObjectSelector | undefined;
    private _resourceRules;
    get resourceRules(): ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRulesList;
    putResourceRules(value: ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules[] | cdktn.IResolvable): void;
    resetResourceRules(): void;
    get resourceRulesInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraintsResourceRules[] | undefined;
}
export interface ValidatingAdmissionPolicyV1SpecParamKind {
    /**
    * APIVersion is the API group version the resources belong to. In format of "group/version"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#api_version ValidatingAdmissionPolicyV1#api_version}
    */
    readonly apiVersion: string;
    /**
    * Kind is the API kind the resources belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#kind ValidatingAdmissionPolicyV1#kind}
    */
    readonly kind: string;
}
export declare function validatingAdmissionPolicyV1SpecParamKindToTerraform(struct?: ValidatingAdmissionPolicyV1SpecParamKind | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecParamKindToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecParamKind | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecParamKindOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1SpecParamKind | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecParamKind | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
}
export interface ValidatingAdmissionPolicyV1SpecValidations {
    /**
    * Expression represents the expression which will be evaluated by CEL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#expression ValidatingAdmissionPolicyV1#expression}
    */
    readonly expression: string;
    /**
    * Message represents the message displayed when validation fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#message ValidatingAdmissionPolicyV1#message}
    */
    readonly message: string;
    /**
    * Message Expression declares a CEL expression that evaluates to the validation failure message that is returned when this rule fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#message_expression ValidatingAdmissionPolicyV1#message_expression}
    */
    readonly messageExpression?: string;
    /**
    * Reason represents a machine-readable description of why this validation failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#reason ValidatingAdmissionPolicyV1#reason}
    */
    readonly reason?: string;
}
export declare function validatingAdmissionPolicyV1SpecValidationsToTerraform(struct?: ValidatingAdmissionPolicyV1SpecValidations | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecValidationsToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecValidations | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecValidationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecValidations | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecValidations | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    get messageInput(): string | undefined;
    private _messageExpression?;
    get messageExpression(): string;
    set messageExpression(value: string);
    resetMessageExpression(): void;
    get messageExpressionInput(): string | undefined;
    private _reason?;
    get reason(): string;
    set reason(value: string);
    resetReason(): void;
    get reasonInput(): string | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecValidationsList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecValidations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecValidationsOutputReference;
}
export interface ValidatingAdmissionPolicyV1SpecVariables {
    /**
    * Expression is the expression that will be evaluated as the value of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#expression ValidatingAdmissionPolicyV1#expression}
    */
    readonly expression?: string;
    /**
    * Name is the name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#name ValidatingAdmissionPolicyV1#name}
    */
    readonly name?: string;
}
export declare function validatingAdmissionPolicyV1SpecVariablesToTerraform(struct?: ValidatingAdmissionPolicyV1SpecVariables | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecVariablesToHclTerraform(struct?: ValidatingAdmissionPolicyV1SpecVariables | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ValidatingAdmissionPolicyV1SpecVariables | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1SpecVariables | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class ValidatingAdmissionPolicyV1SpecVariablesList extends cdktn.ComplexList {
    internalValue?: ValidatingAdmissionPolicyV1SpecVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ValidatingAdmissionPolicyV1SpecVariablesOutputReference;
}
export interface ValidatingAdmissionPolicyV1Spec {
    /**
    * auditAnnotations contains CEL expressions which are used to produce audit annotations for the audit event of the API request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#audit_annotations ValidatingAdmissionPolicyV1#audit_annotations}
    */
    readonly auditAnnotations: ValidatingAdmissionPolicyV1SpecAuditAnnotations[] | cdktn.IResolvable;
    /**
    * failurePolicy defines how to handle failures for the admission policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#failure_policy ValidatingAdmissionPolicyV1#failure_policy}
    */
    readonly failurePolicy: string;
    /**
    * MatchConditions is a list of conditions that must be met for a request to be validated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_conditions ValidatingAdmissionPolicyV1#match_conditions}
    */
    readonly matchConditions?: ValidatingAdmissionPolicyV1SpecMatchConditions[] | cdktn.IResolvable;
    /**
    * MatchConstraints specifies what resources this policy is designed to validate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#match_constraints ValidatingAdmissionPolicyV1#match_constraints}
    */
    readonly matchConstraints: ValidatingAdmissionPolicyV1SpecMatchConstraints;
    /**
    * ParamKind specifies the kind of resources used to parameterize this policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#param_kind ValidatingAdmissionPolicyV1#param_kind}
    */
    readonly paramKind?: ValidatingAdmissionPolicyV1SpecParamKind;
    /**
    * Validations contain CEL expressions which is used to apply the validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#validations ValidatingAdmissionPolicyV1#validations}
    */
    readonly validations?: ValidatingAdmissionPolicyV1SpecValidations[] | cdktn.IResolvable;
    /**
    * Variables contain definitions of variables that can be used in composition of other expressions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#variables ValidatingAdmissionPolicyV1#variables}
    */
    readonly variables?: ValidatingAdmissionPolicyV1SpecVariables[] | cdktn.IResolvable;
}
export declare function validatingAdmissionPolicyV1SpecToTerraform(struct?: ValidatingAdmissionPolicyV1Spec | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1SpecToHclTerraform(struct?: ValidatingAdmissionPolicyV1Spec | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1Spec | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1Spec | cdktn.IResolvable | undefined);
    private _auditAnnotations;
    get auditAnnotations(): ValidatingAdmissionPolicyV1SpecAuditAnnotationsList;
    putAuditAnnotations(value: ValidatingAdmissionPolicyV1SpecAuditAnnotations[] | cdktn.IResolvable): void;
    get auditAnnotationsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecAuditAnnotations[] | undefined;
    private _failurePolicy?;
    get failurePolicy(): string;
    set failurePolicy(value: string);
    get failurePolicyInput(): string | undefined;
    private _matchConditions;
    get matchConditions(): ValidatingAdmissionPolicyV1SpecMatchConditionsList;
    putMatchConditions(value: ValidatingAdmissionPolicyV1SpecMatchConditions[] | cdktn.IResolvable): void;
    resetMatchConditions(): void;
    get matchConditionsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConditions[] | undefined;
    private _matchConstraints;
    get matchConstraints(): ValidatingAdmissionPolicyV1SpecMatchConstraintsOutputReference;
    putMatchConstraints(value: ValidatingAdmissionPolicyV1SpecMatchConstraints): void;
    get matchConstraintsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecMatchConstraints | undefined;
    private _paramKind;
    get paramKind(): ValidatingAdmissionPolicyV1SpecParamKindOutputReference;
    putParamKind(value: ValidatingAdmissionPolicyV1SpecParamKind): void;
    resetParamKind(): void;
    get paramKindInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecParamKind | undefined;
    private _validations;
    get validations(): ValidatingAdmissionPolicyV1SpecValidationsList;
    putValidations(value: ValidatingAdmissionPolicyV1SpecValidations[] | cdktn.IResolvable): void;
    resetValidations(): void;
    get validationsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecValidations[] | undefined;
    private _variables;
    get variables(): ValidatingAdmissionPolicyV1SpecVariablesList;
    putVariables(value: ValidatingAdmissionPolicyV1SpecVariables[] | cdktn.IResolvable): void;
    resetVariables(): void;
    get variablesInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1SpecVariables[] | undefined;
}
export interface ValidatingAdmissionPolicyV1Timeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#create ValidatingAdmissionPolicyV1#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#delete ValidatingAdmissionPolicyV1#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#read ValidatingAdmissionPolicyV1#read}
    */
    readonly read?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#update ValidatingAdmissionPolicyV1#update}
    */
    readonly update?: string;
}
export declare function validatingAdmissionPolicyV1TimeoutsToTerraform(struct?: ValidatingAdmissionPolicyV1Timeouts | cdktn.IResolvable): any;
export declare function validatingAdmissionPolicyV1TimeoutsToHclTerraform(struct?: ValidatingAdmissionPolicyV1Timeouts | cdktn.IResolvable): any;
export declare class ValidatingAdmissionPolicyV1TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ValidatingAdmissionPolicyV1Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ValidatingAdmissionPolicyV1Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1 kubernetes_validating_admission_policy_v1}
*/
export declare class ValidatingAdmissionPolicyV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_validating_admission_policy_v1";
    /**
    * Generates CDKTN code for importing a ValidatingAdmissionPolicyV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ValidatingAdmissionPolicyV1 to import
    * @param importFromId The id of the existing ValidatingAdmissionPolicyV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ValidatingAdmissionPolicyV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/validating_admission_policy_v1 kubernetes_validating_admission_policy_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ValidatingAdmissionPolicyV1Config
    */
    constructor(scope: Construct, id: string, config: ValidatingAdmissionPolicyV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): ValidatingAdmissionPolicyV1MetadataOutputReference;
    putMetadata(value: ValidatingAdmissionPolicyV1Metadata): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1Metadata | undefined;
    private _spec;
    get spec(): ValidatingAdmissionPolicyV1SpecOutputReference;
    putSpec(value: ValidatingAdmissionPolicyV1Spec): void;
    get specInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1Spec | undefined;
    private _timeouts;
    get timeouts(): ValidatingAdmissionPolicyV1TimeoutsOutputReference;
    putTimeouts(value: ValidatingAdmissionPolicyV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ValidatingAdmissionPolicyV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
