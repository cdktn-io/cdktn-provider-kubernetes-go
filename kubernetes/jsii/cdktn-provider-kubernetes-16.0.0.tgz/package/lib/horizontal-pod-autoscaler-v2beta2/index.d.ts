/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HorizontalPodAutoscalerV2Beta2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#id HorizontalPodAutoscalerV2Beta2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#metadata HorizontalPodAutoscalerV2Beta2#metadata}
    */
    readonly metadata: HorizontalPodAutoscalerV2Beta2Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#spec HorizontalPodAutoscalerV2Beta2#spec}
    */
    readonly spec: HorizontalPodAutoscalerV2Beta2Spec;
}
export interface HorizontalPodAutoscalerV2Beta2Metadata {
    /**
    * An unstructured key value map stored with the horizontal pod autoscaler that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#annotations HorizontalPodAutoscalerV2Beta2#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#generate_name HorizontalPodAutoscalerV2Beta2#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the horizontal pod autoscaler. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#labels HorizontalPodAutoscalerV2Beta2#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the horizontal pod autoscaler, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the horizontal pod autoscaler must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#namespace HorizontalPodAutoscalerV2Beta2#namespace}
    */
    readonly namespace?: string;
}
export declare function horizontalPodAutoscalerV2Beta2MetadataToTerraform(struct?: HorizontalPodAutoscalerV2Beta2MetadataOutputReference | HorizontalPodAutoscalerV2Beta2Metadata): any;
export declare function horizontalPodAutoscalerV2Beta2MetadataToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2MetadataOutputReference | HorizontalPodAutoscalerV2Beta2Metadata): any;
export declare class HorizontalPodAutoscalerV2Beta2MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2Metadata | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy {
    /**
    * Period specifies the window of time for which the policy should hold true. PeriodSeconds must be greater than zero and less than or equal to 1800 (30 min).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#period_seconds HorizontalPodAutoscalerV2Beta2#period_seconds}
    */
    readonly periodSeconds: number;
    /**
    * Type is used to specify the scaling policy: Percent or Pods
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * Value contains the amount of change which is permitted by the policy. It must be greater than zero.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value: number;
}
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicyToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicyToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy | cdktn.IResolvable | undefined);
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    get periodSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicyList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicyOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown {
    /**
    * Used to specify which policy should be used. If not set, the default value Max is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#select_policy HorizontalPodAutoscalerV2Beta2#select_policy}
    */
    readonly selectPolicy?: string;
    /**
    * Number of seconds for which past recommendations should be considered while scaling up or scaling down. This value must be greater than or equal to zero and less than or equal to 3600 (one hour). If not set, use the default values: - For scale up: 0 (i.e. no stabilization is done). - For scale down: 300 (i.e. the stabilization window is 300 seconds long).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#stabilization_window_seconds HorizontalPodAutoscalerV2Beta2#stabilization_window_seconds}
    */
    readonly stabilizationWindowSeconds?: number;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#policy HorizontalPodAutoscalerV2Beta2#policy}
    */
    readonly policy: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown | cdktn.IResolvable | undefined);
    private _selectPolicy?;
    get selectPolicy(): string;
    set selectPolicy(value: string);
    resetSelectPolicy(): void;
    get selectPolicyInput(): string | undefined;
    private _stabilizationWindowSeconds?;
    get stabilizationWindowSeconds(): number;
    set stabilizationWindowSeconds(value: number);
    resetStabilizationWindowSeconds(): void;
    get stabilizationWindowSecondsInput(): number | undefined;
    private _policy;
    get policy(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicyList;
    putPolicy(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy[] | cdktn.IResolvable): void;
    get policyInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownPolicy[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy {
    /**
    * Period specifies the window of time for which the policy should hold true. PeriodSeconds must be greater than zero and less than or equal to 1800 (30 min).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#period_seconds HorizontalPodAutoscalerV2Beta2#period_seconds}
    */
    readonly periodSeconds: number;
    /**
    * Type is used to specify the scaling policy: Percent or Pods
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * Value contains the amount of change which is permitted by the policy. It must be greater than zero.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value: number;
}
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicyToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicyToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy | cdktn.IResolvable | undefined);
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    get periodSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicyList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicyOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp {
    /**
    * Used to specify which policy should be used. If not set, the default value Max is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#select_policy HorizontalPodAutoscalerV2Beta2#select_policy}
    */
    readonly selectPolicy?: string;
    /**
    * Number of seconds for which past recommendations should be considered while scaling up or scaling down. This value must be greater than or equal to zero and less than or equal to 3600 (one hour). If not set, use the default values: - For scale up: 0 (i.e. no stabilization is done). - For scale down: 300 (i.e. the stabilization window is 300 seconds long).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#stabilization_window_seconds HorizontalPodAutoscalerV2Beta2#stabilization_window_seconds}
    */
    readonly stabilizationWindowSeconds?: number;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#policy HorizontalPodAutoscalerV2Beta2#policy}
    */
    readonly policy: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp | cdktn.IResolvable | undefined);
    private _selectPolicy?;
    get selectPolicy(): string;
    set selectPolicy(value: string);
    resetSelectPolicy(): void;
    get selectPolicyInput(): string | undefined;
    private _stabilizationWindowSeconds?;
    get stabilizationWindowSeconds(): number;
    set stabilizationWindowSeconds(value: number);
    resetStabilizationWindowSeconds(): void;
    get stabilizationWindowSecondsInput(): number | undefined;
    private _policy;
    get policy(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicyList;
    putPolicy(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy[] | cdktn.IResolvable): void;
    get policyInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpPolicy[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecBehavior {
    /**
    * scale_down block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#scale_down HorizontalPodAutoscalerV2Beta2#scale_down}
    */
    readonly scaleDown?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown[] | cdktn.IResolvable;
    /**
    * scale_up block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#scale_up HorizontalPodAutoscalerV2Beta2#scale_up}
    */
    readonly scaleUp?: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorOutputReference | HorizontalPodAutoscalerV2Beta2SpecBehavior): any;
export declare function horizontalPodAutoscalerV2Beta2SpecBehaviorToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecBehaviorOutputReference | HorizontalPodAutoscalerV2Beta2SpecBehavior): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecBehavior | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecBehavior | undefined);
    private _scaleDown;
    get scaleDown(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDownList;
    putScaleDown(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown[] | cdktn.IResolvable): void;
    resetScaleDown(): void;
    get scaleDownInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleDown[] | undefined;
    private _scaleUp;
    get scaleUp(): HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUpList;
    putScaleUp(value: HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp[] | cdktn.IResolvable): void;
    resetScaleUp(): void;
    get scaleUpInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecBehaviorScaleUp[] | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget {
    /**
    * averageUtilization is the target value of the average of the resource metric across all relevant pods, represented as a percentage of the requested value of the resource for the pods. Currently only valid for Resource metric source type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_utilization HorizontalPodAutoscalerV2Beta2#average_utilization}
    */
    readonly averageUtilization?: number;
    /**
    * averageValue is the target value of the average of the metric across all relevant pods (as a quantity)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_value HorizontalPodAutoscalerV2Beta2#average_value}
    */
    readonly averageValue?: string;
    /**
    * type represents whether the metric type is Utilization, Value, or AverageValue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * value is the target value of the metric (as a quantity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value?: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTargetToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTargetToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget | undefined);
    private _averageUtilization?;
    get averageUtilization(): number;
    set averageUtilization(value: number);
    resetAverageUtilization(): void;
    get averageUtilizationInput(): number | undefined;
    private _averageValue?;
    get averageValue(): string;
    set averageValue(value: string);
    resetAverageValue(): void;
    get averageValueInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource {
    /**
    * name of the container in the pods of the scaling target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#container HorizontalPodAutoscalerV2Beta2#container}
    */
    readonly container: string;
    /**
    * name of the resource in question
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#target HorizontalPodAutoscalerV2Beta2#target}
    */
    readonly target?: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricContainerResourceToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricContainerResourceToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource | undefined);
    private _container?;
    get container(): string;
    set container(value: string);
    get containerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _target;
    get target(): HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTargetOutputReference;
    putTarget(value: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget): void;
    resetTarget(): void;
    get targetInput(): HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceTarget | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#key HorizontalPodAutoscalerV2Beta2#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#operator HorizontalPodAutoscalerV2Beta2#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#values HorizontalPodAutoscalerV2Beta2#values}
    */
    readonly values?: string[];
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressionsToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressionsToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressionsOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#match_labels HorizontalPodAutoscalerV2Beta2#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#match_expressions HorizontalPodAutoscalerV2Beta2#match_expressions}
    */
    readonly matchExpressions?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressionsList;
    putMatchExpressions(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorMatchExpressions[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric {
    /**
    * name is the name of the given metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#selector HorizontalPodAutoscalerV2Beta2#selector}
    */
    readonly selector?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalMetricToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalMetricToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _selector;
    get selector(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelectorList;
    putSelector(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector[] | cdktn.IResolvable): void;
    resetSelector(): void;
    get selectorInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricSelector[] | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget {
    /**
    * averageUtilization is the target value of the average of the resource metric across all relevant pods, represented as a percentage of the requested value of the resource for the pods. Currently only valid for Resource metric source type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_utilization HorizontalPodAutoscalerV2Beta2#average_utilization}
    */
    readonly averageUtilization?: number;
    /**
    * averageValue is the target value of the average of the metric across all relevant pods (as a quantity)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_value HorizontalPodAutoscalerV2Beta2#average_value}
    */
    readonly averageValue?: string;
    /**
    * type represents whether the metric type is Utilization, Value, or AverageValue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * value is the target value of the metric (as a quantity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value?: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalTargetToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalTargetToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget | undefined);
    private _averageUtilization?;
    get averageUtilization(): number;
    set averageUtilization(value: number);
    resetAverageUtilization(): void;
    get averageUtilizationInput(): number | undefined;
    private _averageValue?;
    get averageValue(): string;
    set averageValue(value: string);
    resetAverageValue(): void;
    get averageValueInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricExternal {
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#metric HorizontalPodAutoscalerV2Beta2#metric}
    */
    readonly metric: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#target HorizontalPodAutoscalerV2Beta2#target}
    */
    readonly target?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricExternal): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricExternalToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricExternalOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricExternal): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricExternalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricExternal | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternal | undefined);
    private _metric;
    get metric(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetricOutputReference;
    putMetric(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric): void;
    get metricInput(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalMetric | undefined;
    private _target;
    get target(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalTargetOutputReference;
    putTarget(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget): void;
    resetTarget(): void;
    get targetInput(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalTarget | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject {
    /**
    * API version of the referent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#api_version HorizontalPodAutoscalerV2Beta2#api_version}
    */
    readonly apiVersion: string;
    /**
    * Kind of the referent; More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#kind HorizontalPodAutoscalerV2Beta2#kind}
    */
    readonly kind: string;
    /**
    * Name of the referent; More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObjectToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObjectOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObjectToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObjectOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#key HorizontalPodAutoscalerV2Beta2#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#operator HorizontalPodAutoscalerV2Beta2#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#values HorizontalPodAutoscalerV2Beta2#values}
    */
    readonly values?: string[];
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressionsToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressionsToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressionsOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#match_labels HorizontalPodAutoscalerV2Beta2#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#match_expressions HorizontalPodAutoscalerV2Beta2#match_expressions}
    */
    readonly matchExpressions?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressionsList;
    putMatchExpressions(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorMatchExpressions[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric {
    /**
    * name is the name of the given metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#selector HorizontalPodAutoscalerV2Beta2#selector}
    */
    readonly selector?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectMetricToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectMetricToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _selector;
    get selector(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelectorList;
    putSelector(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector[] | cdktn.IResolvable): void;
    resetSelector(): void;
    get selectorInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricSelector[] | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget {
    /**
    * averageUtilization is the target value of the average of the resource metric across all relevant pods, represented as a percentage of the requested value of the resource for the pods. Currently only valid for Resource metric source type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_utilization HorizontalPodAutoscalerV2Beta2#average_utilization}
    */
    readonly averageUtilization?: number;
    /**
    * averageValue is the target value of the average of the metric across all relevant pods (as a quantity)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_value HorizontalPodAutoscalerV2Beta2#average_value}
    */
    readonly averageValue?: string;
    /**
    * type represents whether the metric type is Utilization, Value, or AverageValue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * value is the target value of the metric (as a quantity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value?: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectTargetToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectTargetToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget | undefined);
    private _averageUtilization?;
    get averageUtilization(): number;
    set averageUtilization(value: number);
    resetAverageUtilization(): void;
    get averageUtilizationInput(): number | undefined;
    private _averageValue?;
    get averageValue(): string;
    set averageValue(value: string);
    resetAverageValue(): void;
    get averageValueInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricObject {
    /**
    * described_object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#described_object HorizontalPodAutoscalerV2Beta2#described_object}
    */
    readonly describedObject: HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject;
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#metric HorizontalPodAutoscalerV2Beta2#metric}
    */
    readonly metric: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#target HorizontalPodAutoscalerV2Beta2#target}
    */
    readonly target?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObject): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricObjectToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricObjectOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricObject): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricObject | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricObject | undefined);
    private _describedObject;
    get describedObject(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObjectOutputReference;
    putDescribedObject(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject): void;
    get describedObjectInput(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectDescribedObject | undefined;
    private _metric;
    get metric(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetricOutputReference;
    putMetric(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric): void;
    get metricInput(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectMetric | undefined;
    private _target;
    get target(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectTargetOutputReference;
    putTarget(value: HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget): void;
    resetTarget(): void;
    get targetInput(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectTarget | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#key HorizontalPodAutoscalerV2Beta2#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#operator HorizontalPodAutoscalerV2Beta2#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#values HorizontalPodAutoscalerV2Beta2#values}
    */
    readonly values?: string[];
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressionsToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressionsToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressionsOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#match_labels HorizontalPodAutoscalerV2Beta2#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#match_expressions HorizontalPodAutoscalerV2Beta2#match_expressions}
    */
    readonly matchExpressions?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressionsList;
    putMatchExpressions(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorMatchExpressions[] | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric {
    /**
    * name is the name of the given metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#selector HorizontalPodAutoscalerV2Beta2#selector}
    */
    readonly selector?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector[] | cdktn.IResolvable;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsMetricToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsMetricToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _selector;
    get selector(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelectorList;
    putSelector(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector[] | cdktn.IResolvable): void;
    resetSelector(): void;
    get selectorInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricSelector[] | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget {
    /**
    * averageUtilization is the target value of the average of the resource metric across all relevant pods, represented as a percentage of the requested value of the resource for the pods. Currently only valid for Resource metric source type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_utilization HorizontalPodAutoscalerV2Beta2#average_utilization}
    */
    readonly averageUtilization?: number;
    /**
    * averageValue is the target value of the average of the metric across all relevant pods (as a quantity)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_value HorizontalPodAutoscalerV2Beta2#average_value}
    */
    readonly averageValue?: string;
    /**
    * type represents whether the metric type is Utilization, Value, or AverageValue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * value is the target value of the metric (as a quantity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value?: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsTargetToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsTargetToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget | undefined);
    private _averageUtilization?;
    get averageUtilization(): number;
    set averageUtilization(value: number);
    resetAverageUtilization(): void;
    get averageUtilizationInput(): number | undefined;
    private _averageValue?;
    get averageValue(): string;
    set averageValue(value: string);
    resetAverageValue(): void;
    get averageValueInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricPods {
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#metric HorizontalPodAutoscalerV2Beta2#metric}
    */
    readonly metric: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#target HorizontalPodAutoscalerV2Beta2#target}
    */
    readonly target?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricPods): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricPodsToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricPodsOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricPods): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricPodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricPods | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricPods | undefined);
    private _metric;
    get metric(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetricOutputReference;
    putMetric(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric): void;
    get metricInput(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsMetric | undefined;
    private _target;
    get target(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsTargetOutputReference;
    putTarget(value: HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget): void;
    resetTarget(): void;
    get targetInput(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsTarget | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget {
    /**
    * averageUtilization is the target value of the average of the resource metric across all relevant pods, represented as a percentage of the requested value of the resource for the pods. Currently only valid for Resource metric source type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_utilization HorizontalPodAutoscalerV2Beta2#average_utilization}
    */
    readonly averageUtilization?: number;
    /**
    * averageValue is the target value of the average of the metric across all relevant pods (as a quantity)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#average_value HorizontalPodAutoscalerV2Beta2#average_value}
    */
    readonly averageValue?: string;
    /**
    * type represents whether the metric type is Utilization, Value, or AverageValue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * value is the target value of the metric (as a quantity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#value HorizontalPodAutoscalerV2Beta2#value}
    */
    readonly value?: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricResourceTargetToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricResourceTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricResourceTargetToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricResourceTargetOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricResourceTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget | undefined);
    private _averageUtilization?;
    get averageUtilization(): number;
    set averageUtilization(value: number);
    resetAverageUtilization(): void;
    get averageUtilizationInput(): number | undefined;
    private _averageValue?;
    get averageValue(): string;
    set averageValue(value: string);
    resetAverageValue(): void;
    get averageValueInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetricResource {
    /**
    * name is the name of the resource in question.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#target HorizontalPodAutoscalerV2Beta2#target}
    */
    readonly target?: HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricResourceToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricResourceOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricResource): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricResourceToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetricResourceOutputReference | HorizontalPodAutoscalerV2Beta2SpecMetricResource): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetricResource | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetricResource | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _target;
    get target(): HorizontalPodAutoscalerV2Beta2SpecMetricResourceTargetOutputReference;
    putTarget(value: HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget): void;
    resetTarget(): void;
    get targetInput(): HorizontalPodAutoscalerV2Beta2SpecMetricResourceTarget | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2SpecMetric {
    /**
    * type is the type of metric source. It should be one of "ContainerResource", "External", "Object", "Pods" or "Resource", each mapping to a matching field in the object. Note: "ContainerResource" type is available on when the feature-gate HPAContainerMetrics is enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#type HorizontalPodAutoscalerV2Beta2#type}
    */
    readonly type: string;
    /**
    * container_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#container_resource HorizontalPodAutoscalerV2Beta2#container_resource}
    */
    readonly containerResource?: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource;
    /**
    * external block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#external HorizontalPodAutoscalerV2Beta2#external}
    */
    readonly external?: HorizontalPodAutoscalerV2Beta2SpecMetricExternal;
    /**
    * object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#object HorizontalPodAutoscalerV2Beta2#object}
    */
    readonly object?: HorizontalPodAutoscalerV2Beta2SpecMetricObject;
    /**
    * pods block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#pods HorizontalPodAutoscalerV2Beta2#pods}
    */
    readonly pods?: HorizontalPodAutoscalerV2Beta2SpecMetricPods;
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#resource HorizontalPodAutoscalerV2Beta2#resource}
    */
    readonly resource?: HorizontalPodAutoscalerV2Beta2SpecMetricResource;
}
export declare function horizontalPodAutoscalerV2Beta2SpecMetricToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetric | cdktn.IResolvable): any;
export declare function horizontalPodAutoscalerV2Beta2SpecMetricToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecMetric | cdktn.IResolvable): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecMetric | cdktn.IResolvable | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecMetric | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _containerResource;
    get containerResource(): HorizontalPodAutoscalerV2Beta2SpecMetricContainerResourceOutputReference;
    putContainerResource(value: HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource): void;
    resetContainerResource(): void;
    get containerResourceInput(): HorizontalPodAutoscalerV2Beta2SpecMetricContainerResource | undefined;
    private _external;
    get external(): HorizontalPodAutoscalerV2Beta2SpecMetricExternalOutputReference;
    putExternal(value: HorizontalPodAutoscalerV2Beta2SpecMetricExternal): void;
    resetExternal(): void;
    get externalInput(): HorizontalPodAutoscalerV2Beta2SpecMetricExternal | undefined;
    private _object;
    get object(): HorizontalPodAutoscalerV2Beta2SpecMetricObjectOutputReference;
    putObject(value: HorizontalPodAutoscalerV2Beta2SpecMetricObject): void;
    resetObject(): void;
    get objectInput(): HorizontalPodAutoscalerV2Beta2SpecMetricObject | undefined;
    private _pods;
    get pods(): HorizontalPodAutoscalerV2Beta2SpecMetricPodsOutputReference;
    putPods(value: HorizontalPodAutoscalerV2Beta2SpecMetricPods): void;
    resetPods(): void;
    get podsInput(): HorizontalPodAutoscalerV2Beta2SpecMetricPods | undefined;
    private _resource;
    get resource(): HorizontalPodAutoscalerV2Beta2SpecMetricResourceOutputReference;
    putResource(value: HorizontalPodAutoscalerV2Beta2SpecMetricResource): void;
    resetResource(): void;
    get resourceInput(): HorizontalPodAutoscalerV2Beta2SpecMetricResource | undefined;
}
export declare class HorizontalPodAutoscalerV2Beta2SpecMetricList extends cdktn.ComplexList {
    internalValue?: HorizontalPodAutoscalerV2Beta2SpecMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HorizontalPodAutoscalerV2Beta2SpecMetricOutputReference;
}
export interface HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef {
    /**
    * API version of the referent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#api_version HorizontalPodAutoscalerV2Beta2#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Kind of the referent. e.g. `ReplicationController`. More info: http://releases.k8s.io/HEAD/docs/devel/api-conventions.md#types-kinds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#kind HorizontalPodAutoscalerV2Beta2#kind}
    */
    readonly kind: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#name HorizontalPodAutoscalerV2Beta2#name}
    */
    readonly name: string;
}
export declare function horizontalPodAutoscalerV2Beta2SpecScaleTargetRefToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecScaleTargetRefOutputReference | HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef): any;
export declare function horizontalPodAutoscalerV2Beta2SpecScaleTargetRefToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecScaleTargetRefOutputReference | HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecScaleTargetRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface HorizontalPodAutoscalerV2Beta2Spec {
    /**
    * Upper limit for the number of pods that can be set by the autoscaler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#max_replicas HorizontalPodAutoscalerV2Beta2#max_replicas}
    */
    readonly maxReplicas: number;
    /**
    * Lower limit for the number of pods that can be set by the autoscaler, defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#min_replicas HorizontalPodAutoscalerV2Beta2#min_replicas}
    */
    readonly minReplicas?: number;
    /**
    * Target average CPU utilization (represented as a percentage of requested CPU) over all the pods. If not specified the default autoscaling policy will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#target_cpu_utilization_percentage HorizontalPodAutoscalerV2Beta2#target_cpu_utilization_percentage}
    */
    readonly targetCpuUtilizationPercentage?: number;
    /**
    * behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#behavior HorizontalPodAutoscalerV2Beta2#behavior}
    */
    readonly behavior?: HorizontalPodAutoscalerV2Beta2SpecBehavior;
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#metric HorizontalPodAutoscalerV2Beta2#metric}
    */
    readonly metric?: HorizontalPodAutoscalerV2Beta2SpecMetric[] | cdktn.IResolvable;
    /**
    * scale_target_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#scale_target_ref HorizontalPodAutoscalerV2Beta2#scale_target_ref}
    */
    readonly scaleTargetRef: HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef;
}
export declare function horizontalPodAutoscalerV2Beta2SpecToTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecOutputReference | HorizontalPodAutoscalerV2Beta2Spec): any;
export declare function horizontalPodAutoscalerV2Beta2SpecToHclTerraform(struct?: HorizontalPodAutoscalerV2Beta2SpecOutputReference | HorizontalPodAutoscalerV2Beta2Spec): any;
export declare class HorizontalPodAutoscalerV2Beta2SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HorizontalPodAutoscalerV2Beta2Spec | undefined;
    set internalValue(value: HorizontalPodAutoscalerV2Beta2Spec | undefined);
    private _maxReplicas?;
    get maxReplicas(): number;
    set maxReplicas(value: number);
    get maxReplicasInput(): number | undefined;
    private _minReplicas?;
    get minReplicas(): number;
    set minReplicas(value: number);
    resetMinReplicas(): void;
    get minReplicasInput(): number | undefined;
    private _targetCpuUtilizationPercentage?;
    get targetCpuUtilizationPercentage(): number;
    set targetCpuUtilizationPercentage(value: number);
    resetTargetCpuUtilizationPercentage(): void;
    get targetCpuUtilizationPercentageInput(): number | undefined;
    private _behavior;
    get behavior(): HorizontalPodAutoscalerV2Beta2SpecBehaviorOutputReference;
    putBehavior(value: HorizontalPodAutoscalerV2Beta2SpecBehavior): void;
    resetBehavior(): void;
    get behaviorInput(): HorizontalPodAutoscalerV2Beta2SpecBehavior | undefined;
    private _metric;
    get metric(): HorizontalPodAutoscalerV2Beta2SpecMetricList;
    putMetric(value: HorizontalPodAutoscalerV2Beta2SpecMetric[] | cdktn.IResolvable): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | HorizontalPodAutoscalerV2Beta2SpecMetric[] | undefined;
    private _scaleTargetRef;
    get scaleTargetRef(): HorizontalPodAutoscalerV2Beta2SpecScaleTargetRefOutputReference;
    putScaleTargetRef(value: HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef): void;
    get scaleTargetRefInput(): HorizontalPodAutoscalerV2Beta2SpecScaleTargetRef | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2 kubernetes_horizontal_pod_autoscaler_v2beta2}
*/
export declare class HorizontalPodAutoscalerV2Beta2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_horizontal_pod_autoscaler_v2beta2";
    /**
    * Generates CDKTN code for importing a HorizontalPodAutoscalerV2Beta2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HorizontalPodAutoscalerV2Beta2 to import
    * @param importFromId The id of the existing HorizontalPodAutoscalerV2Beta2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HorizontalPodAutoscalerV2Beta2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/horizontal_pod_autoscaler_v2beta2 kubernetes_horizontal_pod_autoscaler_v2beta2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HorizontalPodAutoscalerV2Beta2Config
    */
    constructor(scope: Construct, id: string, config: HorizontalPodAutoscalerV2Beta2Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): HorizontalPodAutoscalerV2Beta2MetadataOutputReference;
    putMetadata(value: HorizontalPodAutoscalerV2Beta2Metadata): void;
    get metadataInput(): HorizontalPodAutoscalerV2Beta2Metadata | undefined;
    private _spec;
    get spec(): HorizontalPodAutoscalerV2Beta2SpecOutputReference;
    putSpec(value: HorizontalPodAutoscalerV2Beta2Spec): void;
    get specInput(): HorizontalPodAutoscalerV2Beta2Spec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
