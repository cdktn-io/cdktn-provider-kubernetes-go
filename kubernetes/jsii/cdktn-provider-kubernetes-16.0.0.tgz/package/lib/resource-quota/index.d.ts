/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ResourceQuotaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#id ResourceQuota#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#metadata ResourceQuota#metadata}
    */
    readonly metadata: ResourceQuotaMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#spec ResourceQuota#spec}
    */
    readonly spec?: ResourceQuotaSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#timeouts ResourceQuota#timeouts}
    */
    readonly timeouts?: ResourceQuotaTimeouts;
}
export interface ResourceQuotaMetadata {
    /**
    * An unstructured key value map stored with the resource quota that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#annotations ResourceQuota#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#generate_name ResourceQuota#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the resource quota. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#labels ResourceQuota#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the resource quota, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#name ResourceQuota#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the resource quota must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#namespace ResourceQuota#namespace}
    */
    readonly namespace?: string;
}
export declare function resourceQuotaMetadataToTerraform(struct?: ResourceQuotaMetadataOutputReference | ResourceQuotaMetadata): any;
export declare function resourceQuotaMetadataToHclTerraform(struct?: ResourceQuotaMetadataOutputReference | ResourceQuotaMetadata): any;
export declare class ResourceQuotaMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaMetadata | undefined;
    set internalValue(value: ResourceQuotaMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface ResourceQuotaSpecScopeSelectorMatchExpression {
    /**
    * Represents a scope's relationship to a set of values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#operator ResourceQuota#operator}
    */
    readonly operator: string;
    /**
    * The name of the scope that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#scope_name ResourceQuota#scope_name}
    */
    readonly scopeName: string;
    /**
    * A list of scope selector requirements by scope of the resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#values ResourceQuota#values}
    */
    readonly values?: string[];
}
export declare function resourceQuotaSpecScopeSelectorMatchExpressionToTerraform(struct?: ResourceQuotaSpecScopeSelectorMatchExpression | cdktn.IResolvable): any;
export declare function resourceQuotaSpecScopeSelectorMatchExpressionToHclTerraform(struct?: ResourceQuotaSpecScopeSelectorMatchExpression | cdktn.IResolvable): any;
export declare class ResourceQuotaSpecScopeSelectorMatchExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResourceQuotaSpecScopeSelectorMatchExpression | cdktn.IResolvable | undefined;
    set internalValue(value: ResourceQuotaSpecScopeSelectorMatchExpression | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _scopeName?;
    get scopeName(): string;
    set scopeName(value: string);
    get scopeNameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ResourceQuotaSpecScopeSelectorMatchExpressionList extends cdktn.ComplexList {
    internalValue?: ResourceQuotaSpecScopeSelectorMatchExpression[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResourceQuotaSpecScopeSelectorMatchExpressionOutputReference;
}
export interface ResourceQuotaSpecScopeSelector {
    /**
    * match_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#match_expression ResourceQuota#match_expression}
    */
    readonly matchExpression?: ResourceQuotaSpecScopeSelectorMatchExpression[] | cdktn.IResolvable;
}
export declare function resourceQuotaSpecScopeSelectorToTerraform(struct?: ResourceQuotaSpecScopeSelectorOutputReference | ResourceQuotaSpecScopeSelector): any;
export declare function resourceQuotaSpecScopeSelectorToHclTerraform(struct?: ResourceQuotaSpecScopeSelectorOutputReference | ResourceQuotaSpecScopeSelector): any;
export declare class ResourceQuotaSpecScopeSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaSpecScopeSelector | undefined;
    set internalValue(value: ResourceQuotaSpecScopeSelector | undefined);
    private _matchExpression;
    get matchExpression(): ResourceQuotaSpecScopeSelectorMatchExpressionList;
    putMatchExpression(value: ResourceQuotaSpecScopeSelectorMatchExpression[] | cdktn.IResolvable): void;
    resetMatchExpression(): void;
    get matchExpressionInput(): cdktn.IResolvable | ResourceQuotaSpecScopeSelectorMatchExpression[] | undefined;
}
export interface ResourceQuotaSpec {
    /**
    * The set of desired hard limits for each named resource. More info: http://releases.k8s.io/HEAD/docs/design/admission_control_resource_quota.md#admissioncontrol-plugin-resourcequota
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#hard ResourceQuota#hard}
    */
    readonly hard?: {
        [key: string]: string;
    };
    /**
    * A collection of filters that must match each object tracked by a quota. If not specified, the quota matches all objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#scopes ResourceQuota#scopes}
    */
    readonly scopes?: string[];
    /**
    * scope_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#scope_selector ResourceQuota#scope_selector}
    */
    readonly scopeSelector?: ResourceQuotaSpecScopeSelector;
}
export declare function resourceQuotaSpecToTerraform(struct?: ResourceQuotaSpecOutputReference | ResourceQuotaSpec): any;
export declare function resourceQuotaSpecToHclTerraform(struct?: ResourceQuotaSpecOutputReference | ResourceQuotaSpec): any;
export declare class ResourceQuotaSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaSpec | undefined;
    set internalValue(value: ResourceQuotaSpec | undefined);
    private _hard?;
    get hard(): {
        [key: string]: string;
    };
    set hard(value: {
        [key: string]: string;
    });
    resetHard(): void;
    get hardInput(): {
        [key: string]: string;
    } | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _scopeSelector;
    get scopeSelector(): ResourceQuotaSpecScopeSelectorOutputReference;
    putScopeSelector(value: ResourceQuotaSpecScopeSelector): void;
    resetScopeSelector(): void;
    get scopeSelectorInput(): ResourceQuotaSpecScopeSelector | undefined;
}
export interface ResourceQuotaTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#create ResourceQuota#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#update ResourceQuota#update}
    */
    readonly update?: string;
}
export declare function resourceQuotaTimeoutsToTerraform(struct?: ResourceQuotaTimeouts | cdktn.IResolvable): any;
export declare function resourceQuotaTimeoutsToHclTerraform(struct?: ResourceQuotaTimeouts | cdktn.IResolvable): any;
export declare class ResourceQuotaTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ResourceQuotaTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ResourceQuotaTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota kubernetes_resource_quota}
*/
export declare class ResourceQuota extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_resource_quota";
    /**
    * Generates CDKTN code for importing a ResourceQuota resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ResourceQuota to import
    * @param importFromId The id of the existing ResourceQuota that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ResourceQuota to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/resource_quota kubernetes_resource_quota} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourceQuotaConfig
    */
    constructor(scope: Construct, id: string, config: ResourceQuotaConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): ResourceQuotaMetadataOutputReference;
    putMetadata(value: ResourceQuotaMetadata): void;
    get metadataInput(): ResourceQuotaMetadata | undefined;
    private _spec;
    get spec(): ResourceQuotaSpecOutputReference;
    putSpec(value: ResourceQuotaSpec): void;
    resetSpec(): void;
    get specInput(): ResourceQuotaSpec | undefined;
    private _timeouts;
    get timeouts(): ResourceQuotaTimeoutsOutputReference;
    putTimeouts(value: ResourceQuotaTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ResourceQuotaTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
