/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PersistentVolumeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#id PersistentVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#metadata PersistentVolume#metadata}
    */
    readonly metadata: PersistentVolumeMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#spec PersistentVolume#spec}
    */
    readonly spec: PersistentVolumeSpec[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#timeouts PersistentVolume#timeouts}
    */
    readonly timeouts?: PersistentVolumeTimeouts;
}
export interface PersistentVolumeMetadata {
    /**
    * An unstructured key value map stored with the persistent volume that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#annotations PersistentVolume#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the persistent volume. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#labels PersistentVolume#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the persistent volume, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
}
export declare function persistentVolumeMetadataToTerraform(struct?: PersistentVolumeMetadataOutputReference | PersistentVolumeMetadata): any;
export declare function persistentVolumeMetadataToHclTerraform(struct?: PersistentVolumeMetadataOutputReference | PersistentVolumeMetadata): any;
export declare class PersistentVolumeMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeMetadata | undefined;
    set internalValue(value: PersistentVolumeMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface PersistentVolumeSpecClaimRef {
    /**
    * The name of the PersistentVolumeClaim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name: string;
    /**
    * The namespace of the PersistentVolumeClaim. Uses 'default' namespace if none is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecClaimRefToTerraform(struct?: PersistentVolumeSpecClaimRefOutputReference | PersistentVolumeSpecClaimRef): any;
export declare function persistentVolumeSpecClaimRefToHclTerraform(struct?: PersistentVolumeSpecClaimRefOutputReference | PersistentVolumeSpecClaimRef): any;
export declare class PersistentVolumeSpecClaimRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecClaimRef | undefined;
    set internalValue(value: PersistentVolumeSpecClaimRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#key PersistentVolume#key}
    */
    readonly key: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists`, `DoesNotExist`, `Gt`, and `Lt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#operator PersistentVolume#operator}
    */
    readonly operator: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#values PersistentVolume#values}
    */
    readonly values?: string[];
}
export declare function persistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsToTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable): any;
export declare function persistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsToHclTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable): any;
export declare class PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsOutputReference;
}
export interface PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#key PersistentVolume#key}
    */
    readonly key: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists`, `DoesNotExist`, `Gt`, and `Lt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#operator PersistentVolume#operator}
    */
    readonly operator: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#values PersistentVolume#values}
    */
    readonly values?: string[];
}
export declare function persistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFieldsToTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable): any;
export declare function persistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFieldsToHclTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable): any;
export declare class PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable | undefined;
    set internalValue(value: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFieldsList extends cdktn.ComplexList {
    internalValue?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFieldsOutputReference;
}
export interface PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm {
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#match_expressions PersistentVolume#match_expressions}
    */
    readonly matchExpressions?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | cdktn.IResolvable;
    /**
    * match_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#match_fields PersistentVolume#match_fields}
    */
    readonly matchFields?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | cdktn.IResolvable;
}
export declare function persistentVolumeSpecNodeAffinityRequiredNodeSelectorTermToTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable): any;
export declare function persistentVolumeSpecNodeAffinityRequiredNodeSelectorTermToHclTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable): any;
export declare class PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable | undefined;
    set internalValue(value: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable | undefined);
    private _matchExpressions;
    get matchExpressions(): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsList;
    putMatchExpressions(value: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | undefined;
    private _matchFields;
    get matchFields(): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFieldsList;
    putMatchFields(value: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | cdktn.IResolvable): void;
    resetMatchFields(): void;
    get matchFieldsInput(): cdktn.IResolvable | PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | undefined;
}
export declare class PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermList extends cdktn.ComplexList {
    internalValue?: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermOutputReference;
}
export interface PersistentVolumeSpecNodeAffinityRequired {
    /**
    * node_selector_term block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#node_selector_term PersistentVolume#node_selector_term}
    */
    readonly nodeSelectorTerm: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm[] | cdktn.IResolvable;
}
export declare function persistentVolumeSpecNodeAffinityRequiredToTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredOutputReference | PersistentVolumeSpecNodeAffinityRequired): any;
export declare function persistentVolumeSpecNodeAffinityRequiredToHclTerraform(struct?: PersistentVolumeSpecNodeAffinityRequiredOutputReference | PersistentVolumeSpecNodeAffinityRequired): any;
export declare class PersistentVolumeSpecNodeAffinityRequiredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecNodeAffinityRequired | undefined;
    set internalValue(value: PersistentVolumeSpecNodeAffinityRequired | undefined);
    private _nodeSelectorTerm;
    get nodeSelectorTerm(): PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTermList;
    putNodeSelectorTerm(value: PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm[] | cdktn.IResolvable): void;
    get nodeSelectorTermInput(): cdktn.IResolvable | PersistentVolumeSpecNodeAffinityRequiredNodeSelectorTerm[] | undefined;
}
export interface PersistentVolumeSpecNodeAffinity {
    /**
    * required block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#required PersistentVolume#required}
    */
    readonly required?: PersistentVolumeSpecNodeAffinityRequired;
}
export declare function persistentVolumeSpecNodeAffinityToTerraform(struct?: PersistentVolumeSpecNodeAffinityOutputReference | PersistentVolumeSpecNodeAffinity): any;
export declare function persistentVolumeSpecNodeAffinityToHclTerraform(struct?: PersistentVolumeSpecNodeAffinityOutputReference | PersistentVolumeSpecNodeAffinity): any;
export declare class PersistentVolumeSpecNodeAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecNodeAffinity | undefined;
    set internalValue(value: PersistentVolumeSpecNodeAffinity | undefined);
    private _required;
    get required(): PersistentVolumeSpecNodeAffinityRequiredOutputReference;
    putRequired(value: PersistentVolumeSpecNodeAffinityRequired): void;
    resetRequired(): void;
    get requiredInput(): PersistentVolumeSpecNodeAffinityRequired | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#partition PersistentVolume#partition}
    */
    readonly partition?: number;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Unique ID of the persistent disk resource in AWS (Amazon EBS volume). More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume_id PersistentVolume#volume_id}
    */
    readonly volumeId: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStoreToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference | PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore): any;
export declare function persistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStoreToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference | PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceAzureDisk {
    /**
    * Host Caching mode: None, Read Only, Read Write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#caching_mode PersistentVolume#caching_mode}
    */
    readonly cachingMode: string;
    /**
    * The URI the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#data_disk_uri PersistentVolume#data_disk_uri}
    */
    readonly dataDiskUri: string;
    /**
    * The Name of the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#disk_name PersistentVolume#disk_name}
    */
    readonly diskName: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * The type for the data disk. Expected values: Shared, Dedicated, Managed. Defaults to Shared
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#kind PersistentVolume#kind}
    */
    readonly kind?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function persistentVolumeSpecPersistentVolumeSourceAzureDiskToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceAzureDiskOutputReference | PersistentVolumeSpecPersistentVolumeSourceAzureDisk): any;
export declare function persistentVolumeSpecPersistentVolumeSourceAzureDiskToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceAzureDiskOutputReference | PersistentVolumeSpecPersistentVolumeSourceAzureDisk): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceAzureDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceAzureDisk | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceAzureDisk | undefined);
    private _cachingMode?;
    get cachingMode(): string;
    set cachingMode(value: string);
    get cachingModeInput(): string | undefined;
    private _dataDiskUri?;
    get dataDiskUri(): string;
    set dataDiskUri(value: string);
    get dataDiskUriInput(): string | undefined;
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    get diskNameInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceAzureFile {
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The name of secret that contains Azure Storage Account Name and Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#secret_name PersistentVolume#secret_name}
    */
    readonly secretName: string;
    /**
    * The namespace of the secret that contains Azure Storage Account Name and Key. For Kubernetes up to 1.18.x the default is the same as the Pod. For Kubernetes 1.19.x and later the default is "default" namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#secret_namespace PersistentVolume#secret_namespace}
    */
    readonly secretNamespace?: string;
    /**
    * Share Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#share_name PersistentVolume#share_name}
    */
    readonly shareName: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceAzureFileToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceAzureFileOutputReference | PersistentVolumeSpecPersistentVolumeSourceAzureFile): any;
export declare function persistentVolumeSpecPersistentVolumeSourceAzureFileToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceAzureFileOutputReference | PersistentVolumeSpecPersistentVolumeSourceAzureFile): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceAzureFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceAzureFile | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceAzureFile | undefined);
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _secretNamespace?;
    get secretNamespace(): string;
    set secretNamespace(value: string);
    resetSecretNamespace(): void;
    get secretNamespaceInput(): string | undefined;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    get shareNameInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCephFsSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCephFsSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCephFs {
    /**
    * Monitors is a collection of Ceph monitors. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#monitors PersistentVolume#monitors}
    */
    readonly monitors: string[];
    /**
    * Used as the mounted root, rather than the full Ceph tree, default is /
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#path PersistentVolume#path}
    */
    readonly path?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to `false` (read/write). More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The path to key ring for User, default is `/etc/ceph/user.secret`. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#secret_file PersistentVolume#secret_file}
    */
    readonly secretFile?: string;
    /**
    * User is the rados user name, default is admin. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#user PersistentVolume#user}
    */
    readonly user?: string;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#secret_ref PersistentVolume#secret_ref}
    */
    readonly secretRef?: PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCephFsToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCephFsOutputReference | PersistentVolumeSpecPersistentVolumeSourceCephFs): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCephFsToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCephFsOutputReference | PersistentVolumeSpecPersistentVolumeSourceCephFs): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCephFsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCephFs | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCephFs | undefined);
    private _monitors?;
    get monitors(): string[];
    set monitors(value: string[]);
    get monitorsInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretFile?;
    get secretFile(): string;
    set secretFile(value: string);
    resetSecretFile(): void;
    get secretFileInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _secretRef;
    get secretRef(): PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRefOutputReference;
    putSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): PersistentVolumeSpecPersistentVolumeSourceCephFsSecretRef | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCinder {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write). More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Volume ID used to identify the volume in Cinder. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume_id PersistentVolume#volume_id}
    */
    readonly volumeId: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCinderToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCinderOutputReference | PersistentVolumeSpecPersistentVolumeSourceCinder): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCinderToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCinderOutputReference | PersistentVolumeSpecPersistentVolumeSourceCinder): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCinderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCinder | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCinder | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceCsi {
    /**
    * the name of the volume driver to use. More info: https://kubernetes.io/docs/concepts/storage/volumes/#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#driver PersistentVolume#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Attributes of the volume to publish.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume_attributes PersistentVolume#volume_attributes}
    */
    readonly volumeAttributes?: {
        [key: string]: string;
    };
    /**
    * A string value that uniquely identifies the volume. More info: https://kubernetes.io/docs/concepts/storage/volumes/#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume_handle PersistentVolume#volume_handle}
    */
    readonly volumeHandle: string;
    /**
    * controller_expand_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#controller_expand_secret_ref PersistentVolume#controller_expand_secret_ref}
    */
    readonly controllerExpandSecretRef?: PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef;
    /**
    * controller_publish_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#controller_publish_secret_ref PersistentVolume#controller_publish_secret_ref}
    */
    readonly controllerPublishSecretRef?: PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef;
    /**
    * node_publish_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#node_publish_secret_ref PersistentVolume#node_publish_secret_ref}
    */
    readonly nodePublishSecretRef?: PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef;
    /**
    * node_stage_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#node_stage_secret_ref PersistentVolume#node_stage_secret_ref}
    */
    readonly nodeStageSecretRef?: PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef;
}
export declare function persistentVolumeSpecPersistentVolumeSourceCsiToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsi): any;
export declare function persistentVolumeSpecPersistentVolumeSourceCsiToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceCsiOutputReference | PersistentVolumeSpecPersistentVolumeSourceCsi): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceCsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceCsi | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceCsi | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeAttributes?;
    get volumeAttributes(): {
        [key: string]: string;
    };
    set volumeAttributes(value: {
        [key: string]: string;
    });
    resetVolumeAttributes(): void;
    get volumeAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _volumeHandle?;
    get volumeHandle(): string;
    set volumeHandle(value: string);
    get volumeHandleInput(): string | undefined;
    private _controllerExpandSecretRef;
    get controllerExpandSecretRef(): PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference;
    putControllerExpandSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef): void;
    resetControllerExpandSecretRef(): void;
    get controllerExpandSecretRefInput(): PersistentVolumeSpecPersistentVolumeSourceCsiControllerExpandSecretRef | undefined;
    private _controllerPublishSecretRef;
    get controllerPublishSecretRef(): PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference;
    putControllerPublishSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef): void;
    resetControllerPublishSecretRef(): void;
    get controllerPublishSecretRefInput(): PersistentVolumeSpecPersistentVolumeSourceCsiControllerPublishSecretRef | undefined;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference;
    putNodePublishSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef): void;
    resetNodePublishSecretRef(): void;
    get nodePublishSecretRefInput(): PersistentVolumeSpecPersistentVolumeSourceCsiNodePublishSecretRef | undefined;
    private _nodeStageSecretRef;
    get nodeStageSecretRef(): PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference;
    putNodeStageSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef): void;
    resetNodeStageSecretRef(): void;
    get nodeStageSecretRefInput(): PersistentVolumeSpecPersistentVolumeSourceCsiNodeStageSecretRef | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceFc {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * FC target lun number
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#lun PersistentVolume#lun}
    */
    readonly lun: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * FC target worldwide names (WWNs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#target_ww_ns PersistentVolume#target_ww_ns}
    */
    readonly targetWwNs: string[];
}
export declare function persistentVolumeSpecPersistentVolumeSourceFcToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFcOutputReference | PersistentVolumeSpecPersistentVolumeSourceFc): any;
export declare function persistentVolumeSpecPersistentVolumeSourceFcToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFcOutputReference | PersistentVolumeSpecPersistentVolumeSourceFc): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceFcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceFc | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceFc | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetWwNs?;
    get targetWwNs(): string[];
    set targetWwNs(value: string[]);
    get targetWwNsInput(): string[] | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceFlexVolume {
    /**
    * Driver is the name of the driver to use for this volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#driver PersistentVolume#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". The default filesystem depends on FlexVolume script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * Extra command options if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#options PersistentVolume#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#secret_ref PersistentVolume#secret_ref}
    */
    readonly secretRef?: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef;
}
export declare function persistentVolumeSpecPersistentVolumeSourceFlexVolumeToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeOutputReference | PersistentVolumeSpecPersistentVolumeSourceFlexVolume): any;
export declare function persistentVolumeSpecPersistentVolumeSourceFlexVolumeToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeOutputReference | PersistentVolumeSpecPersistentVolumeSourceFlexVolume): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceFlexVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceFlexVolume | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceFlexVolume | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference;
    putSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): PersistentVolumeSpecPersistentVolumeSourceFlexVolumeSecretRef | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceFlocker {
    /**
    * Name of the dataset stored as metadata -> name on the dataset for Flocker should be considered as deprecated
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#dataset_name PersistentVolume#dataset_name}
    */
    readonly datasetName?: string;
    /**
    * UUID of the dataset. This is unique identifier of a Flocker dataset
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#dataset_uuid PersistentVolume#dataset_uuid}
    */
    readonly datasetUuid?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceFlockerToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFlockerOutputReference | PersistentVolumeSpecPersistentVolumeSourceFlocker): any;
export declare function persistentVolumeSpecPersistentVolumeSourceFlockerToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceFlockerOutputReference | PersistentVolumeSpecPersistentVolumeSourceFlocker): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceFlockerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceFlocker | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceFlocker | undefined);
    private _datasetName?;
    get datasetName(): string;
    set datasetName(value: string);
    resetDatasetName(): void;
    get datasetNameInput(): string | undefined;
    private _datasetUuid?;
    get datasetUuid(): string;
    set datasetUuid(value: string);
    resetDatasetUuid(): void;
    get datasetUuidInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty). More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#partition PersistentVolume#partition}
    */
    readonly partition?: number;
    /**
    * Unique name of the PD resource in GCE. Used to identify the disk in GCE. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#pd_name PersistentVolume#pd_name}
    */
    readonly pdName: string;
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function persistentVolumeSpecPersistentVolumeSourceGcePersistentDiskToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceGcePersistentDiskOutputReference | PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk): any;
export declare function persistentVolumeSpecPersistentVolumeSourceGcePersistentDiskToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceGcePersistentDiskOutputReference | PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceGcePersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _pdName?;
    get pdName(): string;
    set pdName(value: string);
    get pdNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceGlusterfs {
    /**
    * The endpoint name that details Glusterfs topology. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#endpoints_name PersistentVolume#endpoints_name}
    */
    readonly endpointsName: string;
    /**
    * The Glusterfs volume path. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#path PersistentVolume#path}
    */
    readonly path: string;
    /**
    * Whether to force the Glusterfs volume to be mounted with read-only permissions. Defaults to false. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function persistentVolumeSpecPersistentVolumeSourceGlusterfsToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceGlusterfsOutputReference | PersistentVolumeSpecPersistentVolumeSourceGlusterfs): any;
export declare function persistentVolumeSpecPersistentVolumeSourceGlusterfsToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceGlusterfsOutputReference | PersistentVolumeSpecPersistentVolumeSourceGlusterfs): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceGlusterfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceGlusterfs | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceGlusterfs | undefined);
    private _endpointsName?;
    get endpointsName(): string;
    set endpointsName(value: string);
    get endpointsNameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceHostPath {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#hostpath
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#path PersistentVolume#path}
    */
    readonly path?: string;
    /**
    * Type for HostPath volume. Allowed values are "" (default), DirectoryOrCreate, Directory, FileOrCreate, File, Socket, CharDevice and BlockDevice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#type PersistentVolume#type}
    */
    readonly type?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceHostPathToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceHostPathOutputReference | PersistentVolumeSpecPersistentVolumeSourceHostPath): any;
export declare function persistentVolumeSpecPersistentVolumeSourceHostPathToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceHostPathOutputReference | PersistentVolumeSpecPersistentVolumeSourceHostPath): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceHostPath | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceHostPath | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceIscsi {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#iscsi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * Target iSCSI Qualified Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#iqn PersistentVolume#iqn}
    */
    readonly iqn: string;
    /**
    * iSCSI interface name that uses an iSCSI transport. Defaults to 'default' (tcp).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#iscsi_interface PersistentVolume#iscsi_interface}
    */
    readonly iscsiInterface?: string;
    /**
    * iSCSI target lun number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#lun PersistentVolume#lun}
    */
    readonly lun?: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * iSCSI target portal. The portal is either an IP or ip_addr:port if the port is other than default (typically TCP ports 860 and 3260).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#target_portal PersistentVolume#target_portal}
    */
    readonly targetPortal: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceIscsiToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceIscsiOutputReference | PersistentVolumeSpecPersistentVolumeSourceIscsi): any;
export declare function persistentVolumeSpecPersistentVolumeSourceIscsiToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceIscsiOutputReference | PersistentVolumeSpecPersistentVolumeSourceIscsi): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceIscsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceIscsi | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceIscsi | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _iqn?;
    get iqn(): string;
    set iqn(value: string);
    get iqnInput(): string | undefined;
    private _iscsiInterface?;
    get iscsiInterface(): string;
    set iscsiInterface(value: string);
    resetIscsiInterface(): void;
    get iscsiInterfaceInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    resetLun(): void;
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetPortal?;
    get targetPortal(): string;
    set targetPortal(value: string);
    get targetPortalInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceLocal {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#local
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#path PersistentVolume#path}
    */
    readonly path?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceLocalToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceLocalOutputReference | PersistentVolumeSpecPersistentVolumeSourceLocal): any;
export declare function persistentVolumeSpecPersistentVolumeSourceLocalToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceLocalOutputReference | PersistentVolumeSpecPersistentVolumeSourceLocal): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceLocalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceLocal | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceLocal | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceNfs {
    /**
    * Path that is exported by the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#path PersistentVolume#path}
    */
    readonly path: string;
    /**
    * Whether to force the NFS export to be mounted with read-only permissions. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Server is the hostname or IP address of the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#server PersistentVolume#server}
    */
    readonly server: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceNfsToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceNfsOutputReference | PersistentVolumeSpecPersistentVolumeSourceNfs): any;
export declare function persistentVolumeSpecPersistentVolumeSourceNfsToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceNfsOutputReference | PersistentVolumeSpecPersistentVolumeSourceNfs): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceNfs | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * ID that identifies Photon Controller persistent disk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#pd_id PersistentVolume#pd_id}
    */
    readonly pdId: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourcePhotonPersistentDiskToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDiskOutputReference | PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk): any;
export declare function persistentVolumeSpecPersistentVolumeSourcePhotonPersistentDiskToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDiskOutputReference | PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk): any;
export declare class PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _pdId?;
    get pdId(): string;
    set pdId(value: string);
    get pdIdInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceQuobyte {
    /**
    * Group to map volume access to Default is no group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#group PersistentVolume#group}
    */
    readonly group?: string;
    /**
    * Whether to force the Quobyte volume to be mounted with read-only permissions. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Registry represents a single or multiple Quobyte Registry services specified as a string as host:port pair (multiple entries are separated with commas) which acts as the central registry for volumes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#registry PersistentVolume#registry}
    */
    readonly registry: string;
    /**
    * User to map volume access to Defaults to serivceaccount user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#user PersistentVolume#user}
    */
    readonly user?: string;
    /**
    * Volume is a string that references an already created Quobyte volume by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume PersistentVolume#volume}
    */
    readonly volume: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceQuobyteToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceQuobyteOutputReference | PersistentVolumeSpecPersistentVolumeSourceQuobyte): any;
export declare function persistentVolumeSpecPersistentVolumeSourceQuobyteToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceQuobyteOutputReference | PersistentVolumeSpecPersistentVolumeSourceQuobyte): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceQuobyteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceQuobyte | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceQuobyte | undefined);
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    get registryInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _volume?;
    get volume(): string;
    set volume(value: string);
    get volumeInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#name PersistentVolume#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#namespace PersistentVolume#namespace}
    */
    readonly namespace?: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceRbdSecretRefToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceRbdSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef): any;
export declare function persistentVolumeSpecPersistentVolumeSourceRbdSecretRefToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceRbdSecretRefOutputReference | PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceRbdSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceRbd {
    /**
    * A collection of Ceph monitors. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#ceph_monitors PersistentVolume#ceph_monitors}
    */
    readonly cephMonitors: string[];
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#rbd
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * Keyring is the path to key ring for RBDUser. Default is /etc/ceph/keyring. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#keyring PersistentVolume#keyring}
    */
    readonly keyring?: string;
    /**
    * The rados user name. Default is admin. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#rados_user PersistentVolume#rados_user}
    */
    readonly radosUser?: string;
    /**
    * The rados image name. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#rbd_image PersistentVolume#rbd_image}
    */
    readonly rbdImage: string;
    /**
    * The rados pool name. Default is rbd. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#rbd_pool PersistentVolume#rbd_pool}
    */
    readonly rbdPool?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#read_only PersistentVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#secret_ref PersistentVolume#secret_ref}
    */
    readonly secretRef?: PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef;
}
export declare function persistentVolumeSpecPersistentVolumeSourceRbdToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceRbdOutputReference | PersistentVolumeSpecPersistentVolumeSourceRbd): any;
export declare function persistentVolumeSpecPersistentVolumeSourceRbdToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceRbdOutputReference | PersistentVolumeSpecPersistentVolumeSourceRbd): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceRbdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceRbd | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceRbd | undefined);
    private _cephMonitors?;
    get cephMonitors(): string[];
    set cephMonitors(value: string[]);
    get cephMonitorsInput(): string[] | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _keyring?;
    get keyring(): string;
    set keyring(value: string);
    resetKeyring(): void;
    get keyringInput(): string | undefined;
    private _radosUser?;
    get radosUser(): string;
    set radosUser(value: string);
    resetRadosUser(): void;
    get radosUserInput(): string | undefined;
    private _rbdImage?;
    get rbdImage(): string;
    set rbdImage(value: string);
    get rbdImageInput(): string | undefined;
    private _rbdPool?;
    get rbdPool(): string;
    set rbdPool(value: string);
    resetRbdPool(): void;
    get rbdPoolInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): PersistentVolumeSpecPersistentVolumeSourceRbdSecretRefOutputReference;
    putSecretRef(value: PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): PersistentVolumeSpecPersistentVolumeSourceRbdSecretRef | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSourceVsphereVolume {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fs_type PersistentVolume#fs_type}
    */
    readonly fsType?: string;
    /**
    * Path that identifies vSphere volume vmdk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume_path PersistentVolume#volume_path}
    */
    readonly volumePath: string;
}
export declare function persistentVolumeSpecPersistentVolumeSourceVsphereVolumeToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceVsphereVolumeOutputReference | PersistentVolumeSpecPersistentVolumeSourceVsphereVolume): any;
export declare function persistentVolumeSpecPersistentVolumeSourceVsphereVolumeToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceVsphereVolumeOutputReference | PersistentVolumeSpecPersistentVolumeSourceVsphereVolume): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceVsphereVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSourceVsphereVolume | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSourceVsphereVolume | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _volumePath?;
    get volumePath(): string;
    set volumePath(value: string);
    get volumePathInput(): string | undefined;
}
export interface PersistentVolumeSpecPersistentVolumeSource {
    /**
    * aws_elastic_block_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#aws_elastic_block_store PersistentVolume#aws_elastic_block_store}
    */
    readonly awsElasticBlockStore?: PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore;
    /**
    * azure_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#azure_disk PersistentVolume#azure_disk}
    */
    readonly azureDisk?: PersistentVolumeSpecPersistentVolumeSourceAzureDisk;
    /**
    * azure_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#azure_file PersistentVolume#azure_file}
    */
    readonly azureFile?: PersistentVolumeSpecPersistentVolumeSourceAzureFile;
    /**
    * ceph_fs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#ceph_fs PersistentVolume#ceph_fs}
    */
    readonly cephFs?: PersistentVolumeSpecPersistentVolumeSourceCephFs;
    /**
    * cinder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#cinder PersistentVolume#cinder}
    */
    readonly cinder?: PersistentVolumeSpecPersistentVolumeSourceCinder;
    /**
    * csi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#csi PersistentVolume#csi}
    */
    readonly csi?: PersistentVolumeSpecPersistentVolumeSourceCsi;
    /**
    * fc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#fc PersistentVolume#fc}
    */
    readonly fc?: PersistentVolumeSpecPersistentVolumeSourceFc;
    /**
    * flex_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#flex_volume PersistentVolume#flex_volume}
    */
    readonly flexVolume?: PersistentVolumeSpecPersistentVolumeSourceFlexVolume;
    /**
    * flocker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#flocker PersistentVolume#flocker}
    */
    readonly flocker?: PersistentVolumeSpecPersistentVolumeSourceFlocker;
    /**
    * gce_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#gce_persistent_disk PersistentVolume#gce_persistent_disk}
    */
    readonly gcePersistentDisk?: PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk;
    /**
    * glusterfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#glusterfs PersistentVolume#glusterfs}
    */
    readonly glusterfs?: PersistentVolumeSpecPersistentVolumeSourceGlusterfs;
    /**
    * host_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#host_path PersistentVolume#host_path}
    */
    readonly hostPath?: PersistentVolumeSpecPersistentVolumeSourceHostPath;
    /**
    * iscsi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#iscsi PersistentVolume#iscsi}
    */
    readonly iscsi?: PersistentVolumeSpecPersistentVolumeSourceIscsi;
    /**
    * local block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#local PersistentVolume#local}
    */
    readonly local?: PersistentVolumeSpecPersistentVolumeSourceLocal;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#nfs PersistentVolume#nfs}
    */
    readonly nfs?: PersistentVolumeSpecPersistentVolumeSourceNfs;
    /**
    * photon_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#photon_persistent_disk PersistentVolume#photon_persistent_disk}
    */
    readonly photonPersistentDisk?: PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk;
    /**
    * quobyte block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#quobyte PersistentVolume#quobyte}
    */
    readonly quobyte?: PersistentVolumeSpecPersistentVolumeSourceQuobyte;
    /**
    * rbd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#rbd PersistentVolume#rbd}
    */
    readonly rbd?: PersistentVolumeSpecPersistentVolumeSourceRbd;
    /**
    * vsphere_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#vsphere_volume PersistentVolume#vsphere_volume}
    */
    readonly vsphereVolume?: PersistentVolumeSpecPersistentVolumeSourceVsphereVolume;
}
export declare function persistentVolumeSpecPersistentVolumeSourceToTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceOutputReference | PersistentVolumeSpecPersistentVolumeSource): any;
export declare function persistentVolumeSpecPersistentVolumeSourceToHclTerraform(struct?: PersistentVolumeSpecPersistentVolumeSourceOutputReference | PersistentVolumeSpecPersistentVolumeSource): any;
export declare class PersistentVolumeSpecPersistentVolumeSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeSpecPersistentVolumeSource | undefined;
    set internalValue(value: PersistentVolumeSpecPersistentVolumeSource | undefined);
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference;
    putAwsElasticBlockStore(value: PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore): void;
    resetAwsElasticBlockStore(): void;
    get awsElasticBlockStoreInput(): PersistentVolumeSpecPersistentVolumeSourceAwsElasticBlockStore | undefined;
    private _azureDisk;
    get azureDisk(): PersistentVolumeSpecPersistentVolumeSourceAzureDiskOutputReference;
    putAzureDisk(value: PersistentVolumeSpecPersistentVolumeSourceAzureDisk): void;
    resetAzureDisk(): void;
    get azureDiskInput(): PersistentVolumeSpecPersistentVolumeSourceAzureDisk | undefined;
    private _azureFile;
    get azureFile(): PersistentVolumeSpecPersistentVolumeSourceAzureFileOutputReference;
    putAzureFile(value: PersistentVolumeSpecPersistentVolumeSourceAzureFile): void;
    resetAzureFile(): void;
    get azureFileInput(): PersistentVolumeSpecPersistentVolumeSourceAzureFile | undefined;
    private _cephFs;
    get cephFs(): PersistentVolumeSpecPersistentVolumeSourceCephFsOutputReference;
    putCephFs(value: PersistentVolumeSpecPersistentVolumeSourceCephFs): void;
    resetCephFs(): void;
    get cephFsInput(): PersistentVolumeSpecPersistentVolumeSourceCephFs | undefined;
    private _cinder;
    get cinder(): PersistentVolumeSpecPersistentVolumeSourceCinderOutputReference;
    putCinder(value: PersistentVolumeSpecPersistentVolumeSourceCinder): void;
    resetCinder(): void;
    get cinderInput(): PersistentVolumeSpecPersistentVolumeSourceCinder | undefined;
    private _csi;
    get csi(): PersistentVolumeSpecPersistentVolumeSourceCsiOutputReference;
    putCsi(value: PersistentVolumeSpecPersistentVolumeSourceCsi): void;
    resetCsi(): void;
    get csiInput(): PersistentVolumeSpecPersistentVolumeSourceCsi | undefined;
    private _fc;
    get fc(): PersistentVolumeSpecPersistentVolumeSourceFcOutputReference;
    putFc(value: PersistentVolumeSpecPersistentVolumeSourceFc): void;
    resetFc(): void;
    get fcInput(): PersistentVolumeSpecPersistentVolumeSourceFc | undefined;
    private _flexVolume;
    get flexVolume(): PersistentVolumeSpecPersistentVolumeSourceFlexVolumeOutputReference;
    putFlexVolume(value: PersistentVolumeSpecPersistentVolumeSourceFlexVolume): void;
    resetFlexVolume(): void;
    get flexVolumeInput(): PersistentVolumeSpecPersistentVolumeSourceFlexVolume | undefined;
    private _flocker;
    get flocker(): PersistentVolumeSpecPersistentVolumeSourceFlockerOutputReference;
    putFlocker(value: PersistentVolumeSpecPersistentVolumeSourceFlocker): void;
    resetFlocker(): void;
    get flockerInput(): PersistentVolumeSpecPersistentVolumeSourceFlocker | undefined;
    private _gcePersistentDisk;
    get gcePersistentDisk(): PersistentVolumeSpecPersistentVolumeSourceGcePersistentDiskOutputReference;
    putGcePersistentDisk(value: PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk): void;
    resetGcePersistentDisk(): void;
    get gcePersistentDiskInput(): PersistentVolumeSpecPersistentVolumeSourceGcePersistentDisk | undefined;
    private _glusterfs;
    get glusterfs(): PersistentVolumeSpecPersistentVolumeSourceGlusterfsOutputReference;
    putGlusterfs(value: PersistentVolumeSpecPersistentVolumeSourceGlusterfs): void;
    resetGlusterfs(): void;
    get glusterfsInput(): PersistentVolumeSpecPersistentVolumeSourceGlusterfs | undefined;
    private _hostPath;
    get hostPath(): PersistentVolumeSpecPersistentVolumeSourceHostPathOutputReference;
    putHostPath(value: PersistentVolumeSpecPersistentVolumeSourceHostPath): void;
    resetHostPath(): void;
    get hostPathInput(): PersistentVolumeSpecPersistentVolumeSourceHostPath | undefined;
    private _iscsi;
    get iscsi(): PersistentVolumeSpecPersistentVolumeSourceIscsiOutputReference;
    putIscsi(value: PersistentVolumeSpecPersistentVolumeSourceIscsi): void;
    resetIscsi(): void;
    get iscsiInput(): PersistentVolumeSpecPersistentVolumeSourceIscsi | undefined;
    private _local;
    get local(): PersistentVolumeSpecPersistentVolumeSourceLocalOutputReference;
    putLocal(value: PersistentVolumeSpecPersistentVolumeSourceLocal): void;
    resetLocal(): void;
    get localInput(): PersistentVolumeSpecPersistentVolumeSourceLocal | undefined;
    private _nfs;
    get nfs(): PersistentVolumeSpecPersistentVolumeSourceNfsOutputReference;
    putNfs(value: PersistentVolumeSpecPersistentVolumeSourceNfs): void;
    resetNfs(): void;
    get nfsInput(): PersistentVolumeSpecPersistentVolumeSourceNfs | undefined;
    private _photonPersistentDisk;
    get photonPersistentDisk(): PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDiskOutputReference;
    putPhotonPersistentDisk(value: PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk): void;
    resetPhotonPersistentDisk(): void;
    get photonPersistentDiskInput(): PersistentVolumeSpecPersistentVolumeSourcePhotonPersistentDisk | undefined;
    private _quobyte;
    get quobyte(): PersistentVolumeSpecPersistentVolumeSourceQuobyteOutputReference;
    putQuobyte(value: PersistentVolumeSpecPersistentVolumeSourceQuobyte): void;
    resetQuobyte(): void;
    get quobyteInput(): PersistentVolumeSpecPersistentVolumeSourceQuobyte | undefined;
    private _rbd;
    get rbd(): PersistentVolumeSpecPersistentVolumeSourceRbdOutputReference;
    putRbd(value: PersistentVolumeSpecPersistentVolumeSourceRbd): void;
    resetRbd(): void;
    get rbdInput(): PersistentVolumeSpecPersistentVolumeSourceRbd | undefined;
    private _vsphereVolume;
    get vsphereVolume(): PersistentVolumeSpecPersistentVolumeSourceVsphereVolumeOutputReference;
    putVsphereVolume(value: PersistentVolumeSpecPersistentVolumeSourceVsphereVolume): void;
    resetVsphereVolume(): void;
    get vsphereVolumeInput(): PersistentVolumeSpecPersistentVolumeSourceVsphereVolume | undefined;
}
export interface PersistentVolumeSpec {
    /**
    * Contains all ways the volume can be mounted. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#access-modes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#access_modes PersistentVolume#access_modes}
    */
    readonly accessModes: string[];
    /**
    * A description of the persistent volume's resources and capacity. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#capacity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#capacity PersistentVolume#capacity}
    */
    readonly capacity: {
        [key: string]: string;
    };
    /**
    * A list of mount options, e.g. ["ro", "soft"]. Not validated - mount will simply fail if one is invalid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#mount_options PersistentVolume#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * What happens to a persistent volume when released from its claim. Valid options are Retain (default) and Recycle. Recycling must be supported by the volume plugin underlying this persistent volume. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#reclaiming
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#persistent_volume_reclaim_policy PersistentVolume#persistent_volume_reclaim_policy}
    */
    readonly persistentVolumeReclaimPolicy?: string;
    /**
    * A description of the persistent volume's class. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes/#class
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#storage_class_name PersistentVolume#storage_class_name}
    */
    readonly storageClassName?: string;
    /**
    * Defines if a volume is intended to be used with a formatted filesystem. or to remain in raw block state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#volume_mode PersistentVolume#volume_mode}
    */
    readonly volumeMode?: string;
    /**
    * claim_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#claim_ref PersistentVolume#claim_ref}
    */
    readonly claimRef?: PersistentVolumeSpecClaimRef;
    /**
    * node_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#node_affinity PersistentVolume#node_affinity}
    */
    readonly nodeAffinity?: PersistentVolumeSpecNodeAffinity;
    /**
    * persistent_volume_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#persistent_volume_source PersistentVolume#persistent_volume_source}
    */
    readonly persistentVolumeSource: PersistentVolumeSpecPersistentVolumeSource;
}
export declare function persistentVolumeSpecToTerraform(struct?: PersistentVolumeSpec | cdktn.IResolvable): any;
export declare function persistentVolumeSpecToHclTerraform(struct?: PersistentVolumeSpec | cdktn.IResolvable): any;
export declare class PersistentVolumeSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PersistentVolumeSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PersistentVolumeSpec | cdktn.IResolvable | undefined);
    private _accessModes?;
    get accessModes(): string[];
    set accessModes(value: string[]);
    get accessModesInput(): string[] | undefined;
    private _capacity?;
    get capacity(): {
        [key: string]: string;
    };
    set capacity(value: {
        [key: string]: string;
    });
    get capacityInput(): {
        [key: string]: string;
    } | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _persistentVolumeReclaimPolicy?;
    get persistentVolumeReclaimPolicy(): string;
    set persistentVolumeReclaimPolicy(value: string);
    resetPersistentVolumeReclaimPolicy(): void;
    get persistentVolumeReclaimPolicyInput(): string | undefined;
    private _storageClassName?;
    get storageClassName(): string;
    set storageClassName(value: string);
    resetStorageClassName(): void;
    get storageClassNameInput(): string | undefined;
    private _volumeMode?;
    get volumeMode(): string;
    set volumeMode(value: string);
    resetVolumeMode(): void;
    get volumeModeInput(): string | undefined;
    private _claimRef;
    get claimRef(): PersistentVolumeSpecClaimRefOutputReference;
    putClaimRef(value: PersistentVolumeSpecClaimRef): void;
    resetClaimRef(): void;
    get claimRefInput(): PersistentVolumeSpecClaimRef | undefined;
    private _nodeAffinity;
    get nodeAffinity(): PersistentVolumeSpecNodeAffinityOutputReference;
    putNodeAffinity(value: PersistentVolumeSpecNodeAffinity): void;
    resetNodeAffinity(): void;
    get nodeAffinityInput(): PersistentVolumeSpecNodeAffinity | undefined;
    private _persistentVolumeSource;
    get persistentVolumeSource(): PersistentVolumeSpecPersistentVolumeSourceOutputReference;
    putPersistentVolumeSource(value: PersistentVolumeSpecPersistentVolumeSource): void;
    get persistentVolumeSourceInput(): PersistentVolumeSpecPersistentVolumeSource | undefined;
}
export declare class PersistentVolumeSpecList extends cdktn.ComplexList {
    internalValue?: PersistentVolumeSpec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PersistentVolumeSpecOutputReference;
}
export interface PersistentVolumeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#create PersistentVolume#create}
    */
    readonly create?: string;
}
export declare function persistentVolumeTimeoutsToTerraform(struct?: PersistentVolumeTimeouts | cdktn.IResolvable): any;
export declare function persistentVolumeTimeoutsToHclTerraform(struct?: PersistentVolumeTimeouts | cdktn.IResolvable): any;
export declare class PersistentVolumeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PersistentVolumeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PersistentVolumeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume kubernetes_persistent_volume}
*/
export declare class PersistentVolume extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_persistent_volume";
    /**
    * Generates CDKTN code for importing a PersistentVolume resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PersistentVolume to import
    * @param importFromId The id of the existing PersistentVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PersistentVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/persistent_volume kubernetes_persistent_volume} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PersistentVolumeConfig
    */
    constructor(scope: Construct, id: string, config: PersistentVolumeConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): PersistentVolumeMetadataOutputReference;
    putMetadata(value: PersistentVolumeMetadata): void;
    get metadataInput(): PersistentVolumeMetadata | undefined;
    private _spec;
    get spec(): PersistentVolumeSpecList;
    putSpec(value: PersistentVolumeSpec[] | cdktn.IResolvable): void;
    get specInput(): cdktn.IResolvable | PersistentVolumeSpec[] | undefined;
    private _timeouts;
    get timeouts(): PersistentVolumeTimeoutsOutputReference;
    putTimeouts(value: PersistentVolumeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PersistentVolumeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
