/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesEndpointsV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#id DataKubernetesEndpointsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#metadata DataKubernetesEndpointsV1#metadata}
    */
    readonly metadata: DataKubernetesEndpointsV1Metadata;
    /**
    * subset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#subset DataKubernetesEndpointsV1#subset}
    */
    readonly subset?: DataKubernetesEndpointsV1Subset[] | cdktn.IResolvable;
}
export interface DataKubernetesEndpointsV1Metadata {
    /**
    * An unstructured key value map stored with the endpoints that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#annotations DataKubernetesEndpointsV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#generate_name DataKubernetesEndpointsV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the endpoints. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#labels DataKubernetesEndpointsV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the endpoints, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#name DataKubernetesEndpointsV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the endpoints must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#namespace DataKubernetesEndpointsV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesEndpointsV1MetadataToTerraform(struct?: DataKubernetesEndpointsV1MetadataOutputReference | DataKubernetesEndpointsV1Metadata): any;
export declare function dataKubernetesEndpointsV1MetadataToHclTerraform(struct?: DataKubernetesEndpointsV1MetadataOutputReference | DataKubernetesEndpointsV1Metadata): any;
export declare class DataKubernetesEndpointsV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesEndpointsV1Metadata | undefined;
    set internalValue(value: DataKubernetesEndpointsV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface DataKubernetesEndpointsV1SubsetAddress {
    /**
    * The Hostname of this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#hostname DataKubernetesEndpointsV1#hostname}
    */
    readonly hostname?: string;
    /**
    * The IP of this endpoint. May not be loopback (127.0.0.0/8), link-local (169.254.0.0/16), or link-local multicast ((224.0.0.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#ip DataKubernetesEndpointsV1#ip}
    */
    readonly ip: string;
    /**
    * Node hosting this endpoint. This can be used to determine endpoints local to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#node_name DataKubernetesEndpointsV1#node_name}
    */
    readonly nodeName?: string;
}
export declare function dataKubernetesEndpointsV1SubsetAddressToTerraform(struct?: DataKubernetesEndpointsV1SubsetAddress | cdktn.IResolvable): any;
export declare function dataKubernetesEndpointsV1SubsetAddressToHclTerraform(struct?: DataKubernetesEndpointsV1SubsetAddress | cdktn.IResolvable): any;
export declare class DataKubernetesEndpointsV1SubsetAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointsV1SubsetAddress | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesEndpointsV1SubsetAddress | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
}
export declare class DataKubernetesEndpointsV1SubsetAddressList extends cdktn.ComplexList {
    internalValue?: DataKubernetesEndpointsV1SubsetAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointsV1SubsetAddressOutputReference;
}
export interface DataKubernetesEndpointsV1SubsetNotReadyAddress {
    /**
    * The Hostname of this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#hostname DataKubernetesEndpointsV1#hostname}
    */
    readonly hostname?: string;
    /**
    * The IP of this endpoint. May not be loopback (127.0.0.0/8), link-local (169.254.0.0/16), or link-local multicast ((224.0.0.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#ip DataKubernetesEndpointsV1#ip}
    */
    readonly ip: string;
    /**
    * Node hosting this endpoint. This can be used to determine endpoints local to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#node_name DataKubernetesEndpointsV1#node_name}
    */
    readonly nodeName?: string;
}
export declare function dataKubernetesEndpointsV1SubsetNotReadyAddressToTerraform(struct?: DataKubernetesEndpointsV1SubsetNotReadyAddress | cdktn.IResolvable): any;
export declare function dataKubernetesEndpointsV1SubsetNotReadyAddressToHclTerraform(struct?: DataKubernetesEndpointsV1SubsetNotReadyAddress | cdktn.IResolvable): any;
export declare class DataKubernetesEndpointsV1SubsetNotReadyAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointsV1SubsetNotReadyAddress | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesEndpointsV1SubsetNotReadyAddress | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
}
export declare class DataKubernetesEndpointsV1SubsetNotReadyAddressList extends cdktn.ComplexList {
    internalValue?: DataKubernetesEndpointsV1SubsetNotReadyAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointsV1SubsetNotReadyAddressOutputReference;
}
export interface DataKubernetesEndpointsV1SubsetPort {
    /**
    * The name of this port within the endpoint. Must be a DNS_LABEL. Optional if only one Port is defined on this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#name DataKubernetesEndpointsV1#name}
    */
    readonly name?: string;
    /**
    * The port that will be exposed by this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#port DataKubernetesEndpointsV1#port}
    */
    readonly port: number;
    /**
    * The IP protocol for this port. Supports `TCP` and `UDP`. Default is `TCP`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#protocol DataKubernetesEndpointsV1#protocol}
    */
    readonly protocol?: string;
}
export declare function dataKubernetesEndpointsV1SubsetPortToTerraform(struct?: DataKubernetesEndpointsV1SubsetPort | cdktn.IResolvable): any;
export declare function dataKubernetesEndpointsV1SubsetPortToHclTerraform(struct?: DataKubernetesEndpointsV1SubsetPort | cdktn.IResolvable): any;
export declare class DataKubernetesEndpointsV1SubsetPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointsV1SubsetPort | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesEndpointsV1SubsetPort | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class DataKubernetesEndpointsV1SubsetPortList extends cdktn.ComplexList {
    internalValue?: DataKubernetesEndpointsV1SubsetPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointsV1SubsetPortOutputReference;
}
export interface DataKubernetesEndpointsV1Subset {
    /**
    * address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#address DataKubernetesEndpointsV1#address}
    */
    readonly address?: DataKubernetesEndpointsV1SubsetAddress[] | cdktn.IResolvable;
    /**
    * not_ready_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#not_ready_address DataKubernetesEndpointsV1#not_ready_address}
    */
    readonly notReadyAddress?: DataKubernetesEndpointsV1SubsetNotReadyAddress[] | cdktn.IResolvable;
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#port DataKubernetesEndpointsV1#port}
    */
    readonly port?: DataKubernetesEndpointsV1SubsetPort[] | cdktn.IResolvable;
}
export declare function dataKubernetesEndpointsV1SubsetToTerraform(struct?: DataKubernetesEndpointsV1Subset | cdktn.IResolvable): any;
export declare function dataKubernetesEndpointsV1SubsetToHclTerraform(struct?: DataKubernetesEndpointsV1Subset | cdktn.IResolvable): any;
export declare class DataKubernetesEndpointsV1SubsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointsV1Subset | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesEndpointsV1Subset | cdktn.IResolvable | undefined);
    private _address;
    get address(): DataKubernetesEndpointsV1SubsetAddressList;
    putAddress(value: DataKubernetesEndpointsV1SubsetAddress[] | cdktn.IResolvable): void;
    resetAddress(): void;
    get addressInput(): cdktn.IResolvable | DataKubernetesEndpointsV1SubsetAddress[] | undefined;
    private _notReadyAddress;
    get notReadyAddress(): DataKubernetesEndpointsV1SubsetNotReadyAddressList;
    putNotReadyAddress(value: DataKubernetesEndpointsV1SubsetNotReadyAddress[] | cdktn.IResolvable): void;
    resetNotReadyAddress(): void;
    get notReadyAddressInput(): cdktn.IResolvable | DataKubernetesEndpointsV1SubsetNotReadyAddress[] | undefined;
    private _port;
    get port(): DataKubernetesEndpointsV1SubsetPortList;
    putPort(value: DataKubernetesEndpointsV1SubsetPort[] | cdktn.IResolvable): void;
    resetPort(): void;
    get portInput(): cdktn.IResolvable | DataKubernetesEndpointsV1SubsetPort[] | undefined;
}
export declare class DataKubernetesEndpointsV1SubsetList extends cdktn.ComplexList {
    internalValue?: DataKubernetesEndpointsV1Subset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointsV1SubsetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1 kubernetes_endpoints_v1}
*/
export declare class DataKubernetesEndpointsV1 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_endpoints_v1";
    /**
    * Generates CDKTN code for importing a DataKubernetesEndpointsV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesEndpointsV1 to import
    * @param importFromId The id of the existing DataKubernetesEndpointsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesEndpointsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/endpoints_v1 kubernetes_endpoints_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesEndpointsV1Config
    */
    constructor(scope: Construct, id: string, config: DataKubernetesEndpointsV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): DataKubernetesEndpointsV1MetadataOutputReference;
    putMetadata(value: DataKubernetesEndpointsV1Metadata): void;
    get metadataInput(): DataKubernetesEndpointsV1Metadata | undefined;
    private _subset;
    get subset(): DataKubernetesEndpointsV1SubsetList;
    putSubset(value: DataKubernetesEndpointsV1Subset[] | cdktn.IResolvable): void;
    resetSubset(): void;
    get subsetInput(): cdktn.IResolvable | DataKubernetesEndpointsV1Subset[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
