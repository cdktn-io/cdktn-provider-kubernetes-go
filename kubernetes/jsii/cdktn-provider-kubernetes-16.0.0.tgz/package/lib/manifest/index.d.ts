/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ManifestConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of manifest fields whose values can be altered by the API server during 'apply'. Defaults to: ["metadata.annotations", "metadata.labels"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#computed_fields Manifest#computed_fields}
    */
    readonly computedFields?: string[];
    /**
    * A Kubernetes manifest describing the desired state of the resource in HCL format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#manifest Manifest#manifest}
    */
    readonly manifest: {
        [key: string]: any;
    };
    /**
    * The resulting resource state, as returned by the API server after applying the desired state from `manifest`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#object Manifest#object}
    */
    readonly object?: {
        [key: string]: any;
    };
    /**
    * A map of attribute paths and desired patterns to be matched. After each apply the provider will wait for all attributes listed here to reach a value that matches the desired pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#wait_for Manifest#wait_for}
    */
    readonly waitFor?: ManifestWaitFor;
    /**
    * field_manager block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#field_manager Manifest#field_manager}
    */
    readonly fieldManager?: ManifestFieldManager;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#timeouts Manifest#timeouts}
    */
    readonly timeouts?: ManifestTimeouts;
    /**
    * wait block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#wait Manifest#wait}
    */
    readonly wait?: ManifestWait;
}
export interface ManifestWaitFor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#fields Manifest#fields}
    */
    readonly fields?: {
        [key: string]: string;
    };
}
export declare function manifestWaitForToTerraform(struct?: ManifestWaitFor | cdktn.IResolvable): any;
export declare function manifestWaitForToHclTerraform(struct?: ManifestWaitFor | cdktn.IResolvable): any;
export declare class ManifestWaitForOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ManifestWaitFor | cdktn.IResolvable | undefined;
    set internalValue(value: ManifestWaitFor | cdktn.IResolvable | undefined);
    private _fields?;
    get fields(): {
        [key: string]: string;
    };
    set fields(value: {
        [key: string]: string;
    });
    resetFields(): void;
    get fieldsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ManifestFieldManager {
    /**
    * Force changes against conflicts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#force_conflicts Manifest#force_conflicts}
    */
    readonly forceConflicts?: boolean | cdktn.IResolvable;
    /**
    * The name to use for the field manager when creating and updating the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#name Manifest#name}
    */
    readonly name?: string;
}
export declare function manifestFieldManagerToTerraform(struct?: ManifestFieldManagerOutputReference | ManifestFieldManager): any;
export declare function manifestFieldManagerToHclTerraform(struct?: ManifestFieldManagerOutputReference | ManifestFieldManager): any;
export declare class ManifestFieldManagerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ManifestFieldManager | undefined;
    set internalValue(value: ManifestFieldManager | undefined);
    private _forceConflicts?;
    get forceConflicts(): boolean | cdktn.IResolvable;
    set forceConflicts(value: boolean | cdktn.IResolvable);
    resetForceConflicts(): void;
    get forceConflictsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ManifestTimeouts {
    /**
    * Timeout for the create operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#create Manifest#create}
    */
    readonly create?: string;
    /**
    * Timeout for the delete operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#delete Manifest#delete}
    */
    readonly delete?: string;
    /**
    * Timeout for the update operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#update Manifest#update}
    */
    readonly update?: string;
}
export declare function manifestTimeoutsToTerraform(struct?: ManifestTimeoutsOutputReference | ManifestTimeouts): any;
export declare function manifestTimeoutsToHclTerraform(struct?: ManifestTimeoutsOutputReference | ManifestTimeouts): any;
export declare class ManifestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ManifestTimeouts | undefined;
    set internalValue(value: ManifestTimeouts | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ManifestWaitCondition {
    /**
    * The condition status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#status Manifest#status}
    */
    readonly status?: string;
    /**
    * The type of condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#type Manifest#type}
    */
    readonly type?: string;
}
export declare function manifestWaitConditionToTerraform(struct?: ManifestWaitCondition | cdktn.IResolvable): any;
export declare function manifestWaitConditionToHclTerraform(struct?: ManifestWaitCondition | cdktn.IResolvable): any;
export declare class ManifestWaitConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ManifestWaitCondition | cdktn.IResolvable | undefined;
    set internalValue(value: ManifestWaitCondition | cdktn.IResolvable | undefined);
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ManifestWaitConditionList extends cdktn.ComplexList {
    internalValue?: ManifestWaitCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ManifestWaitConditionOutputReference;
}
export interface ManifestWait {
    /**
    * A map of paths to fields to wait for a specific field value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#fields Manifest#fields}
    */
    readonly fields?: {
        [key: string]: string;
    };
    /**
    * Wait for rollout to complete on resources that support `kubectl rollout status`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#rollout Manifest#rollout}
    */
    readonly rollout?: boolean | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#condition Manifest#condition}
    */
    readonly condition?: ManifestWaitCondition[] | cdktn.IResolvable;
}
export declare function manifestWaitToTerraform(struct?: ManifestWaitOutputReference | ManifestWait): any;
export declare function manifestWaitToHclTerraform(struct?: ManifestWaitOutputReference | ManifestWait): any;
export declare class ManifestWaitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ManifestWait | undefined;
    set internalValue(value: ManifestWait | undefined);
    private _fields?;
    get fields(): {
        [key: string]: string;
    };
    set fields(value: {
        [key: string]: string;
    });
    resetFields(): void;
    get fieldsInput(): {
        [key: string]: string;
    } | undefined;
    private _rollout?;
    get rollout(): boolean | cdktn.IResolvable;
    set rollout(value: boolean | cdktn.IResolvable);
    resetRollout(): void;
    get rolloutInput(): boolean | cdktn.IResolvable | undefined;
    private _condition;
    get condition(): ManifestWaitConditionList;
    putCondition(value: ManifestWaitCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | ManifestWaitCondition[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest kubernetes_manifest}
*/
export declare class Manifest extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_manifest";
    /**
    * Generates CDKTN code for importing a Manifest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Manifest to import
    * @param importFromId The id of the existing Manifest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Manifest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/manifest kubernetes_manifest} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ManifestConfig
    */
    constructor(scope: Construct, id: string, config: ManifestConfig);
    private _computedFields?;
    get computedFields(): string[];
    set computedFields(value: string[]);
    resetComputedFields(): void;
    get computedFieldsInput(): string[] | undefined;
    private _manifest?;
    get manifest(): {
        [key: string]: any;
    };
    set manifest(value: {
        [key: string]: any;
    });
    get manifestInput(): {
        [key: string]: any;
    } | undefined;
    private _object?;
    get object(): {
        [key: string]: any;
    };
    set object(value: {
        [key: string]: any;
    });
    resetObject(): void;
    get objectInput(): {
        [key: string]: any;
    } | undefined;
    private _waitFor;
    get waitFor(): ManifestWaitForOutputReference;
    putWaitFor(value: ManifestWaitFor): void;
    resetWaitFor(): void;
    get waitForInput(): cdktn.IResolvable | ManifestWaitFor | undefined;
    private _fieldManager;
    get fieldManager(): ManifestFieldManagerOutputReference;
    putFieldManager(value: ManifestFieldManager): void;
    resetFieldManager(): void;
    get fieldManagerInput(): ManifestFieldManager | undefined;
    private _timeouts;
    get timeouts(): ManifestTimeoutsOutputReference;
    putTimeouts(value: ManifestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): ManifestTimeouts | undefined;
    private _wait;
    get wait(): ManifestWaitOutputReference;
    putWait(value: ManifestWait): void;
    resetWait(): void;
    get waitInput(): ManifestWait | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
