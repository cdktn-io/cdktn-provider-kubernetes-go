/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificateSigningRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Automatically approve the CertificateSigningRequest
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#auto_approve CertificateSigningRequest#auto_approve}
    */
    readonly autoApprove?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#id CertificateSigningRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#metadata CertificateSigningRequest#metadata}
    */
    readonly metadata: CertificateSigningRequestMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#spec CertificateSigningRequest#spec}
    */
    readonly spec: CertificateSigningRequestSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#timeouts CertificateSigningRequest#timeouts}
    */
    readonly timeouts?: CertificateSigningRequestTimeouts;
}
export interface CertificateSigningRequestMetadata {
    /**
    * An unstructured key value map stored with the certificate signing request that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#annotations CertificateSigningRequest#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#generate_name CertificateSigningRequest#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the certificate signing request. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#labels CertificateSigningRequest#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the certificate signing request, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#name CertificateSigningRequest#name}
    */
    readonly name?: string;
}
export declare function certificateSigningRequestMetadataToTerraform(struct?: CertificateSigningRequestMetadataOutputReference | CertificateSigningRequestMetadata): any;
export declare function certificateSigningRequestMetadataToHclTerraform(struct?: CertificateSigningRequestMetadataOutputReference | CertificateSigningRequestMetadata): any;
export declare class CertificateSigningRequestMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateSigningRequestMetadata | undefined;
    set internalValue(value: CertificateSigningRequestMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface CertificateSigningRequestSpec {
    /**
    * Base64-encoded PKCS#10 CSR data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#request CertificateSigningRequest#request}
    */
    readonly request: string;
    /**
    * Requested signer for the request. It is a qualified name in the form: `scope-hostname.io/name`.If empty, it will be defaulted: 1. If it's a kubelet client certificate, it is assigned `kubernetes.io/kube-apiserver-client-kubelet`.2. If it's a kubelet serving certificate, it is assigned `kubernetes.io/kubelet-serving`.3. Otherwise, it is assigned `kubernetes.io/legacy-unknown`. Distribution of trust for signers happens out of band.You can select on this field using `spec.signerName`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#signer_name CertificateSigningRequest#signer_name}
    */
    readonly signerName?: string;
    /**
    * allowedUsages specifies a set of usage contexts the key will be valid for. See:
    * 	https://tools.ietf.org/html/rfc5280#section-4.2.1.3
    * 	https://tools.ietf.org/html/rfc5280#section-4.2.1.12
    *
    * Valid values are:
    *  "signing",
    *  "digital signature",
    *  "content commitment",
    *  "key encipherment",
    *  "key agreement",
    *  "data encipherment",
    *  "cert sign",
    *  "crl sign",
    *  "encipher only",
    *  "decipher only",
    *  "any",
    *  "server auth",
    *  "client auth",
    *  "code signing",
    *  "email protection",
    *  "s/mime",
    *  "ipsec end system",
    *  "ipsec tunnel",
    *  "ipsec user",
    *  "timestamping",
    *  "ocsp signing",
    *  "microsoft sgc",
    *  "netscape sgc"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#usages CertificateSigningRequest#usages}
    */
    readonly usages?: string[];
}
export declare function certificateSigningRequestSpecToTerraform(struct?: CertificateSigningRequestSpecOutputReference | CertificateSigningRequestSpec): any;
export declare function certificateSigningRequestSpecToHclTerraform(struct?: CertificateSigningRequestSpecOutputReference | CertificateSigningRequestSpec): any;
export declare class CertificateSigningRequestSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateSigningRequestSpec | undefined;
    set internalValue(value: CertificateSigningRequestSpec | undefined);
    private _request?;
    get request(): string;
    set request(value: string);
    get requestInput(): string | undefined;
    private _signerName?;
    get signerName(): string;
    set signerName(value: string);
    resetSignerName(): void;
    get signerNameInput(): string | undefined;
    private _usages?;
    get usages(): string[];
    set usages(value: string[]);
    resetUsages(): void;
    get usagesInput(): string[] | undefined;
}
export interface CertificateSigningRequestTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#create CertificateSigningRequest#create}
    */
    readonly create?: string;
}
export declare function certificateSigningRequestTimeoutsToTerraform(struct?: CertificateSigningRequestTimeouts | cdktn.IResolvable): any;
export declare function certificateSigningRequestTimeoutsToHclTerraform(struct?: CertificateSigningRequestTimeouts | cdktn.IResolvable): any;
export declare class CertificateSigningRequestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificateSigningRequestTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CertificateSigningRequestTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request kubernetes_certificate_signing_request}
*/
export declare class CertificateSigningRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_certificate_signing_request";
    /**
    * Generates CDKTN code for importing a CertificateSigningRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificateSigningRequest to import
    * @param importFromId The id of the existing CertificateSigningRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificateSigningRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/certificate_signing_request kubernetes_certificate_signing_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificateSigningRequestConfig
    */
    constructor(scope: Construct, id: string, config: CertificateSigningRequestConfig);
    private _autoApprove?;
    get autoApprove(): boolean | cdktn.IResolvable;
    set autoApprove(value: boolean | cdktn.IResolvable);
    resetAutoApprove(): void;
    get autoApproveInput(): boolean | cdktn.IResolvable | undefined;
    get certificate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): CertificateSigningRequestMetadataOutputReference;
    putMetadata(value: CertificateSigningRequestMetadata): void;
    get metadataInput(): CertificateSigningRequestMetadata | undefined;
    private _spec;
    get spec(): CertificateSigningRequestSpecOutputReference;
    putSpec(value: CertificateSigningRequestSpec): void;
    get specInput(): CertificateSigningRequestSpec | undefined;
    private _timeouts;
    get timeouts(): CertificateSigningRequestTimeoutsOutputReference;
    putTimeouts(value: CertificateSigningRequestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CertificateSigningRequestTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
