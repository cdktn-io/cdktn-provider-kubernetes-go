/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TokenRequestV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#id TokenRequestV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#metadata TokenRequestV1#metadata}
    */
    readonly metadata: TokenRequestV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#spec TokenRequestV1#spec}
    */
    readonly spec?: TokenRequestV1Spec;
}
export interface TokenRequestV1Metadata {
    /**
    * An unstructured key value map stored with the token request that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#annotations TokenRequestV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#generate_name TokenRequestV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the token request. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#labels TokenRequestV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the token request, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#name TokenRequestV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the token request must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#namespace TokenRequestV1#namespace}
    */
    readonly namespace?: string;
}
export declare function tokenRequestV1MetadataToTerraform(struct?: TokenRequestV1MetadataOutputReference | TokenRequestV1Metadata): any;
export declare function tokenRequestV1MetadataToHclTerraform(struct?: TokenRequestV1MetadataOutputReference | TokenRequestV1Metadata): any;
export declare class TokenRequestV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TokenRequestV1Metadata | undefined;
    set internalValue(value: TokenRequestV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface TokenRequestV1SpecBoundObjectRef {
    /**
    * API version of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#api_version TokenRequestV1#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Kind of the referent. Valid kinds are 'Pod' and 'Secret'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#kind TokenRequestV1#kind}
    */
    readonly kind?: string;
    /**
    * Name of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#name TokenRequestV1#name}
    */
    readonly name?: string;
    /**
    * UID of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#uid TokenRequestV1#uid}
    */
    readonly uid?: string;
}
export declare function tokenRequestV1SpecBoundObjectRefToTerraform(struct?: TokenRequestV1SpecBoundObjectRefOutputReference | TokenRequestV1SpecBoundObjectRef): any;
export declare function tokenRequestV1SpecBoundObjectRefToHclTerraform(struct?: TokenRequestV1SpecBoundObjectRefOutputReference | TokenRequestV1SpecBoundObjectRef): any;
export declare class TokenRequestV1SpecBoundObjectRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TokenRequestV1SpecBoundObjectRef | undefined;
    set internalValue(value: TokenRequestV1SpecBoundObjectRef | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _uid?;
    get uid(): string;
    set uid(value: string);
    resetUid(): void;
    get uidInput(): string | undefined;
}
export interface TokenRequestV1Spec {
    /**
    * Audiences are the intendend audiences of the token. A recipient of a token must identify themself with an identifier in the list of audiences of the token, and otherwise should reject the token. A token issued for multiple audiences may be used to authenticate against any of the audiences listed but implies a high degree of trust between the target audiences.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#audiences TokenRequestV1#audiences}
    */
    readonly audiences?: string[];
    /**
    * expiration_seconds is the requested duration of validity of the request. The token issuer may return a token with a different validity duration so a client needs to check the 'expiration' field in a response. The expiration can't be less than 10 minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#expiration_seconds TokenRequestV1#expiration_seconds}
    */
    readonly expirationSeconds?: number;
    /**
    * bound_object_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#bound_object_ref TokenRequestV1#bound_object_ref}
    */
    readonly boundObjectRef?: TokenRequestV1SpecBoundObjectRef;
}
export declare function tokenRequestV1SpecToTerraform(struct?: TokenRequestV1SpecOutputReference | TokenRequestV1Spec): any;
export declare function tokenRequestV1SpecToHclTerraform(struct?: TokenRequestV1SpecOutputReference | TokenRequestV1Spec): any;
export declare class TokenRequestV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TokenRequestV1Spec | undefined;
    set internalValue(value: TokenRequestV1Spec | undefined);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _expirationSeconds?;
    get expirationSeconds(): number;
    set expirationSeconds(value: number);
    resetExpirationSeconds(): void;
    get expirationSecondsInput(): number | undefined;
    private _boundObjectRef;
    get boundObjectRef(): TokenRequestV1SpecBoundObjectRefOutputReference;
    putBoundObjectRef(value: TokenRequestV1SpecBoundObjectRef): void;
    resetBoundObjectRef(): void;
    get boundObjectRefInput(): TokenRequestV1SpecBoundObjectRef | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1 kubernetes_token_request_v1}
*/
export declare class TokenRequestV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_token_request_v1";
    /**
    * Generates CDKTN code for importing a TokenRequestV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TokenRequestV1 to import
    * @param importFromId The id of the existing TokenRequestV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TokenRequestV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/token_request_v1 kubernetes_token_request_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TokenRequestV1Config
    */
    constructor(scope: Construct, id: string, config: TokenRequestV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get token(): string;
    private _metadata;
    get metadata(): TokenRequestV1MetadataOutputReference;
    putMetadata(value: TokenRequestV1Metadata): void;
    get metadataInput(): TokenRequestV1Metadata | undefined;
    private _spec;
    get spec(): TokenRequestV1SpecOutputReference;
    putSpec(value: TokenRequestV1Spec): void;
    resetSpec(): void;
    get specInput(): TokenRequestV1Spec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
