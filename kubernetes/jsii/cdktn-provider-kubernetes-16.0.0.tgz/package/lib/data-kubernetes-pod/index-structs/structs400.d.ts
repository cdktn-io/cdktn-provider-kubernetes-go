/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataKubernetesPodSpecInitContainerLifecyclePreStopExecList, DataKubernetesPodSpecInitContainerLifecyclePostStartList, DataKubernetesPodSpecInitContainerEnvList, DataKubernetesPodSpecInitContainerEnvFromList, DataKubernetesPodSpecAffinityList, DataKubernetesPodSpecContainerList, DataKubernetesPodSpecDnsConfigList, DataKubernetesPodSpecHostAliasesList, DataKubernetesPodSpecImagePullSecretsList } from './structs0';
export interface DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGet {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGet): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGet): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocket {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocketToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocket): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocket): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePreStop {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStop): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStop): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePreStop | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePreStop | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecInitContainerLifecyclePreStopExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecInitContainerLifecyclePreStopHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecInitContainerLifecyclePreStopTcpSocketList;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePreStopOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecycle {
}
export declare function dataKubernetesPodSpecInitContainerLifecycleToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecycle): any;
export declare function dataKubernetesPodSpecInitContainerLifecycleToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecycle): any;
export declare class DataKubernetesPodSpecInitContainerLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecycle | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecycle | undefined);
    private _postStart;
    get postStart(): DataKubernetesPodSpecInitContainerLifecyclePostStartList;
    private _preStop;
    get preStop(): DataKubernetesPodSpecInitContainerLifecyclePreStopList;
}
export declare class DataKubernetesPodSpecInitContainerLifecycleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecycleOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLivenessProbeExec {
}
export declare function dataKubernetesPodSpecInitContainerLivenessProbeExecToTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeExec): any;
export declare function dataKubernetesPodSpecInitContainerLivenessProbeExecToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeExec): any;
export declare class DataKubernetesPodSpecInitContainerLivenessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLivenessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLivenessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecInitContainerLivenessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLivenessProbeExecOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLivenessProbeGrpc {
}
export declare function dataKubernetesPodSpecInitContainerLivenessProbeGrpcToTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeGrpc): any;
export declare function dataKubernetesPodSpecInitContainerLivenessProbeGrpcToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeGrpc): any;
export declare class DataKubernetesPodSpecInitContainerLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLivenessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLivenessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodSpecInitContainerLivenessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLivenessProbeGrpcOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLivenessProbeHttpGet {
}
export declare function dataKubernetesPodSpecInitContainerLivenessProbeHttpGetToTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeHttpGet): any;
export declare function dataKubernetesPodSpecInitContainerLivenessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeHttpGet): any;
export declare class DataKubernetesPodSpecInitContainerLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLivenessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLivenessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecInitContainerLivenessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecInitContainerLivenessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLivenessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLivenessProbeTcpSocket {
}
export declare function dataKubernetesPodSpecInitContainerLivenessProbeTcpSocketToTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeTcpSocket): any;
export declare function dataKubernetesPodSpecInitContainerLivenessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbeTcpSocket): any;
export declare class DataKubernetesPodSpecInitContainerLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLivenessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLivenessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecInitContainerLivenessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLivenessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLivenessProbe {
}
export declare function dataKubernetesPodSpecInitContainerLivenessProbeToTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbe): any;
export declare function dataKubernetesPodSpecInitContainerLivenessProbeToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLivenessProbe): any;
export declare class DataKubernetesPodSpecInitContainerLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLivenessProbe | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLivenessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecInitContainerLivenessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodSpecInitContainerLivenessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecInitContainerLivenessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecInitContainerLivenessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodSpecInitContainerLivenessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLivenessProbeOutputReference;
}
export interface DataKubernetesPodSpecInitContainerPort {
}
export declare function dataKubernetesPodSpecInitContainerPortToTerraform(struct?: DataKubernetesPodSpecInitContainerPort): any;
export declare function dataKubernetesPodSpecInitContainerPortToHclTerraform(struct?: DataKubernetesPodSpecInitContainerPort): any;
export declare class DataKubernetesPodSpecInitContainerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerPort | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerPort | undefined);
    get containerPort(): number;
    get hostIp(): string;
    get hostPort(): number;
    get name(): string;
    get protocol(): string;
}
export declare class DataKubernetesPodSpecInitContainerPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerPortOutputReference;
}
export interface DataKubernetesPodSpecInitContainerReadinessProbeExec {
}
export declare function dataKubernetesPodSpecInitContainerReadinessProbeExecToTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeExec): any;
export declare function dataKubernetesPodSpecInitContainerReadinessProbeExecToHclTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeExec): any;
export declare class DataKubernetesPodSpecInitContainerReadinessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerReadinessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerReadinessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecInitContainerReadinessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerReadinessProbeExecOutputReference;
}
export interface DataKubernetesPodSpecInitContainerReadinessProbeGrpc {
}
export declare function dataKubernetesPodSpecInitContainerReadinessProbeGrpcToTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeGrpc): any;
export declare function dataKubernetesPodSpecInitContainerReadinessProbeGrpcToHclTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeGrpc): any;
export declare class DataKubernetesPodSpecInitContainerReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerReadinessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerReadinessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodSpecInitContainerReadinessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerReadinessProbeGrpcOutputReference;
}
export interface DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecInitContainerReadinessProbeHttpGet {
}
export declare function dataKubernetesPodSpecInitContainerReadinessProbeHttpGetToTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeHttpGet): any;
export declare function dataKubernetesPodSpecInitContainerReadinessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeHttpGet): any;
export declare class DataKubernetesPodSpecInitContainerReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerReadinessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerReadinessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecInitContainerReadinessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecInitContainerReadinessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerReadinessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodSpecInitContainerReadinessProbeTcpSocket {
}
export declare function dataKubernetesPodSpecInitContainerReadinessProbeTcpSocketToTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeTcpSocket): any;
export declare function dataKubernetesPodSpecInitContainerReadinessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbeTcpSocket): any;
export declare class DataKubernetesPodSpecInitContainerReadinessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerReadinessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerReadinessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecInitContainerReadinessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerReadinessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecInitContainerReadinessProbe {
}
export declare function dataKubernetesPodSpecInitContainerReadinessProbeToTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbe): any;
export declare function dataKubernetesPodSpecInitContainerReadinessProbeToHclTerraform(struct?: DataKubernetesPodSpecInitContainerReadinessProbe): any;
export declare class DataKubernetesPodSpecInitContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerReadinessProbe | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerReadinessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecInitContainerReadinessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodSpecInitContainerReadinessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecInitContainerReadinessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecInitContainerReadinessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodSpecInitContainerReadinessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerReadinessProbeOutputReference;
}
export interface DataKubernetesPodSpecInitContainerResources {
}
export declare function dataKubernetesPodSpecInitContainerResourcesToTerraform(struct?: DataKubernetesPodSpecInitContainerResources): any;
export declare function dataKubernetesPodSpecInitContainerResourcesToHclTerraform(struct?: DataKubernetesPodSpecInitContainerResources): any;
export declare class DataKubernetesPodSpecInitContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerResources | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
    private _requests;
    get requests(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecInitContainerResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerResourcesOutputReference;
}
export interface DataKubernetesPodSpecInitContainerSecurityContextCapabilities {
}
export declare function dataKubernetesPodSpecInitContainerSecurityContextCapabilitiesToTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContextCapabilities): any;
export declare function dataKubernetesPodSpecInitContainerSecurityContextCapabilitiesToHclTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContextCapabilities): any;
export declare class DataKubernetesPodSpecInitContainerSecurityContextCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerSecurityContextCapabilities | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerSecurityContextCapabilities | undefined);
    get add(): string[];
    get drop(): string[];
}
export declare class DataKubernetesPodSpecInitContainerSecurityContextCapabilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerSecurityContextCapabilitiesOutputReference;
}
export interface DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodSpecInitContainerSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodSpecInitContainerSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodSpecInitContainerSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodSpecInitContainerSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodSpecInitContainerSecurityContextSeccompProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodSpecInitContainerSecurityContext {
}
export declare function dataKubernetesPodSpecInitContainerSecurityContextToTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContext): any;
export declare function dataKubernetesPodSpecInitContainerSecurityContextToHclTerraform(struct?: DataKubernetesPodSpecInitContainerSecurityContext): any;
export declare class DataKubernetesPodSpecInitContainerSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerSecurityContext | undefined);
    get allowPrivilegeEscalation(): cdktn.IResolvable;
    private _capabilities;
    get capabilities(): DataKubernetesPodSpecInitContainerSecurityContextCapabilitiesList;
    get privileged(): cdktn.IResolvable;
    get readOnlyRootFilesystem(): cdktn.IResolvable;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktn.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodSpecInitContainerSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodSpecInitContainerSecurityContextSeccompProfileList;
}
export declare class DataKubernetesPodSpecInitContainerSecurityContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerSecurityContextOutputReference;
}
export interface DataKubernetesPodSpecInitContainerStartupProbeExec {
}
export declare function dataKubernetesPodSpecInitContainerStartupProbeExecToTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeExec): any;
export declare function dataKubernetesPodSpecInitContainerStartupProbeExecToHclTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeExec): any;
export declare class DataKubernetesPodSpecInitContainerStartupProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerStartupProbeExec | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerStartupProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecInitContainerStartupProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerStartupProbeExecOutputReference;
}
export interface DataKubernetesPodSpecInitContainerStartupProbeGrpc {
}
export declare function dataKubernetesPodSpecInitContainerStartupProbeGrpcToTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeGrpc): any;
export declare function dataKubernetesPodSpecInitContainerStartupProbeGrpcToHclTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeGrpc): any;
export declare class DataKubernetesPodSpecInitContainerStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerStartupProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerStartupProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodSpecInitContainerStartupProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerStartupProbeGrpcOutputReference;
}
export interface DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecInitContainerStartupProbeHttpGet {
}
export declare function dataKubernetesPodSpecInitContainerStartupProbeHttpGetToTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeHttpGet): any;
export declare function dataKubernetesPodSpecInitContainerStartupProbeHttpGetToHclTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeHttpGet): any;
export declare class DataKubernetesPodSpecInitContainerStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerStartupProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerStartupProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecInitContainerStartupProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecInitContainerStartupProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerStartupProbeHttpGetOutputReference;
}
export interface DataKubernetesPodSpecInitContainerStartupProbeTcpSocket {
}
export declare function dataKubernetesPodSpecInitContainerStartupProbeTcpSocketToTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeTcpSocket): any;
export declare function dataKubernetesPodSpecInitContainerStartupProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbeTcpSocket): any;
export declare class DataKubernetesPodSpecInitContainerStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerStartupProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerStartupProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecInitContainerStartupProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerStartupProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecInitContainerStartupProbe {
}
export declare function dataKubernetesPodSpecInitContainerStartupProbeToTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbe): any;
export declare function dataKubernetesPodSpecInitContainerStartupProbeToHclTerraform(struct?: DataKubernetesPodSpecInitContainerStartupProbe): any;
export declare class DataKubernetesPodSpecInitContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerStartupProbe | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerStartupProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecInitContainerStartupProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodSpecInitContainerStartupProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecInitContainerStartupProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecInitContainerStartupProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodSpecInitContainerStartupProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerStartupProbeOutputReference;
}
export interface DataKubernetesPodSpecInitContainerVolumeDevice {
}
export declare function dataKubernetesPodSpecInitContainerVolumeDeviceToTerraform(struct?: DataKubernetesPodSpecInitContainerVolumeDevice): any;
export declare function dataKubernetesPodSpecInitContainerVolumeDeviceToHclTerraform(struct?: DataKubernetesPodSpecInitContainerVolumeDevice): any;
export declare class DataKubernetesPodSpecInitContainerVolumeDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerVolumeDevice | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerVolumeDevice | undefined);
    get devicePath(): string;
    get name(): string;
}
export declare class DataKubernetesPodSpecInitContainerVolumeDeviceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerVolumeDeviceOutputReference;
}
export interface DataKubernetesPodSpecInitContainerVolumeMount {
}
export declare function dataKubernetesPodSpecInitContainerVolumeMountToTerraform(struct?: DataKubernetesPodSpecInitContainerVolumeMount): any;
export declare function dataKubernetesPodSpecInitContainerVolumeMountToHclTerraform(struct?: DataKubernetesPodSpecInitContainerVolumeMount): any;
export declare class DataKubernetesPodSpecInitContainerVolumeMountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerVolumeMount | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerVolumeMount | undefined);
    get mountPath(): string;
    get mountPropagation(): string;
    get name(): string;
    get readOnly(): cdktn.IResolvable;
    get subPath(): string;
    get subPathExpr(): string;
}
export declare class DataKubernetesPodSpecInitContainerVolumeMountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerVolumeMountOutputReference;
}
export interface DataKubernetesPodSpecInitContainer {
}
export declare function dataKubernetesPodSpecInitContainerToTerraform(struct?: DataKubernetesPodSpecInitContainer): any;
export declare function dataKubernetesPodSpecInitContainerToHclTerraform(struct?: DataKubernetesPodSpecInitContainer): any;
export declare class DataKubernetesPodSpecInitContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainer | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainer | undefined);
    get args(): string[];
    get command(): string[];
    private _env;
    get env(): DataKubernetesPodSpecInitContainerEnvList;
    private _envFrom;
    get envFrom(): DataKubernetesPodSpecInitContainerEnvFromList;
    get image(): string;
    get imagePullPolicy(): string;
    private _lifecycle;
    get lifecycle(): DataKubernetesPodSpecInitContainerLifecycleList;
    private _livenessProbe;
    get livenessProbe(): DataKubernetesPodSpecInitContainerLivenessProbeList;
    get name(): string;
    private _port;
    get port(): DataKubernetesPodSpecInitContainerPortList;
    private _readinessProbe;
    get readinessProbe(): DataKubernetesPodSpecInitContainerReadinessProbeList;
    private _resources;
    get resources(): DataKubernetesPodSpecInitContainerResourcesList;
    get restartPolicy(): string;
    private _securityContext;
    get securityContext(): DataKubernetesPodSpecInitContainerSecurityContextList;
    private _startupProbe;
    get startupProbe(): DataKubernetesPodSpecInitContainerStartupProbeList;
    get stdin(): cdktn.IResolvable;
    get stdinOnce(): cdktn.IResolvable;
    get terminationMessagePath(): string;
    get terminationMessagePolicy(): string;
    get tty(): cdktn.IResolvable;
    private _volumeDevice;
    get volumeDevice(): DataKubernetesPodSpecInitContainerVolumeDeviceList;
    private _volumeMount;
    get volumeMount(): DataKubernetesPodSpecInitContainerVolumeMountList;
    get workingDir(): string;
}
export declare class DataKubernetesPodSpecInitContainerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerOutputReference;
}
export interface DataKubernetesPodSpecOs {
}
export declare function dataKubernetesPodSpecOsToTerraform(struct?: DataKubernetesPodSpecOs): any;
export declare function dataKubernetesPodSpecOsToHclTerraform(struct?: DataKubernetesPodSpecOs): any;
export declare class DataKubernetesPodSpecOsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecOs | undefined;
    set internalValue(value: DataKubernetesPodSpecOs | undefined);
    get name(): string;
}
export declare class DataKubernetesPodSpecOsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecOsOutputReference;
}
export interface DataKubernetesPodSpecReadinessGate {
}
export declare function dataKubernetesPodSpecReadinessGateToTerraform(struct?: DataKubernetesPodSpecReadinessGate): any;
export declare function dataKubernetesPodSpecReadinessGateToHclTerraform(struct?: DataKubernetesPodSpecReadinessGate): any;
export declare class DataKubernetesPodSpecReadinessGateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecReadinessGate | undefined;
    set internalValue(value: DataKubernetesPodSpecReadinessGate | undefined);
    get conditionType(): string;
}
export declare class DataKubernetesPodSpecReadinessGateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecReadinessGateOutputReference;
}
export interface DataKubernetesPodSpecSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodSpecSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodSpecSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodSpecSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodSpecSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodSpecSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodSpecSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodSpecSecurityContextSeLinuxOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodSpecSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodSpecSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodSpecSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodSpecSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodSpecSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodSpecSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodSpecSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodSpecSecurityContextSeccompProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodSpecSecurityContextSysctl {
}
export declare function dataKubernetesPodSpecSecurityContextSysctlToTerraform(struct?: DataKubernetesPodSpecSecurityContextSysctl): any;
export declare function dataKubernetesPodSpecSecurityContextSysctlToHclTerraform(struct?: DataKubernetesPodSpecSecurityContextSysctl): any;
export declare class DataKubernetesPodSpecSecurityContextSysctlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecSecurityContextSysctl | undefined;
    set internalValue(value: DataKubernetesPodSpecSecurityContextSysctl | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecSecurityContextSysctlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecSecurityContextSysctlOutputReference;
}
export interface DataKubernetesPodSpecSecurityContextWindowsOptions {
}
export declare function dataKubernetesPodSpecSecurityContextWindowsOptionsToTerraform(struct?: DataKubernetesPodSpecSecurityContextWindowsOptions): any;
export declare function dataKubernetesPodSpecSecurityContextWindowsOptionsToHclTerraform(struct?: DataKubernetesPodSpecSecurityContextWindowsOptions): any;
export declare class DataKubernetesPodSpecSecurityContextWindowsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecSecurityContextWindowsOptions | undefined;
    set internalValue(value: DataKubernetesPodSpecSecurityContextWindowsOptions | undefined);
    get gmsaCredentialSpec(): string;
    get gmsaCredentialSpecName(): string;
    get hostProcess(): cdktn.IResolvable;
    get runAsUsername(): string;
}
export declare class DataKubernetesPodSpecSecurityContextWindowsOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecSecurityContextWindowsOptionsOutputReference;
}
export interface DataKubernetesPodSpecSecurityContext {
}
export declare function dataKubernetesPodSpecSecurityContextToTerraform(struct?: DataKubernetesPodSpecSecurityContext): any;
export declare function dataKubernetesPodSpecSecurityContextToHclTerraform(struct?: DataKubernetesPodSpecSecurityContext): any;
export declare class DataKubernetesPodSpecSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodSpecSecurityContext | undefined);
    get fsGroup(): string;
    get fsGroupChangePolicy(): string;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktn.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodSpecSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodSpecSecurityContextSeccompProfileList;
    get supplementalGroups(): number[];
    private _sysctl;
    get sysctl(): DataKubernetesPodSpecSecurityContextSysctlList;
    private _windowsOptions;
    get windowsOptions(): DataKubernetesPodSpecSecurityContextWindowsOptionsList;
}
export declare class DataKubernetesPodSpecSecurityContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecSecurityContextOutputReference;
}
export interface DataKubernetesPodSpecToleration {
}
export declare function dataKubernetesPodSpecTolerationToTerraform(struct?: DataKubernetesPodSpecToleration): any;
export declare function dataKubernetesPodSpecTolerationToHclTerraform(struct?: DataKubernetesPodSpecToleration): any;
export declare class DataKubernetesPodSpecTolerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecToleration | undefined;
    set internalValue(value: DataKubernetesPodSpecToleration | undefined);
    get effect(): string;
    get key(): string;
    get operator(): string;
    get tolerationSeconds(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecTolerationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecTolerationOutputReference;
}
export interface DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecTopologySpreadConstraintLabelSelector {
}
export declare function dataKubernetesPodSpecTopologySpreadConstraintLabelSelectorToTerraform(struct?: DataKubernetesPodSpecTopologySpreadConstraintLabelSelector): any;
export declare function dataKubernetesPodSpecTopologySpreadConstraintLabelSelectorToHclTerraform(struct?: DataKubernetesPodSpecTopologySpreadConstraintLabelSelector): any;
export declare class DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecTopologySpreadConstraintLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecTopologySpreadConstraintLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorOutputReference;
}
export interface DataKubernetesPodSpecTopologySpreadConstraint {
}
export declare function dataKubernetesPodSpecTopologySpreadConstraintToTerraform(struct?: DataKubernetesPodSpecTopologySpreadConstraint): any;
export declare function dataKubernetesPodSpecTopologySpreadConstraintToHclTerraform(struct?: DataKubernetesPodSpecTopologySpreadConstraint): any;
export declare class DataKubernetesPodSpecTopologySpreadConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecTopologySpreadConstraint | undefined;
    set internalValue(value: DataKubernetesPodSpecTopologySpreadConstraint | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodSpecTopologySpreadConstraintLabelSelectorList;
    get matchLabelKeys(): string[];
    get maxSkew(): number;
    get minDomains(): number;
    get nodeAffinityPolicy(): string;
    get nodeTaintsPolicy(): string;
    get topologyKey(): string;
    get whenUnsatisfiable(): string;
}
export declare class DataKubernetesPodSpecTopologySpreadConstraintList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecTopologySpreadConstraintOutputReference;
}
export interface DataKubernetesPodSpecVolumeAwsElasticBlockStore {
}
export declare function dataKubernetesPodSpecVolumeAwsElasticBlockStoreToTerraform(struct?: DataKubernetesPodSpecVolumeAwsElasticBlockStore): any;
export declare function dataKubernetesPodSpecVolumeAwsElasticBlockStoreToHclTerraform(struct?: DataKubernetesPodSpecVolumeAwsElasticBlockStore): any;
export declare class DataKubernetesPodSpecVolumeAwsElasticBlockStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeAwsElasticBlockStore | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeAwsElasticBlockStore | undefined);
    get fsType(): string;
    get partition(): number;
    get readOnly(): cdktn.IResolvable;
    get volumeId(): string;
}
export declare class DataKubernetesPodSpecVolumeAwsElasticBlockStoreList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeAwsElasticBlockStoreOutputReference;
}
export interface DataKubernetesPodSpecVolumeAzureDisk {
}
export declare function dataKubernetesPodSpecVolumeAzureDiskToTerraform(struct?: DataKubernetesPodSpecVolumeAzureDisk): any;
export declare function dataKubernetesPodSpecVolumeAzureDiskToHclTerraform(struct?: DataKubernetesPodSpecVolumeAzureDisk): any;
export declare class DataKubernetesPodSpecVolumeAzureDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeAzureDisk | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeAzureDisk | undefined);
    get cachingMode(): string;
    get dataDiskUri(): string;
    get diskName(): string;
    get fsType(): string;
    get kind(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumeAzureDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeAzureDiskOutputReference;
}
export interface DataKubernetesPodSpecVolumeAzureFile {
}
export declare function dataKubernetesPodSpecVolumeAzureFileToTerraform(struct?: DataKubernetesPodSpecVolumeAzureFile): any;
export declare function dataKubernetesPodSpecVolumeAzureFileToHclTerraform(struct?: DataKubernetesPodSpecVolumeAzureFile): any;
export declare class DataKubernetesPodSpecVolumeAzureFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeAzureFile | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeAzureFile | undefined);
    get readOnly(): cdktn.IResolvable;
    get secretName(): string;
    get secretNamespace(): string;
    get shareName(): string;
}
export declare class DataKubernetesPodSpecVolumeAzureFileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeAzureFileOutputReference;
}
export interface DataKubernetesPodSpecVolumeCephFsSecretRef {
}
export declare function dataKubernetesPodSpecVolumeCephFsSecretRefToTerraform(struct?: DataKubernetesPodSpecVolumeCephFsSecretRef): any;
export declare function dataKubernetesPodSpecVolumeCephFsSecretRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeCephFsSecretRef): any;
export declare class DataKubernetesPodSpecVolumeCephFsSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeCephFsSecretRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeCephFsSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodSpecVolumeCephFsSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeCephFsSecretRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeCephFs {
}
export declare function dataKubernetesPodSpecVolumeCephFsToTerraform(struct?: DataKubernetesPodSpecVolumeCephFs): any;
export declare function dataKubernetesPodSpecVolumeCephFsToHclTerraform(struct?: DataKubernetesPodSpecVolumeCephFs): any;
export declare class DataKubernetesPodSpecVolumeCephFsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeCephFs | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeCephFs | undefined);
    get monitors(): string[];
    get path(): string;
    get readOnly(): cdktn.IResolvable;
    get secretFile(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodSpecVolumeCephFsSecretRefList;
    get user(): string;
}
export declare class DataKubernetesPodSpecVolumeCephFsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeCephFsOutputReference;
}
export interface DataKubernetesPodSpecVolumeCinder {
}
export declare function dataKubernetesPodSpecVolumeCinderToTerraform(struct?: DataKubernetesPodSpecVolumeCinder): any;
export declare function dataKubernetesPodSpecVolumeCinderToHclTerraform(struct?: DataKubernetesPodSpecVolumeCinder): any;
export declare class DataKubernetesPodSpecVolumeCinderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeCinder | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeCinder | undefined);
    get fsType(): string;
    get readOnly(): cdktn.IResolvable;
    get volumeId(): string;
}
export declare class DataKubernetesPodSpecVolumeCinderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeCinderOutputReference;
}
export interface DataKubernetesPodSpecVolumeConfigMapItems {
}
export declare function dataKubernetesPodSpecVolumeConfigMapItemsToTerraform(struct?: DataKubernetesPodSpecVolumeConfigMapItems): any;
export declare function dataKubernetesPodSpecVolumeConfigMapItemsToHclTerraform(struct?: DataKubernetesPodSpecVolumeConfigMapItems): any;
export declare class DataKubernetesPodSpecVolumeConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeConfigMapItems | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeConfigMapItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodSpecVolumeConfigMapItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeConfigMapItemsOutputReference;
}
export interface DataKubernetesPodSpecVolumeConfigMap {
}
export declare function dataKubernetesPodSpecVolumeConfigMapToTerraform(struct?: DataKubernetesPodSpecVolumeConfigMap): any;
export declare function dataKubernetesPodSpecVolumeConfigMapToHclTerraform(struct?: DataKubernetesPodSpecVolumeConfigMap): any;
export declare class DataKubernetesPodSpecVolumeConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeConfigMap | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeConfigMap | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodSpecVolumeConfigMapItemsList;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumeConfigMapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeConfigMapOutputReference;
}
export interface DataKubernetesPodSpecVolumeCsiNodePublishSecretRef {
}
export declare function dataKubernetesPodSpecVolumeCsiNodePublishSecretRefToTerraform(struct?: DataKubernetesPodSpecVolumeCsiNodePublishSecretRef): any;
export declare function dataKubernetesPodSpecVolumeCsiNodePublishSecretRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeCsiNodePublishSecretRef): any;
export declare class DataKubernetesPodSpecVolumeCsiNodePublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeCsiNodePublishSecretRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeCsiNodePublishSecretRef | undefined);
    get name(): string;
}
export declare class DataKubernetesPodSpecVolumeCsiNodePublishSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeCsiNodePublishSecretRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeCsi {
}
export declare function dataKubernetesPodSpecVolumeCsiToTerraform(struct?: DataKubernetesPodSpecVolumeCsi): any;
export declare function dataKubernetesPodSpecVolumeCsiToHclTerraform(struct?: DataKubernetesPodSpecVolumeCsi): any;
export declare class DataKubernetesPodSpecVolumeCsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeCsi | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeCsi | undefined);
    get driver(): string;
    get fsType(): string;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): DataKubernetesPodSpecVolumeCsiNodePublishSecretRefList;
    get readOnly(): cdktn.IResolvable;
    private _volumeAttributes;
    get volumeAttributes(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecVolumeCsiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeCsiOutputReference;
}
export interface DataKubernetesPodSpecVolumeDownwardApiItemsFieldRef {
}
export declare function dataKubernetesPodSpecVolumeDownwardApiItemsFieldRefToTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApiItemsFieldRef): any;
export declare function dataKubernetesPodSpecVolumeDownwardApiItemsFieldRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApiItemsFieldRef): any;
export declare class DataKubernetesPodSpecVolumeDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeDownwardApiItemsFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodSpecVolumeDownwardApiItemsFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeDownwardApiItemsFieldRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRef {
}
export declare function dataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRefToTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare function dataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare class DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeDownwardApiItems {
}
export declare function dataKubernetesPodSpecVolumeDownwardApiItemsToTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApiItems): any;
export declare function dataKubernetesPodSpecVolumeDownwardApiItemsToHclTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApiItems): any;
export declare class DataKubernetesPodSpecVolumeDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeDownwardApiItems | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeDownwardApiItems | undefined);
    private _fieldRef;
    get fieldRef(): DataKubernetesPodSpecVolumeDownwardApiItemsFieldRefList;
    get mode(): string;
    get path(): string;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodSpecVolumeDownwardApiItemsResourceFieldRefList;
}
export declare class DataKubernetesPodSpecVolumeDownwardApiItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeDownwardApiItemsOutputReference;
}
export interface DataKubernetesPodSpecVolumeDownwardApi {
}
export declare function dataKubernetesPodSpecVolumeDownwardApiToTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApi): any;
export declare function dataKubernetesPodSpecVolumeDownwardApiToHclTerraform(struct?: DataKubernetesPodSpecVolumeDownwardApi): any;
export declare class DataKubernetesPodSpecVolumeDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeDownwardApi | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeDownwardApi | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodSpecVolumeDownwardApiItemsList;
}
export declare class DataKubernetesPodSpecVolumeDownwardApiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeDownwardApiOutputReference;
}
export interface DataKubernetesPodSpecVolumeEmptyDir {
}
export declare function dataKubernetesPodSpecVolumeEmptyDirToTerraform(struct?: DataKubernetesPodSpecVolumeEmptyDir): any;
export declare function dataKubernetesPodSpecVolumeEmptyDirToHclTerraform(struct?: DataKubernetesPodSpecVolumeEmptyDir): any;
export declare class DataKubernetesPodSpecVolumeEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEmptyDir | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEmptyDir | undefined);
    get medium(): string;
    get sizeLimit(): string;
}
export declare class DataKubernetesPodSpecVolumeEmptyDirList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEmptyDirOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadata {
}
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadataToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadataToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _labels;
    get labels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResources {
}
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
    private _requests;
    get requests(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelector {
}
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpec {
}
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined);
    get accessModes(): string[];
    private _resources;
    get resources(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesList;
    private _selector;
    get selector(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorList;
    get storageClassName(): string;
    get volumeMode(): string;
    get volumeName(): string;
}
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplate {
}
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplate): any;
export declare function dataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplate): any;
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplate | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplate | undefined);
    private _metadata;
    get metadata(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateMetadataList;
    private _spec;
    get spec(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateSpecList;
}
export declare class DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateOutputReference;
}
export interface DataKubernetesPodSpecVolumeEphemeral {
}
export declare function dataKubernetesPodSpecVolumeEphemeralToTerraform(struct?: DataKubernetesPodSpecVolumeEphemeral): any;
export declare function dataKubernetesPodSpecVolumeEphemeralToHclTerraform(struct?: DataKubernetesPodSpecVolumeEphemeral): any;
export declare class DataKubernetesPodSpecVolumeEphemeralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeEphemeral | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeEphemeral | undefined);
    private _volumeClaimTemplate;
    get volumeClaimTemplate(): DataKubernetesPodSpecVolumeEphemeralVolumeClaimTemplateList;
}
export declare class DataKubernetesPodSpecVolumeEphemeralList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeEphemeralOutputReference;
}
export interface DataKubernetesPodSpecVolumeFc {
}
export declare function dataKubernetesPodSpecVolumeFcToTerraform(struct?: DataKubernetesPodSpecVolumeFc): any;
export declare function dataKubernetesPodSpecVolumeFcToHclTerraform(struct?: DataKubernetesPodSpecVolumeFc): any;
export declare class DataKubernetesPodSpecVolumeFcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeFc | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeFc | undefined);
    get fsType(): string;
    get lun(): number;
    get readOnly(): cdktn.IResolvable;
    get targetWwNs(): string[];
}
export declare class DataKubernetesPodSpecVolumeFcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeFcOutputReference;
}
export interface DataKubernetesPodSpecVolumeFlexVolumeSecretRef {
}
export declare function dataKubernetesPodSpecVolumeFlexVolumeSecretRefToTerraform(struct?: DataKubernetesPodSpecVolumeFlexVolumeSecretRef): any;
export declare function dataKubernetesPodSpecVolumeFlexVolumeSecretRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeFlexVolumeSecretRef): any;
export declare class DataKubernetesPodSpecVolumeFlexVolumeSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeFlexVolumeSecretRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeFlexVolumeSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodSpecVolumeFlexVolumeSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeFlexVolumeSecretRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeFlexVolume {
}
export declare function dataKubernetesPodSpecVolumeFlexVolumeToTerraform(struct?: DataKubernetesPodSpecVolumeFlexVolume): any;
export declare function dataKubernetesPodSpecVolumeFlexVolumeToHclTerraform(struct?: DataKubernetesPodSpecVolumeFlexVolume): any;
export declare class DataKubernetesPodSpecVolumeFlexVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeFlexVolume | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeFlexVolume | undefined);
    get driver(): string;
    get fsType(): string;
    private _options;
    get options(): cdktn.StringMap;
    get readOnly(): cdktn.IResolvable;
    private _secretRef;
    get secretRef(): DataKubernetesPodSpecVolumeFlexVolumeSecretRefList;
}
export declare class DataKubernetesPodSpecVolumeFlexVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeFlexVolumeOutputReference;
}
export interface DataKubernetesPodSpecVolumeFlocker {
}
export declare function dataKubernetesPodSpecVolumeFlockerToTerraform(struct?: DataKubernetesPodSpecVolumeFlocker): any;
export declare function dataKubernetesPodSpecVolumeFlockerToHclTerraform(struct?: DataKubernetesPodSpecVolumeFlocker): any;
export declare class DataKubernetesPodSpecVolumeFlockerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeFlocker | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeFlocker | undefined);
    get datasetName(): string;
    get datasetUuid(): string;
}
export declare class DataKubernetesPodSpecVolumeFlockerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeFlockerOutputReference;
}
export interface DataKubernetesPodSpecVolumeGcePersistentDisk {
}
export declare function dataKubernetesPodSpecVolumeGcePersistentDiskToTerraform(struct?: DataKubernetesPodSpecVolumeGcePersistentDisk): any;
export declare function dataKubernetesPodSpecVolumeGcePersistentDiskToHclTerraform(struct?: DataKubernetesPodSpecVolumeGcePersistentDisk): any;
export declare class DataKubernetesPodSpecVolumeGcePersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeGcePersistentDisk | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeGcePersistentDisk | undefined);
    get fsType(): string;
    get partition(): number;
    get pdName(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumeGcePersistentDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeGcePersistentDiskOutputReference;
}
export interface DataKubernetesPodSpecVolumeGitRepo {
}
export declare function dataKubernetesPodSpecVolumeGitRepoToTerraform(struct?: DataKubernetesPodSpecVolumeGitRepo): any;
export declare function dataKubernetesPodSpecVolumeGitRepoToHclTerraform(struct?: DataKubernetesPodSpecVolumeGitRepo): any;
export declare class DataKubernetesPodSpecVolumeGitRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeGitRepo | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeGitRepo | undefined);
    get directory(): string;
    get repository(): string;
    get revision(): string;
}
export declare class DataKubernetesPodSpecVolumeGitRepoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeGitRepoOutputReference;
}
export interface DataKubernetesPodSpecVolumeGlusterfs {
}
export declare function dataKubernetesPodSpecVolumeGlusterfsToTerraform(struct?: DataKubernetesPodSpecVolumeGlusterfs): any;
export declare function dataKubernetesPodSpecVolumeGlusterfsToHclTerraform(struct?: DataKubernetesPodSpecVolumeGlusterfs): any;
export declare class DataKubernetesPodSpecVolumeGlusterfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeGlusterfs | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeGlusterfs | undefined);
    get endpointsName(): string;
    get path(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumeGlusterfsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeGlusterfsOutputReference;
}
export interface DataKubernetesPodSpecVolumeHostPath {
}
export declare function dataKubernetesPodSpecVolumeHostPathToTerraform(struct?: DataKubernetesPodSpecVolumeHostPath): any;
export declare function dataKubernetesPodSpecVolumeHostPathToHclTerraform(struct?: DataKubernetesPodSpecVolumeHostPath): any;
export declare class DataKubernetesPodSpecVolumeHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeHostPath | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeHostPath | undefined);
    get path(): string;
    get type(): string;
}
export declare class DataKubernetesPodSpecVolumeHostPathList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeHostPathOutputReference;
}
export interface DataKubernetesPodSpecVolumeIscsi {
}
export declare function dataKubernetesPodSpecVolumeIscsiToTerraform(struct?: DataKubernetesPodSpecVolumeIscsi): any;
export declare function dataKubernetesPodSpecVolumeIscsiToHclTerraform(struct?: DataKubernetesPodSpecVolumeIscsi): any;
export declare class DataKubernetesPodSpecVolumeIscsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeIscsi | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeIscsi | undefined);
    get fsType(): string;
    get iqn(): string;
    get iscsiInterface(): string;
    get lun(): number;
    get readOnly(): cdktn.IResolvable;
    get targetPortal(): string;
}
export declare class DataKubernetesPodSpecVolumeIscsiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeIscsiOutputReference;
}
export interface DataKubernetesPodSpecVolumeLocal {
}
export declare function dataKubernetesPodSpecVolumeLocalToTerraform(struct?: DataKubernetesPodSpecVolumeLocal): any;
export declare function dataKubernetesPodSpecVolumeLocalToHclTerraform(struct?: DataKubernetesPodSpecVolumeLocal): any;
export declare class DataKubernetesPodSpecVolumeLocalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeLocal | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeLocal | undefined);
    get path(): string;
}
export declare class DataKubernetesPodSpecVolumeLocalList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeLocalOutputReference;
}
export interface DataKubernetesPodSpecVolumeNfs {
}
export declare function dataKubernetesPodSpecVolumeNfsToTerraform(struct?: DataKubernetesPodSpecVolumeNfs): any;
export declare function dataKubernetesPodSpecVolumeNfsToHclTerraform(struct?: DataKubernetesPodSpecVolumeNfs): any;
export declare class DataKubernetesPodSpecVolumeNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeNfs | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeNfs | undefined);
    get path(): string;
    get readOnly(): cdktn.IResolvable;
    get server(): string;
}
export declare class DataKubernetesPodSpecVolumeNfsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeNfsOutputReference;
}
export interface DataKubernetesPodSpecVolumePersistentVolumeClaim {
}
export declare function dataKubernetesPodSpecVolumePersistentVolumeClaimToTerraform(struct?: DataKubernetesPodSpecVolumePersistentVolumeClaim): any;
export declare function dataKubernetesPodSpecVolumePersistentVolumeClaimToHclTerraform(struct?: DataKubernetesPodSpecVolumePersistentVolumeClaim): any;
export declare class DataKubernetesPodSpecVolumePersistentVolumeClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumePersistentVolumeClaim | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumePersistentVolumeClaim | undefined);
    get claimName(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumePersistentVolumeClaimList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumePersistentVolumeClaimOutputReference;
}
export interface DataKubernetesPodSpecVolumePhotonPersistentDisk {
}
export declare function dataKubernetesPodSpecVolumePhotonPersistentDiskToTerraform(struct?: DataKubernetesPodSpecVolumePhotonPersistentDisk): any;
export declare function dataKubernetesPodSpecVolumePhotonPersistentDiskToHclTerraform(struct?: DataKubernetesPodSpecVolumePhotonPersistentDisk): any;
export declare class DataKubernetesPodSpecVolumePhotonPersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumePhotonPersistentDisk | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumePhotonPersistentDisk | undefined);
    get fsType(): string;
    get pdId(): string;
}
export declare class DataKubernetesPodSpecVolumePhotonPersistentDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumePhotonPersistentDiskOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItems {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesConfigMapItemsToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItems): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesConfigMapItemsToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItems): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItems | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItemsOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesConfigMap {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesConfigMapToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesConfigMap): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesConfigMapToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesConfigMap): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesConfigMap | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesConfigMap | undefined);
    private _items;
    get items(): DataKubernetesPodSpecVolumeProjectedSourcesConfigMapItemsList;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesConfigMapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesConfigMapOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRef {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRefToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItems {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItems): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItems): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItems | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItems | undefined);
    private _fieldRef;
    get fieldRef(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsFieldRefList;
    get mode(): string;
    get path(): string;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefList;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesDownwardApi {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApi): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesDownwardApiToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApi): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApi | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesDownwardApi | undefined);
    private _items;
    get items(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiItemsList;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesSecretItems {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesSecretItemsToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesSecretItems): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesSecretItemsToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesSecretItems): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesSecretItems | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesSecretItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesSecretItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesSecretItemsOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesSecret {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesSecretToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesSecret): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesSecretToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesSecret): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesSecret | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesSecret | undefined);
    private _items;
    get items(): DataKubernetesPodSpecVolumeProjectedSourcesSecretItemsList;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesSecretList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesSecretOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountToken {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesServiceAccountTokenToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountToken): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesServiceAccountTokenToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountToken): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountToken | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountToken | undefined);
    get audience(): string;
    get expirationSeconds(): number;
    get path(): string;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountTokenList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountTokenOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjectedSources {
}
export declare function dataKubernetesPodSpecVolumeProjectedSourcesToTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSources): any;
export declare function dataKubernetesPodSpecVolumeProjectedSourcesToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjectedSources): any;
export declare class DataKubernetesPodSpecVolumeProjectedSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjectedSources | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjectedSources | undefined);
    private _configMap;
    get configMap(): DataKubernetesPodSpecVolumeProjectedSourcesConfigMapList;
    private _downwardApi;
    get downwardApi(): DataKubernetesPodSpecVolumeProjectedSourcesDownwardApiList;
    private _secret;
    get secret(): DataKubernetesPodSpecVolumeProjectedSourcesSecretList;
    private _serviceAccountToken;
    get serviceAccountToken(): DataKubernetesPodSpecVolumeProjectedSourcesServiceAccountTokenList;
}
export declare class DataKubernetesPodSpecVolumeProjectedSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedSourcesOutputReference;
}
export interface DataKubernetesPodSpecVolumeProjected {
}
export declare function dataKubernetesPodSpecVolumeProjectedToTerraform(struct?: DataKubernetesPodSpecVolumeProjected): any;
export declare function dataKubernetesPodSpecVolumeProjectedToHclTerraform(struct?: DataKubernetesPodSpecVolumeProjected): any;
export declare class DataKubernetesPodSpecVolumeProjectedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeProjected | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeProjected | undefined);
    get defaultMode(): string;
    private _sources;
    get sources(): DataKubernetesPodSpecVolumeProjectedSourcesList;
}
export declare class DataKubernetesPodSpecVolumeProjectedList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeProjectedOutputReference;
}
export interface DataKubernetesPodSpecVolumeQuobyte {
}
export declare function dataKubernetesPodSpecVolumeQuobyteToTerraform(struct?: DataKubernetesPodSpecVolumeQuobyte): any;
export declare function dataKubernetesPodSpecVolumeQuobyteToHclTerraform(struct?: DataKubernetesPodSpecVolumeQuobyte): any;
export declare class DataKubernetesPodSpecVolumeQuobyteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeQuobyte | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeQuobyte | undefined);
    get group(): string;
    get readOnly(): cdktn.IResolvable;
    get registry(): string;
    get user(): string;
    get volume(): string;
}
export declare class DataKubernetesPodSpecVolumeQuobyteList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeQuobyteOutputReference;
}
export interface DataKubernetesPodSpecVolumeRbdSecretRef {
}
export declare function dataKubernetesPodSpecVolumeRbdSecretRefToTerraform(struct?: DataKubernetesPodSpecVolumeRbdSecretRef): any;
export declare function dataKubernetesPodSpecVolumeRbdSecretRefToHclTerraform(struct?: DataKubernetesPodSpecVolumeRbdSecretRef): any;
export declare class DataKubernetesPodSpecVolumeRbdSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeRbdSecretRef | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeRbdSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodSpecVolumeRbdSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeRbdSecretRefOutputReference;
}
export interface DataKubernetesPodSpecVolumeRbd {
}
export declare function dataKubernetesPodSpecVolumeRbdToTerraform(struct?: DataKubernetesPodSpecVolumeRbd): any;
export declare function dataKubernetesPodSpecVolumeRbdToHclTerraform(struct?: DataKubernetesPodSpecVolumeRbd): any;
export declare class DataKubernetesPodSpecVolumeRbdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeRbd | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeRbd | undefined);
    get cephMonitors(): string[];
    get fsType(): string;
    get keyring(): string;
    get radosUser(): string;
    get rbdImage(): string;
    get rbdPool(): string;
    get readOnly(): cdktn.IResolvable;
    private _secretRef;
    get secretRef(): DataKubernetesPodSpecVolumeRbdSecretRefList;
}
export declare class DataKubernetesPodSpecVolumeRbdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeRbdOutputReference;
}
export interface DataKubernetesPodSpecVolumeSecretItems {
}
export declare function dataKubernetesPodSpecVolumeSecretItemsToTerraform(struct?: DataKubernetesPodSpecVolumeSecretItems): any;
export declare function dataKubernetesPodSpecVolumeSecretItemsToHclTerraform(struct?: DataKubernetesPodSpecVolumeSecretItems): any;
export declare class DataKubernetesPodSpecVolumeSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeSecretItems | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeSecretItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodSpecVolumeSecretItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeSecretItemsOutputReference;
}
export interface DataKubernetesPodSpecVolumeSecret {
}
export declare function dataKubernetesPodSpecVolumeSecretToTerraform(struct?: DataKubernetesPodSpecVolumeSecret): any;
export declare function dataKubernetesPodSpecVolumeSecretToHclTerraform(struct?: DataKubernetesPodSpecVolumeSecret): any;
export declare class DataKubernetesPodSpecVolumeSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeSecret | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeSecret | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodSpecVolumeSecretItemsList;
    get optional(): cdktn.IResolvable;
    get secretName(): string;
}
export declare class DataKubernetesPodSpecVolumeSecretList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeSecretOutputReference;
}
export interface DataKubernetesPodSpecVolumeVsphereVolume {
}
export declare function dataKubernetesPodSpecVolumeVsphereVolumeToTerraform(struct?: DataKubernetesPodSpecVolumeVsphereVolume): any;
export declare function dataKubernetesPodSpecVolumeVsphereVolumeToHclTerraform(struct?: DataKubernetesPodSpecVolumeVsphereVolume): any;
export declare class DataKubernetesPodSpecVolumeVsphereVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolumeVsphereVolume | undefined;
    set internalValue(value: DataKubernetesPodSpecVolumeVsphereVolume | undefined);
    get fsType(): string;
    get volumePath(): string;
}
export declare class DataKubernetesPodSpecVolumeVsphereVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeVsphereVolumeOutputReference;
}
export interface DataKubernetesPodSpecVolume {
}
export declare function dataKubernetesPodSpecVolumeToTerraform(struct?: DataKubernetesPodSpecVolume): any;
export declare function dataKubernetesPodSpecVolumeToHclTerraform(struct?: DataKubernetesPodSpecVolume): any;
export declare class DataKubernetesPodSpecVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecVolume | undefined;
    set internalValue(value: DataKubernetesPodSpecVolume | undefined);
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): DataKubernetesPodSpecVolumeAwsElasticBlockStoreList;
    private _azureDisk;
    get azureDisk(): DataKubernetesPodSpecVolumeAzureDiskList;
    private _azureFile;
    get azureFile(): DataKubernetesPodSpecVolumeAzureFileList;
    private _cephFs;
    get cephFs(): DataKubernetesPodSpecVolumeCephFsList;
    private _cinder;
    get cinder(): DataKubernetesPodSpecVolumeCinderList;
    private _configMap;
    get configMap(): DataKubernetesPodSpecVolumeConfigMapList;
    private _csi;
    get csi(): DataKubernetesPodSpecVolumeCsiList;
    private _downwardApi;
    get downwardApi(): DataKubernetesPodSpecVolumeDownwardApiList;
    private _emptyDir;
    get emptyDir(): DataKubernetesPodSpecVolumeEmptyDirList;
    private _ephemeral;
    get ephemeral(): DataKubernetesPodSpecVolumeEphemeralList;
    private _fc;
    get fc(): DataKubernetesPodSpecVolumeFcList;
    private _flexVolume;
    get flexVolume(): DataKubernetesPodSpecVolumeFlexVolumeList;
    private _flocker;
    get flocker(): DataKubernetesPodSpecVolumeFlockerList;
    private _gcePersistentDisk;
    get gcePersistentDisk(): DataKubernetesPodSpecVolumeGcePersistentDiskList;
    private _gitRepo;
    get gitRepo(): DataKubernetesPodSpecVolumeGitRepoList;
    private _glusterfs;
    get glusterfs(): DataKubernetesPodSpecVolumeGlusterfsList;
    private _hostPath;
    get hostPath(): DataKubernetesPodSpecVolumeHostPathList;
    private _iscsi;
    get iscsi(): DataKubernetesPodSpecVolumeIscsiList;
    private _local;
    get local(): DataKubernetesPodSpecVolumeLocalList;
    get name(): string;
    private _nfs;
    get nfs(): DataKubernetesPodSpecVolumeNfsList;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): DataKubernetesPodSpecVolumePersistentVolumeClaimList;
    private _photonPersistentDisk;
    get photonPersistentDisk(): DataKubernetesPodSpecVolumePhotonPersistentDiskList;
    private _projected;
    get projected(): DataKubernetesPodSpecVolumeProjectedList;
    private _quobyte;
    get quobyte(): DataKubernetesPodSpecVolumeQuobyteList;
    private _rbd;
    get rbd(): DataKubernetesPodSpecVolumeRbdList;
    private _secret;
    get secret(): DataKubernetesPodSpecVolumeSecretList;
    private _vsphereVolume;
    get vsphereVolume(): DataKubernetesPodSpecVolumeVsphereVolumeList;
}
export declare class DataKubernetesPodSpecVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecVolumeOutputReference;
}
export interface DataKubernetesPodSpec {
}
export declare function dataKubernetesPodSpecToTerraform(struct?: DataKubernetesPodSpec): any;
export declare function dataKubernetesPodSpecToHclTerraform(struct?: DataKubernetesPodSpec): any;
export declare class DataKubernetesPodSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpec | undefined;
    set internalValue(value: DataKubernetesPodSpec | undefined);
    get activeDeadlineSeconds(): number;
    private _affinity;
    get affinity(): DataKubernetesPodSpecAffinityList;
    get automountServiceAccountToken(): cdktn.IResolvable;
    private _container;
    get container(): DataKubernetesPodSpecContainerList;
    private _dnsConfig;
    get dnsConfig(): DataKubernetesPodSpecDnsConfigList;
    get dnsPolicy(): string;
    get enableServiceLinks(): cdktn.IResolvable;
    private _hostAliases;
    get hostAliases(): DataKubernetesPodSpecHostAliasesList;
    get hostIpc(): cdktn.IResolvable;
    get hostNetwork(): cdktn.IResolvable;
    get hostPid(): cdktn.IResolvable;
    get hostname(): string;
    private _imagePullSecrets;
    get imagePullSecrets(): DataKubernetesPodSpecImagePullSecretsList;
    private _initContainer;
    get initContainer(): DataKubernetesPodSpecInitContainerList;
    get nodeName(): string;
    private _nodeSelector;
    get nodeSelector(): cdktn.StringMap;
    private _os;
    get os(): DataKubernetesPodSpecOsList;
    get priorityClassName(): string;
    private _readinessGate;
    get readinessGate(): DataKubernetesPodSpecReadinessGateList;
    get restartPolicy(): string;
    get runtimeClassName(): string;
    get schedulerName(): string;
    private _securityContext;
    get securityContext(): DataKubernetesPodSpecSecurityContextList;
    get serviceAccountName(): string;
    get shareProcessNamespace(): cdktn.IResolvable;
    get subdomain(): string;
    get terminationGracePeriodSeconds(): number;
    private _toleration;
    get toleration(): DataKubernetesPodSpecTolerationList;
    private _topologySpreadConstraint;
    get topologySpreadConstraint(): DataKubernetesPodSpecTopologySpreadConstraintList;
    private _volume;
    get volume(): DataKubernetesPodSpecVolumeList;
}
export declare class DataKubernetesPodSpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecOutputReference;
}
export interface DataKubernetesPodMetadata {
    /**
    * An unstructured key value map stored with the pod that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/pod#annotations DataKubernetesPod#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/pod#generate_name DataKubernetesPod#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the pod. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/pod#labels DataKubernetesPod#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the pod, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/pod#name DataKubernetesPod#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the pod must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/data-sources/pod#namespace DataKubernetesPod#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPodMetadataToTerraform(struct?: DataKubernetesPodMetadataOutputReference | DataKubernetesPodMetadata): any;
export declare function dataKubernetesPodMetadataToHclTerraform(struct?: DataKubernetesPodMetadataOutputReference | DataKubernetesPodMetadata): any;
export declare class DataKubernetesPodMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPodMetadata | undefined;
    set internalValue(value: DataKubernetesPodMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
