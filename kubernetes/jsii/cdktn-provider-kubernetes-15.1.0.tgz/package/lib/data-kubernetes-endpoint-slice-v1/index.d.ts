/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesEndpointSliceV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#id DataKubernetesEndpointSliceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#metadata DataKubernetesEndpointSliceV1#metadata}
    */
    readonly metadata: DataKubernetesEndpointSliceV1Metadata;
}
export interface DataKubernetesEndpointSliceV1EndpointCondition {
}
export declare function dataKubernetesEndpointSliceV1EndpointConditionToTerraform(struct?: DataKubernetesEndpointSliceV1EndpointCondition): any;
export declare function dataKubernetesEndpointSliceV1EndpointConditionToHclTerraform(struct?: DataKubernetesEndpointSliceV1EndpointCondition): any;
export declare class DataKubernetesEndpointSliceV1EndpointConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointSliceV1EndpointCondition | undefined;
    set internalValue(value: DataKubernetesEndpointSliceV1EndpointCondition | undefined);
    get ready(): cdktn.IResolvable;
    get serving(): cdktn.IResolvable;
    get terminating(): cdktn.IResolvable;
}
export declare class DataKubernetesEndpointSliceV1EndpointConditionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointSliceV1EndpointConditionOutputReference;
}
export interface DataKubernetesEndpointSliceV1EndpointTargetRef {
}
export declare function dataKubernetesEndpointSliceV1EndpointTargetRefToTerraform(struct?: DataKubernetesEndpointSliceV1EndpointTargetRef): any;
export declare function dataKubernetesEndpointSliceV1EndpointTargetRefToHclTerraform(struct?: DataKubernetesEndpointSliceV1EndpointTargetRef): any;
export declare class DataKubernetesEndpointSliceV1EndpointTargetRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointSliceV1EndpointTargetRef | undefined;
    set internalValue(value: DataKubernetesEndpointSliceV1EndpointTargetRef | undefined);
    get fieldPath(): string;
    get name(): string;
    get namespace(): string;
    get resourceVersion(): string;
    get uid(): string;
}
export declare class DataKubernetesEndpointSliceV1EndpointTargetRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointSliceV1EndpointTargetRefOutputReference;
}
export interface DataKubernetesEndpointSliceV1Endpoint {
}
export declare function dataKubernetesEndpointSliceV1EndpointToTerraform(struct?: DataKubernetesEndpointSliceV1Endpoint): any;
export declare function dataKubernetesEndpointSliceV1EndpointToHclTerraform(struct?: DataKubernetesEndpointSliceV1Endpoint): any;
export declare class DataKubernetesEndpointSliceV1EndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointSliceV1Endpoint | undefined;
    set internalValue(value: DataKubernetesEndpointSliceV1Endpoint | undefined);
    get addresses(): string[];
    private _condition;
    get condition(): DataKubernetesEndpointSliceV1EndpointConditionList;
    get hostname(): string;
    get nodeName(): string;
    private _targetRef;
    get targetRef(): DataKubernetesEndpointSliceV1EndpointTargetRefList;
    get zone(): string;
}
export declare class DataKubernetesEndpointSliceV1EndpointList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointSliceV1EndpointOutputReference;
}
export interface DataKubernetesEndpointSliceV1Port {
}
export declare function dataKubernetesEndpointSliceV1PortToTerraform(struct?: DataKubernetesEndpointSliceV1Port): any;
export declare function dataKubernetesEndpointSliceV1PortToHclTerraform(struct?: DataKubernetesEndpointSliceV1Port): any;
export declare class DataKubernetesEndpointSliceV1PortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesEndpointSliceV1Port | undefined;
    set internalValue(value: DataKubernetesEndpointSliceV1Port | undefined);
    get appProtocol(): string;
    get name(): string;
    get port(): string;
    get protocol(): string;
}
export declare class DataKubernetesEndpointSliceV1PortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesEndpointSliceV1PortOutputReference;
}
export interface DataKubernetesEndpointSliceV1Metadata {
    /**
    * An unstructured key value map stored with the endpoint_slice that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#annotations DataKubernetesEndpointSliceV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#generate_name DataKubernetesEndpointSliceV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the endpoint_slice. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#labels DataKubernetesEndpointSliceV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the endpoint_slice, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#name DataKubernetesEndpointSliceV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the endpoint_slice must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#namespace DataKubernetesEndpointSliceV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesEndpointSliceV1MetadataToTerraform(struct?: DataKubernetesEndpointSliceV1MetadataOutputReference | DataKubernetesEndpointSliceV1Metadata): any;
export declare function dataKubernetesEndpointSliceV1MetadataToHclTerraform(struct?: DataKubernetesEndpointSliceV1MetadataOutputReference | DataKubernetesEndpointSliceV1Metadata): any;
export declare class DataKubernetesEndpointSliceV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesEndpointSliceV1Metadata | undefined;
    set internalValue(value: DataKubernetesEndpointSliceV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1 kubernetes_endpoint_slice_v1}
*/
export declare class DataKubernetesEndpointSliceV1 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_endpoint_slice_v1";
    /**
    * Generates CDKTN code for importing a DataKubernetesEndpointSliceV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesEndpointSliceV1 to import
    * @param importFromId The id of the existing DataKubernetesEndpointSliceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesEndpointSliceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/endpoint_slice_v1 kubernetes_endpoint_slice_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesEndpointSliceV1Config
    */
    constructor(scope: Construct, id: string, config: DataKubernetesEndpointSliceV1Config);
    get addressType(): string;
    private _endpoint;
    get endpoint(): DataKubernetesEndpointSliceV1EndpointList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _port;
    get port(): DataKubernetesEndpointSliceV1PortList;
    private _metadata;
    get metadata(): DataKubernetesEndpointSliceV1MetadataOutputReference;
    putMetadata(value: DataKubernetesEndpointSliceV1Metadata): void;
    get metadataInput(): DataKubernetesEndpointSliceV1Metadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
