/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesNodesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/nodes#id DataKubernetesNodes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/nodes#metadata DataKubernetesNodes#metadata}
    */
    readonly metadata?: DataKubernetesNodesMetadata;
}
export interface DataKubernetesNodesNodesMetadata {
}
export declare function dataKubernetesNodesNodesMetadataToTerraform(struct?: DataKubernetesNodesNodesMetadata): any;
export declare function dataKubernetesNodesNodesMetadataToHclTerraform(struct?: DataKubernetesNodesNodesMetadata): any;
export declare class DataKubernetesNodesNodesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesMetadata | undefined;
    set internalValue(value: DataKubernetesNodesNodesMetadata | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get generation(): number;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get resourceVersion(): string;
    get uid(): string;
}
export declare class DataKubernetesNodesNodesMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesMetadataOutputReference;
}
export interface DataKubernetesNodesNodesSpecTaints {
}
export declare function dataKubernetesNodesNodesSpecTaintsToTerraform(struct?: DataKubernetesNodesNodesSpecTaints): any;
export declare function dataKubernetesNodesNodesSpecTaintsToHclTerraform(struct?: DataKubernetesNodesNodesSpecTaints): any;
export declare class DataKubernetesNodesNodesSpecTaintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesSpecTaints | undefined;
    set internalValue(value: DataKubernetesNodesNodesSpecTaints | undefined);
    get effect(): string;
    get key(): string;
    get value(): string;
}
export declare class DataKubernetesNodesNodesSpecTaintsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesSpecTaintsOutputReference;
}
export interface DataKubernetesNodesNodesSpec {
}
export declare function dataKubernetesNodesNodesSpecToTerraform(struct?: DataKubernetesNodesNodesSpec): any;
export declare function dataKubernetesNodesNodesSpecToHclTerraform(struct?: DataKubernetesNodesNodesSpec): any;
export declare class DataKubernetesNodesNodesSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesSpec | undefined;
    set internalValue(value: DataKubernetesNodesNodesSpec | undefined);
    get podCidr(): string;
    get podCidrs(): string[];
    get providerId(): string;
    private _taints;
    get taints(): DataKubernetesNodesNodesSpecTaintsList;
    get unschedulable(): cdktn.IResolvable;
}
export declare class DataKubernetesNodesNodesSpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesSpecOutputReference;
}
export interface DataKubernetesNodesNodesStatusAddresses {
}
export declare function dataKubernetesNodesNodesStatusAddressesToTerraform(struct?: DataKubernetesNodesNodesStatusAddresses): any;
export declare function dataKubernetesNodesNodesStatusAddressesToHclTerraform(struct?: DataKubernetesNodesNodesStatusAddresses): any;
export declare class DataKubernetesNodesNodesStatusAddressesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesStatusAddresses | undefined;
    set internalValue(value: DataKubernetesNodesNodesStatusAddresses | undefined);
    get address(): string;
    get type(): string;
}
export declare class DataKubernetesNodesNodesStatusAddressesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesStatusAddressesOutputReference;
}
export interface DataKubernetesNodesNodesStatusConditions {
}
export declare function dataKubernetesNodesNodesStatusConditionsToTerraform(struct?: DataKubernetesNodesNodesStatusConditions): any;
export declare function dataKubernetesNodesNodesStatusConditionsToHclTerraform(struct?: DataKubernetesNodesNodesStatusConditions): any;
export declare class DataKubernetesNodesNodesStatusConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesStatusConditions | undefined;
    set internalValue(value: DataKubernetesNodesNodesStatusConditions | undefined);
    get lastHeartbeatTime(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get status(): string;
    get type(): string;
}
export declare class DataKubernetesNodesNodesStatusConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesStatusConditionsOutputReference;
}
export interface DataKubernetesNodesNodesStatusNodeInfo {
}
export declare function dataKubernetesNodesNodesStatusNodeInfoToTerraform(struct?: DataKubernetesNodesNodesStatusNodeInfo): any;
export declare function dataKubernetesNodesNodesStatusNodeInfoToHclTerraform(struct?: DataKubernetesNodesNodesStatusNodeInfo): any;
export declare class DataKubernetesNodesNodesStatusNodeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesStatusNodeInfo | undefined;
    set internalValue(value: DataKubernetesNodesNodesStatusNodeInfo | undefined);
    get architecture(): string;
    get bootId(): string;
    get containerRuntimeVersion(): string;
    get kernelVersion(): string;
    get kubeProxyVersion(): string;
    get kubeletVersion(): string;
    get machineId(): string;
    get operatingSystem(): string;
    get osImage(): string;
    get systemUuid(): string;
}
export declare class DataKubernetesNodesNodesStatusNodeInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesStatusNodeInfoOutputReference;
}
export interface DataKubernetesNodesNodesStatus {
}
export declare function dataKubernetesNodesNodesStatusToTerraform(struct?: DataKubernetesNodesNodesStatus): any;
export declare function dataKubernetesNodesNodesStatusToHclTerraform(struct?: DataKubernetesNodesNodesStatus): any;
export declare class DataKubernetesNodesNodesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodesStatus | undefined;
    set internalValue(value: DataKubernetesNodesNodesStatus | undefined);
    private _addresses;
    get addresses(): DataKubernetesNodesNodesStatusAddressesList;
    private _allocatable;
    get allocatable(): cdktn.StringMap;
    private _capacity;
    get capacity(): cdktn.StringMap;
    private _conditions;
    get conditions(): DataKubernetesNodesNodesStatusConditionsList;
    private _nodeInfo;
    get nodeInfo(): DataKubernetesNodesNodesStatusNodeInfoList;
}
export declare class DataKubernetesNodesNodesStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesStatusOutputReference;
}
export interface DataKubernetesNodesNodes {
}
export declare function dataKubernetesNodesNodesToTerraform(struct?: DataKubernetesNodesNodes): any;
export declare function dataKubernetesNodesNodesToHclTerraform(struct?: DataKubernetesNodesNodes): any;
export declare class DataKubernetesNodesNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesNodesNodes | undefined;
    set internalValue(value: DataKubernetesNodesNodes | undefined);
    private _metadata;
    get metadata(): DataKubernetesNodesNodesMetadataList;
    private _spec;
    get spec(): DataKubernetesNodesNodesSpecList;
    private _status;
    get status(): DataKubernetesNodesNodesStatusList;
}
export declare class DataKubernetesNodesNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesNodesNodesOutputReference;
}
export interface DataKubernetesNodesMetadata {
    /**
    * Select nodes with these labels. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/nodes#labels DataKubernetesNodes#labels}
    */
    readonly labels: {
        [key: string]: string;
    };
}
export declare function dataKubernetesNodesMetadataToTerraform(struct?: DataKubernetesNodesMetadataOutputReference | DataKubernetesNodesMetadata): any;
export declare function dataKubernetesNodesMetadataToHclTerraform(struct?: DataKubernetesNodesMetadataOutputReference | DataKubernetesNodesMetadata): any;
export declare class DataKubernetesNodesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesNodesMetadata | undefined;
    set internalValue(value: DataKubernetesNodesMetadata | undefined);
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/nodes kubernetes_nodes}
*/
export declare class DataKubernetesNodes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_nodes";
    /**
    * Generates CDKTN code for importing a DataKubernetesNodes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesNodes to import
    * @param importFromId The id of the existing DataKubernetesNodes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/nodes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesNodes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/nodes kubernetes_nodes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesNodesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataKubernetesNodesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nodes;
    get nodes(): DataKubernetesNodesNodesList;
    private _metadata;
    get metadata(): DataKubernetesNodesMetadataOutputReference;
    putMetadata(value: DataKubernetesNodesMetadata): void;
    resetMetadata(): void;
    get metadataInput(): DataKubernetesNodesMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
