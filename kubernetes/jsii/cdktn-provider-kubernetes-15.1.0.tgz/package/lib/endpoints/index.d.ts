/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#id Endpoints#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#metadata Endpoints#metadata}
    */
    readonly metadata: EndpointsMetadata;
    /**
    * subset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#subset Endpoints#subset}
    */
    readonly subset?: EndpointsSubset[] | cdktn.IResolvable;
}
export interface EndpointsMetadata {
    /**
    * An unstructured key value map stored with the endpoints that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#annotations Endpoints#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#generate_name Endpoints#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the endpoints. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#labels Endpoints#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the endpoints, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#name Endpoints#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the endpoints must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#namespace Endpoints#namespace}
    */
    readonly namespace?: string;
}
export declare function endpointsMetadataToTerraform(struct?: EndpointsMetadataOutputReference | EndpointsMetadata): any;
export declare function endpointsMetadataToHclTerraform(struct?: EndpointsMetadataOutputReference | EndpointsMetadata): any;
export declare class EndpointsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EndpointsMetadata | undefined;
    set internalValue(value: EndpointsMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface EndpointsSubsetAddress {
    /**
    * The Hostname of this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#hostname Endpoints#hostname}
    */
    readonly hostname?: string;
    /**
    * The IP of this endpoint. May not be loopback (127.0.0.0/8), link-local (169.254.0.0/16), or link-local multicast ((224.0.0.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#ip Endpoints#ip}
    */
    readonly ip: string;
    /**
    * Node hosting this endpoint. This can be used to determine endpoints local to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#node_name Endpoints#node_name}
    */
    readonly nodeName?: string;
}
export declare function endpointsSubsetAddressToTerraform(struct?: EndpointsSubsetAddress | cdktn.IResolvable): any;
export declare function endpointsSubsetAddressToHclTerraform(struct?: EndpointsSubsetAddress | cdktn.IResolvable): any;
export declare class EndpointsSubsetAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsSubsetAddress | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsSubsetAddress | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
}
export declare class EndpointsSubsetAddressList extends cdktn.ComplexList {
    internalValue?: EndpointsSubsetAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsSubsetAddressOutputReference;
}
export interface EndpointsSubsetNotReadyAddress {
    /**
    * The Hostname of this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#hostname Endpoints#hostname}
    */
    readonly hostname?: string;
    /**
    * The IP of this endpoint. May not be loopback (127.0.0.0/8), link-local (169.254.0.0/16), or link-local multicast ((224.0.0.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#ip Endpoints#ip}
    */
    readonly ip: string;
    /**
    * Node hosting this endpoint. This can be used to determine endpoints local to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#node_name Endpoints#node_name}
    */
    readonly nodeName?: string;
}
export declare function endpointsSubsetNotReadyAddressToTerraform(struct?: EndpointsSubsetNotReadyAddress | cdktn.IResolvable): any;
export declare function endpointsSubsetNotReadyAddressToHclTerraform(struct?: EndpointsSubsetNotReadyAddress | cdktn.IResolvable): any;
export declare class EndpointsSubsetNotReadyAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsSubsetNotReadyAddress | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsSubsetNotReadyAddress | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
}
export declare class EndpointsSubsetNotReadyAddressList extends cdktn.ComplexList {
    internalValue?: EndpointsSubsetNotReadyAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsSubsetNotReadyAddressOutputReference;
}
export interface EndpointsSubsetPort {
    /**
    * The name of this port within the endpoint. Must be a DNS_LABEL. Optional if only one Port is defined on this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#name Endpoints#name}
    */
    readonly name?: string;
    /**
    * The port that will be exposed by this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#port Endpoints#port}
    */
    readonly port: number;
    /**
    * The IP protocol for this port. Supports `TCP` and `UDP`. Default is `TCP`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#protocol Endpoints#protocol}
    */
    readonly protocol?: string;
}
export declare function endpointsSubsetPortToTerraform(struct?: EndpointsSubsetPort | cdktn.IResolvable): any;
export declare function endpointsSubsetPortToHclTerraform(struct?: EndpointsSubsetPort | cdktn.IResolvable): any;
export declare class EndpointsSubsetPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsSubsetPort | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsSubsetPort | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class EndpointsSubsetPortList extends cdktn.ComplexList {
    internalValue?: EndpointsSubsetPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsSubsetPortOutputReference;
}
export interface EndpointsSubset {
    /**
    * address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#address Endpoints#address}
    */
    readonly address?: EndpointsSubsetAddress[] | cdktn.IResolvable;
    /**
    * not_ready_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#not_ready_address Endpoints#not_ready_address}
    */
    readonly notReadyAddress?: EndpointsSubsetNotReadyAddress[] | cdktn.IResolvable;
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#port Endpoints#port}
    */
    readonly port?: EndpointsSubsetPort[] | cdktn.IResolvable;
}
export declare function endpointsSubsetToTerraform(struct?: EndpointsSubset | cdktn.IResolvable): any;
export declare function endpointsSubsetToHclTerraform(struct?: EndpointsSubset | cdktn.IResolvable): any;
export declare class EndpointsSubsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsSubset | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsSubset | cdktn.IResolvable | undefined);
    private _address;
    get address(): EndpointsSubsetAddressList;
    putAddress(value: EndpointsSubsetAddress[] | cdktn.IResolvable): void;
    resetAddress(): void;
    get addressInput(): cdktn.IResolvable | EndpointsSubsetAddress[] | undefined;
    private _notReadyAddress;
    get notReadyAddress(): EndpointsSubsetNotReadyAddressList;
    putNotReadyAddress(value: EndpointsSubsetNotReadyAddress[] | cdktn.IResolvable): void;
    resetNotReadyAddress(): void;
    get notReadyAddressInput(): cdktn.IResolvable | EndpointsSubsetNotReadyAddress[] | undefined;
    private _port;
    get port(): EndpointsSubsetPortList;
    putPort(value: EndpointsSubsetPort[] | cdktn.IResolvable): void;
    resetPort(): void;
    get portInput(): cdktn.IResolvable | EndpointsSubsetPort[] | undefined;
}
export declare class EndpointsSubsetList extends cdktn.ComplexList {
    internalValue?: EndpointsSubset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsSubsetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints kubernetes_endpoints}
*/
export declare class Endpoints extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_endpoints";
    /**
    * Generates CDKTN code for importing a Endpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Endpoints to import
    * @param importFromId The id of the existing Endpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Endpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/endpoints kubernetes_endpoints} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EndpointsConfig
    */
    constructor(scope: Construct, id: string, config: EndpointsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): EndpointsMetadataOutputReference;
    putMetadata(value: EndpointsMetadata): void;
    get metadataInput(): EndpointsMetadata | undefined;
    private _subset;
    get subset(): EndpointsSubsetList;
    putSubset(value: EndpointsSubset[] | cdktn.IResolvable): void;
    resetSubset(): void;
    get subsetInput(): cdktn.IResolvable | EndpointsSubset[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
