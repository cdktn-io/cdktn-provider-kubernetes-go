/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageClassConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether the storage class allow volume expand
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#allow_volume_expansion StorageClass#allow_volume_expansion}
    */
    readonly allowVolumeExpansion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#id StorageClass#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Persistent Volumes that are dynamically created by a storage class will have the mount options specified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#mount_options StorageClass#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * The parameters for the provisioner that should create volumes of this storage class
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#parameters StorageClass#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Indicates the type of the reclaim policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#reclaim_policy StorageClass#reclaim_policy}
    */
    readonly reclaimPolicy?: string;
    /**
    * Indicates the type of the provisioner
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#storage_provisioner StorageClass#storage_provisioner}
    */
    readonly storageProvisioner: string;
    /**
    * Indicates when volume binding and dynamic provisioning should occur
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#volume_binding_mode StorageClass#volume_binding_mode}
    */
    readonly volumeBindingMode?: string;
    /**
    * allowed_topologies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#allowed_topologies StorageClass#allowed_topologies}
    */
    readonly allowedTopologies?: StorageClassAllowedTopologies;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#metadata StorageClass#metadata}
    */
    readonly metadata: StorageClassMetadata;
}
export interface StorageClassAllowedTopologiesMatchLabelExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#key StorageClass#key}
    */
    readonly key?: string;
    /**
    * An array of string values. One value must match the label to be selected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#values StorageClass#values}
    */
    readonly values?: string[];
}
export declare function storageClassAllowedTopologiesMatchLabelExpressionsToTerraform(struct?: StorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable): any;
export declare function storageClassAllowedTopologiesMatchLabelExpressionsToHclTerraform(struct?: StorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable): any;
export declare class StorageClassAllowedTopologiesMatchLabelExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: StorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class StorageClassAllowedTopologiesMatchLabelExpressionsList extends cdktn.ComplexList {
    internalValue?: StorageClassAllowedTopologiesMatchLabelExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageClassAllowedTopologiesMatchLabelExpressionsOutputReference;
}
export interface StorageClassAllowedTopologies {
    /**
    * match_label_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#match_label_expressions StorageClass#match_label_expressions}
    */
    readonly matchLabelExpressions?: StorageClassAllowedTopologiesMatchLabelExpressions[] | cdktn.IResolvable;
}
export declare function storageClassAllowedTopologiesToTerraform(struct?: StorageClassAllowedTopologiesOutputReference | StorageClassAllowedTopologies): any;
export declare function storageClassAllowedTopologiesToHclTerraform(struct?: StorageClassAllowedTopologiesOutputReference | StorageClassAllowedTopologies): any;
export declare class StorageClassAllowedTopologiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageClassAllowedTopologies | undefined;
    set internalValue(value: StorageClassAllowedTopologies | undefined);
    private _matchLabelExpressions;
    get matchLabelExpressions(): StorageClassAllowedTopologiesMatchLabelExpressionsList;
    putMatchLabelExpressions(value: StorageClassAllowedTopologiesMatchLabelExpressions[] | cdktn.IResolvable): void;
    resetMatchLabelExpressions(): void;
    get matchLabelExpressionsInput(): cdktn.IResolvable | StorageClassAllowedTopologiesMatchLabelExpressions[] | undefined;
}
export interface StorageClassMetadata {
    /**
    * An unstructured key value map stored with the storage class that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#annotations StorageClass#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#generate_name StorageClass#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the storage class. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#labels StorageClass#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the storage class, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#name StorageClass#name}
    */
    readonly name?: string;
}
export declare function storageClassMetadataToTerraform(struct?: StorageClassMetadataOutputReference | StorageClassMetadata): any;
export declare function storageClassMetadataToHclTerraform(struct?: StorageClassMetadataOutputReference | StorageClassMetadata): any;
export declare class StorageClassMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageClassMetadata | undefined;
    set internalValue(value: StorageClassMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class kubernetes_storage_class}
*/
export declare class StorageClass extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_storage_class";
    /**
    * Generates CDKTN code for importing a StorageClass resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageClass to import
    * @param importFromId The id of the existing StorageClass that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageClass to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/storage_class kubernetes_storage_class} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageClassConfig
    */
    constructor(scope: Construct, id: string, config: StorageClassConfig);
    private _allowVolumeExpansion?;
    get allowVolumeExpansion(): boolean | cdktn.IResolvable;
    set allowVolumeExpansion(value: boolean | cdktn.IResolvable);
    resetAllowVolumeExpansion(): void;
    get allowVolumeExpansionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _reclaimPolicy?;
    get reclaimPolicy(): string;
    set reclaimPolicy(value: string);
    resetReclaimPolicy(): void;
    get reclaimPolicyInput(): string | undefined;
    private _storageProvisioner?;
    get storageProvisioner(): string;
    set storageProvisioner(value: string);
    get storageProvisionerInput(): string | undefined;
    private _volumeBindingMode?;
    get volumeBindingMode(): string;
    set volumeBindingMode(value: string);
    resetVolumeBindingMode(): void;
    get volumeBindingModeInput(): string | undefined;
    private _allowedTopologies;
    get allowedTopologies(): StorageClassAllowedTopologiesOutputReference;
    putAllowedTopologies(value: StorageClassAllowedTopologies): void;
    resetAllowedTopologies(): void;
    get allowedTopologiesInput(): StorageClassAllowedTopologies | undefined;
    private _metadata;
    get metadata(): StorageClassMetadataOutputReference;
    putMetadata(value: StorageClassMetadata): void;
    get metadataInput(): StorageClassMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
