/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { DataKubernetesPodV1SpecList, DataKubernetesPodV1Metadata, DataKubernetesPodV1MetadataOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesPodV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#id DataKubernetesPodV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#metadata DataKubernetesPodV1#metadata}
    */
    readonly metadata: DataKubernetesPodV1Metadata;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1 kubernetes_pod_v1}
*/
export declare class DataKubernetesPodV1 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_pod_v1";
    /**
    * Generates CDKTN code for importing a DataKubernetesPodV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesPodV1 to import
    * @param importFromId The id of the existing DataKubernetesPodV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesPodV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1 kubernetes_pod_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesPodV1Config
    */
    constructor(scope: Construct, id: string, config: DataKubernetesPodV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _spec;
    get spec(): DataKubernetesPodV1SpecList;
    get status(): string;
    private _metadata;
    get metadata(): DataKubernetesPodV1MetadataOutputReference;
    putMetadata(value: DataKubernetesPodV1Metadata): void;
    get metadataInput(): DataKubernetesPodV1Metadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
