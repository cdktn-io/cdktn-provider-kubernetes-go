/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataKubernetesPodV1SpecInitContainerLifecyclePreStopExecList, DataKubernetesPodV1SpecInitContainerLifecyclePostStartList, DataKubernetesPodV1SpecInitContainerEnvList, DataKubernetesPodV1SpecInitContainerEnvFromList, DataKubernetesPodV1SpecAffinityList, DataKubernetesPodV1SpecContainerList, DataKubernetesPodV1SpecDnsConfigList, DataKubernetesPodV1SpecHostAliasesList, DataKubernetesPodV1SpecImagePullSecretsList } from './structs0';
export interface DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGet {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGet): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGet): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecyclePreStop {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStop): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecyclePreStopToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecyclePreStop): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecyclePreStop | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecyclePreStop | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopTcpSocketList;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecyclePreStopList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecyclePreStopOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLifecycle {
}
export declare function dataKubernetesPodV1SpecInitContainerLifecycleToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecycle): any;
export declare function dataKubernetesPodV1SpecInitContainerLifecycleToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLifecycle): any;
export declare class DataKubernetesPodV1SpecInitContainerLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLifecycle | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLifecycle | undefined);
    private _postStart;
    get postStart(): DataKubernetesPodV1SpecInitContainerLifecyclePostStartList;
    private _preStop;
    get preStop(): DataKubernetesPodV1SpecInitContainerLifecyclePreStopList;
}
export declare class DataKubernetesPodV1SpecInitContainerLifecycleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLifecycleOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLivenessProbeExec {
}
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeExecToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeExec): any;
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeExec): any;
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLivenessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLivenessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLivenessProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLivenessProbeGrpc {
}
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeGrpcToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeGrpc): any;
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeGrpcToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeGrpc): any;
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLivenessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLivenessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLivenessProbeGrpcOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerLivenessProbe {
}
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeToTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbe): any;
export declare function dataKubernetesPodV1SpecInitContainerLivenessProbeToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerLivenessProbe): any;
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerLivenessProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerLivenessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerLivenessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodV1SpecInitContainerLivenessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerLivenessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerLivenessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecInitContainerLivenessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerLivenessProbeOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerPort {
}
export declare function dataKubernetesPodV1SpecInitContainerPortToTerraform(struct?: DataKubernetesPodV1SpecInitContainerPort): any;
export declare function dataKubernetesPodV1SpecInitContainerPortToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerPort): any;
export declare class DataKubernetesPodV1SpecInitContainerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerPort | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerPort | undefined);
    get containerPort(): number;
    get hostIp(): string;
    get hostPort(): number;
    get name(): string;
    get protocol(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerPortOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbeExec {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeExecToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeExec): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeExec): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbeGrpc {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeGrpcToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeGrpc): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeGrpcToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeGrpc): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeGrpcOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerReadinessProbe {
}
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeToTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbe): any;
export declare function dataKubernetesPodV1SpecInitContainerReadinessProbeToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerReadinessProbe): any;
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerReadinessProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerReadinessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerReadinessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodV1SpecInitContainerReadinessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerReadinessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerReadinessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecInitContainerReadinessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerReadinessProbeOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerResources {
}
export declare function dataKubernetesPodV1SpecInitContainerResourcesToTerraform(struct?: DataKubernetesPodV1SpecInitContainerResources): any;
export declare function dataKubernetesPodV1SpecInitContainerResourcesToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerResources): any;
export declare class DataKubernetesPodV1SpecInitContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerResources | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
    private _requests;
    get requests(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecInitContainerResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerResourcesOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContextCapabilities | undefined);
    get add(): string[];
    get drop(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerSecurityContext {
}
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextToTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContext): any;
export declare function dataKubernetesPodV1SpecInitContainerSecurityContextToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerSecurityContext): any;
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerSecurityContext | undefined);
    get allowPrivilegeEscalation(): cdktn.IResolvable;
    private _capabilities;
    get capabilities(): DataKubernetesPodV1SpecInitContainerSecurityContextCapabilitiesList;
    get privileged(): cdktn.IResolvable;
    get readOnlyRootFilesystem(): cdktn.IResolvable;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktn.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodV1SpecInitContainerSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodV1SpecInitContainerSecurityContextSeccompProfileList;
}
export declare class DataKubernetesPodV1SpecInitContainerSecurityContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerSecurityContextOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeExec {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeExecToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeExec): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeExecToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeExec): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeExec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeExecOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeGrpc {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeGrpcToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeGrpc): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeGrpcToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeGrpc): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeGrpcOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeHttpGetToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerStartupProbe {
}
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeToTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbe): any;
export declare function dataKubernetesPodV1SpecInitContainerStartupProbeToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerStartupProbe): any;
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerStartupProbe | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerStartupProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodV1SpecInitContainerStartupProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodV1SpecInitContainerStartupProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodV1SpecInitContainerStartupProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodV1SpecInitContainerStartupProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodV1SpecInitContainerStartupProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerStartupProbeOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerVolumeDevice {
}
export declare function dataKubernetesPodV1SpecInitContainerVolumeDeviceToTerraform(struct?: DataKubernetesPodV1SpecInitContainerVolumeDevice): any;
export declare function dataKubernetesPodV1SpecInitContainerVolumeDeviceToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerVolumeDevice): any;
export declare class DataKubernetesPodV1SpecInitContainerVolumeDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerVolumeDevice | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerVolumeDevice | undefined);
    get devicePath(): string;
    get name(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerVolumeDeviceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerVolumeDeviceOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainerVolumeMount {
}
export declare function dataKubernetesPodV1SpecInitContainerVolumeMountToTerraform(struct?: DataKubernetesPodV1SpecInitContainerVolumeMount): any;
export declare function dataKubernetesPodV1SpecInitContainerVolumeMountToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainerVolumeMount): any;
export declare class DataKubernetesPodV1SpecInitContainerVolumeMountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainerVolumeMount | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainerVolumeMount | undefined);
    get mountPath(): string;
    get mountPropagation(): string;
    get name(): string;
    get readOnly(): cdktn.IResolvable;
    get subPath(): string;
    get subPathExpr(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerVolumeMountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerVolumeMountOutputReference;
}
export interface DataKubernetesPodV1SpecInitContainer {
}
export declare function dataKubernetesPodV1SpecInitContainerToTerraform(struct?: DataKubernetesPodV1SpecInitContainer): any;
export declare function dataKubernetesPodV1SpecInitContainerToHclTerraform(struct?: DataKubernetesPodV1SpecInitContainer): any;
export declare class DataKubernetesPodV1SpecInitContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecInitContainer | undefined;
    set internalValue(value: DataKubernetesPodV1SpecInitContainer | undefined);
    get args(): string[];
    get command(): string[];
    private _env;
    get env(): DataKubernetesPodV1SpecInitContainerEnvList;
    private _envFrom;
    get envFrom(): DataKubernetesPodV1SpecInitContainerEnvFromList;
    get image(): string;
    get imagePullPolicy(): string;
    private _lifecycle;
    get lifecycle(): DataKubernetesPodV1SpecInitContainerLifecycleList;
    private _livenessProbe;
    get livenessProbe(): DataKubernetesPodV1SpecInitContainerLivenessProbeList;
    get name(): string;
    private _port;
    get port(): DataKubernetesPodV1SpecInitContainerPortList;
    private _readinessProbe;
    get readinessProbe(): DataKubernetesPodV1SpecInitContainerReadinessProbeList;
    private _resources;
    get resources(): DataKubernetesPodV1SpecInitContainerResourcesList;
    get restartPolicy(): string;
    private _securityContext;
    get securityContext(): DataKubernetesPodV1SpecInitContainerSecurityContextList;
    private _startupProbe;
    get startupProbe(): DataKubernetesPodV1SpecInitContainerStartupProbeList;
    get stdin(): cdktn.IResolvable;
    get stdinOnce(): cdktn.IResolvable;
    get terminationMessagePath(): string;
    get terminationMessagePolicy(): string;
    get tty(): cdktn.IResolvable;
    private _volumeDevice;
    get volumeDevice(): DataKubernetesPodV1SpecInitContainerVolumeDeviceList;
    private _volumeMount;
    get volumeMount(): DataKubernetesPodV1SpecInitContainerVolumeMountList;
    get workingDir(): string;
}
export declare class DataKubernetesPodV1SpecInitContainerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecInitContainerOutputReference;
}
export interface DataKubernetesPodV1SpecOs {
}
export declare function dataKubernetesPodV1SpecOsToTerraform(struct?: DataKubernetesPodV1SpecOs): any;
export declare function dataKubernetesPodV1SpecOsToHclTerraform(struct?: DataKubernetesPodV1SpecOs): any;
export declare class DataKubernetesPodV1SpecOsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecOs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecOs | undefined);
    get name(): string;
}
export declare class DataKubernetesPodV1SpecOsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecOsOutputReference;
}
export interface DataKubernetesPodV1SpecReadinessGate {
}
export declare function dataKubernetesPodV1SpecReadinessGateToTerraform(struct?: DataKubernetesPodV1SpecReadinessGate): any;
export declare function dataKubernetesPodV1SpecReadinessGateToHclTerraform(struct?: DataKubernetesPodV1SpecReadinessGate): any;
export declare class DataKubernetesPodV1SpecReadinessGateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecReadinessGate | undefined;
    set internalValue(value: DataKubernetesPodV1SpecReadinessGate | undefined);
    get conditionType(): string;
}
export declare class DataKubernetesPodV1SpecReadinessGateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecReadinessGateOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodV1SpecSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodV1SpecSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodV1SpecSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodV1SpecSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodV1SpecSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextSeccompProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextSysctl {
}
export declare function dataKubernetesPodV1SpecSecurityContextSysctlToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSysctl): any;
export declare function dataKubernetesPodV1SpecSecurityContextSysctlToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextSysctl): any;
export declare class DataKubernetesPodV1SpecSecurityContextSysctlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextSysctl | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextSysctl | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextSysctlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextSysctlOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContextWindowsOptions {
}
export declare function dataKubernetesPodV1SpecSecurityContextWindowsOptionsToTerraform(struct?: DataKubernetesPodV1SpecSecurityContextWindowsOptions): any;
export declare function dataKubernetesPodV1SpecSecurityContextWindowsOptionsToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContextWindowsOptions): any;
export declare class DataKubernetesPodV1SpecSecurityContextWindowsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContextWindowsOptions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContextWindowsOptions | undefined);
    get gmsaCredentialSpec(): string;
    get gmsaCredentialSpecName(): string;
    get hostProcess(): cdktn.IResolvable;
    get runAsUsername(): string;
}
export declare class DataKubernetesPodV1SpecSecurityContextWindowsOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextWindowsOptionsOutputReference;
}
export interface DataKubernetesPodV1SpecSecurityContext {
}
export declare function dataKubernetesPodV1SpecSecurityContextToTerraform(struct?: DataKubernetesPodV1SpecSecurityContext): any;
export declare function dataKubernetesPodV1SpecSecurityContextToHclTerraform(struct?: DataKubernetesPodV1SpecSecurityContext): any;
export declare class DataKubernetesPodV1SpecSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodV1SpecSecurityContext | undefined);
    get fsGroup(): string;
    get fsGroupChangePolicy(): string;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktn.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodV1SpecSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodV1SpecSecurityContextSeccompProfileList;
    get supplementalGroups(): number[];
    private _sysctl;
    get sysctl(): DataKubernetesPodV1SpecSecurityContextSysctlList;
    private _windowsOptions;
    get windowsOptions(): DataKubernetesPodV1SpecSecurityContextWindowsOptionsList;
}
export declare class DataKubernetesPodV1SpecSecurityContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecSecurityContextOutputReference;
}
export interface DataKubernetesPodV1SpecToleration {
}
export declare function dataKubernetesPodV1SpecTolerationToTerraform(struct?: DataKubernetesPodV1SpecToleration): any;
export declare function dataKubernetesPodV1SpecTolerationToHclTerraform(struct?: DataKubernetesPodV1SpecToleration): any;
export declare class DataKubernetesPodV1SpecTolerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecToleration | undefined;
    set internalValue(value: DataKubernetesPodV1SpecToleration | undefined);
    get effect(): string;
    get key(): string;
    get operator(): string;
    get tolerationSeconds(): string;
    get value(): string;
}
export declare class DataKubernetesPodV1SpecTolerationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTolerationOutputReference;
}
export interface DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector {
}
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorToTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector): any;
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector): any;
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecTopologySpreadConstraint {
}
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintToTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraint): any;
export declare function dataKubernetesPodV1SpecTopologySpreadConstraintToHclTerraform(struct?: DataKubernetesPodV1SpecTopologySpreadConstraint): any;
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecTopologySpreadConstraint | undefined;
    set internalValue(value: DataKubernetesPodV1SpecTopologySpreadConstraint | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodV1SpecTopologySpreadConstraintLabelSelectorList;
    get matchLabelKeys(): string[];
    get maxSkew(): number;
    get minDomains(): number;
    get nodeAffinityPolicy(): string;
    get nodeTaintsPolicy(): string;
    get topologyKey(): string;
    get whenUnsatisfiable(): string;
}
export declare class DataKubernetesPodV1SpecTopologySpreadConstraintList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecTopologySpreadConstraintOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeAwsElasticBlockStore {
}
export declare function dataKubernetesPodV1SpecVolumeAwsElasticBlockStoreToTerraform(struct?: DataKubernetesPodV1SpecVolumeAwsElasticBlockStore): any;
export declare function dataKubernetesPodV1SpecVolumeAwsElasticBlockStoreToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeAwsElasticBlockStore): any;
export declare class DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeAwsElasticBlockStore | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeAwsElasticBlockStore | undefined);
    get fsType(): string;
    get partition(): number;
    get readOnly(): cdktn.IResolvable;
    get volumeId(): string;
}
export declare class DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeAzureDisk {
}
export declare function dataKubernetesPodV1SpecVolumeAzureDiskToTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureDisk): any;
export declare function dataKubernetesPodV1SpecVolumeAzureDiskToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureDisk): any;
export declare class DataKubernetesPodV1SpecVolumeAzureDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeAzureDisk | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeAzureDisk | undefined);
    get cachingMode(): string;
    get dataDiskUri(): string;
    get diskName(): string;
    get fsType(): string;
    get kind(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeAzureDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeAzureDiskOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeAzureFile {
}
export declare function dataKubernetesPodV1SpecVolumeAzureFileToTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureFile): any;
export declare function dataKubernetesPodV1SpecVolumeAzureFileToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeAzureFile): any;
export declare class DataKubernetesPodV1SpecVolumeAzureFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeAzureFile | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeAzureFile | undefined);
    get readOnly(): cdktn.IResolvable;
    get secretName(): string;
    get secretNamespace(): string;
    get shareName(): string;
}
export declare class DataKubernetesPodV1SpecVolumeAzureFileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeAzureFileOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCephFsSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeCephFsSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFsSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeCephFsSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFsSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeCephFsSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCephFsSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCephFsSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCephFsSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCephFsSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCephFs {
}
export declare function dataKubernetesPodV1SpecVolumeCephFsToTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFs): any;
export declare function dataKubernetesPodV1SpecVolumeCephFsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCephFs): any;
export declare class DataKubernetesPodV1SpecVolumeCephFsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCephFs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCephFs | undefined);
    get monitors(): string[];
    get path(): string;
    get readOnly(): cdktn.IResolvable;
    get secretFile(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecVolumeCephFsSecretRefList;
    get user(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCephFsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCephFsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCinder {
}
export declare function dataKubernetesPodV1SpecVolumeCinderToTerraform(struct?: DataKubernetesPodV1SpecVolumeCinder): any;
export declare function dataKubernetesPodV1SpecVolumeCinderToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCinder): any;
export declare class DataKubernetesPodV1SpecVolumeCinderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCinder | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCinder | undefined);
    get fsType(): string;
    get readOnly(): cdktn.IResolvable;
    get volumeId(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCinderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCinderOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeConfigMapItems {
}
export declare function dataKubernetesPodV1SpecVolumeConfigMapItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMapItems): any;
export declare function dataKubernetesPodV1SpecVolumeConfigMapItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMapItems): any;
export declare class DataKubernetesPodV1SpecVolumeConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeConfigMapItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeConfigMapItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeConfigMapItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeConfigMapItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeConfigMap {
}
export declare function dataKubernetesPodV1SpecVolumeConfigMapToTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMap): any;
export declare function dataKubernetesPodV1SpecVolumeConfigMapToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeConfigMap): any;
export declare class DataKubernetesPodV1SpecVolumeConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeConfigMap | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeConfigMap | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeConfigMapItemsList;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeConfigMapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeConfigMapOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRef | undefined);
    get name(): string;
}
export declare class DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeCsi {
}
export declare function dataKubernetesPodV1SpecVolumeCsiToTerraform(struct?: DataKubernetesPodV1SpecVolumeCsi): any;
export declare function dataKubernetesPodV1SpecVolumeCsiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeCsi): any;
export declare class DataKubernetesPodV1SpecVolumeCsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeCsi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeCsi | undefined);
    get driver(): string;
    get fsType(): string;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): DataKubernetesPodV1SpecVolumeCsiNodePublishSecretRefList;
    get readOnly(): cdktn.IResolvable;
    private _volumeAttributes;
    get volumeAttributes(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecVolumeCsiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeCsiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApiItems {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItems): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApiItems): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApiItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApiItems | undefined);
    private _fieldRef;
    get fieldRef(): DataKubernetesPodV1SpecVolumeDownwardApiItemsFieldRefList;
    get mode(): string;
    get path(): string;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodV1SpecVolumeDownwardApiItemsResourceFieldRefList;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeDownwardApi {
}
export declare function dataKubernetesPodV1SpecVolumeDownwardApiToTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApi): any;
export declare function dataKubernetesPodV1SpecVolumeDownwardApiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeDownwardApi): any;
export declare class DataKubernetesPodV1SpecVolumeDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeDownwardApi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeDownwardApi | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeDownwardApiItemsList;
}
export declare class DataKubernetesPodV1SpecVolumeDownwardApiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeDownwardApiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEmptyDir {
}
export declare function dataKubernetesPodV1SpecVolumeEmptyDirToTerraform(struct?: DataKubernetesPodV1SpecVolumeEmptyDir): any;
export declare function dataKubernetesPodV1SpecVolumeEmptyDirToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEmptyDir): any;
export declare class DataKubernetesPodV1SpecVolumeEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEmptyDir | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEmptyDir | undefined);
    get medium(): string;
    get sizeLimit(): string;
}
export declare class DataKubernetesPodV1SpecVolumeEmptyDirList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEmptyDirOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadata {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadataToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadataToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _labels;
    get labels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResources {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
    private _requests;
    get requests(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelector {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpec {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpec | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpec | undefined);
    get accessModes(): string[];
    private _resources;
    get resources(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecResourcesList;
    private _selector;
    get selector(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecSelectorList;
    get storageClassName(): string;
    get volumeMode(): string;
    get volumeName(): string;
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplate {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplate): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplate): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplate | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplate | undefined);
    private _metadata;
    get metadata(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateMetadataList;
    private _spec;
    get spec(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateSpecList;
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeEphemeral {
}
export declare function dataKubernetesPodV1SpecVolumeEphemeralToTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeral): any;
export declare function dataKubernetesPodV1SpecVolumeEphemeralToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeEphemeral): any;
export declare class DataKubernetesPodV1SpecVolumeEphemeralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeEphemeral | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeEphemeral | undefined);
    private _volumeClaimTemplate;
    get volumeClaimTemplate(): DataKubernetesPodV1SpecVolumeEphemeralVolumeClaimTemplateList;
}
export declare class DataKubernetesPodV1SpecVolumeEphemeralList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeEphemeralOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFc {
}
export declare function dataKubernetesPodV1SpecVolumeFcToTerraform(struct?: DataKubernetesPodV1SpecVolumeFc): any;
export declare function dataKubernetesPodV1SpecVolumeFcToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFc): any;
export declare class DataKubernetesPodV1SpecVolumeFcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFc | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFc | undefined);
    get fsType(): string;
    get lun(): number;
    get readOnly(): cdktn.IResolvable;
    get targetWwNs(): string[];
}
export declare class DataKubernetesPodV1SpecVolumeFcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFcOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFlexVolumeSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFlexVolume {
}
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeToTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolume): any;
export declare function dataKubernetesPodV1SpecVolumeFlexVolumeToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFlexVolume): any;
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFlexVolume | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFlexVolume | undefined);
    get driver(): string;
    get fsType(): string;
    private _options;
    get options(): cdktn.StringMap;
    get readOnly(): cdktn.IResolvable;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecVolumeFlexVolumeSecretRefList;
}
export declare class DataKubernetesPodV1SpecVolumeFlexVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFlexVolumeOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeFlocker {
}
export declare function dataKubernetesPodV1SpecVolumeFlockerToTerraform(struct?: DataKubernetesPodV1SpecVolumeFlocker): any;
export declare function dataKubernetesPodV1SpecVolumeFlockerToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeFlocker): any;
export declare class DataKubernetesPodV1SpecVolumeFlockerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeFlocker | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeFlocker | undefined);
    get datasetName(): string;
    get datasetUuid(): string;
}
export declare class DataKubernetesPodV1SpecVolumeFlockerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeFlockerOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeGcePersistentDisk {
}
export declare function dataKubernetesPodV1SpecVolumeGcePersistentDiskToTerraform(struct?: DataKubernetesPodV1SpecVolumeGcePersistentDisk): any;
export declare function dataKubernetesPodV1SpecVolumeGcePersistentDiskToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeGcePersistentDisk): any;
export declare class DataKubernetesPodV1SpecVolumeGcePersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeGcePersistentDisk | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeGcePersistentDisk | undefined);
    get fsType(): string;
    get partition(): number;
    get pdName(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeGcePersistentDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeGcePersistentDiskOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeGitRepo {
}
export declare function dataKubernetesPodV1SpecVolumeGitRepoToTerraform(struct?: DataKubernetesPodV1SpecVolumeGitRepo): any;
export declare function dataKubernetesPodV1SpecVolumeGitRepoToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeGitRepo): any;
export declare class DataKubernetesPodV1SpecVolumeGitRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeGitRepo | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeGitRepo | undefined);
    get directory(): string;
    get repository(): string;
    get revision(): string;
}
export declare class DataKubernetesPodV1SpecVolumeGitRepoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeGitRepoOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeGlusterfs {
}
export declare function dataKubernetesPodV1SpecVolumeGlusterfsToTerraform(struct?: DataKubernetesPodV1SpecVolumeGlusterfs): any;
export declare function dataKubernetesPodV1SpecVolumeGlusterfsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeGlusterfs): any;
export declare class DataKubernetesPodV1SpecVolumeGlusterfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeGlusterfs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeGlusterfs | undefined);
    get endpointsName(): string;
    get path(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeGlusterfsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeGlusterfsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeHostPath {
}
export declare function dataKubernetesPodV1SpecVolumeHostPathToTerraform(struct?: DataKubernetesPodV1SpecVolumeHostPath): any;
export declare function dataKubernetesPodV1SpecVolumeHostPathToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeHostPath): any;
export declare class DataKubernetesPodV1SpecVolumeHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeHostPath | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeHostPath | undefined);
    get path(): string;
    get type(): string;
}
export declare class DataKubernetesPodV1SpecVolumeHostPathList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeHostPathOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeIscsi {
}
export declare function dataKubernetesPodV1SpecVolumeIscsiToTerraform(struct?: DataKubernetesPodV1SpecVolumeIscsi): any;
export declare function dataKubernetesPodV1SpecVolumeIscsiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeIscsi): any;
export declare class DataKubernetesPodV1SpecVolumeIscsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeIscsi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeIscsi | undefined);
    get fsType(): string;
    get iqn(): string;
    get iscsiInterface(): string;
    get lun(): number;
    get readOnly(): cdktn.IResolvable;
    get targetPortal(): string;
}
export declare class DataKubernetesPodV1SpecVolumeIscsiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeIscsiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeLocal {
}
export declare function dataKubernetesPodV1SpecVolumeLocalToTerraform(struct?: DataKubernetesPodV1SpecVolumeLocal): any;
export declare function dataKubernetesPodV1SpecVolumeLocalToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeLocal): any;
export declare class DataKubernetesPodV1SpecVolumeLocalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeLocal | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeLocal | undefined);
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeLocalList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeLocalOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeNfs {
}
export declare function dataKubernetesPodV1SpecVolumeNfsToTerraform(struct?: DataKubernetesPodV1SpecVolumeNfs): any;
export declare function dataKubernetesPodV1SpecVolumeNfsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeNfs): any;
export declare class DataKubernetesPodV1SpecVolumeNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeNfs | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeNfs | undefined);
    get path(): string;
    get readOnly(): cdktn.IResolvable;
    get server(): string;
}
export declare class DataKubernetesPodV1SpecVolumeNfsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeNfsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumePersistentVolumeClaim {
}
export declare function dataKubernetesPodV1SpecVolumePersistentVolumeClaimToTerraform(struct?: DataKubernetesPodV1SpecVolumePersistentVolumeClaim): any;
export declare function dataKubernetesPodV1SpecVolumePersistentVolumeClaimToHclTerraform(struct?: DataKubernetesPodV1SpecVolumePersistentVolumeClaim): any;
export declare class DataKubernetesPodV1SpecVolumePersistentVolumeClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumePersistentVolumeClaim | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumePersistentVolumeClaim | undefined);
    get claimName(): string;
    get readOnly(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumePersistentVolumeClaimList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumePersistentVolumeClaimOutputReference;
}
export interface DataKubernetesPodV1SpecVolumePhotonPersistentDisk {
}
export declare function dataKubernetesPodV1SpecVolumePhotonPersistentDiskToTerraform(struct?: DataKubernetesPodV1SpecVolumePhotonPersistentDisk): any;
export declare function dataKubernetesPodV1SpecVolumePhotonPersistentDiskToHclTerraform(struct?: DataKubernetesPodV1SpecVolumePhotonPersistentDisk): any;
export declare class DataKubernetesPodV1SpecVolumePhotonPersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumePhotonPersistentDisk | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumePhotonPersistentDisk | undefined);
    get fsType(): string;
    get pdId(): string;
}
export declare class DataKubernetesPodV1SpecVolumePhotonPersistentDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumePhotonPersistentDiskOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMap | undefined);
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapItemsList;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItems | undefined);
    private _fieldRef;
    get fieldRef(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsFieldRefList;
    get mode(): string;
    get path(): string;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApi | undefined);
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiItemsList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesSecret {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecret): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesSecretToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesSecret): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecret | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesSecret | undefined);
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretItemsList;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesSecretList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountToken | undefined);
    get audience(): string;
    get expirationSeconds(): number;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjectedSources {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSources): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedSourcesToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjectedSources): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjectedSources | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjectedSources | undefined);
    private _configMap;
    get configMap(): DataKubernetesPodV1SpecVolumeProjectedSourcesConfigMapList;
    private _downwardApi;
    get downwardApi(): DataKubernetesPodV1SpecVolumeProjectedSourcesDownwardApiList;
    private _secret;
    get secret(): DataKubernetesPodV1SpecVolumeProjectedSourcesSecretList;
    private _serviceAccountToken;
    get serviceAccountToken(): DataKubernetesPodV1SpecVolumeProjectedSourcesServiceAccountTokenList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedSourcesOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeProjected {
}
export declare function dataKubernetesPodV1SpecVolumeProjectedToTerraform(struct?: DataKubernetesPodV1SpecVolumeProjected): any;
export declare function dataKubernetesPodV1SpecVolumeProjectedToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeProjected): any;
export declare class DataKubernetesPodV1SpecVolumeProjectedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeProjected | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeProjected | undefined);
    get defaultMode(): string;
    private _sources;
    get sources(): DataKubernetesPodV1SpecVolumeProjectedSourcesList;
}
export declare class DataKubernetesPodV1SpecVolumeProjectedList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeProjectedOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeQuobyte {
}
export declare function dataKubernetesPodV1SpecVolumeQuobyteToTerraform(struct?: DataKubernetesPodV1SpecVolumeQuobyte): any;
export declare function dataKubernetesPodV1SpecVolumeQuobyteToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeQuobyte): any;
export declare class DataKubernetesPodV1SpecVolumeQuobyteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeQuobyte | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeQuobyte | undefined);
    get group(): string;
    get readOnly(): cdktn.IResolvable;
    get registry(): string;
    get user(): string;
    get volume(): string;
}
export declare class DataKubernetesPodV1SpecVolumeQuobyteList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeQuobyteOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeRbdSecretRef {
}
export declare function dataKubernetesPodV1SpecVolumeRbdSecretRefToTerraform(struct?: DataKubernetesPodV1SpecVolumeRbdSecretRef): any;
export declare function dataKubernetesPodV1SpecVolumeRbdSecretRefToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeRbdSecretRef): any;
export declare class DataKubernetesPodV1SpecVolumeRbdSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeRbdSecretRef | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeRbdSecretRef | undefined);
    get name(): string;
    get namespace(): string;
}
export declare class DataKubernetesPodV1SpecVolumeRbdSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeRbdSecretRefOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeRbd {
}
export declare function dataKubernetesPodV1SpecVolumeRbdToTerraform(struct?: DataKubernetesPodV1SpecVolumeRbd): any;
export declare function dataKubernetesPodV1SpecVolumeRbdToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeRbd): any;
export declare class DataKubernetesPodV1SpecVolumeRbdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeRbd | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeRbd | undefined);
    get cephMonitors(): string[];
    get fsType(): string;
    get keyring(): string;
    get radosUser(): string;
    get rbdImage(): string;
    get rbdPool(): string;
    get readOnly(): cdktn.IResolvable;
    private _secretRef;
    get secretRef(): DataKubernetesPodV1SpecVolumeRbdSecretRefList;
}
export declare class DataKubernetesPodV1SpecVolumeRbdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeRbdOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeSecretItems {
}
export declare function dataKubernetesPodV1SpecVolumeSecretItemsToTerraform(struct?: DataKubernetesPodV1SpecVolumeSecretItems): any;
export declare function dataKubernetesPodV1SpecVolumeSecretItemsToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeSecretItems): any;
export declare class DataKubernetesPodV1SpecVolumeSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeSecretItems | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeSecretItems | undefined);
    get key(): string;
    get mode(): string;
    get path(): string;
}
export declare class DataKubernetesPodV1SpecVolumeSecretItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeSecretItemsOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeSecret {
}
export declare function dataKubernetesPodV1SpecVolumeSecretToTerraform(struct?: DataKubernetesPodV1SpecVolumeSecret): any;
export declare function dataKubernetesPodV1SpecVolumeSecretToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeSecret): any;
export declare class DataKubernetesPodV1SpecVolumeSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeSecret | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeSecret | undefined);
    get defaultMode(): string;
    private _items;
    get items(): DataKubernetesPodV1SpecVolumeSecretItemsList;
    get optional(): cdktn.IResolvable;
    get secretName(): string;
}
export declare class DataKubernetesPodV1SpecVolumeSecretList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeSecretOutputReference;
}
export interface DataKubernetesPodV1SpecVolumeVsphereVolume {
}
export declare function dataKubernetesPodV1SpecVolumeVsphereVolumeToTerraform(struct?: DataKubernetesPodV1SpecVolumeVsphereVolume): any;
export declare function dataKubernetesPodV1SpecVolumeVsphereVolumeToHclTerraform(struct?: DataKubernetesPodV1SpecVolumeVsphereVolume): any;
export declare class DataKubernetesPodV1SpecVolumeVsphereVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolumeVsphereVolume | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolumeVsphereVolume | undefined);
    get fsType(): string;
    get volumePath(): string;
}
export declare class DataKubernetesPodV1SpecVolumeVsphereVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeVsphereVolumeOutputReference;
}
export interface DataKubernetesPodV1SpecVolume {
}
export declare function dataKubernetesPodV1SpecVolumeToTerraform(struct?: DataKubernetesPodV1SpecVolume): any;
export declare function dataKubernetesPodV1SpecVolumeToHclTerraform(struct?: DataKubernetesPodV1SpecVolume): any;
export declare class DataKubernetesPodV1SpecVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1SpecVolume | undefined;
    set internalValue(value: DataKubernetesPodV1SpecVolume | undefined);
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): DataKubernetesPodV1SpecVolumeAwsElasticBlockStoreList;
    private _azureDisk;
    get azureDisk(): DataKubernetesPodV1SpecVolumeAzureDiskList;
    private _azureFile;
    get azureFile(): DataKubernetesPodV1SpecVolumeAzureFileList;
    private _cephFs;
    get cephFs(): DataKubernetesPodV1SpecVolumeCephFsList;
    private _cinder;
    get cinder(): DataKubernetesPodV1SpecVolumeCinderList;
    private _configMap;
    get configMap(): DataKubernetesPodV1SpecVolumeConfigMapList;
    private _csi;
    get csi(): DataKubernetesPodV1SpecVolumeCsiList;
    private _downwardApi;
    get downwardApi(): DataKubernetesPodV1SpecVolumeDownwardApiList;
    private _emptyDir;
    get emptyDir(): DataKubernetesPodV1SpecVolumeEmptyDirList;
    private _ephemeral;
    get ephemeral(): DataKubernetesPodV1SpecVolumeEphemeralList;
    private _fc;
    get fc(): DataKubernetesPodV1SpecVolumeFcList;
    private _flexVolume;
    get flexVolume(): DataKubernetesPodV1SpecVolumeFlexVolumeList;
    private _flocker;
    get flocker(): DataKubernetesPodV1SpecVolumeFlockerList;
    private _gcePersistentDisk;
    get gcePersistentDisk(): DataKubernetesPodV1SpecVolumeGcePersistentDiskList;
    private _gitRepo;
    get gitRepo(): DataKubernetesPodV1SpecVolumeGitRepoList;
    private _glusterfs;
    get glusterfs(): DataKubernetesPodV1SpecVolumeGlusterfsList;
    private _hostPath;
    get hostPath(): DataKubernetesPodV1SpecVolumeHostPathList;
    private _iscsi;
    get iscsi(): DataKubernetesPodV1SpecVolumeIscsiList;
    private _local;
    get local(): DataKubernetesPodV1SpecVolumeLocalList;
    get name(): string;
    private _nfs;
    get nfs(): DataKubernetesPodV1SpecVolumeNfsList;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): DataKubernetesPodV1SpecVolumePersistentVolumeClaimList;
    private _photonPersistentDisk;
    get photonPersistentDisk(): DataKubernetesPodV1SpecVolumePhotonPersistentDiskList;
    private _projected;
    get projected(): DataKubernetesPodV1SpecVolumeProjectedList;
    private _quobyte;
    get quobyte(): DataKubernetesPodV1SpecVolumeQuobyteList;
    private _rbd;
    get rbd(): DataKubernetesPodV1SpecVolumeRbdList;
    private _secret;
    get secret(): DataKubernetesPodV1SpecVolumeSecretList;
    private _vsphereVolume;
    get vsphereVolume(): DataKubernetesPodV1SpecVolumeVsphereVolumeList;
}
export declare class DataKubernetesPodV1SpecVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecVolumeOutputReference;
}
export interface DataKubernetesPodV1Spec {
}
export declare function dataKubernetesPodV1SpecToTerraform(struct?: DataKubernetesPodV1Spec): any;
export declare function dataKubernetesPodV1SpecToHclTerraform(struct?: DataKubernetesPodV1Spec): any;
export declare class DataKubernetesPodV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodV1Spec | undefined;
    set internalValue(value: DataKubernetesPodV1Spec | undefined);
    get activeDeadlineSeconds(): number;
    private _affinity;
    get affinity(): DataKubernetesPodV1SpecAffinityList;
    get automountServiceAccountToken(): cdktn.IResolvable;
    private _container;
    get container(): DataKubernetesPodV1SpecContainerList;
    private _dnsConfig;
    get dnsConfig(): DataKubernetesPodV1SpecDnsConfigList;
    get dnsPolicy(): string;
    get enableServiceLinks(): cdktn.IResolvable;
    private _hostAliases;
    get hostAliases(): DataKubernetesPodV1SpecHostAliasesList;
    get hostIpc(): cdktn.IResolvable;
    get hostNetwork(): cdktn.IResolvable;
    get hostPid(): cdktn.IResolvable;
    get hostname(): string;
    private _imagePullSecrets;
    get imagePullSecrets(): DataKubernetesPodV1SpecImagePullSecretsList;
    private _initContainer;
    get initContainer(): DataKubernetesPodV1SpecInitContainerList;
    get nodeName(): string;
    private _nodeSelector;
    get nodeSelector(): cdktn.StringMap;
    private _os;
    get os(): DataKubernetesPodV1SpecOsList;
    get priorityClassName(): string;
    private _readinessGate;
    get readinessGate(): DataKubernetesPodV1SpecReadinessGateList;
    get restartPolicy(): string;
    get runtimeClassName(): string;
    get schedulerName(): string;
    private _securityContext;
    get securityContext(): DataKubernetesPodV1SpecSecurityContextList;
    get serviceAccountName(): string;
    get shareProcessNamespace(): cdktn.IResolvable;
    get subdomain(): string;
    get terminationGracePeriodSeconds(): number;
    private _toleration;
    get toleration(): DataKubernetesPodV1SpecTolerationList;
    private _topologySpreadConstraint;
    get topologySpreadConstraint(): DataKubernetesPodV1SpecTopologySpreadConstraintList;
    private _volume;
    get volume(): DataKubernetesPodV1SpecVolumeList;
}
export declare class DataKubernetesPodV1SpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodV1SpecOutputReference;
}
export interface DataKubernetesPodV1Metadata {
    /**
    * An unstructured key value map stored with the pod that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#annotations DataKubernetesPodV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#generate_name DataKubernetesPodV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the pod. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#labels DataKubernetesPodV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the pod, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#name DataKubernetesPodV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the pod must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/pod_v1#namespace DataKubernetesPodV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPodV1MetadataToTerraform(struct?: DataKubernetesPodV1MetadataOutputReference | DataKubernetesPodV1Metadata): any;
export declare function dataKubernetesPodV1MetadataToHclTerraform(struct?: DataKubernetesPodV1MetadataOutputReference | DataKubernetesPodV1Metadata): any;
export declare class DataKubernetesPodV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPodV1Metadata | undefined;
    set internalValue(value: DataKubernetesPodV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
