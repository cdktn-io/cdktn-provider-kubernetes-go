/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigMapV1DataConfig extends cdktn.TerraformMetaArguments {
    /**
    * The data we want to add to the ConfigMap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#data ConfigMapV1Data#data}
    */
    readonly data: {
        [key: string]: string;
    };
    /**
    * Set the name of the field manager for the specified labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#field_manager ConfigMapV1Data#field_manager}
    */
    readonly fieldManager?: string;
    /**
    * Force overwriting data that is managed outside of Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#force ConfigMapV1Data#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#id ConfigMapV1Data#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#metadata ConfigMapV1Data#metadata}
    */
    readonly metadata: ConfigMapV1DataMetadata;
}
export interface ConfigMapV1DataMetadata {
    /**
    * The name of the ConfigMap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#name ConfigMapV1Data#name}
    */
    readonly name: string;
    /**
    * The namespace of the ConfigMap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#namespace ConfigMapV1Data#namespace}
    */
    readonly namespace?: string;
}
export declare function configMapV1DataMetadataToTerraform(struct?: ConfigMapV1DataMetadataOutputReference | ConfigMapV1DataMetadata): any;
export declare function configMapV1DataMetadataToHclTerraform(struct?: ConfigMapV1DataMetadataOutputReference | ConfigMapV1DataMetadata): any;
export declare class ConfigMapV1DataMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigMapV1DataMetadata | undefined;
    set internalValue(value: ConfigMapV1DataMetadata | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data kubernetes_config_map_v1_data}
*/
export declare class ConfigMapV1Data extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_config_map_v1_data";
    /**
    * Generates CDKTN code for importing a ConfigMapV1Data resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigMapV1Data to import
    * @param importFromId The id of the existing ConfigMapV1Data that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigMapV1Data to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/config_map_v1_data kubernetes_config_map_v1_data} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigMapV1DataConfig
    */
    constructor(scope: Construct, id: string, config: ConfigMapV1DataConfig);
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _fieldManager?;
    get fieldManager(): string;
    set fieldManager(value: string);
    resetFieldManager(): void;
    get fieldManagerInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): ConfigMapV1DataMetadataOutputReference;
    putMetadata(value: ConfigMapV1DataMetadata): void;
    get metadataInput(): ConfigMapV1DataMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
