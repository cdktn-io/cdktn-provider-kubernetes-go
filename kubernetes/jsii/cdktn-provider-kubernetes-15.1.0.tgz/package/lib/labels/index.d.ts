/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LabelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The apiVersion of the resource to label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#api_version Labels#api_version}
    */
    readonly apiVersion: string;
    /**
    * Set the name of the field manager for the specified labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#field_manager Labels#field_manager}
    */
    readonly fieldManager?: string;
    /**
    * Force overwriting labels that were created or edited outside of Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#force Labels#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#id Labels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The kind of the resource to label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#kind Labels#kind}
    */
    readonly kind: string;
    /**
    * A map of labels to apply to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#labels Labels#labels}
    */
    readonly labels: {
        [key: string]: string;
    };
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#metadata Labels#metadata}
    */
    readonly metadata: LabelsMetadata;
}
export interface LabelsMetadata {
    /**
    * The name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#name Labels#name}
    */
    readonly name: string;
    /**
    * The namespace of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#namespace Labels#namespace}
    */
    readonly namespace?: string;
}
export declare function labelsMetadataToTerraform(struct?: LabelsMetadataOutputReference | LabelsMetadata): any;
export declare function labelsMetadataToHclTerraform(struct?: LabelsMetadataOutputReference | LabelsMetadata): any;
export declare class LabelsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LabelsMetadata | undefined;
    set internalValue(value: LabelsMetadata | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels kubernetes_labels}
*/
export declare class Labels extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_labels";
    /**
    * Generates CDKTN code for importing a Labels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Labels to import
    * @param importFromId The id of the existing Labels that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Labels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/labels kubernetes_labels} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LabelsConfig
    */
    constructor(scope: Construct, id: string, config: LabelsConfig);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _fieldManager?;
    get fieldManager(): string;
    set fieldManager(value: string);
    resetFieldManager(): void;
    get fieldManagerInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _metadata;
    get metadata(): LabelsMetadataOutputReference;
    putMetadata(value: LabelsMetadata): void;
    get metadataInput(): LabelsMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
