/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { StatefulSetMetadata, StatefulSetMetadataOutputReference, StatefulSetSpec, StatefulSetSpecOutputReference, StatefulSetTimeouts, StatefulSetTimeoutsOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StatefulSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set#id StatefulSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Wait for the rollout of the stateful set to complete. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set#wait_for_rollout StatefulSet#wait_for_rollout}
    */
    readonly waitForRollout?: boolean | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set#metadata StatefulSet#metadata}
    */
    readonly metadata: StatefulSetMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set#spec StatefulSet#spec}
    */
    readonly spec: StatefulSetSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set#timeouts StatefulSet#timeouts}
    */
    readonly timeouts?: StatefulSetTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set kubernetes_stateful_set}
*/
export declare class StatefulSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_stateful_set";
    /**
    * Generates CDKTN code for importing a StatefulSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StatefulSet to import
    * @param importFromId The id of the existing StatefulSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StatefulSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/stateful_set kubernetes_stateful_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StatefulSetConfig
    */
    constructor(scope: Construct, id: string, config: StatefulSetConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _waitForRollout?;
    get waitForRollout(): boolean | cdktn.IResolvable;
    set waitForRollout(value: boolean | cdktn.IResolvable);
    resetWaitForRollout(): void;
    get waitForRolloutInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): StatefulSetMetadataOutputReference;
    putMetadata(value: StatefulSetMetadata): void;
    get metadataInput(): StatefulSetMetadata | undefined;
    private _spec;
    get spec(): StatefulSetSpecOutputReference;
    putSpec(value: StatefulSetSpec): void;
    get specInput(): StatefulSetSpec | undefined;
    private _timeouts;
    get timeouts(): StatefulSetTimeoutsOutputReference;
    putTimeouts(value: StatefulSetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StatefulSetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
