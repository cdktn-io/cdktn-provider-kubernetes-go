/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NetworkPolicyV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#id NetworkPolicyV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#metadata NetworkPolicyV1#metadata}
    */
    readonly metadata: NetworkPolicyV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#spec NetworkPolicyV1#spec}
    */
    readonly spec: NetworkPolicyV1Spec;
}
export interface NetworkPolicyV1Metadata {
    /**
    * An unstructured key value map stored with the network policy that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#annotations NetworkPolicyV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#generate_name NetworkPolicyV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the network policy. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#labels NetworkPolicyV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the network policy, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#name NetworkPolicyV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the network policy must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#namespace NetworkPolicyV1#namespace}
    */
    readonly namespace?: string;
}
export declare function networkPolicyV1MetadataToTerraform(struct?: NetworkPolicyV1MetadataOutputReference | NetworkPolicyV1Metadata): any;
export declare function networkPolicyV1MetadataToHclTerraform(struct?: NetworkPolicyV1MetadataOutputReference | NetworkPolicyV1Metadata): any;
export declare class NetworkPolicyV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1Metadata | undefined;
    set internalValue(value: NetworkPolicyV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface NetworkPolicyV1SpecEgressPorts {
    /**
    * endPort indicates that the range of ports from port to endPort if set, inclusive, should be allowed by the policy. This field cannot be defined if the port field is not defined or if the port field is defined as a named (string) port. The endPort must be equal or greater than port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#end_port NetworkPolicyV1#end_port}
    */
    readonly endPort?: number;
    /**
    * port represents the port on the given protocol. This can either be a numerical or named port on a pod. If this field is not provided, this matches all port names and numbers. If present, only traffic on the specified protocol AND port will be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#port NetworkPolicyV1#port}
    */
    readonly port?: string;
    /**
    * protocol represents the protocol (TCP, UDP, or SCTP) which traffic must match. If not specified, this field defaults to TCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#protocol NetworkPolicyV1#protocol}
    */
    readonly protocol?: string;
}
export declare function networkPolicyV1SpecEgressPortsToTerraform(struct?: NetworkPolicyV1SpecEgressPorts | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecEgressPortsToHclTerraform(struct?: NetworkPolicyV1SpecEgressPorts | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecEgressPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecEgressPorts | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressPorts | cdktn.IResolvable | undefined);
    private _endPort?;
    get endPort(): number;
    set endPort(value: number);
    resetEndPort(): void;
    get endPortInput(): number | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class NetworkPolicyV1SpecEgressPortsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecEgressPorts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecEgressPortsOutputReference;
}
export interface NetworkPolicyV1SpecEgressToIpBlock {
    /**
    * cidr is a string representing the IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#cidr NetworkPolicyV1#cidr}
    */
    readonly cidr?: string;
    /**
    * except is a slice of CIDRs that should not be included within an IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64" Except values will be rejected if they are outside the cidr range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#except NetworkPolicyV1#except}
    */
    readonly except?: string[];
}
export declare function networkPolicyV1SpecEgressToIpBlockToTerraform(struct?: NetworkPolicyV1SpecEgressToIpBlockOutputReference | NetworkPolicyV1SpecEgressToIpBlock): any;
export declare function networkPolicyV1SpecEgressToIpBlockToHclTerraform(struct?: NetworkPolicyV1SpecEgressToIpBlockOutputReference | NetworkPolicyV1SpecEgressToIpBlock): any;
export declare class NetworkPolicyV1SpecEgressToIpBlockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecEgressToIpBlock | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressToIpBlock | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    private _except?;
    get except(): string[];
    set except(value: string[]);
    resetExcept(): void;
    get exceptInput(): string[] | undefined;
}
export interface NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#key NetworkPolicyV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#operator NetworkPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#values NetworkPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function networkPolicyV1SpecEgressToNamespaceSelectorMatchExpressionsToTerraform(struct?: NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecEgressToNamespaceSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicyV1SpecEgressToNamespaceSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_labels NetworkPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_expressions NetworkPolicyV1#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecEgressToNamespaceSelectorToTerraform(struct?: NetworkPolicyV1SpecEgressToNamespaceSelectorOutputReference | NetworkPolicyV1SpecEgressToNamespaceSelector): any;
export declare function networkPolicyV1SpecEgressToNamespaceSelectorToHclTerraform(struct?: NetworkPolicyV1SpecEgressToNamespaceSelectorOutputReference | NetworkPolicyV1SpecEgressToNamespaceSelector): any;
export declare class NetworkPolicyV1SpecEgressToNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecEgressToNamespaceSelector | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressToNamespaceSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicyV1SpecEgressToNamespaceSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#key NetworkPolicyV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#operator NetworkPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#values NetworkPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function networkPolicyV1SpecEgressToPodSelectorMatchExpressionsToTerraform(struct?: NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecEgressToPodSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecEgressToPodSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicyV1SpecEgressToPodSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecEgressToPodSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicyV1SpecEgressToPodSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_labels NetworkPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_expressions NetworkPolicyV1#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecEgressToPodSelectorToTerraform(struct?: NetworkPolicyV1SpecEgressToPodSelectorOutputReference | NetworkPolicyV1SpecEgressToPodSelector): any;
export declare function networkPolicyV1SpecEgressToPodSelectorToHclTerraform(struct?: NetworkPolicyV1SpecEgressToPodSelectorOutputReference | NetworkPolicyV1SpecEgressToPodSelector): any;
export declare class NetworkPolicyV1SpecEgressToPodSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecEgressToPodSelector | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressToPodSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicyV1SpecEgressToPodSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicyV1SpecEgressToPodSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicyV1SpecEgressTo {
    /**
    * ip_block block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#ip_block NetworkPolicyV1#ip_block}
    */
    readonly ipBlock?: NetworkPolicyV1SpecEgressToIpBlock;
    /**
    * namespace_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#namespace_selector NetworkPolicyV1#namespace_selector}
    */
    readonly namespaceSelector?: NetworkPolicyV1SpecEgressToNamespaceSelector;
    /**
    * pod_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#pod_selector NetworkPolicyV1#pod_selector}
    */
    readonly podSelector?: NetworkPolicyV1SpecEgressToPodSelector;
}
export declare function networkPolicyV1SpecEgressToToTerraform(struct?: NetworkPolicyV1SpecEgressTo | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecEgressToToHclTerraform(struct?: NetworkPolicyV1SpecEgressTo | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecEgressToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecEgressTo | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgressTo | cdktn.IResolvable | undefined);
    private _ipBlock;
    get ipBlock(): NetworkPolicyV1SpecEgressToIpBlockOutputReference;
    putIpBlock(value: NetworkPolicyV1SpecEgressToIpBlock): void;
    resetIpBlock(): void;
    get ipBlockInput(): NetworkPolicyV1SpecEgressToIpBlock | undefined;
    private _namespaceSelector;
    get namespaceSelector(): NetworkPolicyV1SpecEgressToNamespaceSelectorOutputReference;
    putNamespaceSelector(value: NetworkPolicyV1SpecEgressToNamespaceSelector): void;
    resetNamespaceSelector(): void;
    get namespaceSelectorInput(): NetworkPolicyV1SpecEgressToNamespaceSelector | undefined;
    private _podSelector;
    get podSelector(): NetworkPolicyV1SpecEgressToPodSelectorOutputReference;
    putPodSelector(value: NetworkPolicyV1SpecEgressToPodSelector): void;
    resetPodSelector(): void;
    get podSelectorInput(): NetworkPolicyV1SpecEgressToPodSelector | undefined;
}
export declare class NetworkPolicyV1SpecEgressToList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecEgressTo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecEgressToOutputReference;
}
export interface NetworkPolicyV1SpecEgress {
    /**
    * ports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#ports NetworkPolicyV1#ports}
    */
    readonly ports?: NetworkPolicyV1SpecEgressPorts[] | cdktn.IResolvable;
    /**
    * to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#to NetworkPolicyV1#to}
    */
    readonly to?: NetworkPolicyV1SpecEgressTo[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecEgressToTerraform(struct?: NetworkPolicyV1SpecEgress | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecEgressToHclTerraform(struct?: NetworkPolicyV1SpecEgress | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecEgress | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecEgress | cdktn.IResolvable | undefined);
    private _ports;
    get ports(): NetworkPolicyV1SpecEgressPortsList;
    putPorts(value: NetworkPolicyV1SpecEgressPorts[] | cdktn.IResolvable): void;
    resetPorts(): void;
    get portsInput(): cdktn.IResolvable | NetworkPolicyV1SpecEgressPorts[] | undefined;
    private _to;
    get to(): NetworkPolicyV1SpecEgressToList;
    putTo(value: NetworkPolicyV1SpecEgressTo[] | cdktn.IResolvable): void;
    resetTo(): void;
    get toInput(): cdktn.IResolvable | NetworkPolicyV1SpecEgressTo[] | undefined;
}
export declare class NetworkPolicyV1SpecEgressList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecEgress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecEgressOutputReference;
}
export interface NetworkPolicyV1SpecIngressFromIpBlock {
    /**
    * cidr is a string representing the IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#cidr NetworkPolicyV1#cidr}
    */
    readonly cidr?: string;
    /**
    * except is a slice of CIDRs that should not be included within an IPBlock Valid examples are "192.168.1.0/24" or "2001:db8::/64" Except values will be rejected if they are outside the cidr range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#except NetworkPolicyV1#except}
    */
    readonly except?: string[];
}
export declare function networkPolicyV1SpecIngressFromIpBlockToTerraform(struct?: NetworkPolicyV1SpecIngressFromIpBlockOutputReference | NetworkPolicyV1SpecIngressFromIpBlock): any;
export declare function networkPolicyV1SpecIngressFromIpBlockToHclTerraform(struct?: NetworkPolicyV1SpecIngressFromIpBlockOutputReference | NetworkPolicyV1SpecIngressFromIpBlock): any;
export declare class NetworkPolicyV1SpecIngressFromIpBlockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecIngressFromIpBlock | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressFromIpBlock | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    private _except?;
    get except(): string[];
    set except(value: string[]);
    resetExcept(): void;
    get exceptInput(): string[] | undefined;
}
export interface NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#key NetworkPolicyV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#operator NetworkPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#values NetworkPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function networkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressionsToTerraform(struct?: NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicyV1SpecIngressFromNamespaceSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_labels NetworkPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_expressions NetworkPolicyV1#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecIngressFromNamespaceSelectorToTerraform(struct?: NetworkPolicyV1SpecIngressFromNamespaceSelectorOutputReference | NetworkPolicyV1SpecIngressFromNamespaceSelector): any;
export declare function networkPolicyV1SpecIngressFromNamespaceSelectorToHclTerraform(struct?: NetworkPolicyV1SpecIngressFromNamespaceSelectorOutputReference | NetworkPolicyV1SpecIngressFromNamespaceSelector): any;
export declare class NetworkPolicyV1SpecIngressFromNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecIngressFromNamespaceSelector | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressFromNamespaceSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicyV1SpecIngressFromNamespaceSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#key NetworkPolicyV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#operator NetworkPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#values NetworkPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function networkPolicyV1SpecIngressFromPodSelectorMatchExpressionsToTerraform(struct?: NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecIngressFromPodSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicyV1SpecIngressFromPodSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_labels NetworkPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_expressions NetworkPolicyV1#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecIngressFromPodSelectorToTerraform(struct?: NetworkPolicyV1SpecIngressFromPodSelectorOutputReference | NetworkPolicyV1SpecIngressFromPodSelector): any;
export declare function networkPolicyV1SpecIngressFromPodSelectorToHclTerraform(struct?: NetworkPolicyV1SpecIngressFromPodSelectorOutputReference | NetworkPolicyV1SpecIngressFromPodSelector): any;
export declare class NetworkPolicyV1SpecIngressFromPodSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecIngressFromPodSelector | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressFromPodSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicyV1SpecIngressFromPodSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicyV1SpecIngressFrom {
    /**
    * ip_block block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#ip_block NetworkPolicyV1#ip_block}
    */
    readonly ipBlock?: NetworkPolicyV1SpecIngressFromIpBlock;
    /**
    * namespace_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#namespace_selector NetworkPolicyV1#namespace_selector}
    */
    readonly namespaceSelector?: NetworkPolicyV1SpecIngressFromNamespaceSelector;
    /**
    * pod_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#pod_selector NetworkPolicyV1#pod_selector}
    */
    readonly podSelector?: NetworkPolicyV1SpecIngressFromPodSelector;
}
export declare function networkPolicyV1SpecIngressFromToTerraform(struct?: NetworkPolicyV1SpecIngressFrom | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecIngressFromToHclTerraform(struct?: NetworkPolicyV1SpecIngressFrom | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecIngressFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecIngressFrom | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressFrom | cdktn.IResolvable | undefined);
    private _ipBlock;
    get ipBlock(): NetworkPolicyV1SpecIngressFromIpBlockOutputReference;
    putIpBlock(value: NetworkPolicyV1SpecIngressFromIpBlock): void;
    resetIpBlock(): void;
    get ipBlockInput(): NetworkPolicyV1SpecIngressFromIpBlock | undefined;
    private _namespaceSelector;
    get namespaceSelector(): NetworkPolicyV1SpecIngressFromNamespaceSelectorOutputReference;
    putNamespaceSelector(value: NetworkPolicyV1SpecIngressFromNamespaceSelector): void;
    resetNamespaceSelector(): void;
    get namespaceSelectorInput(): NetworkPolicyV1SpecIngressFromNamespaceSelector | undefined;
    private _podSelector;
    get podSelector(): NetworkPolicyV1SpecIngressFromPodSelectorOutputReference;
    putPodSelector(value: NetworkPolicyV1SpecIngressFromPodSelector): void;
    resetPodSelector(): void;
    get podSelectorInput(): NetworkPolicyV1SpecIngressFromPodSelector | undefined;
}
export declare class NetworkPolicyV1SpecIngressFromList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecIngressFrom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecIngressFromOutputReference;
}
export interface NetworkPolicyV1SpecIngressPorts {
    /**
    * endPort indicates that the range of ports from port to endPort if set, inclusive, should be allowed by the policy. This field cannot be defined if the port field is not defined or if the port field is defined as a named (string) port. The endPort must be equal or greater than port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#end_port NetworkPolicyV1#end_port}
    */
    readonly endPort?: number;
    /**
    * port represents the port on the given protocol. This can either be a numerical or named port on a pod. If this field is not provided, this matches all port names and numbers. If present, only traffic on the specified protocol AND port will be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#port NetworkPolicyV1#port}
    */
    readonly port?: string;
    /**
    * protocol represents the protocol (TCP, UDP, or SCTP) which traffic must match. If not specified, this field defaults to TCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#protocol NetworkPolicyV1#protocol}
    */
    readonly protocol?: string;
}
export declare function networkPolicyV1SpecIngressPortsToTerraform(struct?: NetworkPolicyV1SpecIngressPorts | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecIngressPortsToHclTerraform(struct?: NetworkPolicyV1SpecIngressPorts | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecIngressPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecIngressPorts | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngressPorts | cdktn.IResolvable | undefined);
    private _endPort?;
    get endPort(): number;
    set endPort(value: number);
    resetEndPort(): void;
    get endPortInput(): number | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class NetworkPolicyV1SpecIngressPortsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecIngressPorts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecIngressPortsOutputReference;
}
export interface NetworkPolicyV1SpecIngress {
    /**
    * from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#from NetworkPolicyV1#from}
    */
    readonly from?: NetworkPolicyV1SpecIngressFrom[] | cdktn.IResolvable;
    /**
    * ports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#ports NetworkPolicyV1#ports}
    */
    readonly ports?: NetworkPolicyV1SpecIngressPorts[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecIngressToTerraform(struct?: NetworkPolicyV1SpecIngress | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecIngressToHclTerraform(struct?: NetworkPolicyV1SpecIngress | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecIngress | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecIngress | cdktn.IResolvable | undefined);
    private _from;
    get from(): NetworkPolicyV1SpecIngressFromList;
    putFrom(value: NetworkPolicyV1SpecIngressFrom[] | cdktn.IResolvable): void;
    resetFrom(): void;
    get fromInput(): cdktn.IResolvable | NetworkPolicyV1SpecIngressFrom[] | undefined;
    private _ports;
    get ports(): NetworkPolicyV1SpecIngressPortsList;
    putPorts(value: NetworkPolicyV1SpecIngressPorts[] | cdktn.IResolvable): void;
    resetPorts(): void;
    get portsInput(): cdktn.IResolvable | NetworkPolicyV1SpecIngressPorts[] | undefined;
}
export declare class NetworkPolicyV1SpecIngressList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecIngress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecIngressOutputReference;
}
export interface NetworkPolicyV1SpecPodSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#key NetworkPolicyV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#operator NetworkPolicyV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#values NetworkPolicyV1#values}
    */
    readonly values?: string[];
}
export declare function networkPolicyV1SpecPodSelectorMatchExpressionsToTerraform(struct?: NetworkPolicyV1SpecPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function networkPolicyV1SpecPodSelectorMatchExpressionsToHclTerraform(struct?: NetworkPolicyV1SpecPodSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class NetworkPolicyV1SpecPodSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkPolicyV1SpecPodSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: NetworkPolicyV1SpecPodSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class NetworkPolicyV1SpecPodSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: NetworkPolicyV1SpecPodSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkPolicyV1SpecPodSelectorMatchExpressionsOutputReference;
}
export interface NetworkPolicyV1SpecPodSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_labels NetworkPolicyV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#match_expressions NetworkPolicyV1#match_expressions}
    */
    readonly matchExpressions?: NetworkPolicyV1SpecPodSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function networkPolicyV1SpecPodSelectorToTerraform(struct?: NetworkPolicyV1SpecPodSelectorOutputReference | NetworkPolicyV1SpecPodSelector): any;
export declare function networkPolicyV1SpecPodSelectorToHclTerraform(struct?: NetworkPolicyV1SpecPodSelectorOutputReference | NetworkPolicyV1SpecPodSelector): any;
export declare class NetworkPolicyV1SpecPodSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1SpecPodSelector | undefined;
    set internalValue(value: NetworkPolicyV1SpecPodSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): NetworkPolicyV1SpecPodSelectorMatchExpressionsList;
    putMatchExpressions(value: NetworkPolicyV1SpecPodSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | NetworkPolicyV1SpecPodSelectorMatchExpressions[] | undefined;
}
export interface NetworkPolicyV1Spec {
    /**
    * policyTypes is a list of rule types that the NetworkPolicy relates to. Valid options are ["Ingress"], ["Egress"], or ["Ingress", "Egress"]. If this field is not specified, it will default based on the existence of ingress or egress rules; policies that contain an egress section are assumed to affect egress, and all policies (whether or not they contain an ingress section) are assumed to affect ingress. If you want to write an egress-only policy, you must explicitly specify policyTypes [ "Egress" ]. Likewise, if you want to write a policy that specifies that no egress is allowed, you must specify a policyTypes value that include "Egress" (since such a policy would not include an egress section and would otherwise default to just [ "Ingress" ]). This field is beta-level in 1.8
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#policy_types NetworkPolicyV1#policy_types}
    */
    readonly policyTypes: string[];
    /**
    * egress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#egress NetworkPolicyV1#egress}
    */
    readonly egress?: NetworkPolicyV1SpecEgress[] | cdktn.IResolvable;
    /**
    * ingress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#ingress NetworkPolicyV1#ingress}
    */
    readonly ingress?: NetworkPolicyV1SpecIngress[] | cdktn.IResolvable;
    /**
    * pod_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#pod_selector NetworkPolicyV1#pod_selector}
    */
    readonly podSelector: NetworkPolicyV1SpecPodSelector;
}
export declare function networkPolicyV1SpecToTerraform(struct?: NetworkPolicyV1SpecOutputReference | NetworkPolicyV1Spec): any;
export declare function networkPolicyV1SpecToHclTerraform(struct?: NetworkPolicyV1SpecOutputReference | NetworkPolicyV1Spec): any;
export declare class NetworkPolicyV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkPolicyV1Spec | undefined;
    set internalValue(value: NetworkPolicyV1Spec | undefined);
    private _policyTypes?;
    get policyTypes(): string[];
    set policyTypes(value: string[]);
    get policyTypesInput(): string[] | undefined;
    private _egress;
    get egress(): NetworkPolicyV1SpecEgressList;
    putEgress(value: NetworkPolicyV1SpecEgress[] | cdktn.IResolvable): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | NetworkPolicyV1SpecEgress[] | undefined;
    private _ingress;
    get ingress(): NetworkPolicyV1SpecIngressList;
    putIngress(value: NetworkPolicyV1SpecIngress[] | cdktn.IResolvable): void;
    resetIngress(): void;
    get ingressInput(): cdktn.IResolvable | NetworkPolicyV1SpecIngress[] | undefined;
    private _podSelector;
    get podSelector(): NetworkPolicyV1SpecPodSelectorOutputReference;
    putPodSelector(value: NetworkPolicyV1SpecPodSelector): void;
    get podSelectorInput(): NetworkPolicyV1SpecPodSelector | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1 kubernetes_network_policy_v1}
*/
export declare class NetworkPolicyV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_network_policy_v1";
    /**
    * Generates CDKTN code for importing a NetworkPolicyV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkPolicyV1 to import
    * @param importFromId The id of the existing NetworkPolicyV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkPolicyV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/network_policy_v1 kubernetes_network_policy_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkPolicyV1Config
    */
    constructor(scope: Construct, id: string, config: NetworkPolicyV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): NetworkPolicyV1MetadataOutputReference;
    putMetadata(value: NetworkPolicyV1Metadata): void;
    get metadataInput(): NetworkPolicyV1Metadata | undefined;
    private _spec;
    get spec(): NetworkPolicyV1SpecOutputReference;
    putSpec(value: NetworkPolicyV1Spec): void;
    get specInput(): NetworkPolicyV1Spec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
