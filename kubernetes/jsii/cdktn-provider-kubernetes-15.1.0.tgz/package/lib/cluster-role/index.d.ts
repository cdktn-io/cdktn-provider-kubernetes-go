/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClusterRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#id ClusterRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * aggregation_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#aggregation_rule ClusterRole#aggregation_rule}
    */
    readonly aggregationRule?: ClusterRoleAggregationRule;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#metadata ClusterRole#metadata}
    */
    readonly metadata: ClusterRoleMetadata;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#rule ClusterRole#rule}
    */
    readonly rule?: ClusterRoleRule[] | cdktn.IResolvable;
}
export interface ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#key ClusterRole#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#operator ClusterRole#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#values ClusterRole#values}
    */
    readonly values?: string[];
}
export declare function clusterRoleAggregationRuleClusterRoleSelectorsMatchExpressionsToTerraform(struct?: ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable): any;
export declare function clusterRoleAggregationRuleClusterRoleSelectorsMatchExpressionsToHclTerraform(struct?: ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable): any;
export declare class ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressionsOutputReference;
}
export interface ClusterRoleAggregationRuleClusterRoleSelectors {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#match_labels ClusterRole#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#match_expressions ClusterRole#match_expressions}
    */
    readonly matchExpressions?: ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions[] | cdktn.IResolvable;
}
export declare function clusterRoleAggregationRuleClusterRoleSelectorsToTerraform(struct?: ClusterRoleAggregationRuleClusterRoleSelectors | cdktn.IResolvable): any;
export declare function clusterRoleAggregationRuleClusterRoleSelectorsToHclTerraform(struct?: ClusterRoleAggregationRuleClusterRoleSelectors | cdktn.IResolvable): any;
export declare class ClusterRoleAggregationRuleClusterRoleSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterRoleAggregationRuleClusterRoleSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterRoleAggregationRuleClusterRoleSelectors | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressionsList;
    putMatchExpressions(value: ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | ClusterRoleAggregationRuleClusterRoleSelectorsMatchExpressions[] | undefined;
}
export declare class ClusterRoleAggregationRuleClusterRoleSelectorsList extends cdktn.ComplexList {
    internalValue?: ClusterRoleAggregationRuleClusterRoleSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterRoleAggregationRuleClusterRoleSelectorsOutputReference;
}
export interface ClusterRoleAggregationRule {
    /**
    * cluster_role_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#cluster_role_selectors ClusterRole#cluster_role_selectors}
    */
    readonly clusterRoleSelectors?: ClusterRoleAggregationRuleClusterRoleSelectors[] | cdktn.IResolvable;
}
export declare function clusterRoleAggregationRuleToTerraform(struct?: ClusterRoleAggregationRuleOutputReference | ClusterRoleAggregationRule): any;
export declare function clusterRoleAggregationRuleToHclTerraform(struct?: ClusterRoleAggregationRuleOutputReference | ClusterRoleAggregationRule): any;
export declare class ClusterRoleAggregationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterRoleAggregationRule | undefined;
    set internalValue(value: ClusterRoleAggregationRule | undefined);
    private _clusterRoleSelectors;
    get clusterRoleSelectors(): ClusterRoleAggregationRuleClusterRoleSelectorsList;
    putClusterRoleSelectors(value: ClusterRoleAggregationRuleClusterRoleSelectors[] | cdktn.IResolvable): void;
    resetClusterRoleSelectors(): void;
    get clusterRoleSelectorsInput(): cdktn.IResolvable | ClusterRoleAggregationRuleClusterRoleSelectors[] | undefined;
}
export interface ClusterRoleMetadata {
    /**
    * An unstructured key value map stored with the clusterRole that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#annotations ClusterRole#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#generate_name ClusterRole#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the clusterRole. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#labels ClusterRole#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the clusterRole, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#name ClusterRole#name}
    */
    readonly name?: string;
}
export declare function clusterRoleMetadataToTerraform(struct?: ClusterRoleMetadataOutputReference | ClusterRoleMetadata): any;
export declare function clusterRoleMetadataToHclTerraform(struct?: ClusterRoleMetadataOutputReference | ClusterRoleMetadata): any;
export declare class ClusterRoleMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterRoleMetadata | undefined;
    set internalValue(value: ClusterRoleMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface ClusterRoleRule {
    /**
    * APIGroups is the name of the APIGroup that contains the resources. If multiple API groups are specified, any action requested against one of the enumerated resources in any API group will be allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#api_groups ClusterRole#api_groups}
    */
    readonly apiGroups?: string[];
    /**
    * NonResourceURLs is a set of partial urls that a user should have access to. *s are allowed, but only as the full, final step in the path Since non-resource URLs are not namespaced, this field is only applicable for ClusterRoles referenced from a ClusterRoleBinding. Rules can either apply to API resources (such as "pods" or "secrets") or non-resource URL paths (such as "/api"), but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#non_resource_urls ClusterRole#non_resource_urls}
    */
    readonly nonResourceUrls?: string[];
    /**
    * ResourceNames is an optional white list of names that the rule applies to. An empty set means that everything is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#resource_names ClusterRole#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * Resources is a list of resources this rule applies to. ResourceAll represents all resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#resources ClusterRole#resources}
    */
    readonly resources?: string[];
    /**
    * Verbs is a list of Verbs that apply to ALL the ResourceKinds and AttributeRestrictions contained in this rule. VerbAll represents all kinds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#verbs ClusterRole#verbs}
    */
    readonly verbs: string[];
}
export declare function clusterRoleRuleToTerraform(struct?: ClusterRoleRule | cdktn.IResolvable): any;
export declare function clusterRoleRuleToHclTerraform(struct?: ClusterRoleRule | cdktn.IResolvable): any;
export declare class ClusterRoleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterRoleRule | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterRoleRule | cdktn.IResolvable | undefined);
    private _apiGroups?;
    get apiGroups(): string[];
    set apiGroups(value: string[]);
    resetApiGroups(): void;
    get apiGroupsInput(): string[] | undefined;
    private _nonResourceUrls?;
    get nonResourceUrls(): string[];
    set nonResourceUrls(value: string[]);
    resetNonResourceUrls(): void;
    get nonResourceUrlsInput(): string[] | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _verbs?;
    get verbs(): string[];
    set verbs(value: string[]);
    get verbsInput(): string[] | undefined;
}
export declare class ClusterRoleRuleList extends cdktn.ComplexList {
    internalValue?: ClusterRoleRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterRoleRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role kubernetes_cluster_role}
*/
export declare class ClusterRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_cluster_role";
    /**
    * Generates CDKTN code for importing a ClusterRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClusterRole to import
    * @param importFromId The id of the existing ClusterRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClusterRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/cluster_role kubernetes_cluster_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClusterRoleConfig
    */
    constructor(scope: Construct, id: string, config: ClusterRoleConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _aggregationRule;
    get aggregationRule(): ClusterRoleAggregationRuleOutputReference;
    putAggregationRule(value: ClusterRoleAggregationRule): void;
    resetAggregationRule(): void;
    get aggregationRuleInput(): ClusterRoleAggregationRule | undefined;
    private _metadata;
    get metadata(): ClusterRoleMetadataOutputReference;
    putMetadata(value: ClusterRoleMetadata): void;
    get metadataInput(): ClusterRoleMetadata | undefined;
    private _rule;
    get rule(): ClusterRoleRuleList;
    putRule(value: ClusterRoleRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | ClusterRoleRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
