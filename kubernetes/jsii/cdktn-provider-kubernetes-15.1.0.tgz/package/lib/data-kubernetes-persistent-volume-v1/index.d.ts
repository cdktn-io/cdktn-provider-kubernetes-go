/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesPersistentVolumeV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#id DataKubernetesPersistentVolumeV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#metadata DataKubernetesPersistentVolumeV1#metadata}
    */
    readonly metadata: DataKubernetesPersistentVolumeV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#spec DataKubernetesPersistentVolumeV1#spec}
    */
    readonly spec?: DataKubernetesPersistentVolumeV1Spec[] | cdktn.IResolvable;
}
export interface DataKubernetesPersistentVolumeV1Metadata {
    /**
    * An unstructured key value map stored with the persistent volume that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#annotations DataKubernetesPersistentVolumeV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the persistent volume. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#labels DataKubernetesPersistentVolumeV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the persistent volume, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
}
export declare function dataKubernetesPersistentVolumeV1MetadataToTerraform(struct?: DataKubernetesPersistentVolumeV1MetadataOutputReference | DataKubernetesPersistentVolumeV1Metadata): any;
export declare function dataKubernetesPersistentVolumeV1MetadataToHclTerraform(struct?: DataKubernetesPersistentVolumeV1MetadataOutputReference | DataKubernetesPersistentVolumeV1Metadata): any;
export declare class DataKubernetesPersistentVolumeV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1Metadata | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface DataKubernetesPersistentVolumeV1SpecClaimRef {
    /**
    * The name of the PersistentVolumeClaim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name: string;
    /**
    * The namespace of the PersistentVolumeClaim. Uses 'default' namespace if none is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecClaimRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecClaimRefOutputReference | DataKubernetesPersistentVolumeV1SpecClaimRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecClaimRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecClaimRefOutputReference | DataKubernetesPersistentVolumeV1SpecClaimRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecClaimRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecClaimRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecClaimRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#key DataKubernetesPersistentVolumeV1#key}
    */
    readonly key: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists`, `DoesNotExist`, `Gt`, and `Lt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#operator DataKubernetesPersistentVolumeV1#operator}
    */
    readonly operator: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#values DataKubernetesPersistentVolumeV1#values}
    */
    readonly values?: string[];
}
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable): any;
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable): any;
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsOutputReference;
}
export interface DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#key DataKubernetesPersistentVolumeV1#key}
    */
    readonly key: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists`, `DoesNotExist`, `Gt`, and `Lt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#operator DataKubernetesPersistentVolumeV1#operator}
    */
    readonly operator: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#values DataKubernetesPersistentVolumeV1#values}
    */
    readonly values?: string[];
}
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFieldsToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable): any;
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFieldsToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable): any;
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFieldsList extends cdktn.ComplexList {
    internalValue?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFieldsOutputReference;
}
export interface DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm {
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#match_expressions DataKubernetesPersistentVolumeV1#match_expressions}
    */
    readonly matchExpressions?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | cdktn.IResolvable;
    /**
    * match_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#match_fields DataKubernetesPersistentVolumeV1#match_fields}
    */
    readonly matchFields?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | cdktn.IResolvable;
}
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable): any;
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable): any;
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm | cdktn.IResolvable | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressionsList;
    putMatchExpressions(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchExpressions[] | undefined;
    private _matchFields;
    get matchFields(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFieldsList;
    putMatchFields(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | cdktn.IResolvable): void;
    resetMatchFields(): void;
    get matchFieldsInput(): cdktn.IResolvable | DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermMatchFields[] | undefined;
}
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermList extends cdktn.ComplexList {
    internalValue?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermOutputReference;
}
export interface DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired {
    /**
    * node_selector_term block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#node_selector_term DataKubernetesPersistentVolumeV1#node_selector_term}
    */
    readonly nodeSelectorTerm: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm[] | cdktn.IResolvable;
}
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredOutputReference | DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired): any;
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredOutputReference | DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired): any;
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired | undefined);
    private _nodeSelectorTerm;
    get nodeSelectorTerm(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTermList;
    putNodeSelectorTerm(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm[] | cdktn.IResolvable): void;
    get nodeSelectorTermInput(): cdktn.IResolvable | DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredNodeSelectorTerm[] | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecNodeAffinity {
    /**
    * required block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#required DataKubernetesPersistentVolumeV1#required}
    */
    readonly required?: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired;
}
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityOutputReference | DataKubernetesPersistentVolumeV1SpecNodeAffinity): any;
export declare function dataKubernetesPersistentVolumeV1SpecNodeAffinityToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecNodeAffinityOutputReference | DataKubernetesPersistentVolumeV1SpecNodeAffinity): any;
export declare class DataKubernetesPersistentVolumeV1SpecNodeAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecNodeAffinity | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecNodeAffinity | undefined);
    private _required;
    get required(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequiredOutputReference;
    putRequired(value: DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired): void;
    resetRequired(): void;
    get requiredInput(): DataKubernetesPersistentVolumeV1SpecNodeAffinityRequired | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#partition DataKubernetesPersistentVolumeV1#partition}
    */
    readonly partition?: number;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Unique ID of the persistent disk resource in AWS (Amazon EBS volume). More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume_id DataKubernetesPersistentVolumeV1#volume_id}
    */
    readonly volumeId: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStoreToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStoreToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk {
    /**
    * Host Caching mode: None, Read Only, Read Write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#caching_mode DataKubernetesPersistentVolumeV1#caching_mode}
    */
    readonly cachingMode: string;
    /**
    * The URI the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#data_disk_uri DataKubernetesPersistentVolumeV1#data_disk_uri}
    */
    readonly dataDiskUri: string;
    /**
    * The Name of the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#disk_name DataKubernetesPersistentVolumeV1#disk_name}
    */
    readonly diskName: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The type for the data disk. Expected values: Shared, Dedicated, Managed. Defaults to Shared
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#kind DataKubernetesPersistentVolumeV1#kind}
    */
    readonly kind?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDiskToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDiskOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDiskToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDiskOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk | undefined);
    private _cachingMode?;
    get cachingMode(): string;
    set cachingMode(value: string);
    get cachingModeInput(): string | undefined;
    private _dataDiskUri?;
    get dataDiskUri(): string;
    set dataDiskUri(value: string);
    get dataDiskUriInput(): string | undefined;
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    get diskNameInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile {
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The name of secret that contains Azure Storage Account Name and Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#secret_name DataKubernetesPersistentVolumeV1#secret_name}
    */
    readonly secretName: string;
    /**
    * The namespace of the secret that contains Azure Storage Account Name and Key. For Kubernetes up to 1.18.x the default is the same as the Pod. For Kubernetes 1.19.x and later the default is "default" namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#secret_namespace DataKubernetesPersistentVolumeV1#secret_namespace}
    */
    readonly secretNamespace?: string;
    /**
    * Share Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#share_name DataKubernetesPersistentVolumeV1#share_name}
    */
    readonly shareName: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFileToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFileOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFileToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFileOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile | undefined);
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _secretNamespace?;
    get secretNamespace(): string;
    set secretNamespace(value: string);
    resetSecretNamespace(): void;
    get secretNamespaceInput(): string | undefined;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    get shareNameInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs {
    /**
    * Monitors is a collection of Ceph monitors. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#monitors DataKubernetesPersistentVolumeV1#monitors}
    */
    readonly monitors: string[];
    /**
    * Used as the mounted root, rather than the full Ceph tree, default is /
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#path DataKubernetesPersistentVolumeV1#path}
    */
    readonly path?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to `false` (read/write). More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The path to key ring for User, default is `/etc/ceph/user.secret`. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#secret_file DataKubernetesPersistentVolumeV1#secret_file}
    */
    readonly secretFile?: string;
    /**
    * User is the rados user name, default is admin. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#user DataKubernetesPersistentVolumeV1#user}
    */
    readonly user?: string;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#secret_ref DataKubernetesPersistentVolumeV1#secret_ref}
    */
    readonly secretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs | undefined);
    private _monitors?;
    get monitors(): string[];
    set monitors(value: string[]);
    get monitorsInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretFile?;
    get secretFile(): string;
    set secretFile(value: string);
    resetSecretFile(): void;
    get secretFileInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _secretRef;
    get secretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRefOutputReference;
    putSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsSecretRef | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write). More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Volume ID used to identify the volume in Cinder. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume_id DataKubernetesPersistentVolumeV1#volume_id}
    */
    readonly volumeId: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinderToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinderOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinderToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinderOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi {
    /**
    * the name of the volume driver to use. More info: https://kubernetes.io/docs/concepts/storage/volumes/#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#driver DataKubernetesPersistentVolumeV1#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Attributes of the volume to publish.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume_attributes DataKubernetesPersistentVolumeV1#volume_attributes}
    */
    readonly volumeAttributes?: {
        [key: string]: string;
    };
    /**
    * A string value that uniquely identifies the volume. More info: https://kubernetes.io/docs/concepts/storage/volumes/#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume_handle DataKubernetesPersistentVolumeV1#volume_handle}
    */
    readonly volumeHandle: string;
    /**
    * controller_expand_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#controller_expand_secret_ref DataKubernetesPersistentVolumeV1#controller_expand_secret_ref}
    */
    readonly controllerExpandSecretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef;
    /**
    * controller_publish_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#controller_publish_secret_ref DataKubernetesPersistentVolumeV1#controller_publish_secret_ref}
    */
    readonly controllerPublishSecretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef;
    /**
    * node_publish_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#node_publish_secret_ref DataKubernetesPersistentVolumeV1#node_publish_secret_ref}
    */
    readonly nodePublishSecretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef;
    /**
    * node_stage_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#node_stage_secret_ref DataKubernetesPersistentVolumeV1#node_stage_secret_ref}
    */
    readonly nodeStageSecretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeAttributes?;
    get volumeAttributes(): {
        [key: string]: string;
    };
    set volumeAttributes(value: {
        [key: string]: string;
    });
    resetVolumeAttributes(): void;
    get volumeAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _volumeHandle?;
    get volumeHandle(): string;
    set volumeHandle(value: string);
    get volumeHandleInput(): string | undefined;
    private _controllerExpandSecretRef;
    get controllerExpandSecretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRefOutputReference;
    putControllerExpandSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef): void;
    resetControllerExpandSecretRef(): void;
    get controllerExpandSecretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerExpandSecretRef | undefined;
    private _controllerPublishSecretRef;
    get controllerPublishSecretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRefOutputReference;
    putControllerPublishSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef): void;
    resetControllerPublishSecretRef(): void;
    get controllerPublishSecretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiControllerPublishSecretRef | undefined;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRefOutputReference;
    putNodePublishSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef): void;
    resetNodePublishSecretRef(): void;
    get nodePublishSecretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodePublishSecretRef | undefined;
    private _nodeStageSecretRef;
    get nodeStageSecretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRefOutputReference;
    putNodeStageSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef): void;
    resetNodeStageSecretRef(): void;
    get nodeStageSecretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiNodeStageSecretRef | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * FC target lun number
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#lun DataKubernetesPersistentVolumeV1#lun}
    */
    readonly lun: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * FC target worldwide names (WWNs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#target_ww_ns DataKubernetesPersistentVolumeV1#target_ww_ns}
    */
    readonly targetWwNs: string[];
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFcToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFcOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFcToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFcOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetWwNs?;
    get targetWwNs(): string[];
    set targetWwNs(value: string[]);
    get targetWwNsInput(): string[] | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume {
    /**
    * Driver is the name of the driver to use for this volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#driver DataKubernetesPersistentVolumeV1#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". The default filesystem depends on FlexVolume script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Extra command options if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#options DataKubernetesPersistentVolumeV1#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#secret_ref DataKubernetesPersistentVolumeV1#secret_ref}
    */
    readonly secretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRefOutputReference;
    putSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeSecretRef | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker {
    /**
    * Name of the dataset stored as metadata -> name on the dataset for Flocker should be considered as deprecated
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#dataset_name DataKubernetesPersistentVolumeV1#dataset_name}
    */
    readonly datasetName?: string;
    /**
    * UUID of the dataset. This is unique identifier of a Flocker dataset
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#dataset_uuid DataKubernetesPersistentVolumeV1#dataset_uuid}
    */
    readonly datasetUuid?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlockerToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlockerOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlockerToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlockerOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlockerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker | undefined);
    private _datasetName?;
    get datasetName(): string;
    set datasetName(value: string);
    resetDatasetName(): void;
    get datasetNameInput(): string | undefined;
    private _datasetUuid?;
    get datasetUuid(): string;
    set datasetUuid(value: string);
    resetDatasetUuid(): void;
    get datasetUuidInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty). More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#partition DataKubernetesPersistentVolumeV1#partition}
    */
    readonly partition?: number;
    /**
    * Unique name of the PD resource in GCE. Used to identify the disk in GCE. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#pd_name DataKubernetesPersistentVolumeV1#pd_name}
    */
    readonly pdName: string;
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDiskToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDiskOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDiskToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDiskOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _pdName?;
    get pdName(): string;
    set pdName(value: string);
    get pdNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs {
    /**
    * The endpoint name that details Glusterfs topology. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#endpoints_name DataKubernetesPersistentVolumeV1#endpoints_name}
    */
    readonly endpointsName: string;
    /**
    * The Glusterfs volume path. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#path DataKubernetesPersistentVolumeV1#path}
    */
    readonly path: string;
    /**
    * Whether to force the Glusterfs volume to be mounted with read-only permissions. Defaults to false. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfsToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfsOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfsToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfsOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs | undefined);
    private _endpointsName?;
    get endpointsName(): string;
    set endpointsName(value: string);
    get endpointsNameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#hostpath
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#path DataKubernetesPersistentVolumeV1#path}
    */
    readonly path?: string;
    /**
    * Type for HostPath volume. Allowed values are "" (default), DirectoryOrCreate, Directory, FileOrCreate, File, Socket, CharDevice and BlockDevice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#type DataKubernetesPersistentVolumeV1#type}
    */
    readonly type?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPathToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPathOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPathToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPathOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#iscsi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Target iSCSI Qualified Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#iqn DataKubernetesPersistentVolumeV1#iqn}
    */
    readonly iqn: string;
    /**
    * iSCSI interface name that uses an iSCSI transport. Defaults to 'default' (tcp).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#iscsi_interface DataKubernetesPersistentVolumeV1#iscsi_interface}
    */
    readonly iscsiInterface?: string;
    /**
    * iSCSI target lun number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#lun DataKubernetesPersistentVolumeV1#lun}
    */
    readonly lun?: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * iSCSI target portal. The portal is either an IP or ip_addr:port if the port is other than default (typically TCP ports 860 and 3260).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#target_portal DataKubernetesPersistentVolumeV1#target_portal}
    */
    readonly targetPortal: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsiToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsiOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsiToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsiOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _iqn?;
    get iqn(): string;
    set iqn(value: string);
    get iqnInput(): string | undefined;
    private _iscsiInterface?;
    get iscsiInterface(): string;
    set iscsiInterface(value: string);
    resetIscsiInterface(): void;
    get iscsiInterfaceInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    resetLun(): void;
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetPortal?;
    get targetPortal(): string;
    set targetPortal(value: string);
    get targetPortalInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#local
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#path DataKubernetesPersistentVolumeV1#path}
    */
    readonly path?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocalToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocalOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocalToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocalOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs {
    /**
    * Path that is exported by the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#path DataKubernetesPersistentVolumeV1#path}
    */
    readonly path: string;
    /**
    * Whether to force the NFS export to be mounted with read-only permissions. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Server is the hostname or IP address of the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#server DataKubernetesPersistentVolumeV1#server}
    */
    readonly server: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfsToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfsOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfsToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfsOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * ID that identifies Photon Controller persistent disk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#pd_id DataKubernetesPersistentVolumeV1#pd_id}
    */
    readonly pdId: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDiskToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDiskOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDiskToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDiskOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _pdId?;
    get pdId(): string;
    set pdId(value: string);
    get pdIdInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte {
    /**
    * Group to map volume access to Default is no group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#group DataKubernetesPersistentVolumeV1#group}
    */
    readonly group?: string;
    /**
    * Whether to force the Quobyte volume to be mounted with read-only permissions. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Registry represents a single or multiple Quobyte Registry services specified as a string as host:port pair (multiple entries are separated with commas) which acts as the central registry for volumes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#registry DataKubernetesPersistentVolumeV1#registry}
    */
    readonly registry: string;
    /**
    * User to map volume access to Defaults to serivceaccount user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#user DataKubernetesPersistentVolumeV1#user}
    */
    readonly user?: string;
    /**
    * Volume is a string that references an already created Quobyte volume by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume DataKubernetesPersistentVolumeV1#volume}
    */
    readonly volume: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyteToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyteOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyteToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyteOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte | undefined);
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    get registryInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _volume?;
    get volume(): string;
    set volume(value: string);
    get volumeInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#name DataKubernetesPersistentVolumeV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#namespace DataKubernetesPersistentVolumeV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRefToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRefToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRefOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd {
    /**
    * A collection of Ceph monitors. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#ceph_monitors DataKubernetesPersistentVolumeV1#ceph_monitors}
    */
    readonly cephMonitors: string[];
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#rbd
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Keyring is the path to key ring for RBDUser. Default is /etc/ceph/keyring. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#keyring DataKubernetesPersistentVolumeV1#keyring}
    */
    readonly keyring?: string;
    /**
    * The rados user name. Default is admin. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#rados_user DataKubernetesPersistentVolumeV1#rados_user}
    */
    readonly radosUser?: string;
    /**
    * The rados image name. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#rbd_image DataKubernetesPersistentVolumeV1#rbd_image}
    */
    readonly rbdImage: string;
    /**
    * The rados pool name. Default is rbd. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#rbd_pool DataKubernetesPersistentVolumeV1#rbd_pool}
    */
    readonly rbdPool?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#read_only DataKubernetesPersistentVolumeV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#secret_ref DataKubernetesPersistentVolumeV1#secret_ref}
    */
    readonly secretRef?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd | undefined);
    private _cephMonitors?;
    get cephMonitors(): string[];
    set cephMonitors(value: string[]);
    get cephMonitorsInput(): string[] | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _keyring?;
    get keyring(): string;
    set keyring(value: string);
    resetKeyring(): void;
    get keyringInput(): string | undefined;
    private _radosUser?;
    get radosUser(): string;
    set radosUser(value: string);
    resetRadosUser(): void;
    get radosUserInput(): string | undefined;
    private _rbdImage?;
    get rbdImage(): string;
    set rbdImage(value: string);
    get rbdImageInput(): string | undefined;
    private _rbdPool?;
    get rbdPool(): string;
    set rbdPool(value: string);
    resetRbdPool(): void;
    get rbdPoolInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRefOutputReference;
    putSecretRef(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdSecretRef | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fs_type DataKubernetesPersistentVolumeV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Path that identifies vSphere volume vmdk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume_path DataKubernetesPersistentVolumeV1#volume_path}
    */
    readonly volumePath: string;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolumeToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolumeOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolumeToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolumeOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _volumePath?;
    get volumePath(): string;
    set volumePath(value: string);
    get volumePathInput(): string | undefined;
}
export interface DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource {
    /**
    * aws_elastic_block_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#aws_elastic_block_store DataKubernetesPersistentVolumeV1#aws_elastic_block_store}
    */
    readonly awsElasticBlockStore?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore;
    /**
    * azure_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#azure_disk DataKubernetesPersistentVolumeV1#azure_disk}
    */
    readonly azureDisk?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk;
    /**
    * azure_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#azure_file DataKubernetesPersistentVolumeV1#azure_file}
    */
    readonly azureFile?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile;
    /**
    * ceph_fs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#ceph_fs DataKubernetesPersistentVolumeV1#ceph_fs}
    */
    readonly cephFs?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs;
    /**
    * cinder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#cinder DataKubernetesPersistentVolumeV1#cinder}
    */
    readonly cinder?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder;
    /**
    * csi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#csi DataKubernetesPersistentVolumeV1#csi}
    */
    readonly csi?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi;
    /**
    * fc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#fc DataKubernetesPersistentVolumeV1#fc}
    */
    readonly fc?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc;
    /**
    * flex_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#flex_volume DataKubernetesPersistentVolumeV1#flex_volume}
    */
    readonly flexVolume?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume;
    /**
    * flocker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#flocker DataKubernetesPersistentVolumeV1#flocker}
    */
    readonly flocker?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker;
    /**
    * gce_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#gce_persistent_disk DataKubernetesPersistentVolumeV1#gce_persistent_disk}
    */
    readonly gcePersistentDisk?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk;
    /**
    * glusterfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#glusterfs DataKubernetesPersistentVolumeV1#glusterfs}
    */
    readonly glusterfs?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs;
    /**
    * host_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#host_path DataKubernetesPersistentVolumeV1#host_path}
    */
    readonly hostPath?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath;
    /**
    * iscsi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#iscsi DataKubernetesPersistentVolumeV1#iscsi}
    */
    readonly iscsi?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi;
    /**
    * local block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#local DataKubernetesPersistentVolumeV1#local}
    */
    readonly local?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#nfs DataKubernetesPersistentVolumeV1#nfs}
    */
    readonly nfs?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs;
    /**
    * photon_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#photon_persistent_disk DataKubernetesPersistentVolumeV1#photon_persistent_disk}
    */
    readonly photonPersistentDisk?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk;
    /**
    * quobyte block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#quobyte DataKubernetesPersistentVolumeV1#quobyte}
    */
    readonly quobyte?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte;
    /**
    * rbd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#rbd DataKubernetesPersistentVolumeV1#rbd}
    */
    readonly rbd?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd;
    /**
    * vsphere_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#vsphere_volume DataKubernetesPersistentVolumeV1#vsphere_volume}
    */
    readonly vsphereVolume?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume;
}
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceToTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource): any;
export declare function dataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceToHclTerraform(struct?: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceOutputReference | DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource): any;
export declare class DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource | undefined);
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStoreOutputReference;
    putAwsElasticBlockStore(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore): void;
    resetAwsElasticBlockStore(): void;
    get awsElasticBlockStoreInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAwsElasticBlockStore | undefined;
    private _azureDisk;
    get azureDisk(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDiskOutputReference;
    putAzureDisk(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk): void;
    resetAzureDisk(): void;
    get azureDiskInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureDisk | undefined;
    private _azureFile;
    get azureFile(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFileOutputReference;
    putAzureFile(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile): void;
    resetAzureFile(): void;
    get azureFileInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceAzureFile | undefined;
    private _cephFs;
    get cephFs(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFsOutputReference;
    putCephFs(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs): void;
    resetCephFs(): void;
    get cephFsInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCephFs | undefined;
    private _cinder;
    get cinder(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinderOutputReference;
    putCinder(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder): void;
    resetCinder(): void;
    get cinderInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCinder | undefined;
    private _csi;
    get csi(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsiOutputReference;
    putCsi(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi): void;
    resetCsi(): void;
    get csiInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceCsi | undefined;
    private _fc;
    get fc(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFcOutputReference;
    putFc(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc): void;
    resetFc(): void;
    get fcInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFc | undefined;
    private _flexVolume;
    get flexVolume(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolumeOutputReference;
    putFlexVolume(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume): void;
    resetFlexVolume(): void;
    get flexVolumeInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlexVolume | undefined;
    private _flocker;
    get flocker(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlockerOutputReference;
    putFlocker(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker): void;
    resetFlocker(): void;
    get flockerInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceFlocker | undefined;
    private _gcePersistentDisk;
    get gcePersistentDisk(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDiskOutputReference;
    putGcePersistentDisk(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk): void;
    resetGcePersistentDisk(): void;
    get gcePersistentDiskInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGcePersistentDisk | undefined;
    private _glusterfs;
    get glusterfs(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfsOutputReference;
    putGlusterfs(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs): void;
    resetGlusterfs(): void;
    get glusterfsInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceGlusterfs | undefined;
    private _hostPath;
    get hostPath(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPathOutputReference;
    putHostPath(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath): void;
    resetHostPath(): void;
    get hostPathInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceHostPath | undefined;
    private _iscsi;
    get iscsi(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsiOutputReference;
    putIscsi(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi): void;
    resetIscsi(): void;
    get iscsiInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceIscsi | undefined;
    private _local;
    get local(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocalOutputReference;
    putLocal(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal): void;
    resetLocal(): void;
    get localInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceLocal | undefined;
    private _nfs;
    get nfs(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfsOutputReference;
    putNfs(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs): void;
    resetNfs(): void;
    get nfsInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceNfs | undefined;
    private _photonPersistentDisk;
    get photonPersistentDisk(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDiskOutputReference;
    putPhotonPersistentDisk(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk): void;
    resetPhotonPersistentDisk(): void;
    get photonPersistentDiskInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourcePhotonPersistentDisk | undefined;
    private _quobyte;
    get quobyte(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyteOutputReference;
    putQuobyte(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte): void;
    resetQuobyte(): void;
    get quobyteInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceQuobyte | undefined;
    private _rbd;
    get rbd(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbdOutputReference;
    putRbd(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd): void;
    resetRbd(): void;
    get rbdInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceRbd | undefined;
    private _vsphereVolume;
    get vsphereVolume(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolumeOutputReference;
    putVsphereVolume(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume): void;
    resetVsphereVolume(): void;
    get vsphereVolumeInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceVsphereVolume | undefined;
}
export interface DataKubernetesPersistentVolumeV1Spec {
    /**
    * Contains all ways the volume can be mounted. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#access-modes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#access_modes DataKubernetesPersistentVolumeV1#access_modes}
    */
    readonly accessModes: string[];
    /**
    * A description of the persistent volume's resources and capacity. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#capacity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#capacity DataKubernetesPersistentVolumeV1#capacity}
    */
    readonly capacity: {
        [key: string]: string;
    };
    /**
    * A list of mount options, e.g. ["ro", "soft"]. Not validated - mount will simply fail if one is invalid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#mount_options DataKubernetesPersistentVolumeV1#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * What happens to a persistent volume when released from its claim. Valid options are Retain (default) and Recycle. Recycling must be supported by the volume plugin underlying this persistent volume. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#reclaiming
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#persistent_volume_reclaim_policy DataKubernetesPersistentVolumeV1#persistent_volume_reclaim_policy}
    */
    readonly persistentVolumeReclaimPolicy?: string;
    /**
    * A description of the persistent volume's class. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes/#class
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#storage_class_name DataKubernetesPersistentVolumeV1#storage_class_name}
    */
    readonly storageClassName?: string;
    /**
    * Defines if a volume is intended to be used with a formatted filesystem. or to remain in raw block state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#volume_mode DataKubernetesPersistentVolumeV1#volume_mode}
    */
    readonly volumeMode?: string;
    /**
    * claim_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#claim_ref DataKubernetesPersistentVolumeV1#claim_ref}
    */
    readonly claimRef?: DataKubernetesPersistentVolumeV1SpecClaimRef;
    /**
    * node_affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#node_affinity DataKubernetesPersistentVolumeV1#node_affinity}
    */
    readonly nodeAffinity?: DataKubernetesPersistentVolumeV1SpecNodeAffinity;
    /**
    * persistent_volume_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#persistent_volume_source DataKubernetesPersistentVolumeV1#persistent_volume_source}
    */
    readonly persistentVolumeSource: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource;
}
export declare function dataKubernetesPersistentVolumeV1SpecToTerraform(struct?: DataKubernetesPersistentVolumeV1Spec | cdktn.IResolvable): any;
export declare function dataKubernetesPersistentVolumeV1SpecToHclTerraform(struct?: DataKubernetesPersistentVolumeV1Spec | cdktn.IResolvable): any;
export declare class DataKubernetesPersistentVolumeV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPersistentVolumeV1Spec | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesPersistentVolumeV1Spec | cdktn.IResolvable | undefined);
    private _accessModes?;
    get accessModes(): string[];
    set accessModes(value: string[]);
    get accessModesInput(): string[] | undefined;
    private _capacity?;
    get capacity(): {
        [key: string]: string;
    };
    set capacity(value: {
        [key: string]: string;
    });
    get capacityInput(): {
        [key: string]: string;
    } | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _persistentVolumeReclaimPolicy?;
    get persistentVolumeReclaimPolicy(): string;
    set persistentVolumeReclaimPolicy(value: string);
    resetPersistentVolumeReclaimPolicy(): void;
    get persistentVolumeReclaimPolicyInput(): string | undefined;
    private _storageClassName?;
    get storageClassName(): string;
    set storageClassName(value: string);
    resetStorageClassName(): void;
    get storageClassNameInput(): string | undefined;
    private _volumeMode?;
    get volumeMode(): string;
    set volumeMode(value: string);
    resetVolumeMode(): void;
    get volumeModeInput(): string | undefined;
    private _claimRef;
    get claimRef(): DataKubernetesPersistentVolumeV1SpecClaimRefOutputReference;
    putClaimRef(value: DataKubernetesPersistentVolumeV1SpecClaimRef): void;
    resetClaimRef(): void;
    get claimRefInput(): DataKubernetesPersistentVolumeV1SpecClaimRef | undefined;
    private _nodeAffinity;
    get nodeAffinity(): DataKubernetesPersistentVolumeV1SpecNodeAffinityOutputReference;
    putNodeAffinity(value: DataKubernetesPersistentVolumeV1SpecNodeAffinity): void;
    resetNodeAffinity(): void;
    get nodeAffinityInput(): DataKubernetesPersistentVolumeV1SpecNodeAffinity | undefined;
    private _persistentVolumeSource;
    get persistentVolumeSource(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSourceOutputReference;
    putPersistentVolumeSource(value: DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource): void;
    get persistentVolumeSourceInput(): DataKubernetesPersistentVolumeV1SpecPersistentVolumeSource | undefined;
}
export declare class DataKubernetesPersistentVolumeV1SpecList extends cdktn.ComplexList {
    internalValue?: DataKubernetesPersistentVolumeV1Spec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPersistentVolumeV1SpecOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1 kubernetes_persistent_volume_v1}
*/
export declare class DataKubernetesPersistentVolumeV1 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_persistent_volume_v1";
    /**
    * Generates CDKTN code for importing a DataKubernetesPersistentVolumeV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesPersistentVolumeV1 to import
    * @param importFromId The id of the existing DataKubernetesPersistentVolumeV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesPersistentVolumeV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/persistent_volume_v1 kubernetes_persistent_volume_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesPersistentVolumeV1Config
    */
    constructor(scope: Construct, id: string, config: DataKubernetesPersistentVolumeV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): DataKubernetesPersistentVolumeV1MetadataOutputReference;
    putMetadata(value: DataKubernetesPersistentVolumeV1Metadata): void;
    get metadataInput(): DataKubernetesPersistentVolumeV1Metadata | undefined;
    private _spec;
    get spec(): DataKubernetesPersistentVolumeV1SpecList;
    putSpec(value: DataKubernetesPersistentVolumeV1Spec[] | cdktn.IResolvable): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | DataKubernetesPersistentVolumeV1Spec[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
