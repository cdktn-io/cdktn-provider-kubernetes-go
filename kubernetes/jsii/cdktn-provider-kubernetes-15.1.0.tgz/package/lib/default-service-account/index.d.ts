/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DefaultServiceAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Enable automatic mounting of the service account token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#automount_service_account_token DefaultServiceAccount#automount_service_account_token}
    */
    readonly automountServiceAccountToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#id DefaultServiceAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * image_pull_secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#image_pull_secret DefaultServiceAccount#image_pull_secret}
    */
    readonly imagePullSecret?: DefaultServiceAccountImagePullSecret[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#metadata DefaultServiceAccount#metadata}
    */
    readonly metadata: DefaultServiceAccountMetadata;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#secret DefaultServiceAccount#secret}
    */
    readonly secret?: DefaultServiceAccountSecret[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#timeouts DefaultServiceAccount#timeouts}
    */
    readonly timeouts?: DefaultServiceAccountTimeouts;
}
export interface DefaultServiceAccountImagePullSecret {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#name DefaultServiceAccount#name}
    */
    readonly name?: string;
}
export declare function defaultServiceAccountImagePullSecretToTerraform(struct?: DefaultServiceAccountImagePullSecret | cdktn.IResolvable): any;
export declare function defaultServiceAccountImagePullSecretToHclTerraform(struct?: DefaultServiceAccountImagePullSecret | cdktn.IResolvable): any;
export declare class DefaultServiceAccountImagePullSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DefaultServiceAccountImagePullSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DefaultServiceAccountImagePullSecret | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DefaultServiceAccountImagePullSecretList extends cdktn.ComplexList {
    internalValue?: DefaultServiceAccountImagePullSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DefaultServiceAccountImagePullSecretOutputReference;
}
export interface DefaultServiceAccountMetadata {
    /**
    * An unstructured key value map stored with the service account that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#annotations DefaultServiceAccount#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the service account. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#labels DefaultServiceAccount#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the service account, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#name DefaultServiceAccount#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the service account must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#namespace DefaultServiceAccount#namespace}
    */
    readonly namespace?: string;
}
export declare function defaultServiceAccountMetadataToTerraform(struct?: DefaultServiceAccountMetadataOutputReference | DefaultServiceAccountMetadata): any;
export declare function defaultServiceAccountMetadataToHclTerraform(struct?: DefaultServiceAccountMetadataOutputReference | DefaultServiceAccountMetadata): any;
export declare class DefaultServiceAccountMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DefaultServiceAccountMetadata | undefined;
    set internalValue(value: DefaultServiceAccountMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface DefaultServiceAccountSecret {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#name DefaultServiceAccount#name}
    */
    readonly name?: string;
}
export declare function defaultServiceAccountSecretToTerraform(struct?: DefaultServiceAccountSecret | cdktn.IResolvable): any;
export declare function defaultServiceAccountSecretToHclTerraform(struct?: DefaultServiceAccountSecret | cdktn.IResolvable): any;
export declare class DefaultServiceAccountSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DefaultServiceAccountSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DefaultServiceAccountSecret | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DefaultServiceAccountSecretList extends cdktn.ComplexList {
    internalValue?: DefaultServiceAccountSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DefaultServiceAccountSecretOutputReference;
}
export interface DefaultServiceAccountTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#create DefaultServiceAccount#create}
    */
    readonly create?: string;
}
export declare function defaultServiceAccountTimeoutsToTerraform(struct?: DefaultServiceAccountTimeouts | cdktn.IResolvable): any;
export declare function defaultServiceAccountTimeoutsToHclTerraform(struct?: DefaultServiceAccountTimeouts | cdktn.IResolvable): any;
export declare class DefaultServiceAccountTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DefaultServiceAccountTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DefaultServiceAccountTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account kubernetes_default_service_account}
*/
export declare class DefaultServiceAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_default_service_account";
    /**
    * Generates CDKTN code for importing a DefaultServiceAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DefaultServiceAccount to import
    * @param importFromId The id of the existing DefaultServiceAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DefaultServiceAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/default_service_account kubernetes_default_service_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DefaultServiceAccountConfig
    */
    constructor(scope: Construct, id: string, config: DefaultServiceAccountConfig);
    private _automountServiceAccountToken?;
    get automountServiceAccountToken(): boolean | cdktn.IResolvable;
    set automountServiceAccountToken(value: boolean | cdktn.IResolvable);
    resetAutomountServiceAccountToken(): void;
    get automountServiceAccountTokenInput(): boolean | cdktn.IResolvable | undefined;
    get defaultSecretName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imagePullSecret;
    get imagePullSecret(): DefaultServiceAccountImagePullSecretList;
    putImagePullSecret(value: DefaultServiceAccountImagePullSecret[] | cdktn.IResolvable): void;
    resetImagePullSecret(): void;
    get imagePullSecretInput(): cdktn.IResolvable | DefaultServiceAccountImagePullSecret[] | undefined;
    private _metadata;
    get metadata(): DefaultServiceAccountMetadataOutputReference;
    putMetadata(value: DefaultServiceAccountMetadata): void;
    get metadataInput(): DefaultServiceAccountMetadata | undefined;
    private _secret;
    get secret(): DefaultServiceAccountSecretList;
    putSecret(value: DefaultServiceAccountSecret[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DefaultServiceAccountSecret[] | undefined;
    private _timeouts;
    get timeouts(): DefaultServiceAccountTimeoutsOutputReference;
    putTimeouts(value: DefaultServiceAccountTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DefaultServiceAccountTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
