/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NodeTaintConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set the name of the field manager for the node taint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#field_manager NodeTaint#field_manager}
    */
    readonly fieldManager?: string;
    /**
    * Force overwriting annotations that were created or edited outside of Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#force NodeTaint#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#id NodeTaint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#metadata NodeTaint#metadata}
    */
    readonly metadata: NodeTaintMetadata;
    /**
    * taint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#taint NodeTaint#taint}
    */
    readonly taint: NodeTaintTaint[] | cdktn.IResolvable;
}
export interface NodeTaintMetadata {
    /**
    * The name of the node
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#name NodeTaint#name}
    */
    readonly name: string;
}
export declare function nodeTaintMetadataToTerraform(struct?: NodeTaintMetadataOutputReference | NodeTaintMetadata): any;
export declare function nodeTaintMetadataToHclTerraform(struct?: NodeTaintMetadataOutputReference | NodeTaintMetadata): any;
export declare class NodeTaintMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NodeTaintMetadata | undefined;
    set internalValue(value: NodeTaintMetadata | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface NodeTaintTaint {
    /**
    * The taint effect
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#effect NodeTaint#effect}
    */
    readonly effect: string;
    /**
    * The taint key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#key NodeTaint#key}
    */
    readonly key: string;
    /**
    * The taint value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#value NodeTaint#value}
    */
    readonly value: string;
}
export declare function nodeTaintTaintToTerraform(struct?: NodeTaintTaint | cdktn.IResolvable): any;
export declare function nodeTaintTaintToHclTerraform(struct?: NodeTaintTaint | cdktn.IResolvable): any;
export declare class NodeTaintTaintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NodeTaintTaint | cdktn.IResolvable | undefined;
    set internalValue(value: NodeTaintTaint | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class NodeTaintTaintList extends cdktn.ComplexList {
    internalValue?: NodeTaintTaint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NodeTaintTaintOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint kubernetes_node_taint}
*/
export declare class NodeTaint extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_node_taint";
    /**
    * Generates CDKTN code for importing a NodeTaint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NodeTaint to import
    * @param importFromId The id of the existing NodeTaint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NodeTaint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/node_taint kubernetes_node_taint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NodeTaintConfig
    */
    constructor(scope: Construct, id: string, config: NodeTaintConfig);
    private _fieldManager?;
    get fieldManager(): string;
    set fieldManager(value: string);
    resetFieldManager(): void;
    get fieldManagerInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): NodeTaintMetadataOutputReference;
    putMetadata(value: NodeTaintMetadata): void;
    get metadataInput(): NodeTaintMetadata | undefined;
    private _taint;
    get taint(): NodeTaintTaintList;
    putTaint(value: NodeTaintTaint[] | cdktn.IResolvable): void;
    get taintInput(): cdktn.IResolvable | NodeTaintTaint[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
