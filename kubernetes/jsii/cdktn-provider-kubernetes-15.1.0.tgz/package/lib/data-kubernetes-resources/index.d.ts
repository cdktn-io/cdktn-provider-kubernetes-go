/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesResourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource apiVersion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#api_version DataKubernetesResources#api_version}
    */
    readonly apiVersion: string;
    /**
    * A selector to restrict the list of returned objects by their fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#field_selector DataKubernetesResources#field_selector}
    */
    readonly fieldSelector?: string;
    /**
    * The resource kind.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#kind DataKubernetesResources#kind}
    */
    readonly kind: string;
    /**
    * A selector to restrict the list of returned objects by their labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#label_selector DataKubernetesResources#label_selector}
    */
    readonly labelSelector?: string;
    /**
    * Limit is a maximum number of responses to return for a list call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#limit DataKubernetesResources#limit}
    */
    readonly limit?: number;
    /**
    * The resource namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#namespace DataKubernetesResources#namespace}
    */
    readonly namespace?: string;
    /**
    * The response from the API server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#objects DataKubernetesResources#objects}
    */
    readonly objects?: {
        [key: string]: any;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources kubernetes_resources}
*/
export declare class DataKubernetesResources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_resources";
    /**
    * Generates CDKTN code for importing a DataKubernetesResources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesResources to import
    * @param importFromId The id of the existing DataKubernetesResources that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesResources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/resources kubernetes_resources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesResourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataKubernetesResourcesConfig);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _fieldSelector?;
    get fieldSelector(): string;
    set fieldSelector(value: string);
    resetFieldSelector(): void;
    get fieldSelectorInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _labelSelector?;
    get labelSelector(): string;
    set labelSelector(value: string);
    resetLabelSelector(): void;
    get labelSelectorInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _objects?;
    get objects(): {
        [key: string]: any;
    };
    set objects(value: {
        [key: string]: any;
    });
    resetObjects(): void;
    get objectsInput(): {
        [key: string]: any;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
