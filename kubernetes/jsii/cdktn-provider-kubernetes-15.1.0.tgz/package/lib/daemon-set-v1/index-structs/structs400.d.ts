/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeExec, DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeExecOutputReference, DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeGrpc, DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeGrpcList, DaemonSetV1SpecTemplateSpecInitContainerEnv, DaemonSetV1SpecTemplateSpecInitContainerEnvList, DaemonSetV1SpecTemplateSpecInitContainerEnvFrom, DaemonSetV1SpecTemplateSpecInitContainerEnvFromList, DaemonSetV1SpecTemplateSpecInitContainerLifecycle, DaemonSetV1SpecTemplateSpecInitContainerLifecycleOutputReference, DaemonSetV1SpecTemplateSpecAffinity, DaemonSetV1SpecTemplateSpecAffinityOutputReference, DaemonSetV1SpecTemplateSpecContainer, DaemonSetV1SpecTemplateSpecContainerList, DaemonSetV1SpecTemplateSpecDnsConfig, DaemonSetV1SpecTemplateSpecDnsConfigOutputReference, DaemonSetV1SpecTemplateSpecHostAliases, DaemonSetV1SpecTemplateSpecHostAliasesList, DaemonSetV1SpecTemplateSpecImagePullSecrets, DaemonSetV1SpecTemplateSpecImagePullSecretsList, DaemonSetV1SpecTemplateMetadata, DaemonSetV1SpecTemplateMetadataOutputReference, DaemonSetV1SpecSelector, DaemonSetV1SpecSelectorOutputReference, DaemonSetV1SpecStrategy, DaemonSetV1SpecStrategyOutputReference } from './structs0';
export interface DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#value DaemonSetV1#value}
    */
    readonly value?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeaderToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeaderToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeaderOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet {
    /**
    * Host name to connect to, defaults to the pod IP. You probably want to set "Host" in httpHeaders instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host DaemonSetV1#host}
    */
    readonly host?: string;
    /**
    * Path to access on the HTTP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
    /**
    * Name or number of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port?: string;
    /**
    * Scheme to use for connecting to the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#scheme DaemonSetV1#scheme}
    */
    readonly scheme?: string;
    /**
    * http_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#http_header DaemonSetV1#http_header}
    */
    readonly httpHeader?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetOutputReference | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetOutputReference | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _httpHeader;
    get httpHeader(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeaderList;
    putHttpHeader(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader[] | cdktn.IResolvable): void;
    resetHttpHeader(): void;
    get httpHeaderInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetHttpHeader[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket {
    /**
    * Number or name of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocketToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocketToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket | cdktn.IResolvable | undefined);
    private _port?;
    get port(): string;
    set port(value: string);
    get portInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocketList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocketOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#failure_threshold DaemonSetV1#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before liveness probes are initiated. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#initial_delay_seconds DaemonSetV1#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#period_seconds DaemonSetV1#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Minimum consecutive successes for the probe to be considered successful after having failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#success_threshold DaemonSetV1#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * Number of seconds after which the probe times out. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#timeout_seconds DaemonSetV1#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * exec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#exec DaemonSetV1#exec}
    */
    readonly exec?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeExec;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#grpc DaemonSetV1#grpc}
    */
    readonly grpc?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeGrpc[] | cdktn.IResolvable;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#http_get DaemonSetV1#http_get}
    */
    readonly httpGet?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#tcp_socket DaemonSetV1#tcp_socket}
    */
    readonly tcpSocket?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeOutputReference | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerLivenessProbeToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeOutputReference | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _exec;
    get exec(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeExecOutputReference;
    putExec(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeExec): void;
    resetExec(): void;
    get execInput(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeExec | undefined;
    private _grpc;
    get grpc(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeGrpcList;
    putGrpc(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeGrpc[] | cdktn.IResolvable): void;
    resetGrpc(): void;
    get grpcInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeGrpc[] | undefined;
    private _httpGet;
    get httpGet(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGetOutputReference;
    putHttpGet(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocketList;
    putTcpSocket(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket[] | cdktn.IResolvable): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeTcpSocket[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerPort {
    /**
    * Number of port to expose on the pod's IP address. This must be a valid port number, 0 < x < 65536.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#container_port DaemonSetV1#container_port}
    */
    readonly containerPort: number;
    /**
    * What host IP to bind the external port to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_ip DaemonSetV1#host_ip}
    */
    readonly hostIp?: string;
    /**
    * Number of port to expose on the host. If specified, this must be a valid port number, 0 < x < 65536. If HostNetwork is specified, this must match ContainerPort. Most containers do not need this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_port DaemonSetV1#host_port}
    */
    readonly hostPort?: number;
    /**
    * If specified, this must be an IANA_SVC_NAME and unique within the pod. Each named port in a pod must have a unique name. Name for the port that can be referred to by services
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Protocol for port. Must be UDP or TCP. Defaults to "TCP".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#protocol DaemonSetV1#protocol}
    */
    readonly protocol?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerPortToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerPortToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable | undefined);
    private _containerPort?;
    get containerPort(): number;
    set containerPort(value: number);
    get containerPortInput(): number | undefined;
    private _hostIp?;
    get hostIp(): string;
    set hostIp(value: string);
    resetHostIp(): void;
    get hostIpInput(): string | undefined;
    private _hostPort?;
    get hostPort(): number;
    set hostPort(value: number);
    resetHostPort(): void;
    get hostPortInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerPortList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerPortOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec {
    /**
    * Command is the command line to execute inside the container, the working directory for the command is root ('/') in the container's filesystem. The command is simply exec'd, it is not run inside a shell, so traditional shell instructions. To use a shell, you need to explicitly call out to that shell. Exit status of 0 is treated as live/healthy and non-zero is unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#command DaemonSetV1#command}
    */
    readonly command?: string[];
}
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeExecToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeExecToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc {
    /**
    * Number of the port to access on the container. Number must be in the range 1 to 65535.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port: number;
    /**
    * Name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md). If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#service DaemonSetV1#service}
    */
    readonly service?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpcToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpcToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpcList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpcOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#value DaemonSetV1#value}
    */
    readonly value?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet {
    /**
    * Host name to connect to, defaults to the pod IP. You probably want to set "Host" in httpHeaders instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host DaemonSetV1#host}
    */
    readonly host?: string;
    /**
    * Path to access on the HTTP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
    /**
    * Name or number of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port?: string;
    /**
    * Scheme to use for connecting to the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#scheme DaemonSetV1#scheme}
    */
    readonly scheme?: string;
    /**
    * http_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#http_header DaemonSetV1#http_header}
    */
    readonly httpHeader?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _httpHeader;
    get httpHeader(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderList;
    putHttpHeader(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | cdktn.IResolvable): void;
    resetHttpHeader(): void;
    get httpHeaderInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket {
    /**
    * Number or name of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable | undefined);
    private _port?;
    get port(): string;
    set port(value: string);
    get portInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#failure_threshold DaemonSetV1#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before liveness probes are initiated. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#initial_delay_seconds DaemonSetV1#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#period_seconds DaemonSetV1#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Minimum consecutive successes for the probe to be considered successful after having failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#success_threshold DaemonSetV1#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * Number of seconds after which the probe times out. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#timeout_seconds DaemonSetV1#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * exec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#exec DaemonSetV1#exec}
    */
    readonly exec?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#grpc DaemonSetV1#grpc}
    */
    readonly grpc?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | cdktn.IResolvable;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#http_get DaemonSetV1#http_get}
    */
    readonly httpGet?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#tcp_socket DaemonSetV1#tcp_socket}
    */
    readonly tcpSocket?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeOutputReference | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerReadinessProbeToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeOutputReference | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _exec;
    get exec(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference;
    putExec(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec): void;
    resetExec(): void;
    get execInput(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeExec | undefined;
    private _grpc;
    get grpc(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpcList;
    putGrpc(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | cdktn.IResolvable): void;
    resetGrpc(): void;
    get grpcInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | undefined;
    private _httpGet;
    get httpGet(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference;
    putHttpGet(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketList;
    putTcpSocket(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | cdktn.IResolvable): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerResources {
    /**
    * Describes the maximum amount of compute resources allowed. More info: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#limits DaemonSetV1#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Requests describes the minimum amount of compute resources required. If Requests is omitted for a container, it defaults to Limits if that is explicitly specified, otherwise to an implementation-defined value. More info: https://kubernetes.io/docs/concepts/configuration/manage-compute-resources-container/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#requests DaemonSetV1#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function daemonSetV1SpecTemplateSpecInitContainerResourcesToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerResourcesOutputReference | DaemonSetV1SpecTemplateSpecInitContainerResources): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerResourcesToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerResourcesOutputReference | DaemonSetV1SpecTemplateSpecInitContainerResources): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerResources | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerResources | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities {
    /**
    * Added capabilities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#add DaemonSetV1#add}
    */
    readonly add?: string[];
    /**
    * Removed capabilities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#drop DaemonSetV1#drop}
    */
    readonly drop?: string[];
}
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities | undefined);
    private _add?;
    get add(): string[];
    set add(value: string[]);
    resetAdd(): void;
    get addInput(): string[] | undefined;
    private _drop?;
    get drop(): string[];
    set drop(value: string[]);
    resetDrop(): void;
    get dropInput(): string[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions {
    /**
    * Level is SELinux level label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#level DaemonSetV1#level}
    */
    readonly level?: string;
    /**
    * Role is a SELinux role label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#role DaemonSetV1#role}
    */
    readonly role?: string;
    /**
    * Type is a SELinux type label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#type DaemonSetV1#type}
    */
    readonly type?: string;
    /**
    * User is a SELinux user label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#user DaemonSetV1#user}
    */
    readonly user?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile {
    /**
    * Localhost Profile indicates a profile defined in a file on the node should be used. The profile must be preconfigured on the node to work.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#localhost_profile DaemonSetV1#localhost_profile}
    */
    readonly localhostProfile?: string;
    /**
    * Type indicates which kind of seccomp profile will be applied. Valid options are: Localhost, RuntimeDefault, Unconfined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#type DaemonSetV1#type}
    */
    readonly type?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile | undefined);
    private _localhostProfile?;
    get localhostProfile(): string;
    set localhostProfile(value: string);
    resetLocalhostProfile(): void;
    get localhostProfileInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerSecurityContext {
    /**
    * AllowPrivilegeEscalation controls whether a process can gain more privileges than its parent process. This bool directly controls if the no_new_privs flag will be set on the container process. AllowPrivilegeEscalation is true always when the container is: 1) run as Privileged 2) has CAP_SYS_ADMIN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#allow_privilege_escalation DaemonSetV1#allow_privilege_escalation}
    */
    readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
    /**
    * Run container in privileged mode. Processes in privileged containers are essentially equivalent to root on the host. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#privileged DaemonSetV1#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Whether this container has a read-only root filesystem. Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only_root_filesystem DaemonSetV1#read_only_root_filesystem}
    */
    readonly readOnlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * The GID to run the entrypoint of the container process. Uses runtime default if unset. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_group DaemonSetV1#run_as_group}
    */
    readonly runAsGroup?: string;
    /**
    * Indicates that the container must run as a non-root user. If true, the Kubelet will validate the image at runtime to ensure that it does not run as UID 0 (root) and fail to start the container if it does. If unset or false, no such validation will be performed. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_non_root DaemonSetV1#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * The UID to run the entrypoint of the container process. Defaults to user specified in image metadata if unspecified. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_user DaemonSetV1#run_as_user}
    */
    readonly runAsUser?: string;
    /**
    * capabilities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#capabilities DaemonSetV1#capabilities}
    */
    readonly capabilities?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities;
    /**
    * se_linux_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#se_linux_options DaemonSetV1#se_linux_options}
    */
    readonly seLinuxOptions?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions;
    /**
    * seccomp_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#seccomp_profile DaemonSetV1#seccomp_profile}
    */
    readonly seccompProfile?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContext): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerSecurityContextToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextOutputReference | DaemonSetV1SpecTemplateSpecInitContainerSecurityContext): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContext | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContext | undefined);
    private _allowPrivilegeEscalation?;
    get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
    set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
    resetAllowPrivilegeEscalation(): void;
    get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readOnlyRootFilesystem?;
    get readOnlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readOnlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadOnlyRootFilesystem(): void;
    get readOnlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsGroup?;
    get runAsGroup(): string;
    set runAsGroup(value: string);
    resetRunAsGroup(): void;
    get runAsGroupInput(): string | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): string;
    set runAsUser(value: string);
    resetRunAsUser(): void;
    get runAsUserInput(): string | undefined;
    private _capabilities;
    get capabilities(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference;
    putCapabilities(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities): void;
    resetCapabilities(): void;
    get capabilitiesInput(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextCapabilities | undefined;
    private _seLinuxOptions;
    get seLinuxOptions(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference;
    putSeLinuxOptions(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions): void;
    resetSeLinuxOptions(): void;
    get seLinuxOptionsInput(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions | undefined;
    private _seccompProfile;
    get seccompProfile(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference;
    putSeccompProfile(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile): void;
    resetSeccompProfile(): void;
    get seccompProfileInput(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec {
    /**
    * Command is the command line to execute inside the container, the working directory for the command is root ('/') in the container's filesystem. The command is simply exec'd, it is not run inside a shell, so traditional shell instructions. To use a shell, you need to explicitly call out to that shell. Exit status of 0 is treated as live/healthy and non-zero is unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#command DaemonSetV1#command}
    */
    readonly command?: string[];
}
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeExecToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeExecToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc {
    /**
    * Number of the port to access on the container. Number must be in the range 1 to 65535.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port: number;
    /**
    * Name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md). If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#service DaemonSetV1#service}
    */
    readonly service?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpcToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpcToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpcList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpcOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#value DaemonSetV1#value}
    */
    readonly value?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet {
    /**
    * Host name to connect to, defaults to the pod IP. You probably want to set "Host" in httpHeaders instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host DaemonSetV1#host}
    */
    readonly host?: string;
    /**
    * Path to access on the HTTP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
    /**
    * Name or number of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port?: string;
    /**
    * Scheme to use for connecting to the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#scheme DaemonSetV1#scheme}
    */
    readonly scheme?: string;
    /**
    * http_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#http_header DaemonSetV1#http_header}
    */
    readonly httpHeader?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _httpHeader;
    get httpHeader(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderList;
    putHttpHeader(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | cdktn.IResolvable): void;
    resetHttpHeader(): void;
    get httpHeaderInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket {
    /**
    * Number or name of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocketToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocketToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable | undefined);
    private _port?;
    get port(): string;
    set port(value: string);
    get portInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocketList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocketOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerStartupProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#failure_threshold DaemonSetV1#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before liveness probes are initiated. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#initial_delay_seconds DaemonSetV1#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#period_seconds DaemonSetV1#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Minimum consecutive successes for the probe to be considered successful after having failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#success_threshold DaemonSetV1#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * Number of seconds after which the probe times out. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#timeout_seconds DaemonSetV1#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * exec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#exec DaemonSetV1#exec}
    */
    readonly exec?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#grpc DaemonSetV1#grpc}
    */
    readonly grpc?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | cdktn.IResolvable;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#http_get DaemonSetV1#http_get}
    */
    readonly httpGet?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#tcp_socket DaemonSetV1#tcp_socket}
    */
    readonly tcpSocket?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeOutputReference | DaemonSetV1SpecTemplateSpecInitContainerStartupProbe): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerStartupProbeToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeOutputReference | DaemonSetV1SpecTemplateSpecInitContainerStartupProbe): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbe | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _exec;
    get exec(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference;
    putExec(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec): void;
    resetExec(): void;
    get execInput(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeExec | undefined;
    private _grpc;
    get grpc(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpcList;
    putGrpc(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | cdktn.IResolvable): void;
    resetGrpc(): void;
    get grpcInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | undefined;
    private _httpGet;
    get httpGet(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference;
    putHttpGet(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocketList;
    putTcpSocket(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | cdktn.IResolvable): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice {
    /**
    * Path within the container at which the volume device should be attached. For example '/dev/xvda'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#device_path DaemonSetV1#device_path}
    */
    readonly devicePath: string;
    /**
    * This must match the Name of a PersistentVolumeClaim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerVolumeDeviceToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerVolumeDeviceToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerVolumeDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable | undefined);
    private _devicePath?;
    get devicePath(): string;
    set devicePath(value: string);
    get devicePathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerVolumeDeviceList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerVolumeDeviceOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainerVolumeMount {
    /**
    * Path within the container at which the volume should be mounted. Must not contain ':'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mount_path DaemonSetV1#mount_path}
    */
    readonly mountPath: string;
    /**
    * Mount propagation mode. mount_propagation determines how mounts are propagated from the host to container and the other way around. Valid values are None (default), HostToContainer and Bidirectional.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mount_propagation DaemonSetV1#mount_propagation}
    */
    readonly mountPropagation?: string;
    /**
    * This must match the Name of a Volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name: string;
    /**
    * Mounted read-only if true, read-write otherwise (false or unspecified). Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Path within the volume from which the container's volume should be mounted. Defaults to "" (volume's root).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#sub_path DaemonSetV1#sub_path}
    */
    readonly subPath?: string;
    /**
    * Dynamic path within the volume from which the container's volume should be mounted. Defaults to "" (volume's root).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#sub_path_expr DaemonSetV1#sub_path_expr}
    */
    readonly subPathExpr?: string;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerVolumeMountToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerVolumeMountToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerVolumeMountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _mountPropagation?;
    get mountPropagation(): string;
    set mountPropagation(value: string);
    resetMountPropagation(): void;
    get mountPropagationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
    private _subPathExpr?;
    get subPathExpr(): string;
    set subPathExpr(value: string);
    resetSubPathExpr(): void;
    get subPathExprInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerVolumeMountList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainerVolumeMount[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerVolumeMountOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecInitContainer {
    /**
    * Arguments to the entrypoint. The docker image's CMD is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. Cannot be updated. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#args DaemonSetV1#args}
    */
    readonly args?: string[];
    /**
    * Entrypoint array. Not executed within a shell. The docker image's ENTRYPOINT is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. Cannot be updated. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#command DaemonSetV1#command}
    */
    readonly command?: string[];
    /**
    * Docker image name. More info: https://kubernetes.io/docs/concepts/containers/images/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#image DaemonSetV1#image}
    */
    readonly image?: string;
    /**
    * Image pull policy. One of Always, Never, IfNotPresent. Defaults to Always if :latest tag is specified, or IfNotPresent otherwise. Cannot be updated. More info: https://kubernetes.io/docs/concepts/containers/images/#updating-images
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#image_pull_policy DaemonSetV1#image_pull_policy}
    */
    readonly imagePullPolicy?: string;
    /**
    * Name of the container specified as a DNS_LABEL. Each container in a pod must have a unique name (DNS_LABEL). Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name: string;
    /**
    * Restart policy for designating init container as a sidecar. Can only be `Always`. More info: https://kubernetes.io/docs/concepts/workloads/pods/sidecar-containers/#pod-sidecar-containers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#restart_policy DaemonSetV1#restart_policy}
    */
    readonly restartPolicy?: string;
    /**
    * Whether this container should allocate a buffer for stdin in the container runtime. If this is not set, reads from stdin in the container will always result in EOF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#stdin DaemonSetV1#stdin}
    */
    readonly stdin?: boolean | cdktn.IResolvable;
    /**
    * Whether the container runtime should close the stdin channel after it has been opened by a single attach. When stdin is true the stdin stream will remain open across multiple attach sessions. If stdinOnce is set to true, stdin is opened on container start, is empty until the first client attaches to stdin, and then remains open and accepts data until the client disconnects, at which time stdin is closed and remains closed until the container is restarted. If this flag is false, a container processes that reads from stdin will never receive an EOF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#stdin_once DaemonSetV1#stdin_once}
    */
    readonly stdinOnce?: boolean | cdktn.IResolvable;
    /**
    * Optional: Path at which the file to which the container's termination message will be written is mounted into the container's filesystem. Message written is intended to be brief final status, such as an assertion failure message. Defaults to /dev/termination-log. Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#termination_message_path DaemonSetV1#termination_message_path}
    */
    readonly terminationMessagePath?: string;
    /**
    * Optional: Indicate how the termination message should be populated. File will use the contents of terminationMessagePath to populate the container status message on both success and failure. FallbackToLogsOnError will use the last chunk of container log output if the termination message file is empty and the container exited with an error. The log output is limited to 2048 bytes or 80 lines, whichever is smaller. Defaults to File. Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#termination_message_policy DaemonSetV1#termination_message_policy}
    */
    readonly terminationMessagePolicy?: string;
    /**
    * Whether this container should allocate a TTY for itself
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#tty DaemonSetV1#tty}
    */
    readonly tty?: boolean | cdktn.IResolvable;
    /**
    * Container's working directory. If not specified, the container runtime's default will be used, which might be configured in the container image. Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#working_dir DaemonSetV1#working_dir}
    */
    readonly workingDir?: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#env DaemonSetV1#env}
    */
    readonly env?: DaemonSetV1SpecTemplateSpecInitContainerEnv[] | cdktn.IResolvable;
    /**
    * env_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#env_from DaemonSetV1#env_from}
    */
    readonly envFrom?: DaemonSetV1SpecTemplateSpecInitContainerEnvFrom[] | cdktn.IResolvable;
    /**
    * lifecycle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#lifecycle DaemonSetV1#lifecycle}
    */
    readonly lifecycle?: DaemonSetV1SpecTemplateSpecInitContainerLifecycle;
    /**
    * liveness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#liveness_probe DaemonSetV1#liveness_probe}
    */
    readonly livenessProbe?: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe;
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#port DaemonSetV1#port}
    */
    readonly port?: DaemonSetV1SpecTemplateSpecInitContainerPort[] | cdktn.IResolvable;
    /**
    * readiness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#readiness_probe DaemonSetV1#readiness_probe}
    */
    readonly readinessProbe?: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#resources DaemonSetV1#resources}
    */
    readonly resources?: DaemonSetV1SpecTemplateSpecInitContainerResources;
    /**
    * security_context block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#security_context DaemonSetV1#security_context}
    */
    readonly securityContext?: DaemonSetV1SpecTemplateSpecInitContainerSecurityContext;
    /**
    * startup_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#startup_probe DaemonSetV1#startup_probe}
    */
    readonly startupProbe?: DaemonSetV1SpecTemplateSpecInitContainerStartupProbe;
    /**
    * volume_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_device DaemonSetV1#volume_device}
    */
    readonly volumeDevice?: DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice[] | cdktn.IResolvable;
    /**
    * volume_mount block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_mount DaemonSetV1#volume_mount}
    */
    readonly volumeMount?: DaemonSetV1SpecTemplateSpecInitContainerVolumeMount[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecInitContainerToTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainer | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecInitContainerToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecInitContainer | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecInitContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecInitContainer | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecInitContainer | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imagePullPolicy?;
    get imagePullPolicy(): string;
    set imagePullPolicy(value: string);
    resetImagePullPolicy(): void;
    get imagePullPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _restartPolicy?;
    get restartPolicy(): string;
    set restartPolicy(value: string);
    resetRestartPolicy(): void;
    get restartPolicyInput(): string | undefined;
    private _stdin?;
    get stdin(): boolean | cdktn.IResolvable;
    set stdin(value: boolean | cdktn.IResolvable);
    resetStdin(): void;
    get stdinInput(): boolean | cdktn.IResolvable | undefined;
    private _stdinOnce?;
    get stdinOnce(): boolean | cdktn.IResolvable;
    set stdinOnce(value: boolean | cdktn.IResolvable);
    resetStdinOnce(): void;
    get stdinOnceInput(): boolean | cdktn.IResolvable | undefined;
    private _terminationMessagePath?;
    get terminationMessagePath(): string;
    set terminationMessagePath(value: string);
    resetTerminationMessagePath(): void;
    get terminationMessagePathInput(): string | undefined;
    private _terminationMessagePolicy?;
    get terminationMessagePolicy(): string;
    set terminationMessagePolicy(value: string);
    resetTerminationMessagePolicy(): void;
    get terminationMessagePolicyInput(): string | undefined;
    private _tty?;
    get tty(): boolean | cdktn.IResolvable;
    set tty(value: boolean | cdktn.IResolvable);
    resetTty(): void;
    get ttyInput(): boolean | cdktn.IResolvable | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    private _env;
    get env(): DaemonSetV1SpecTemplateSpecInitContainerEnvList;
    putEnv(value: DaemonSetV1SpecTemplateSpecInitContainerEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerEnv[] | undefined;
    private _envFrom;
    get envFrom(): DaemonSetV1SpecTemplateSpecInitContainerEnvFromList;
    putEnvFrom(value: DaemonSetV1SpecTemplateSpecInitContainerEnvFrom[] | cdktn.IResolvable): void;
    resetEnvFrom(): void;
    get envFromInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerEnvFrom[] | undefined;
    private _lifecycle;
    get lifecycle(): DaemonSetV1SpecTemplateSpecInitContainerLifecycleOutputReference;
    putLifecycle(value: DaemonSetV1SpecTemplateSpecInitContainerLifecycle): void;
    resetLifecycle(): void;
    get lifecycleInput(): DaemonSetV1SpecTemplateSpecInitContainerLifecycle | undefined;
    private _livenessProbe;
    get livenessProbe(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbeOutputReference;
    putLivenessProbe(value: DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe): void;
    resetLivenessProbe(): void;
    get livenessProbeInput(): DaemonSetV1SpecTemplateSpecInitContainerLivenessProbe | undefined;
    private _port;
    get port(): DaemonSetV1SpecTemplateSpecInitContainerPortList;
    putPort(value: DaemonSetV1SpecTemplateSpecInitContainerPort[] | cdktn.IResolvable): void;
    resetPort(): void;
    get portInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerPort[] | undefined;
    private _readinessProbe;
    get readinessProbe(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbeOutputReference;
    putReadinessProbe(value: DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe): void;
    resetReadinessProbe(): void;
    get readinessProbeInput(): DaemonSetV1SpecTemplateSpecInitContainerReadinessProbe | undefined;
    private _resources;
    get resources(): DaemonSetV1SpecTemplateSpecInitContainerResourcesOutputReference;
    putResources(value: DaemonSetV1SpecTemplateSpecInitContainerResources): void;
    resetResources(): void;
    get resourcesInput(): DaemonSetV1SpecTemplateSpecInitContainerResources | undefined;
    private _securityContext;
    get securityContext(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContextOutputReference;
    putSecurityContext(value: DaemonSetV1SpecTemplateSpecInitContainerSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): DaemonSetV1SpecTemplateSpecInitContainerSecurityContext | undefined;
    private _startupProbe;
    get startupProbe(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbeOutputReference;
    putStartupProbe(value: DaemonSetV1SpecTemplateSpecInitContainerStartupProbe): void;
    resetStartupProbe(): void;
    get startupProbeInput(): DaemonSetV1SpecTemplateSpecInitContainerStartupProbe | undefined;
    private _volumeDevice;
    get volumeDevice(): DaemonSetV1SpecTemplateSpecInitContainerVolumeDeviceList;
    putVolumeDevice(value: DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice[] | cdktn.IResolvable): void;
    resetVolumeDevice(): void;
    get volumeDeviceInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerVolumeDevice[] | undefined;
    private _volumeMount;
    get volumeMount(): DaemonSetV1SpecTemplateSpecInitContainerVolumeMountList;
    putVolumeMount(value: DaemonSetV1SpecTemplateSpecInitContainerVolumeMount[] | cdktn.IResolvable): void;
    resetVolumeMount(): void;
    get volumeMountInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainerVolumeMount[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecInitContainerList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecInitContainer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecInitContainerOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecOs {
    /**
    * Name is the name of the operating system. The currently supported values are linux and windows.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name: string;
}
export declare function daemonSetV1SpecTemplateSpecOsToTerraform(struct?: DaemonSetV1SpecTemplateSpecOsOutputReference | DaemonSetV1SpecTemplateSpecOs): any;
export declare function daemonSetV1SpecTemplateSpecOsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecOsOutputReference | DaemonSetV1SpecTemplateSpecOs): any;
export declare class DaemonSetV1SpecTemplateSpecOsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecOs | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecOs | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecReadinessGate {
    /**
    * refers to a condition in the pod's condition list with matching type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#condition_type DaemonSetV1#condition_type}
    */
    readonly conditionType: string;
}
export declare function daemonSetV1SpecTemplateSpecReadinessGateToTerraform(struct?: DaemonSetV1SpecTemplateSpecReadinessGate | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecReadinessGateToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecReadinessGate | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecReadinessGateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecReadinessGate | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecReadinessGate | cdktn.IResolvable | undefined);
    private _conditionType?;
    get conditionType(): string;
    set conditionType(value: string);
    get conditionTypeInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecReadinessGateList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecReadinessGate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecReadinessGateOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions {
    /**
    * Level is SELinux level label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#level DaemonSetV1#level}
    */
    readonly level?: string;
    /**
    * Role is a SELinux role label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#role DaemonSetV1#role}
    */
    readonly role?: string;
    /**
    * Type is a SELinux type label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#type DaemonSetV1#type}
    */
    readonly type?: string;
    /**
    * User is a SELinux user label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#user DaemonSetV1#user}
    */
    readonly user?: string;
}
export declare function daemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptionsToTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference | DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions): any;
export declare function daemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptionsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference | DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions): any;
export declare class DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile {
    /**
    * Localhost Profile indicates a profile defined in a file on the node should be used. The profile must be preconfigured on the node to work.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#localhost_profile DaemonSetV1#localhost_profile}
    */
    readonly localhostProfile?: string;
    /**
    * Type indicates which kind of seccomp profile will be applied. Valid options are: Localhost, RuntimeDefault, Unconfined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#type DaemonSetV1#type}
    */
    readonly type?: string;
}
export declare function daemonSetV1SpecTemplateSpecSecurityContextSeccompProfileToTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference | DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile): any;
export declare function daemonSetV1SpecTemplateSpecSecurityContextSeccompProfileToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference | DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile): any;
export declare class DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile | undefined);
    private _localhostProfile?;
    get localhostProfile(): string;
    set localhostProfile(value: string);
    resetLocalhostProfile(): void;
    get localhostProfileInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecSecurityContextSysctl {
    /**
    * Name of a property to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name: string;
    /**
    * Value of a property to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#value DaemonSetV1#value}
    */
    readonly value: string;
}
export declare function daemonSetV1SpecTemplateSpecSecurityContextSysctlToTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecSecurityContextSysctlToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecSecurityContextSysctlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecSecurityContextSysctlList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecSecurityContextSysctl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecSecurityContextSysctlOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions {
    /**
    * GMSACredentialSpec is where the GMSA admission webhook inlines the contents of the GMSA credential spec named by the GMSACredentialSpecName field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#gmsa_credential_spec DaemonSetV1#gmsa_credential_spec}
    */
    readonly gmsaCredentialSpec?: string;
    /**
    * GMSACredentialSpecName is the name of the GMSA credential spec to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#gmsa_credential_spec_name DaemonSetV1#gmsa_credential_spec_name}
    */
    readonly gmsaCredentialSpecName?: string;
    /**
    * HostProcess determines if a container should be run as a 'Host Process' container. Default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_process DaemonSetV1#host_process}
    */
    readonly hostProcess?: boolean | cdktn.IResolvable;
    /**
    * The UserName in Windows to run the entrypoint of the container process. Defaults to the user specified in image metadata if unspecified. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_username DaemonSetV1#run_as_username}
    */
    readonly runAsUsername?: string;
}
export declare function daemonSetV1SpecTemplateSpecSecurityContextWindowsOptionsToTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference | DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions): any;
export declare function daemonSetV1SpecTemplateSpecSecurityContextWindowsOptionsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference | DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions): any;
export declare class DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions | undefined);
    private _gmsaCredentialSpec?;
    get gmsaCredentialSpec(): string;
    set gmsaCredentialSpec(value: string);
    resetGmsaCredentialSpec(): void;
    get gmsaCredentialSpecInput(): string | undefined;
    private _gmsaCredentialSpecName?;
    get gmsaCredentialSpecName(): string;
    set gmsaCredentialSpecName(value: string);
    resetGmsaCredentialSpecName(): void;
    get gmsaCredentialSpecNameInput(): string | undefined;
    private _hostProcess?;
    get hostProcess(): boolean | cdktn.IResolvable;
    set hostProcess(value: boolean | cdktn.IResolvable);
    resetHostProcess(): void;
    get hostProcessInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUsername?;
    get runAsUsername(): string;
    set runAsUsername(value: string);
    resetRunAsUsername(): void;
    get runAsUsernameInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecSecurityContext {
    /**
    * A special supplemental group that applies to all containers in a pod. Some volume types allow the Kubelet to change the ownership of that volume to be owned by the pod: 1. The owning GID will be the FSGroup 2. The setgid bit is set (new files created in the volume will be owned by FSGroup) 3. The permission bits are OR'd with rw-rw---- If unset, the Kubelet will not modify the ownership and permissions of any volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_group DaemonSetV1#fs_group}
    */
    readonly fsGroup?: string;
    /**
    * fsGroupChangePolicy defines behavior of changing ownership and permission of the volume before being exposed inside Pod. This field will only apply to volume types which support fsGroup based ownership(and permissions). It will have no effect on ephemeral volume types such as: secret, configmaps and emptydir.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_group_change_policy DaemonSetV1#fs_group_change_policy}
    */
    readonly fsGroupChangePolicy?: string;
    /**
    * The GID to run the entrypoint of the container process. Uses runtime default if unset. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_group DaemonSetV1#run_as_group}
    */
    readonly runAsGroup?: string;
    /**
    * Indicates that the container must run as a non-root user. If true, the Kubelet will validate the image at runtime to ensure that it does not run as UID 0 (root) and fail to start the container if it does. If unset or false, no such validation will be performed. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_non_root DaemonSetV1#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * The UID to run the entrypoint of the container process. Defaults to user specified in image metadata if unspecified. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#run_as_user DaemonSetV1#run_as_user}
    */
    readonly runAsUser?: string;
    /**
    * A list of groups applied to the first process run in each container, in addition to the container's primary GID. If unspecified, no groups will be added to any container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#supplemental_groups DaemonSetV1#supplemental_groups}
    */
    readonly supplementalGroups?: number[];
    /**
    * se_linux_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#se_linux_options DaemonSetV1#se_linux_options}
    */
    readonly seLinuxOptions?: DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions;
    /**
    * seccomp_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#seccomp_profile DaemonSetV1#seccomp_profile}
    */
    readonly seccompProfile?: DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile;
    /**
    * sysctl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#sysctl DaemonSetV1#sysctl}
    */
    readonly sysctl?: DaemonSetV1SpecTemplateSpecSecurityContextSysctl[] | cdktn.IResolvable;
    /**
    * windows_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#windows_options DaemonSetV1#windows_options}
    */
    readonly windowsOptions?: DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions;
}
export declare function daemonSetV1SpecTemplateSpecSecurityContextToTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextOutputReference | DaemonSetV1SpecTemplateSpecSecurityContext): any;
export declare function daemonSetV1SpecTemplateSpecSecurityContextToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecSecurityContextOutputReference | DaemonSetV1SpecTemplateSpecSecurityContext): any;
export declare class DaemonSetV1SpecTemplateSpecSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecSecurityContext | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecSecurityContext | undefined);
    private _fsGroup?;
    get fsGroup(): string;
    set fsGroup(value: string);
    resetFsGroup(): void;
    get fsGroupInput(): string | undefined;
    private _fsGroupChangePolicy?;
    get fsGroupChangePolicy(): string;
    set fsGroupChangePolicy(value: string);
    resetFsGroupChangePolicy(): void;
    get fsGroupChangePolicyInput(): string | undefined;
    private _runAsGroup?;
    get runAsGroup(): string;
    set runAsGroup(value: string);
    resetRunAsGroup(): void;
    get runAsGroupInput(): string | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): string;
    set runAsUser(value: string);
    resetRunAsUser(): void;
    get runAsUserInput(): string | undefined;
    private _supplementalGroups?;
    get supplementalGroups(): number[];
    set supplementalGroups(value: number[]);
    resetSupplementalGroups(): void;
    get supplementalGroupsInput(): number[] | undefined;
    private _seLinuxOptions;
    get seLinuxOptions(): DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference;
    putSeLinuxOptions(value: DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions): void;
    resetSeLinuxOptions(): void;
    get seLinuxOptionsInput(): DaemonSetV1SpecTemplateSpecSecurityContextSeLinuxOptions | undefined;
    private _seccompProfile;
    get seccompProfile(): DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference;
    putSeccompProfile(value: DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile): void;
    resetSeccompProfile(): void;
    get seccompProfileInput(): DaemonSetV1SpecTemplateSpecSecurityContextSeccompProfile | undefined;
    private _sysctl;
    get sysctl(): DaemonSetV1SpecTemplateSpecSecurityContextSysctlList;
    putSysctl(value: DaemonSetV1SpecTemplateSpecSecurityContextSysctl[] | cdktn.IResolvable): void;
    resetSysctl(): void;
    get sysctlInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecSecurityContextSysctl[] | undefined;
    private _windowsOptions;
    get windowsOptions(): DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference;
    putWindowsOptions(value: DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions): void;
    resetWindowsOptions(): void;
    get windowsOptionsInput(): DaemonSetV1SpecTemplateSpecSecurityContextWindowsOptions | undefined;
}
export interface DaemonSetV1SpecTemplateSpecToleration {
    /**
    * Effect indicates the taint effect to match. Empty means match all taint effects. When specified, allowed values are NoSchedule, PreferNoSchedule and NoExecute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#effect DaemonSetV1#effect}
    */
    readonly effect?: string;
    /**
    * Key is the taint key that the toleration applies to. Empty means match all taint keys. If the key is empty, operator must be Exists; this combination means to match all values and all keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * Operator represents a key's relationship to the value. Valid operators are Exists and Equal. Defaults to Equal. Exists is equivalent to wildcard for value, so that a pod can tolerate all taints of a particular category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#operator DaemonSetV1#operator}
    */
    readonly operator?: string;
    /**
    * TolerationSeconds represents the period of time the toleration (which must be of effect NoExecute, otherwise this field is ignored) tolerates the taint. By default, it is not set, which means tolerate the taint forever (do not evict). Zero and negative values will be treated as 0 (evict immediately) by the system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#toleration_seconds DaemonSetV1#toleration_seconds}
    */
    readonly tolerationSeconds?: string;
    /**
    * Value is the taint value the toleration matches to. If the operator is Exists, the value should be empty, otherwise just a regular string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#value DaemonSetV1#value}
    */
    readonly value?: string;
}
export declare function daemonSetV1SpecTemplateSpecTolerationToTerraform(struct?: DaemonSetV1SpecTemplateSpecToleration | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecTolerationToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecToleration | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecTolerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecToleration | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecToleration | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    resetEffect(): void;
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _tolerationSeconds?;
    get tolerationSeconds(): string;
    set tolerationSeconds(value: string);
    resetTolerationSeconds(): void;
    get tolerationSecondsInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecTolerationList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecToleration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecTolerationOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#operator DaemonSetV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#values DaemonSetV1#values}
    */
    readonly values?: string[];
}
export declare function daemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsToTerraform(struct?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#match_labels DaemonSetV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#match_expressions DaemonSetV1#match_expressions}
    */
    readonly matchExpressions?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorToTerraform(struct?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsList;
    putMatchExpressions(value: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecTopologySpreadConstraint {
    /**
    * is a set of pod label keys to select the pods over which spreading will be calculated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#match_label_keys DaemonSetV1#match_label_keys}
    */
    readonly matchLabelKeys?: string[];
    /**
    * describes the degree to which pods may be unevenly distributed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#max_skew DaemonSetV1#max_skew}
    */
    readonly maxSkew?: number;
    /**
    * indicates a minimum number of eligible domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#min_domains DaemonSetV1#min_domains}
    */
    readonly minDomains?: number;
    /**
    * indicates how we will treat Pod's nodeAffinity/nodeSelector when calculating pod topology spread skew.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#node_affinity_policy DaemonSetV1#node_affinity_policy}
    */
    readonly nodeAffinityPolicy?: string;
    /**
    * indicates how we will treat node taints when calculating pod topology spread skew.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#node_taints_policy DaemonSetV1#node_taints_policy}
    */
    readonly nodeTaintsPolicy?: string;
    /**
    * the key of node labels. Nodes that have a label with this key and identical values are considered to be in the same topology.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#topology_key DaemonSetV1#topology_key}
    */
    readonly topologyKey?: string;
    /**
    * indicates how to deal with a pod if it doesn't satisfy the spread constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#when_unsatisfiable DaemonSetV1#when_unsatisfiable}
    */
    readonly whenUnsatisfiable?: string;
    /**
    * label_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#label_selector DaemonSetV1#label_selector}
    */
    readonly labelSelector?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecTopologySpreadConstraintToTerraform(struct?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecTopologySpreadConstraintToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecTopologySpreadConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable | undefined);
    private _matchLabelKeys?;
    get matchLabelKeys(): string[];
    set matchLabelKeys(value: string[]);
    resetMatchLabelKeys(): void;
    get matchLabelKeysInput(): string[] | undefined;
    private _maxSkew?;
    get maxSkew(): number;
    set maxSkew(value: number);
    resetMaxSkew(): void;
    get maxSkewInput(): number | undefined;
    private _minDomains?;
    get minDomains(): number;
    set minDomains(value: number);
    resetMinDomains(): void;
    get minDomainsInput(): number | undefined;
    private _nodeAffinityPolicy?;
    get nodeAffinityPolicy(): string;
    set nodeAffinityPolicy(value: string);
    resetNodeAffinityPolicy(): void;
    get nodeAffinityPolicyInput(): string | undefined;
    private _nodeTaintsPolicy?;
    get nodeTaintsPolicy(): string;
    set nodeTaintsPolicy(value: string);
    resetNodeTaintsPolicy(): void;
    get nodeTaintsPolicyInput(): string | undefined;
    private _topologyKey?;
    get topologyKey(): string;
    set topologyKey(value: string);
    resetTopologyKey(): void;
    get topologyKeyInput(): string | undefined;
    private _whenUnsatisfiable?;
    get whenUnsatisfiable(): string;
    set whenUnsatisfiable(value: string);
    resetWhenUnsatisfiable(): void;
    get whenUnsatisfiableInput(): string | undefined;
    private _labelSelector;
    get labelSelector(): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorList;
    putLabelSelector(value: DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | cdktn.IResolvable): void;
    resetLabelSelector(): void;
    get labelSelectorInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecTopologySpreadConstraintList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#partition DaemonSetV1#partition}
    */
    readonly partition?: number;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Unique ID of the persistent disk resource in AWS (Amazon EBS volume). More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_id DaemonSetV1#volume_id}
    */
    readonly volumeId: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStoreToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference | DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore): any;
export declare function daemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStoreToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference | DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeAzureDisk {
    /**
    * Host Caching mode: None, Read Only, Read Write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#caching_mode DaemonSetV1#caching_mode}
    */
    readonly cachingMode: string;
    /**
    * The URI the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#data_disk_uri DaemonSetV1#data_disk_uri}
    */
    readonly dataDiskUri: string;
    /**
    * The Name of the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#disk_name DaemonSetV1#disk_name}
    */
    readonly diskName: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The type for the data disk. Expected values: Shared, Dedicated, Managed. Defaults to Shared
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#kind DaemonSetV1#kind}
    */
    readonly kind?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeAzureDiskToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeAzureDiskOutputReference | DaemonSetV1SpecTemplateSpecVolumeAzureDisk): any;
export declare function daemonSetV1SpecTemplateSpecVolumeAzureDiskToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeAzureDiskOutputReference | DaemonSetV1SpecTemplateSpecVolumeAzureDisk): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeAzureDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeAzureDisk | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeAzureDisk | undefined);
    private _cachingMode?;
    get cachingMode(): string;
    set cachingMode(value: string);
    get cachingModeInput(): string | undefined;
    private _dataDiskUri?;
    get dataDiskUri(): string;
    set dataDiskUri(value: string);
    get dataDiskUriInput(): string | undefined;
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    get diskNameInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeAzureFile {
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The name of secret that contains Azure Storage Account Name and Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_name DaemonSetV1#secret_name}
    */
    readonly secretName: string;
    /**
    * The namespace of the secret that contains Azure Storage Account Name and Key. For Kubernetes up to 1.18.x the default is the same as the Pod. For Kubernetes 1.19.x and later the default is "default" namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_namespace DaemonSetV1#secret_namespace}
    */
    readonly secretNamespace?: string;
    /**
    * Share Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#share_name DaemonSetV1#share_name}
    */
    readonly shareName: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeAzureFileToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeAzureFileOutputReference | DaemonSetV1SpecTemplateSpecVolumeAzureFile): any;
export declare function daemonSetV1SpecTemplateSpecVolumeAzureFileToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeAzureFileOutputReference | DaemonSetV1SpecTemplateSpecVolumeAzureFile): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeAzureFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeAzureFile | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeAzureFile | undefined);
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _secretNamespace?;
    get secretNamespace(): string;
    set secretNamespace(value: string);
    resetSecretNamespace(): void;
    get secretNamespaceInput(): string | undefined;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    get shareNameInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#namespace DaemonSetV1#namespace}
    */
    readonly namespace?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeCephFsSecretRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeCephFsSecretRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeCephFs {
    /**
    * Monitors is a collection of Ceph monitors. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#monitors DaemonSetV1#monitors}
    */
    readonly monitors: string[];
    /**
    * Used as the mounted root, rather than the full Ceph tree, default is /
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to `false` (read/write). More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The path to key ring for User, default is `/etc/ceph/user.secret`. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_file DaemonSetV1#secret_file}
    */
    readonly secretFile?: string;
    /**
    * User is the rados user name, default is admin. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#user DaemonSetV1#user}
    */
    readonly user?: string;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_ref DaemonSetV1#secret_ref}
    */
    readonly secretRef?: DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef;
}
export declare function daemonSetV1SpecTemplateSpecVolumeCephFsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCephFsOutputReference | DaemonSetV1SpecTemplateSpecVolumeCephFs): any;
export declare function daemonSetV1SpecTemplateSpecVolumeCephFsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCephFsOutputReference | DaemonSetV1SpecTemplateSpecVolumeCephFs): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeCephFsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeCephFs | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeCephFs | undefined);
    private _monitors?;
    get monitors(): string[];
    set monitors(value: string[]);
    get monitorsInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretFile?;
    get secretFile(): string;
    set secretFile(value: string);
    resetSecretFile(): void;
    get secretFileInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _secretRef;
    get secretRef(): DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference;
    putSecretRef(value: DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): DaemonSetV1SpecTemplateSpecVolumeCephFsSecretRef | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeCinder {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write). More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Volume ID used to identify the volume in Cinder. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_id DaemonSetV1#volume_id}
    */
    readonly volumeId: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeCinderToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCinderOutputReference | DaemonSetV1SpecTemplateSpecVolumeCinder): any;
export declare function daemonSetV1SpecTemplateSpecVolumeCinderToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCinderOutputReference | DaemonSetV1SpecTemplateSpecVolumeCinder): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeCinderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeCinder | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeCinder | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeConfigMapItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mode DaemonSetV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeConfigMapItemsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeConfigMapItemsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeConfigMapItemsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeConfigMapItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeConfigMapItemsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeConfigMap {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#default_mode DaemonSetV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Optional: Specify whether the ConfigMap or its keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#optional DaemonSetV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#items DaemonSetV1#items}
    */
    readonly items?: DaemonSetV1SpecTemplateSpecVolumeConfigMapItems[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeConfigMapToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeConfigMapOutputReference | DaemonSetV1SpecTemplateSpecVolumeConfigMap): any;
export declare function daemonSetV1SpecTemplateSpecVolumeConfigMapToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeConfigMapOutputReference | DaemonSetV1SpecTemplateSpecVolumeConfigMap): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeConfigMap | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeConfigMap | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): DaemonSetV1SpecTemplateSpecVolumeConfigMapItemsList;
    putItems(value: DaemonSetV1SpecTemplateSpecVolumeConfigMapItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeConfigMapItems[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeCsi {
    /**
    * the name of the volume driver to use. More info: https://kubernetes.io/docs/concepts/storage/volumes/#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#driver DaemonSetV1#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Attributes of the volume to publish.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_attributes DaemonSetV1#volume_attributes}
    */
    readonly volumeAttributes?: {
        [key: string]: string;
    };
    /**
    * node_publish_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#node_publish_secret_ref DaemonSetV1#node_publish_secret_ref}
    */
    readonly nodePublishSecretRef?: DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef;
}
export declare function daemonSetV1SpecTemplateSpecVolumeCsiToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCsiOutputReference | DaemonSetV1SpecTemplateSpecVolumeCsi): any;
export declare function daemonSetV1SpecTemplateSpecVolumeCsiToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeCsiOutputReference | DaemonSetV1SpecTemplateSpecVolumeCsi): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeCsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeCsi | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeCsi | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeAttributes?;
    get volumeAttributes(): {
        [key: string]: string;
    };
    set volumeAttributes(value: {
        [key: string]: string;
    });
    resetVolumeAttributes(): void;
    get volumeAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference;
    putNodePublishSecretRef(value: DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef): void;
    resetNodePublishSecretRef(): void;
    get nodePublishSecretRefInput(): DaemonSetV1SpecTemplateSpecVolumeCsiNodePublishSecretRef | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef {
    /**
    * Version of the schema the FieldPath is written in terms of, defaults to "v1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#api_version DaemonSetV1#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Path of the field to select in the specified API version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#field_path DaemonSetV1#field_path}
    */
    readonly fieldPath?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#container_name DaemonSetV1#container_name}
    */
    readonly containerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#divisor DaemonSetV1#divisor}
    */
    readonly divisor?: string;
    /**
    * Resource to select
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#resource DaemonSetV1#resource}
    */
    readonly resource: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef | undefined);
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    get containerNameInput(): string | undefined;
    private _divisor?;
    get divisor(): string;
    set divisor(value: string);
    resetDivisor(): void;
    get divisorInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems {
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mode DaemonSetV1#mode}
    */
    readonly mode?: string;
    /**
    * Path is the relative path name of the file to be created. Must not be absolute or contain the '..' path. Must be utf-8 encoded. The first item of the relative path must not start with '..'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path: string;
    /**
    * field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#field_ref DaemonSetV1#field_ref}
    */
    readonly fieldRef: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef;
    /**
    * resource_field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#resource_field_ref DaemonSetV1#resource_field_ref}
    */
    readonly resourceFieldRef?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef;
}
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiItemsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiItemsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _fieldRef;
    get fieldRef(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference;
    putFieldRef(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef): void;
    get fieldRefInput(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef | undefined;
    private _resourceFieldRef;
    get resourceFieldRef(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference;
    putResourceFieldRef(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef): void;
    resetResourceFieldRef(): void;
    get resourceFieldRefInput(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeDownwardApi {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#default_mode DaemonSetV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#items DaemonSetV1#items}
    */
    readonly items?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiOutputReference | DaemonSetV1SpecTemplateSpecVolumeDownwardApi): any;
export declare function daemonSetV1SpecTemplateSpecVolumeDownwardApiToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeDownwardApiOutputReference | DaemonSetV1SpecTemplateSpecVolumeDownwardApi): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeDownwardApi | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApi | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _items;
    get items(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiItemsList;
    putItems(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeDownwardApiItems[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEmptyDir {
    /**
    * What type of storage medium should back this directory. The default is "" which means to use the node's default medium. Must be one of ["" "Memory" "HugePages" "HugePages-2Mi" "HugePages-1Gi"]. More info: https://kubernetes.io/docs/concepts/storage/volumes#emptydir
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#medium DaemonSetV1#medium}
    */
    readonly medium?: string;
    /**
    * Total amount of local storage required for this EmptyDir volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#size_limit DaemonSetV1#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeEmptyDirToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEmptyDirOutputReference | DaemonSetV1SpecTemplateSpecVolumeEmptyDir): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEmptyDirToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEmptyDirOutputReference | DaemonSetV1SpecTemplateSpecVolumeEmptyDir): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEmptyDir | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEmptyDir | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata {
    /**
    * An unstructured key value map stored with the persistent volume claim that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#annotations DaemonSetV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the persistent volume claim. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#labels DaemonSetV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources {
    /**
    * Map describing the maximum amount of compute resources allowed. More info: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#limits DaemonSetV1#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Map describing the minimum amount of compute resources required. If this is omitted for a container, it defaults to `limits` if that is explicitly specified, otherwise to an implementation-defined value. More info: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#requests DaemonSetV1#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#operator DaemonSetV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#values DaemonSetV1#values}
    */
    readonly values?: string[];
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#match_labels DaemonSetV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#match_expressions DaemonSetV1#match_expressions}
    */
    readonly matchExpressions?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList;
    putMatchExpressions(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec {
    /**
    * A set of the desired access modes the volume should have. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#access-modes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#access_modes DaemonSetV1#access_modes}
    */
    readonly accessModes: string[];
    /**
    * Name of the storage class requested by the claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#storage_class_name DaemonSetV1#storage_class_name}
    */
    readonly storageClassName?: string;
    /**
    * Defines what type of volume is required by the claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_mode DaemonSetV1#volume_mode}
    */
    readonly volumeMode?: string;
    /**
    * The binding reference to the PersistentVolume backing this claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_name DaemonSetV1#volume_name}
    */
    readonly volumeName?: string;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#resources DaemonSetV1#resources}
    */
    readonly resources: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#selector DaemonSetV1#selector}
    */
    readonly selector?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector;
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined);
    private _accessModes?;
    get accessModes(): string[];
    set accessModes(value: string[]);
    get accessModesInput(): string[] | undefined;
    private _storageClassName?;
    get storageClassName(): string;
    set storageClassName(value: string);
    resetStorageClassName(): void;
    get storageClassNameInput(): string | undefined;
    private _volumeMode?;
    get volumeMode(): string;
    set volumeMode(value: string);
    resetVolumeMode(): void;
    get volumeModeInput(): string | undefined;
    private _volumeName?;
    get volumeName(): string;
    set volumeName(value: string);
    resetVolumeName(): void;
    get volumeNameInput(): string | undefined;
    private _resources;
    get resources(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference;
    putResources(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources): void;
    get resourcesInput(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined;
    private _selector;
    get selector(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference;
    putSelector(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): void;
    resetSelector(): void;
    get selectorInput(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate {
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#metadata DaemonSetV1#metadata}
    */
    readonly metadata?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#spec DaemonSetV1#spec}
    */
    readonly spec: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec;
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate | undefined);
    private _metadata;
    get metadata(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference;
    putMetadata(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata): void;
    resetMetadata(): void;
    get metadataInput(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined;
    private _spec;
    get spec(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference;
    putSpec(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec): void;
    get specInput(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeEphemeral {
    /**
    * volume_claim_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_claim_template DaemonSetV1#volume_claim_template}
    */
    readonly volumeClaimTemplate: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate;
}
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeral): any;
export declare function daemonSetV1SpecTemplateSpecVolumeEphemeralToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeEphemeralOutputReference | DaemonSetV1SpecTemplateSpecVolumeEphemeral): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeEphemeralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeEphemeral | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeEphemeral | undefined);
    private _volumeClaimTemplate;
    get volumeClaimTemplate(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference;
    putVolumeClaimTemplate(value: DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate): void;
    get volumeClaimTemplateInput(): DaemonSetV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeFc {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * FC target lun number
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#lun DaemonSetV1#lun}
    */
    readonly lun: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * FC target worldwide names (WWNs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#target_ww_ns DaemonSetV1#target_ww_ns}
    */
    readonly targetWwNs: string[];
}
export declare function daemonSetV1SpecTemplateSpecVolumeFcToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFcOutputReference | DaemonSetV1SpecTemplateSpecVolumeFc): any;
export declare function daemonSetV1SpecTemplateSpecVolumeFcToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFcOutputReference | DaemonSetV1SpecTemplateSpecVolumeFc): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeFcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeFc | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeFc | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetWwNs?;
    get targetWwNs(): string[];
    set targetWwNs(value: string[]);
    get targetWwNsInput(): string[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#namespace DaemonSetV1#namespace}
    */
    readonly namespace?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeFlexVolume {
    /**
    * Driver is the name of the driver to use for this volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#driver DaemonSetV1#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". The default filesystem depends on FlexVolume script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Extra command options if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#options DaemonSetV1#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_ref DaemonSetV1#secret_ref}
    */
    readonly secretRef?: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef;
}
export declare function daemonSetV1SpecTemplateSpecVolumeFlexVolumeToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeOutputReference | DaemonSetV1SpecTemplateSpecVolumeFlexVolume): any;
export declare function daemonSetV1SpecTemplateSpecVolumeFlexVolumeToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeOutputReference | DaemonSetV1SpecTemplateSpecVolumeFlexVolume): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeFlexVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeFlexVolume | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeFlexVolume | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference;
    putSecretRef(value: DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): DaemonSetV1SpecTemplateSpecVolumeFlexVolumeSecretRef | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeFlocker {
    /**
    * Name of the dataset stored as metadata -> name on the dataset for Flocker should be considered as deprecated
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#dataset_name DaemonSetV1#dataset_name}
    */
    readonly datasetName?: string;
    /**
    * UUID of the dataset. This is unique identifier of a Flocker dataset
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#dataset_uuid DaemonSetV1#dataset_uuid}
    */
    readonly datasetUuid?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeFlockerToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFlockerOutputReference | DaemonSetV1SpecTemplateSpecVolumeFlocker): any;
export declare function daemonSetV1SpecTemplateSpecVolumeFlockerToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeFlockerOutputReference | DaemonSetV1SpecTemplateSpecVolumeFlocker): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeFlockerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeFlocker | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeFlocker | undefined);
    private _datasetName?;
    get datasetName(): string;
    set datasetName(value: string);
    resetDatasetName(): void;
    get datasetNameInput(): string | undefined;
    private _datasetUuid?;
    get datasetUuid(): string;
    set datasetUuid(value: string);
    resetDatasetUuid(): void;
    get datasetUuidInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty). More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#partition DaemonSetV1#partition}
    */
    readonly partition?: number;
    /**
    * Unique name of the PD resource in GCE. Used to identify the disk in GCE. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#pd_name DaemonSetV1#pd_name}
    */
    readonly pdName: string;
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeGcePersistentDiskToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference | DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk): any;
export declare function daemonSetV1SpecTemplateSpecVolumeGcePersistentDiskToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference | DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _pdName?;
    get pdName(): string;
    set pdName(value: string);
    get pdNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeGitRepo {
    /**
    * Target directory name. Must not contain or start with '..'. If '.' is supplied, the volume directory will be the git repository. Otherwise, if specified, the volume will contain the git repository in the subdirectory with the given name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#directory DaemonSetV1#directory}
    */
    readonly directory?: string;
    /**
    * Repository URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#repository DaemonSetV1#repository}
    */
    readonly repository?: string;
    /**
    * Commit hash for the specified revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#revision DaemonSetV1#revision}
    */
    readonly revision?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeGitRepoToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeGitRepoOutputReference | DaemonSetV1SpecTemplateSpecVolumeGitRepo): any;
export declare function daemonSetV1SpecTemplateSpecVolumeGitRepoToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeGitRepoOutputReference | DaemonSetV1SpecTemplateSpecVolumeGitRepo): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeGitRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeGitRepo | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeGitRepo | undefined);
    private _directory?;
    get directory(): string;
    set directory(value: string);
    resetDirectory(): void;
    get directoryInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeGlusterfs {
    /**
    * The endpoint name that details Glusterfs topology. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#endpoints_name DaemonSetV1#endpoints_name}
    */
    readonly endpointsName: string;
    /**
    * The Glusterfs volume path. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path: string;
    /**
    * Whether to force the Glusterfs volume to be mounted with read-only permissions. Defaults to false. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeGlusterfsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeGlusterfsOutputReference | DaemonSetV1SpecTemplateSpecVolumeGlusterfs): any;
export declare function daemonSetV1SpecTemplateSpecVolumeGlusterfsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeGlusterfsOutputReference | DaemonSetV1SpecTemplateSpecVolumeGlusterfs): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeGlusterfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeGlusterfs | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeGlusterfs | undefined);
    private _endpointsName?;
    get endpointsName(): string;
    set endpointsName(value: string);
    get endpointsNameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeHostPath {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#hostpath
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
    /**
    * Type for HostPath volume. Allowed values are "" (default), DirectoryOrCreate, Directory, FileOrCreate, File, Socket, CharDevice and BlockDevice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#type DaemonSetV1#type}
    */
    readonly type?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeHostPathToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeHostPathOutputReference | DaemonSetV1SpecTemplateSpecVolumeHostPath): any;
export declare function daemonSetV1SpecTemplateSpecVolumeHostPathToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeHostPathOutputReference | DaemonSetV1SpecTemplateSpecVolumeHostPath): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeHostPath | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeHostPath | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeIscsi {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#iscsi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Target iSCSI Qualified Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#iqn DaemonSetV1#iqn}
    */
    readonly iqn: string;
    /**
    * iSCSI interface name that uses an iSCSI transport. Defaults to 'default' (tcp).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#iscsi_interface DaemonSetV1#iscsi_interface}
    */
    readonly iscsiInterface?: string;
    /**
    * iSCSI target lun number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#lun DaemonSetV1#lun}
    */
    readonly lun?: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * iSCSI target portal. The portal is either an IP or ip_addr:port if the port is other than default (typically TCP ports 860 and 3260).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#target_portal DaemonSetV1#target_portal}
    */
    readonly targetPortal: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeIscsiToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeIscsiOutputReference | DaemonSetV1SpecTemplateSpecVolumeIscsi): any;
export declare function daemonSetV1SpecTemplateSpecVolumeIscsiToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeIscsiOutputReference | DaemonSetV1SpecTemplateSpecVolumeIscsi): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeIscsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeIscsi | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeIscsi | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _iqn?;
    get iqn(): string;
    set iqn(value: string);
    get iqnInput(): string | undefined;
    private _iscsiInterface?;
    get iscsiInterface(): string;
    set iscsiInterface(value: string);
    resetIscsiInterface(): void;
    get iscsiInterfaceInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    resetLun(): void;
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetPortal?;
    get targetPortal(): string;
    set targetPortal(value: string);
    get targetPortalInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeLocal {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#local
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeLocalToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeLocalOutputReference | DaemonSetV1SpecTemplateSpecVolumeLocal): any;
export declare function daemonSetV1SpecTemplateSpecVolumeLocalToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeLocalOutputReference | DaemonSetV1SpecTemplateSpecVolumeLocal): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeLocalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeLocal | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeLocal | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeNfs {
    /**
    * Path that is exported by the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path: string;
    /**
    * Whether to force the NFS export to be mounted with read-only permissions. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Server is the hostname or IP address of the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#server DaemonSetV1#server}
    */
    readonly server: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeNfsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeNfsOutputReference | DaemonSetV1SpecTemplateSpecVolumeNfs): any;
export declare function daemonSetV1SpecTemplateSpecVolumeNfsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeNfsOutputReference | DaemonSetV1SpecTemplateSpecVolumeNfs): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeNfs | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim {
    /**
    * ClaimName is the name of a PersistentVolumeClaim in the same
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#claim_name DaemonSetV1#claim_name}
    */
    readonly claimName?: string;
    /**
    * Will force the ReadOnly setting in VolumeMounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumePersistentVolumeClaimToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference | DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim): any;
export declare function daemonSetV1SpecTemplateSpecVolumePersistentVolumeClaimToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference | DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim): any;
export declare class DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim | undefined);
    private _claimName?;
    get claimName(): string;
    set claimName(value: string);
    resetClaimName(): void;
    get claimNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * ID that identifies Photon Controller persistent disk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#pd_id DaemonSetV1#pd_id}
    */
    readonly pdId: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumePhotonPersistentDiskToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference | DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk): any;
export declare function daemonSetV1SpecTemplateSpecVolumePhotonPersistentDiskToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference | DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk): any;
export declare class DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _pdId?;
    get pdId(): string;
    set pdId(value: string);
    get pdIdInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mode DaemonSetV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Optional: Specify whether the ConfigMap or it's keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#optional DaemonSetV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#items DaemonSetV1#items}
    */
    readonly items?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsList;
    putItems(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef {
    /**
    * Version of the schema the FieldPath is written in terms of, defaults to 'v1'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#api_version DaemonSetV1#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Path of the field to select in the specified API version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#field_path DaemonSetV1#field_path}
    */
    readonly fieldPath?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#container_name DaemonSetV1#container_name}
    */
    readonly containerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#divisor DaemonSetV1#divisor}
    */
    readonly divisor?: string;
    /**
    * Resource to select
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#resource DaemonSetV1#resource}
    */
    readonly resource: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined);
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    get containerNameInput(): string | undefined;
    private _divisor?;
    get divisor(): string;
    set divisor(value: string);
    resetDivisor(): void;
    get divisorInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems {
    /**
    * Mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mode DaemonSetV1#mode}
    */
    readonly mode?: string;
    /**
    * Path is the relative path name of the file to be created. Must not be absolute or contain the '..' path. Must be utf-8 encoded. The first item of the relative path must not start with '..'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path: string;
    /**
    * field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#field_ref DaemonSetV1#field_ref}
    */
    readonly fieldRef?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef;
    /**
    * resource_field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#resource_field_ref DaemonSetV1#resource_field_ref}
    */
    readonly resourceFieldRef?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _fieldRef;
    get fieldRef(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference;
    putFieldRef(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): void;
    resetFieldRef(): void;
    get fieldRefInput(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    private _resourceFieldRef;
    get resourceFieldRef(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference;
    putResourceFieldRef(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): void;
    resetResourceFieldRef(): void;
    get resourceFieldRefInput(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi {
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#items DaemonSetV1#items}
    */
    readonly items?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi | undefined);
    private _items;
    get items(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsList;
    putItems(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mode DaemonSetV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret {
    /**
    * Name of the secret in the pod's namespace to use. More info: https://kubernetes.io/docs/concepts/storage/volumes#secrets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Optional: Specify whether the Secret or it's keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#optional DaemonSetV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#items DaemonSetV1#items}
    */
    readonly items?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsList;
    putItems(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken {
    /**
    * Audience is the intended audience of the token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#audience DaemonSetV1#audience}
    */
    readonly audience?: string;
    /**
    * ExpirationSeconds is the expected duration of validity of the service account token. It defaults to 1 hour and must be at least 10 minutes (600 seconds).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#expiration_seconds DaemonSetV1#expiration_seconds}
    */
    readonly expirationSeconds?: number;
    /**
    * Path specifies a relative path to the mount point of the projected volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _expirationSeconds?;
    get expirationSeconds(): number;
    set expirationSeconds(value: number);
    resetExpirationSeconds(): void;
    get expirationSecondsInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjectedSources {
    /**
    * config_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#config_map DaemonSetV1#config_map}
    */
    readonly configMap?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | cdktn.IResolvable;
    /**
    * downward_api block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#downward_api DaemonSetV1#downward_api}
    */
    readonly downwardApi?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret DaemonSetV1#secret}
    */
    readonly secret?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | cdktn.IResolvable;
    /**
    * service_account_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#service_account_token DaemonSetV1#service_account_token}
    */
    readonly serviceAccountToken?: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedSourcesToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable | undefined);
    private _configMap;
    get configMap(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMapList;
    putConfigMap(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | cdktn.IResolvable): void;
    resetConfigMap(): void;
    get configMapInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | undefined;
    private _downwardApi;
    get downwardApi(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference;
    putDownwardApi(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi): void;
    resetDownwardApi(): void;
    get downwardApiInput(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi | undefined;
    private _secret;
    get secret(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecretList;
    putSecret(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | undefined;
    private _serviceAccountToken;
    get serviceAccountToken(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference;
    putServiceAccountToken(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken): void;
    resetServiceAccountToken(): void;
    get serviceAccountTokenInput(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjectedSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeProjected {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#default_mode DaemonSetV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#sources DaemonSetV1#sources}
    */
    readonly sources: DaemonSetV1SpecTemplateSpecVolumeProjectedSources[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeProjectedToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _sources;
    get sources(): DaemonSetV1SpecTemplateSpecVolumeProjectedSourcesList;
    putSources(value: DaemonSetV1SpecTemplateSpecVolumeProjectedSources[] | cdktn.IResolvable): void;
    get sourcesInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjectedSources[] | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeProjectedList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeProjected[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeProjectedOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeQuobyte {
    /**
    * Group to map volume access to Default is no group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#group DaemonSetV1#group}
    */
    readonly group?: string;
    /**
    * Whether to force the Quobyte volume to be mounted with read-only permissions. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Registry represents a single or multiple Quobyte Registry services specified as a string as host:port pair (multiple entries are separated with commas) which acts as the central registry for volumes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#registry DaemonSetV1#registry}
    */
    readonly registry: string;
    /**
    * User to map volume access to Defaults to serivceaccount user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#user DaemonSetV1#user}
    */
    readonly user?: string;
    /**
    * Volume is a string that references an already created Quobyte volume by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume DaemonSetV1#volume}
    */
    readonly volume: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeQuobyteToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeQuobyteOutputReference | DaemonSetV1SpecTemplateSpecVolumeQuobyte): any;
export declare function daemonSetV1SpecTemplateSpecVolumeQuobyteToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeQuobyteOutputReference | DaemonSetV1SpecTemplateSpecVolumeQuobyte): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeQuobyteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeQuobyte | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeQuobyte | undefined);
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    get registryInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _volume?;
    get volume(): string;
    set volume(value: string);
    get volumeInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#namespace DaemonSetV1#namespace}
    */
    readonly namespace?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeRbdSecretRefToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeRbdSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef): any;
export declare function daemonSetV1SpecTemplateSpecVolumeRbdSecretRefToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeRbdSecretRefOutputReference | DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeRbdSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeRbd {
    /**
    * A collection of Ceph monitors. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#ceph_monitors DaemonSetV1#ceph_monitors}
    */
    readonly cephMonitors: string[];
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#rbd
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Keyring is the path to key ring for RBDUser. Default is /etc/ceph/keyring. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#keyring DaemonSetV1#keyring}
    */
    readonly keyring?: string;
    /**
    * The rados user name. Default is admin. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#rados_user DaemonSetV1#rados_user}
    */
    readonly radosUser?: string;
    /**
    * The rados image name. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#rbd_image DaemonSetV1#rbd_image}
    */
    readonly rbdImage: string;
    /**
    * The rados pool name. Default is rbd. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#rbd_pool DaemonSetV1#rbd_pool}
    */
    readonly rbdPool?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#read_only DaemonSetV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_ref DaemonSetV1#secret_ref}
    */
    readonly secretRef?: DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef;
}
export declare function daemonSetV1SpecTemplateSpecVolumeRbdToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeRbdOutputReference | DaemonSetV1SpecTemplateSpecVolumeRbd): any;
export declare function daemonSetV1SpecTemplateSpecVolumeRbdToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeRbdOutputReference | DaemonSetV1SpecTemplateSpecVolumeRbd): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeRbdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeRbd | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeRbd | undefined);
    private _cephMonitors?;
    get cephMonitors(): string[];
    set cephMonitors(value: string[]);
    get cephMonitorsInput(): string[] | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _keyring?;
    get keyring(): string;
    set keyring(value: string);
    resetKeyring(): void;
    get keyringInput(): string | undefined;
    private _radosUser?;
    get radosUser(): string;
    set radosUser(value: string);
    resetRadosUser(): void;
    get radosUserInput(): string | undefined;
    private _rbdImage?;
    get rbdImage(): string;
    set rbdImage(value: string);
    get rbdImageInput(): string | undefined;
    private _rbdPool?;
    get rbdPool(): string;
    set rbdPool(value: string);
    resetRbdPool(): void;
    get rbdPoolInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): DaemonSetV1SpecTemplateSpecVolumeRbdSecretRefOutputReference;
    putSecretRef(value: DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): DaemonSetV1SpecTemplateSpecVolumeRbdSecretRef | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeSecretItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#key DaemonSetV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#mode DaemonSetV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#path DaemonSetV1#path}
    */
    readonly path?: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeSecretItemsToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeSecretItemsToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeSecretItemsList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolumeSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeSecretItemsOutputReference;
}
export interface DaemonSetV1SpecTemplateSpecVolumeSecret {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#default_mode DaemonSetV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * Optional: Specify whether the Secret or its keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#optional DaemonSetV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * Name of the secret in the pod's namespace to use. More info: https://kubernetes.io/docs/concepts/storage/volumes#secrets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret_name DaemonSetV1#secret_name}
    */
    readonly secretName?: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#items DaemonSetV1#items}
    */
    readonly items?: DaemonSetV1SpecTemplateSpecVolumeSecretItems[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecVolumeSecretToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeSecretOutputReference | DaemonSetV1SpecTemplateSpecVolumeSecret): any;
export declare function daemonSetV1SpecTemplateSpecVolumeSecretToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeSecretOutputReference | DaemonSetV1SpecTemplateSpecVolumeSecret): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeSecret | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeSecret | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
    private _items;
    get items(): DaemonSetV1SpecTemplateSpecVolumeSecretItemsList;
    putItems(value: DaemonSetV1SpecTemplateSpecVolumeSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeSecretItems[] | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolumeVsphereVolume {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fs_type DaemonSetV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Path that identifies vSphere volume vmdk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume_path DaemonSetV1#volume_path}
    */
    readonly volumePath: string;
}
export declare function daemonSetV1SpecTemplateSpecVolumeVsphereVolumeToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeVsphereVolumeOutputReference | DaemonSetV1SpecTemplateSpecVolumeVsphereVolume): any;
export declare function daemonSetV1SpecTemplateSpecVolumeVsphereVolumeToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolumeVsphereVolumeOutputReference | DaemonSetV1SpecTemplateSpecVolumeVsphereVolume): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeVsphereVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolumeVsphereVolume | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolumeVsphereVolume | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _volumePath?;
    get volumePath(): string;
    set volumePath(value: string);
    get volumePathInput(): string | undefined;
}
export interface DaemonSetV1SpecTemplateSpecVolume {
    /**
    * Volume's name. Must be a DNS_LABEL and unique within the pod. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#name DaemonSetV1#name}
    */
    readonly name?: string;
    /**
    * aws_elastic_block_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#aws_elastic_block_store DaemonSetV1#aws_elastic_block_store}
    */
    readonly awsElasticBlockStore?: DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore;
    /**
    * azure_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#azure_disk DaemonSetV1#azure_disk}
    */
    readonly azureDisk?: DaemonSetV1SpecTemplateSpecVolumeAzureDisk;
    /**
    * azure_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#azure_file DaemonSetV1#azure_file}
    */
    readonly azureFile?: DaemonSetV1SpecTemplateSpecVolumeAzureFile;
    /**
    * ceph_fs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#ceph_fs DaemonSetV1#ceph_fs}
    */
    readonly cephFs?: DaemonSetV1SpecTemplateSpecVolumeCephFs;
    /**
    * cinder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#cinder DaemonSetV1#cinder}
    */
    readonly cinder?: DaemonSetV1SpecTemplateSpecVolumeCinder;
    /**
    * config_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#config_map DaemonSetV1#config_map}
    */
    readonly configMap?: DaemonSetV1SpecTemplateSpecVolumeConfigMap;
    /**
    * csi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#csi DaemonSetV1#csi}
    */
    readonly csi?: DaemonSetV1SpecTemplateSpecVolumeCsi;
    /**
    * downward_api block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#downward_api DaemonSetV1#downward_api}
    */
    readonly downwardApi?: DaemonSetV1SpecTemplateSpecVolumeDownwardApi;
    /**
    * empty_dir block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#empty_dir DaemonSetV1#empty_dir}
    */
    readonly emptyDir?: DaemonSetV1SpecTemplateSpecVolumeEmptyDir;
    /**
    * ephemeral block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#ephemeral DaemonSetV1#ephemeral}
    */
    readonly ephemeral?: DaemonSetV1SpecTemplateSpecVolumeEphemeral;
    /**
    * fc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#fc DaemonSetV1#fc}
    */
    readonly fc?: DaemonSetV1SpecTemplateSpecVolumeFc;
    /**
    * flex_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#flex_volume DaemonSetV1#flex_volume}
    */
    readonly flexVolume?: DaemonSetV1SpecTemplateSpecVolumeFlexVolume;
    /**
    * flocker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#flocker DaemonSetV1#flocker}
    */
    readonly flocker?: DaemonSetV1SpecTemplateSpecVolumeFlocker;
    /**
    * gce_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#gce_persistent_disk DaemonSetV1#gce_persistent_disk}
    */
    readonly gcePersistentDisk?: DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk;
    /**
    * git_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#git_repo DaemonSetV1#git_repo}
    */
    readonly gitRepo?: DaemonSetV1SpecTemplateSpecVolumeGitRepo;
    /**
    * glusterfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#glusterfs DaemonSetV1#glusterfs}
    */
    readonly glusterfs?: DaemonSetV1SpecTemplateSpecVolumeGlusterfs;
    /**
    * host_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_path DaemonSetV1#host_path}
    */
    readonly hostPath?: DaemonSetV1SpecTemplateSpecVolumeHostPath;
    /**
    * iscsi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#iscsi DaemonSetV1#iscsi}
    */
    readonly iscsi?: DaemonSetV1SpecTemplateSpecVolumeIscsi;
    /**
    * local block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#local DaemonSetV1#local}
    */
    readonly local?: DaemonSetV1SpecTemplateSpecVolumeLocal;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#nfs DaemonSetV1#nfs}
    */
    readonly nfs?: DaemonSetV1SpecTemplateSpecVolumeNfs;
    /**
    * persistent_volume_claim block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#persistent_volume_claim DaemonSetV1#persistent_volume_claim}
    */
    readonly persistentVolumeClaim?: DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim;
    /**
    * photon_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#photon_persistent_disk DaemonSetV1#photon_persistent_disk}
    */
    readonly photonPersistentDisk?: DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk;
    /**
    * projected block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#projected DaemonSetV1#projected}
    */
    readonly projected?: DaemonSetV1SpecTemplateSpecVolumeProjected[] | cdktn.IResolvable;
    /**
    * quobyte block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#quobyte DaemonSetV1#quobyte}
    */
    readonly quobyte?: DaemonSetV1SpecTemplateSpecVolumeQuobyte;
    /**
    * rbd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#rbd DaemonSetV1#rbd}
    */
    readonly rbd?: DaemonSetV1SpecTemplateSpecVolumeRbd;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#secret DaemonSetV1#secret}
    */
    readonly secret?: DaemonSetV1SpecTemplateSpecVolumeSecret;
    /**
    * vsphere_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#vsphere_volume DaemonSetV1#vsphere_volume}
    */
    readonly vsphereVolume?: DaemonSetV1SpecTemplateSpecVolumeVsphereVolume;
}
export declare function daemonSetV1SpecTemplateSpecVolumeToTerraform(struct?: DaemonSetV1SpecTemplateSpecVolume | cdktn.IResolvable): any;
export declare function daemonSetV1SpecTemplateSpecVolumeToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecVolume | cdktn.IResolvable): any;
export declare class DaemonSetV1SpecTemplateSpecVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DaemonSetV1SpecTemplateSpecVolume | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpecVolume | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference;
    putAwsElasticBlockStore(value: DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore): void;
    resetAwsElasticBlockStore(): void;
    get awsElasticBlockStoreInput(): DaemonSetV1SpecTemplateSpecVolumeAwsElasticBlockStore | undefined;
    private _azureDisk;
    get azureDisk(): DaemonSetV1SpecTemplateSpecVolumeAzureDiskOutputReference;
    putAzureDisk(value: DaemonSetV1SpecTemplateSpecVolumeAzureDisk): void;
    resetAzureDisk(): void;
    get azureDiskInput(): DaemonSetV1SpecTemplateSpecVolumeAzureDisk | undefined;
    private _azureFile;
    get azureFile(): DaemonSetV1SpecTemplateSpecVolumeAzureFileOutputReference;
    putAzureFile(value: DaemonSetV1SpecTemplateSpecVolumeAzureFile): void;
    resetAzureFile(): void;
    get azureFileInput(): DaemonSetV1SpecTemplateSpecVolumeAzureFile | undefined;
    private _cephFs;
    get cephFs(): DaemonSetV1SpecTemplateSpecVolumeCephFsOutputReference;
    putCephFs(value: DaemonSetV1SpecTemplateSpecVolumeCephFs): void;
    resetCephFs(): void;
    get cephFsInput(): DaemonSetV1SpecTemplateSpecVolumeCephFs | undefined;
    private _cinder;
    get cinder(): DaemonSetV1SpecTemplateSpecVolumeCinderOutputReference;
    putCinder(value: DaemonSetV1SpecTemplateSpecVolumeCinder): void;
    resetCinder(): void;
    get cinderInput(): DaemonSetV1SpecTemplateSpecVolumeCinder | undefined;
    private _configMap;
    get configMap(): DaemonSetV1SpecTemplateSpecVolumeConfigMapOutputReference;
    putConfigMap(value: DaemonSetV1SpecTemplateSpecVolumeConfigMap): void;
    resetConfigMap(): void;
    get configMapInput(): DaemonSetV1SpecTemplateSpecVolumeConfigMap | undefined;
    private _csi;
    get csi(): DaemonSetV1SpecTemplateSpecVolumeCsiOutputReference;
    putCsi(value: DaemonSetV1SpecTemplateSpecVolumeCsi): void;
    resetCsi(): void;
    get csiInput(): DaemonSetV1SpecTemplateSpecVolumeCsi | undefined;
    private _downwardApi;
    get downwardApi(): DaemonSetV1SpecTemplateSpecVolumeDownwardApiOutputReference;
    putDownwardApi(value: DaemonSetV1SpecTemplateSpecVolumeDownwardApi): void;
    resetDownwardApi(): void;
    get downwardApiInput(): DaemonSetV1SpecTemplateSpecVolumeDownwardApi | undefined;
    private _emptyDir;
    get emptyDir(): DaemonSetV1SpecTemplateSpecVolumeEmptyDirOutputReference;
    putEmptyDir(value: DaemonSetV1SpecTemplateSpecVolumeEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): DaemonSetV1SpecTemplateSpecVolumeEmptyDir | undefined;
    private _ephemeral;
    get ephemeral(): DaemonSetV1SpecTemplateSpecVolumeEphemeralOutputReference;
    putEphemeral(value: DaemonSetV1SpecTemplateSpecVolumeEphemeral): void;
    resetEphemeral(): void;
    get ephemeralInput(): DaemonSetV1SpecTemplateSpecVolumeEphemeral | undefined;
    private _fc;
    get fc(): DaemonSetV1SpecTemplateSpecVolumeFcOutputReference;
    putFc(value: DaemonSetV1SpecTemplateSpecVolumeFc): void;
    resetFc(): void;
    get fcInput(): DaemonSetV1SpecTemplateSpecVolumeFc | undefined;
    private _flexVolume;
    get flexVolume(): DaemonSetV1SpecTemplateSpecVolumeFlexVolumeOutputReference;
    putFlexVolume(value: DaemonSetV1SpecTemplateSpecVolumeFlexVolume): void;
    resetFlexVolume(): void;
    get flexVolumeInput(): DaemonSetV1SpecTemplateSpecVolumeFlexVolume | undefined;
    private _flocker;
    get flocker(): DaemonSetV1SpecTemplateSpecVolumeFlockerOutputReference;
    putFlocker(value: DaemonSetV1SpecTemplateSpecVolumeFlocker): void;
    resetFlocker(): void;
    get flockerInput(): DaemonSetV1SpecTemplateSpecVolumeFlocker | undefined;
    private _gcePersistentDisk;
    get gcePersistentDisk(): DaemonSetV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference;
    putGcePersistentDisk(value: DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk): void;
    resetGcePersistentDisk(): void;
    get gcePersistentDiskInput(): DaemonSetV1SpecTemplateSpecVolumeGcePersistentDisk | undefined;
    private _gitRepo;
    get gitRepo(): DaemonSetV1SpecTemplateSpecVolumeGitRepoOutputReference;
    putGitRepo(value: DaemonSetV1SpecTemplateSpecVolumeGitRepo): void;
    resetGitRepo(): void;
    get gitRepoInput(): DaemonSetV1SpecTemplateSpecVolumeGitRepo | undefined;
    private _glusterfs;
    get glusterfs(): DaemonSetV1SpecTemplateSpecVolumeGlusterfsOutputReference;
    putGlusterfs(value: DaemonSetV1SpecTemplateSpecVolumeGlusterfs): void;
    resetGlusterfs(): void;
    get glusterfsInput(): DaemonSetV1SpecTemplateSpecVolumeGlusterfs | undefined;
    private _hostPath;
    get hostPath(): DaemonSetV1SpecTemplateSpecVolumeHostPathOutputReference;
    putHostPath(value: DaemonSetV1SpecTemplateSpecVolumeHostPath): void;
    resetHostPath(): void;
    get hostPathInput(): DaemonSetV1SpecTemplateSpecVolumeHostPath | undefined;
    private _iscsi;
    get iscsi(): DaemonSetV1SpecTemplateSpecVolumeIscsiOutputReference;
    putIscsi(value: DaemonSetV1SpecTemplateSpecVolumeIscsi): void;
    resetIscsi(): void;
    get iscsiInput(): DaemonSetV1SpecTemplateSpecVolumeIscsi | undefined;
    private _local;
    get local(): DaemonSetV1SpecTemplateSpecVolumeLocalOutputReference;
    putLocal(value: DaemonSetV1SpecTemplateSpecVolumeLocal): void;
    resetLocal(): void;
    get localInput(): DaemonSetV1SpecTemplateSpecVolumeLocal | undefined;
    private _nfs;
    get nfs(): DaemonSetV1SpecTemplateSpecVolumeNfsOutputReference;
    putNfs(value: DaemonSetV1SpecTemplateSpecVolumeNfs): void;
    resetNfs(): void;
    get nfsInput(): DaemonSetV1SpecTemplateSpecVolumeNfs | undefined;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference;
    putPersistentVolumeClaim(value: DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim): void;
    resetPersistentVolumeClaim(): void;
    get persistentVolumeClaimInput(): DaemonSetV1SpecTemplateSpecVolumePersistentVolumeClaim | undefined;
    private _photonPersistentDisk;
    get photonPersistentDisk(): DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference;
    putPhotonPersistentDisk(value: DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk): void;
    resetPhotonPersistentDisk(): void;
    get photonPersistentDiskInput(): DaemonSetV1SpecTemplateSpecVolumePhotonPersistentDisk | undefined;
    private _projected;
    get projected(): DaemonSetV1SpecTemplateSpecVolumeProjectedList;
    putProjected(value: DaemonSetV1SpecTemplateSpecVolumeProjected[] | cdktn.IResolvable): void;
    resetProjected(): void;
    get projectedInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolumeProjected[] | undefined;
    private _quobyte;
    get quobyte(): DaemonSetV1SpecTemplateSpecVolumeQuobyteOutputReference;
    putQuobyte(value: DaemonSetV1SpecTemplateSpecVolumeQuobyte): void;
    resetQuobyte(): void;
    get quobyteInput(): DaemonSetV1SpecTemplateSpecVolumeQuobyte | undefined;
    private _rbd;
    get rbd(): DaemonSetV1SpecTemplateSpecVolumeRbdOutputReference;
    putRbd(value: DaemonSetV1SpecTemplateSpecVolumeRbd): void;
    resetRbd(): void;
    get rbdInput(): DaemonSetV1SpecTemplateSpecVolumeRbd | undefined;
    private _secret;
    get secret(): DaemonSetV1SpecTemplateSpecVolumeSecretOutputReference;
    putSecret(value: DaemonSetV1SpecTemplateSpecVolumeSecret): void;
    resetSecret(): void;
    get secretInput(): DaemonSetV1SpecTemplateSpecVolumeSecret | undefined;
    private _vsphereVolume;
    get vsphereVolume(): DaemonSetV1SpecTemplateSpecVolumeVsphereVolumeOutputReference;
    putVsphereVolume(value: DaemonSetV1SpecTemplateSpecVolumeVsphereVolume): void;
    resetVsphereVolume(): void;
    get vsphereVolumeInput(): DaemonSetV1SpecTemplateSpecVolumeVsphereVolume | undefined;
}
export declare class DaemonSetV1SpecTemplateSpecVolumeList extends cdktn.ComplexList {
    internalValue?: DaemonSetV1SpecTemplateSpecVolume[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DaemonSetV1SpecTemplateSpecVolumeOutputReference;
}
export interface DaemonSetV1SpecTemplateSpec {
    /**
    * Optional duration in seconds the pod may be active on the node relative to StartTime before the system will actively try to mark it failed and kill associated containers. Value must be a positive integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#active_deadline_seconds DaemonSetV1#active_deadline_seconds}
    */
    readonly activeDeadlineSeconds?: number;
    /**
    * AutomountServiceAccountToken indicates whether a service account token should be automatically mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#automount_service_account_token DaemonSetV1#automount_service_account_token}
    */
    readonly automountServiceAccountToken?: boolean | cdktn.IResolvable;
    /**
    * Set DNS policy for containers within the pod. Valid values are 'ClusterFirstWithHostNet', 'ClusterFirst', 'Default' or 'None'. DNS parameters given in DNSConfig will be merged with the policy selected with DNSPolicy. To have DNS options set along with hostNetwork, you have to specify DNS policy explicitly to 'ClusterFirstWithHostNet'. Defaults to 'ClusterFirst'. More info: https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#dns_policy DaemonSetV1#dns_policy}
    */
    readonly dnsPolicy?: string;
    /**
    * Enables generating environment variables for service discovery. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#enable_service_links DaemonSetV1#enable_service_links}
    */
    readonly enableServiceLinks?: boolean | cdktn.IResolvable;
    /**
    * Use the host's ipc namespace. Optional: Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_ipc DaemonSetV1#host_ipc}
    */
    readonly hostIpc?: boolean | cdktn.IResolvable;
    /**
    * Host networking requested for this pod. Use the host's network namespace. If this option is set, the ports that will be used must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_network DaemonSetV1#host_network}
    */
    readonly hostNetwork?: boolean | cdktn.IResolvable;
    /**
    * Use the host's pid namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_pid DaemonSetV1#host_pid}
    */
    readonly hostPid?: boolean | cdktn.IResolvable;
    /**
    * Specifies the hostname of the Pod If not specified, the pod's hostname will be set to a system-defined value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#hostname DaemonSetV1#hostname}
    */
    readonly hostname?: string;
    /**
    * NodeName is a request to schedule this pod onto a specific node. If it is non-empty, the scheduler simply schedules this pod onto that node, assuming that it fits resource requirements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#node_name DaemonSetV1#node_name}
    */
    readonly nodeName?: string;
    /**
    * NodeSelector is a selector which must be true for the pod to fit on a node. Selector which must match a node's labels for the pod to be scheduled on that node. More info: https://kubernetes.io/docs/concepts/configuration/assign-pod-node/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#node_selector DaemonSetV1#node_selector}
    */
    readonly nodeSelector?: {
        [key: string]: string;
    };
    /**
    * If specified, indicates the pod's priority. "system-node-critical" and "system-cluster-critical" are two special keywords which indicate the highest priorities with the former being the highest priority. Any other name must be defined by creating a PriorityClass object with that name. If not specified, the pod priority will be default or zero if there is no default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#priority_class_name DaemonSetV1#priority_class_name}
    */
    readonly priorityClassName?: string;
    /**
    * Restart policy for all containers within the pod. One of Always, OnFailure, Never. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#restart-policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#restart_policy DaemonSetV1#restart_policy}
    */
    readonly restartPolicy?: string;
    /**
    * RuntimeClassName is a feature for selecting the container runtime configuration. The container runtime configuration is used to run a Pod's containers. More info: https://kubernetes.io/docs/concepts/containers/runtime-class
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#runtime_class_name DaemonSetV1#runtime_class_name}
    */
    readonly runtimeClassName?: string;
    /**
    * If specified, the pod will be dispatched by specified scheduler. If not specified, the pod will be dispatched by default scheduler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#scheduler_name DaemonSetV1#scheduler_name}
    */
    readonly schedulerName?: string;
    /**
    * ServiceAccountName is the name of the ServiceAccount to use to run this pod. More info: http://releases.k8s.io/HEAD/docs/design/service_accounts.md.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#service_account_name DaemonSetV1#service_account_name}
    */
    readonly serviceAccountName?: string;
    /**
    * Share a single process namespace between all of the containers in a pod. When this is set containers will be able to view and signal processes from other containers in the same pod, and the first process in each container will not be assigned PID 1. HostPID and ShareProcessNamespace cannot both be set. Optional: Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#share_process_namespace DaemonSetV1#share_process_namespace}
    */
    readonly shareProcessNamespace?: boolean | cdktn.IResolvable;
    /**
    * If specified, the fully qualified Pod hostname will be "...svc.". If not specified, the pod will not have a domainname at all..
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#subdomain DaemonSetV1#subdomain}
    */
    readonly subdomain?: string;
    /**
    * Optional duration in seconds the pod needs to terminate gracefully. May be decreased in delete request. Value must be non-negative integer. The value zero indicates delete immediately. If this value is nil, the default grace period will be used instead. The grace period is the duration in seconds after the processes running in the pod are sent a termination signal and the time when the processes are forcibly halted with a kill signal. Set this value longer than the expected cleanup time for your process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#termination_grace_period_seconds DaemonSetV1#termination_grace_period_seconds}
    */
    readonly terminationGracePeriodSeconds?: number;
    /**
    * affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#affinity DaemonSetV1#affinity}
    */
    readonly affinity?: DaemonSetV1SpecTemplateSpecAffinity;
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#container DaemonSetV1#container}
    */
    readonly container?: DaemonSetV1SpecTemplateSpecContainer[] | cdktn.IResolvable;
    /**
    * dns_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#dns_config DaemonSetV1#dns_config}
    */
    readonly dnsConfig?: DaemonSetV1SpecTemplateSpecDnsConfig;
    /**
    * host_aliases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#host_aliases DaemonSetV1#host_aliases}
    */
    readonly hostAliases?: DaemonSetV1SpecTemplateSpecHostAliases[] | cdktn.IResolvable;
    /**
    * image_pull_secrets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#image_pull_secrets DaemonSetV1#image_pull_secrets}
    */
    readonly imagePullSecrets?: DaemonSetV1SpecTemplateSpecImagePullSecrets[] | cdktn.IResolvable;
    /**
    * init_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#init_container DaemonSetV1#init_container}
    */
    readonly initContainer?: DaemonSetV1SpecTemplateSpecInitContainer[] | cdktn.IResolvable;
    /**
    * os block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#os DaemonSetV1#os}
    */
    readonly os?: DaemonSetV1SpecTemplateSpecOs;
    /**
    * readiness_gate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#readiness_gate DaemonSetV1#readiness_gate}
    */
    readonly readinessGate?: DaemonSetV1SpecTemplateSpecReadinessGate[] | cdktn.IResolvable;
    /**
    * security_context block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#security_context DaemonSetV1#security_context}
    */
    readonly securityContext?: DaemonSetV1SpecTemplateSpecSecurityContext;
    /**
    * toleration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#toleration DaemonSetV1#toleration}
    */
    readonly toleration?: DaemonSetV1SpecTemplateSpecToleration[] | cdktn.IResolvable;
    /**
    * topology_spread_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#topology_spread_constraint DaemonSetV1#topology_spread_constraint}
    */
    readonly topologySpreadConstraint?: DaemonSetV1SpecTemplateSpecTopologySpreadConstraint[] | cdktn.IResolvable;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#volume DaemonSetV1#volume}
    */
    readonly volume?: DaemonSetV1SpecTemplateSpecVolume[] | cdktn.IResolvable;
}
export declare function daemonSetV1SpecTemplateSpecToTerraform(struct?: DaemonSetV1SpecTemplateSpecOutputReference | DaemonSetV1SpecTemplateSpec): any;
export declare function daemonSetV1SpecTemplateSpecToHclTerraform(struct?: DaemonSetV1SpecTemplateSpecOutputReference | DaemonSetV1SpecTemplateSpec): any;
export declare class DaemonSetV1SpecTemplateSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplateSpec | undefined;
    set internalValue(value: DaemonSetV1SpecTemplateSpec | undefined);
    private _activeDeadlineSeconds?;
    get activeDeadlineSeconds(): number;
    set activeDeadlineSeconds(value: number);
    resetActiveDeadlineSeconds(): void;
    get activeDeadlineSecondsInput(): number | undefined;
    private _automountServiceAccountToken?;
    get automountServiceAccountToken(): boolean | cdktn.IResolvable;
    set automountServiceAccountToken(value: boolean | cdktn.IResolvable);
    resetAutomountServiceAccountToken(): void;
    get automountServiceAccountTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _dnsPolicy?;
    get dnsPolicy(): string;
    set dnsPolicy(value: string);
    resetDnsPolicy(): void;
    get dnsPolicyInput(): string | undefined;
    private _enableServiceLinks?;
    get enableServiceLinks(): boolean | cdktn.IResolvable;
    set enableServiceLinks(value: boolean | cdktn.IResolvable);
    resetEnableServiceLinks(): void;
    get enableServiceLinksInput(): boolean | cdktn.IResolvable | undefined;
    private _hostIpc?;
    get hostIpc(): boolean | cdktn.IResolvable;
    set hostIpc(value: boolean | cdktn.IResolvable);
    resetHostIpc(): void;
    get hostIpcInput(): boolean | cdktn.IResolvable | undefined;
    private _hostNetwork?;
    get hostNetwork(): boolean | cdktn.IResolvable;
    set hostNetwork(value: boolean | cdktn.IResolvable);
    resetHostNetwork(): void;
    get hostNetworkInput(): boolean | cdktn.IResolvable | undefined;
    private _hostPid?;
    get hostPid(): boolean | cdktn.IResolvable;
    set hostPid(value: boolean | cdktn.IResolvable);
    resetHostPid(): void;
    get hostPidInput(): boolean | cdktn.IResolvable | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
    private _nodeSelector?;
    get nodeSelector(): {
        [key: string]: string;
    };
    set nodeSelector(value: {
        [key: string]: string;
    });
    resetNodeSelector(): void;
    get nodeSelectorInput(): {
        [key: string]: string;
    } | undefined;
    private _priorityClassName?;
    get priorityClassName(): string;
    set priorityClassName(value: string);
    resetPriorityClassName(): void;
    get priorityClassNameInput(): string | undefined;
    private _restartPolicy?;
    get restartPolicy(): string;
    set restartPolicy(value: string);
    resetRestartPolicy(): void;
    get restartPolicyInput(): string | undefined;
    private _runtimeClassName?;
    get runtimeClassName(): string;
    set runtimeClassName(value: string);
    resetRuntimeClassName(): void;
    get runtimeClassNameInput(): string | undefined;
    private _schedulerName?;
    get schedulerName(): string;
    set schedulerName(value: string);
    resetSchedulerName(): void;
    get schedulerNameInput(): string | undefined;
    private _serviceAccountName?;
    get serviceAccountName(): string;
    set serviceAccountName(value: string);
    resetServiceAccountName(): void;
    get serviceAccountNameInput(): string | undefined;
    private _shareProcessNamespace?;
    get shareProcessNamespace(): boolean | cdktn.IResolvable;
    set shareProcessNamespace(value: boolean | cdktn.IResolvable);
    resetShareProcessNamespace(): void;
    get shareProcessNamespaceInput(): boolean | cdktn.IResolvable | undefined;
    private _subdomain?;
    get subdomain(): string;
    set subdomain(value: string);
    resetSubdomain(): void;
    get subdomainInput(): string | undefined;
    private _terminationGracePeriodSeconds?;
    get terminationGracePeriodSeconds(): number;
    set terminationGracePeriodSeconds(value: number);
    resetTerminationGracePeriodSeconds(): void;
    get terminationGracePeriodSecondsInput(): number | undefined;
    private _affinity;
    get affinity(): DaemonSetV1SpecTemplateSpecAffinityOutputReference;
    putAffinity(value: DaemonSetV1SpecTemplateSpecAffinity): void;
    resetAffinity(): void;
    get affinityInput(): DaemonSetV1SpecTemplateSpecAffinity | undefined;
    private _container;
    get container(): DaemonSetV1SpecTemplateSpecContainerList;
    putContainer(value: DaemonSetV1SpecTemplateSpecContainer[] | cdktn.IResolvable): void;
    resetContainer(): void;
    get containerInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecContainer[] | undefined;
    private _dnsConfig;
    get dnsConfig(): DaemonSetV1SpecTemplateSpecDnsConfigOutputReference;
    putDnsConfig(value: DaemonSetV1SpecTemplateSpecDnsConfig): void;
    resetDnsConfig(): void;
    get dnsConfigInput(): DaemonSetV1SpecTemplateSpecDnsConfig | undefined;
    private _hostAliases;
    get hostAliases(): DaemonSetV1SpecTemplateSpecHostAliasesList;
    putHostAliases(value: DaemonSetV1SpecTemplateSpecHostAliases[] | cdktn.IResolvable): void;
    resetHostAliases(): void;
    get hostAliasesInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecHostAliases[] | undefined;
    private _imagePullSecrets;
    get imagePullSecrets(): DaemonSetV1SpecTemplateSpecImagePullSecretsList;
    putImagePullSecrets(value: DaemonSetV1SpecTemplateSpecImagePullSecrets[] | cdktn.IResolvable): void;
    resetImagePullSecrets(): void;
    get imagePullSecretsInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecImagePullSecrets[] | undefined;
    private _initContainer;
    get initContainer(): DaemonSetV1SpecTemplateSpecInitContainerList;
    putInitContainer(value: DaemonSetV1SpecTemplateSpecInitContainer[] | cdktn.IResolvable): void;
    resetInitContainer(): void;
    get initContainerInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecInitContainer[] | undefined;
    private _os;
    get os(): DaemonSetV1SpecTemplateSpecOsOutputReference;
    putOs(value: DaemonSetV1SpecTemplateSpecOs): void;
    resetOs(): void;
    get osInput(): DaemonSetV1SpecTemplateSpecOs | undefined;
    private _readinessGate;
    get readinessGate(): DaemonSetV1SpecTemplateSpecReadinessGateList;
    putReadinessGate(value: DaemonSetV1SpecTemplateSpecReadinessGate[] | cdktn.IResolvable): void;
    resetReadinessGate(): void;
    get readinessGateInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecReadinessGate[] | undefined;
    private _securityContext;
    get securityContext(): DaemonSetV1SpecTemplateSpecSecurityContextOutputReference;
    putSecurityContext(value: DaemonSetV1SpecTemplateSpecSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): DaemonSetV1SpecTemplateSpecSecurityContext | undefined;
    private _toleration;
    get toleration(): DaemonSetV1SpecTemplateSpecTolerationList;
    putToleration(value: DaemonSetV1SpecTemplateSpecToleration[] | cdktn.IResolvable): void;
    resetToleration(): void;
    get tolerationInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecToleration[] | undefined;
    private _topologySpreadConstraint;
    get topologySpreadConstraint(): DaemonSetV1SpecTemplateSpecTopologySpreadConstraintList;
    putTopologySpreadConstraint(value: DaemonSetV1SpecTemplateSpecTopologySpreadConstraint[] | cdktn.IResolvable): void;
    resetTopologySpreadConstraint(): void;
    get topologySpreadConstraintInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecTopologySpreadConstraint[] | undefined;
    private _volume;
    get volume(): DaemonSetV1SpecTemplateSpecVolumeList;
    putVolume(value: DaemonSetV1SpecTemplateSpecVolume[] | cdktn.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | DaemonSetV1SpecTemplateSpecVolume[] | undefined;
}
export interface DaemonSetV1SpecTemplate {
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#metadata DaemonSetV1#metadata}
    */
    readonly metadata: DaemonSetV1SpecTemplateMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#spec DaemonSetV1#spec}
    */
    readonly spec?: DaemonSetV1SpecTemplateSpec;
}
export declare function daemonSetV1SpecTemplateToTerraform(struct?: DaemonSetV1SpecTemplateOutputReference | DaemonSetV1SpecTemplate): any;
export declare function daemonSetV1SpecTemplateToHclTerraform(struct?: DaemonSetV1SpecTemplateOutputReference | DaemonSetV1SpecTemplate): any;
export declare class DaemonSetV1SpecTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1SpecTemplate | undefined;
    set internalValue(value: DaemonSetV1SpecTemplate | undefined);
    private _metadata;
    get metadata(): DaemonSetV1SpecTemplateMetadataOutputReference;
    putMetadata(value: DaemonSetV1SpecTemplateMetadata): void;
    get metadataInput(): DaemonSetV1SpecTemplateMetadata | undefined;
    private _spec;
    get spec(): DaemonSetV1SpecTemplateSpecOutputReference;
    putSpec(value: DaemonSetV1SpecTemplateSpec): void;
    resetSpec(): void;
    get specInput(): DaemonSetV1SpecTemplateSpec | undefined;
}
export interface DaemonSetV1Spec {
    /**
    * Minimum number of seconds for which a newly created pod should be ready without any of its container crashing, for it to be considered available. Defaults to 0 (pod will be considered available as soon as it is ready)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#min_ready_seconds DaemonSetV1#min_ready_seconds}
    */
    readonly minReadySeconds?: number;
    /**
    * The number of old ReplicaSets to retain to allow rollback. This is a pointer to distinguish between explicit zero and not specified. Defaults to 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#revision_history_limit DaemonSetV1#revision_history_limit}
    */
    readonly revisionHistoryLimit?: number;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#selector DaemonSetV1#selector}
    */
    readonly selector?: DaemonSetV1SpecSelector;
    /**
    * strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#strategy DaemonSetV1#strategy}
    */
    readonly strategy?: DaemonSetV1SpecStrategy;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#template DaemonSetV1#template}
    */
    readonly template: DaemonSetV1SpecTemplate;
}
export declare function daemonSetV1SpecToTerraform(struct?: DaemonSetV1SpecOutputReference | DaemonSetV1Spec): any;
export declare function daemonSetV1SpecToHclTerraform(struct?: DaemonSetV1SpecOutputReference | DaemonSetV1Spec): any;
export declare class DaemonSetV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1Spec | undefined;
    set internalValue(value: DaemonSetV1Spec | undefined);
    private _minReadySeconds?;
    get minReadySeconds(): number;
    set minReadySeconds(value: number);
    resetMinReadySeconds(): void;
    get minReadySecondsInput(): number | undefined;
    private _revisionHistoryLimit?;
    get revisionHistoryLimit(): number;
    set revisionHistoryLimit(value: number);
    resetRevisionHistoryLimit(): void;
    get revisionHistoryLimitInput(): number | undefined;
    private _selector;
    get selector(): DaemonSetV1SpecSelectorOutputReference;
    putSelector(value: DaemonSetV1SpecSelector): void;
    resetSelector(): void;
    get selectorInput(): DaemonSetV1SpecSelector | undefined;
    private _strategy;
    get strategy(): DaemonSetV1SpecStrategyOutputReference;
    putStrategy(value: DaemonSetV1SpecStrategy): void;
    resetStrategy(): void;
    get strategyInput(): DaemonSetV1SpecStrategy | undefined;
    private _template;
    get template(): DaemonSetV1SpecTemplateOutputReference;
    putTemplate(value: DaemonSetV1SpecTemplate): void;
    get templateInput(): DaemonSetV1SpecTemplate | undefined;
}
export interface DaemonSetV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#create DaemonSetV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#delete DaemonSetV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/resources/daemon_set_v1#update DaemonSetV1#update}
    */
    readonly update?: string;
}
export declare function daemonSetV1TimeoutsToTerraform(struct?: DaemonSetV1Timeouts | cdktn.IResolvable): any;
export declare function daemonSetV1TimeoutsToHclTerraform(struct?: DaemonSetV1Timeouts | cdktn.IResolvable): any;
export declare class DaemonSetV1TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DaemonSetV1Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DaemonSetV1Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
