/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesStorageClassConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether the storage class allow volume expand
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#allow_volume_expansion DataKubernetesStorageClass#allow_volume_expansion}
    */
    readonly allowVolumeExpansion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#id DataKubernetesStorageClass#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Persistent Volumes that are dynamically created by a storage class will have the mount options specified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#mount_options DataKubernetesStorageClass#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * The parameters for the provisioner that should create volumes of this storage class
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#parameters DataKubernetesStorageClass#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Indicates the type of the reclaim policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#reclaim_policy DataKubernetesStorageClass#reclaim_policy}
    */
    readonly reclaimPolicy?: string;
    /**
    * Indicates when volume binding and dynamic provisioning should occur
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#volume_binding_mode DataKubernetesStorageClass#volume_binding_mode}
    */
    readonly volumeBindingMode?: string;
    /**
    * allowed_topologies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#allowed_topologies DataKubernetesStorageClass#allowed_topologies}
    */
    readonly allowedTopologies?: DataKubernetesStorageClassAllowedTopologies;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#metadata DataKubernetesStorageClass#metadata}
    */
    readonly metadata: DataKubernetesStorageClassMetadata;
}
export interface DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#key DataKubernetesStorageClass#key}
    */
    readonly key?: string;
    /**
    * An array of string values. One value must match the label to be selected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#values DataKubernetesStorageClass#values}
    */
    readonly values?: string[];
}
export declare function dataKubernetesStorageClassAllowedTopologiesMatchLabelExpressionsToTerraform(struct?: DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable): any;
export declare function dataKubernetesStorageClassAllowedTopologiesMatchLabelExpressionsToHclTerraform(struct?: DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable): any;
export declare class DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressionsList extends cdktn.ComplexList {
    internalValue?: DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressionsOutputReference;
}
export interface DataKubernetesStorageClassAllowedTopologies {
    /**
    * match_label_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#match_label_expressions DataKubernetesStorageClass#match_label_expressions}
    */
    readonly matchLabelExpressions?: DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions[] | cdktn.IResolvable;
}
export declare function dataKubernetesStorageClassAllowedTopologiesToTerraform(struct?: DataKubernetesStorageClassAllowedTopologiesOutputReference | DataKubernetesStorageClassAllowedTopologies): any;
export declare function dataKubernetesStorageClassAllowedTopologiesToHclTerraform(struct?: DataKubernetesStorageClassAllowedTopologiesOutputReference | DataKubernetesStorageClassAllowedTopologies): any;
export declare class DataKubernetesStorageClassAllowedTopologiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesStorageClassAllowedTopologies | undefined;
    set internalValue(value: DataKubernetesStorageClassAllowedTopologies | undefined);
    private _matchLabelExpressions;
    get matchLabelExpressions(): DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressionsList;
    putMatchLabelExpressions(value: DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions[] | cdktn.IResolvable): void;
    resetMatchLabelExpressions(): void;
    get matchLabelExpressionsInput(): cdktn.IResolvable | DataKubernetesStorageClassAllowedTopologiesMatchLabelExpressions[] | undefined;
}
export interface DataKubernetesStorageClassMetadata {
    /**
    * An unstructured key value map stored with the storage class that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#annotations DataKubernetesStorageClass#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the storage class. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#labels DataKubernetesStorageClass#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the storage class, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#name DataKubernetesStorageClass#name}
    */
    readonly name?: string;
}
export declare function dataKubernetesStorageClassMetadataToTerraform(struct?: DataKubernetesStorageClassMetadataOutputReference | DataKubernetesStorageClassMetadata): any;
export declare function dataKubernetesStorageClassMetadataToHclTerraform(struct?: DataKubernetesStorageClassMetadataOutputReference | DataKubernetesStorageClassMetadata): any;
export declare class DataKubernetesStorageClassMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesStorageClassMetadata | undefined;
    set internalValue(value: DataKubernetesStorageClassMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class kubernetes_storage_class}
*/
export declare class DataKubernetesStorageClass extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_storage_class";
    /**
    * Generates CDKTN code for importing a DataKubernetesStorageClass resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesStorageClass to import
    * @param importFromId The id of the existing DataKubernetesStorageClass that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesStorageClass to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.0/docs/data-sources/storage_class kubernetes_storage_class} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesStorageClassConfig
    */
    constructor(scope: Construct, id: string, config: DataKubernetesStorageClassConfig);
    private _allowVolumeExpansion?;
    get allowVolumeExpansion(): boolean | cdktn.IResolvable;
    set allowVolumeExpansion(value: boolean | cdktn.IResolvable);
    resetAllowVolumeExpansion(): void;
    get allowVolumeExpansionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _reclaimPolicy?;
    get reclaimPolicy(): string;
    set reclaimPolicy(value: string);
    resetReclaimPolicy(): void;
    get reclaimPolicyInput(): string | undefined;
    get storageProvisioner(): string;
    private _volumeBindingMode?;
    get volumeBindingMode(): string;
    set volumeBindingMode(value: string);
    resetVolumeBindingMode(): void;
    get volumeBindingModeInput(): string | undefined;
    private _allowedTopologies;
    get allowedTopologies(): DataKubernetesStorageClassAllowedTopologiesOutputReference;
    putAllowedTopologies(value: DataKubernetesStorageClassAllowedTopologies): void;
    resetAllowedTopologies(): void;
    get allowedTopologiesInput(): DataKubernetesStorageClassAllowedTopologies | undefined;
    private _metadata;
    get metadata(): DataKubernetesStorageClassMetadataOutputReference;
    putMetadata(value: DataKubernetesStorageClassMetadata): void;
    get metadataInput(): DataKubernetesStorageClassMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
