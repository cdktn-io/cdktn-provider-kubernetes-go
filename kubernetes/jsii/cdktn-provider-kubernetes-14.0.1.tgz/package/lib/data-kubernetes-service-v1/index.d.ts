/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesServiceV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#id DataKubernetesServiceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#metadata DataKubernetesServiceV1#metadata}
    */
    readonly metadata: DataKubernetesServiceV1Metadata;
}
export interface DataKubernetesServiceV1SpecPort {
}
export declare function dataKubernetesServiceV1SpecPortToTerraform(struct?: DataKubernetesServiceV1SpecPort): any;
export declare function dataKubernetesServiceV1SpecPortToHclTerraform(struct?: DataKubernetesServiceV1SpecPort): any;
export declare class DataKubernetesServiceV1SpecPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1SpecPort | undefined;
    set internalValue(value: DataKubernetesServiceV1SpecPort | undefined);
    get appProtocol(): string;
    get name(): string;
    get nodePort(): number;
    get port(): number;
    get protocol(): string;
    get targetPort(): string;
}
export declare class DataKubernetesServiceV1SpecPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1SpecPortOutputReference;
}
export interface DataKubernetesServiceV1SpecSessionAffinityConfigClientIp {
}
export declare function dataKubernetesServiceV1SpecSessionAffinityConfigClientIpToTerraform(struct?: DataKubernetesServiceV1SpecSessionAffinityConfigClientIp): any;
export declare function dataKubernetesServiceV1SpecSessionAffinityConfigClientIpToHclTerraform(struct?: DataKubernetesServiceV1SpecSessionAffinityConfigClientIp): any;
export declare class DataKubernetesServiceV1SpecSessionAffinityConfigClientIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1SpecSessionAffinityConfigClientIp | undefined;
    set internalValue(value: DataKubernetesServiceV1SpecSessionAffinityConfigClientIp | undefined);
    get timeoutSeconds(): number;
}
export declare class DataKubernetesServiceV1SpecSessionAffinityConfigClientIpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1SpecSessionAffinityConfigClientIpOutputReference;
}
export interface DataKubernetesServiceV1SpecSessionAffinityConfig {
}
export declare function dataKubernetesServiceV1SpecSessionAffinityConfigToTerraform(struct?: DataKubernetesServiceV1SpecSessionAffinityConfig): any;
export declare function dataKubernetesServiceV1SpecSessionAffinityConfigToHclTerraform(struct?: DataKubernetesServiceV1SpecSessionAffinityConfig): any;
export declare class DataKubernetesServiceV1SpecSessionAffinityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1SpecSessionAffinityConfig | undefined;
    set internalValue(value: DataKubernetesServiceV1SpecSessionAffinityConfig | undefined);
    private _clientIp;
    get clientIp(): DataKubernetesServiceV1SpecSessionAffinityConfigClientIpList;
}
export declare class DataKubernetesServiceV1SpecSessionAffinityConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1SpecSessionAffinityConfigOutputReference;
}
export interface DataKubernetesServiceV1Spec {
}
export declare function dataKubernetesServiceV1SpecToTerraform(struct?: DataKubernetesServiceV1Spec): any;
export declare function dataKubernetesServiceV1SpecToHclTerraform(struct?: DataKubernetesServiceV1Spec): any;
export declare class DataKubernetesServiceV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1Spec | undefined;
    set internalValue(value: DataKubernetesServiceV1Spec | undefined);
    get allocateLoadBalancerNodePorts(): cdktn.IResolvable;
    get clusterIp(): string;
    get clusterIps(): string[];
    get externalIps(): string[];
    get externalName(): string;
    get externalTrafficPolicy(): string;
    get healthCheckNodePort(): number;
    get internalTrafficPolicy(): string;
    get ipFamilies(): string[];
    get ipFamilyPolicy(): string;
    get loadBalancerClass(): string;
    get loadBalancerIp(): string;
    get loadBalancerSourceRanges(): string[];
    private _port;
    get port(): DataKubernetesServiceV1SpecPortList;
    get publishNotReadyAddresses(): cdktn.IResolvable;
    private _selector;
    get selector(): cdktn.StringMap;
    get sessionAffinity(): string;
    private _sessionAffinityConfig;
    get sessionAffinityConfig(): DataKubernetesServiceV1SpecSessionAffinityConfigList;
    get type(): string;
}
export declare class DataKubernetesServiceV1SpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1SpecOutputReference;
}
export interface DataKubernetesServiceV1StatusLoadBalancerIngress {
}
export declare function dataKubernetesServiceV1StatusLoadBalancerIngressToTerraform(struct?: DataKubernetesServiceV1StatusLoadBalancerIngress): any;
export declare function dataKubernetesServiceV1StatusLoadBalancerIngressToHclTerraform(struct?: DataKubernetesServiceV1StatusLoadBalancerIngress): any;
export declare class DataKubernetesServiceV1StatusLoadBalancerIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1StatusLoadBalancerIngress | undefined;
    set internalValue(value: DataKubernetesServiceV1StatusLoadBalancerIngress | undefined);
    get hostname(): string;
    get ip(): string;
}
export declare class DataKubernetesServiceV1StatusLoadBalancerIngressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1StatusLoadBalancerIngressOutputReference;
}
export interface DataKubernetesServiceV1StatusLoadBalancer {
}
export declare function dataKubernetesServiceV1StatusLoadBalancerToTerraform(struct?: DataKubernetesServiceV1StatusLoadBalancer): any;
export declare function dataKubernetesServiceV1StatusLoadBalancerToHclTerraform(struct?: DataKubernetesServiceV1StatusLoadBalancer): any;
export declare class DataKubernetesServiceV1StatusLoadBalancerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1StatusLoadBalancer | undefined;
    set internalValue(value: DataKubernetesServiceV1StatusLoadBalancer | undefined);
    private _ingress;
    get ingress(): DataKubernetesServiceV1StatusLoadBalancerIngressList;
}
export declare class DataKubernetesServiceV1StatusLoadBalancerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1StatusLoadBalancerOutputReference;
}
export interface DataKubernetesServiceV1Status {
}
export declare function dataKubernetesServiceV1StatusToTerraform(struct?: DataKubernetesServiceV1Status): any;
export declare function dataKubernetesServiceV1StatusToHclTerraform(struct?: DataKubernetesServiceV1Status): any;
export declare class DataKubernetesServiceV1StatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesServiceV1Status | undefined;
    set internalValue(value: DataKubernetesServiceV1Status | undefined);
    private _loadBalancer;
    get loadBalancer(): DataKubernetesServiceV1StatusLoadBalancerList;
}
export declare class DataKubernetesServiceV1StatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesServiceV1StatusOutputReference;
}
export interface DataKubernetesServiceV1Metadata {
    /**
    * An unstructured key value map stored with the service that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#annotations DataKubernetesServiceV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the service. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#labels DataKubernetesServiceV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the service, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#name DataKubernetesServiceV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the service must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#namespace DataKubernetesServiceV1#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesServiceV1MetadataToTerraform(struct?: DataKubernetesServiceV1MetadataOutputReference | DataKubernetesServiceV1Metadata): any;
export declare function dataKubernetesServiceV1MetadataToHclTerraform(struct?: DataKubernetesServiceV1MetadataOutputReference | DataKubernetesServiceV1Metadata): any;
export declare class DataKubernetesServiceV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesServiceV1Metadata | undefined;
    set internalValue(value: DataKubernetesServiceV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1 kubernetes_service_v1}
*/
export declare class DataKubernetesServiceV1 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_service_v1";
    /**
    * Generates CDKTN code for importing a DataKubernetesServiceV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesServiceV1 to import
    * @param importFromId The id of the existing DataKubernetesServiceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesServiceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/service_v1 kubernetes_service_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesServiceV1Config
    */
    constructor(scope: Construct, id: string, config: DataKubernetesServiceV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _spec;
    get spec(): DataKubernetesServiceV1SpecList;
    private _status;
    get status(): DataKubernetesServiceV1StatusList;
    private _metadata;
    get metadata(): DataKubernetesServiceV1MetadataOutputReference;
    putMetadata(value: DataKubernetesServiceV1Metadata): void;
    get metadataInput(): DataKubernetesServiceV1Metadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
