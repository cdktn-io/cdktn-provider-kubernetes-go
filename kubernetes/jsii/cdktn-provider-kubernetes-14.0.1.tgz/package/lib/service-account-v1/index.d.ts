/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceAccountV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Enable automatic mounting of the service account token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#automount_service_account_token ServiceAccountV1#automount_service_account_token}
    */
    readonly automountServiceAccountToken?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#id ServiceAccountV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * image_pull_secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#image_pull_secret ServiceAccountV1#image_pull_secret}
    */
    readonly imagePullSecret?: ServiceAccountV1ImagePullSecret[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#metadata ServiceAccountV1#metadata}
    */
    readonly metadata: ServiceAccountV1Metadata;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#secret ServiceAccountV1#secret}
    */
    readonly secret?: ServiceAccountV1Secret[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#timeouts ServiceAccountV1#timeouts}
    */
    readonly timeouts?: ServiceAccountV1Timeouts;
}
export interface ServiceAccountV1ImagePullSecret {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#name ServiceAccountV1#name}
    */
    readonly name?: string;
}
export declare function serviceAccountV1ImagePullSecretToTerraform(struct?: ServiceAccountV1ImagePullSecret | cdktn.IResolvable): any;
export declare function serviceAccountV1ImagePullSecretToHclTerraform(struct?: ServiceAccountV1ImagePullSecret | cdktn.IResolvable): any;
export declare class ServiceAccountV1ImagePullSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceAccountV1ImagePullSecret | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceAccountV1ImagePullSecret | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class ServiceAccountV1ImagePullSecretList extends cdktn.ComplexList {
    internalValue?: ServiceAccountV1ImagePullSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceAccountV1ImagePullSecretOutputReference;
}
export interface ServiceAccountV1Metadata {
    /**
    * An unstructured key value map stored with the service account that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#annotations ServiceAccountV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#generate_name ServiceAccountV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the service account. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#labels ServiceAccountV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the service account, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#name ServiceAccountV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the service account must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#namespace ServiceAccountV1#namespace}
    */
    readonly namespace?: string;
}
export declare function serviceAccountV1MetadataToTerraform(struct?: ServiceAccountV1MetadataOutputReference | ServiceAccountV1Metadata): any;
export declare function serviceAccountV1MetadataToHclTerraform(struct?: ServiceAccountV1MetadataOutputReference | ServiceAccountV1Metadata): any;
export declare class ServiceAccountV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceAccountV1Metadata | undefined;
    set internalValue(value: ServiceAccountV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface ServiceAccountV1Secret {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#name ServiceAccountV1#name}
    */
    readonly name?: string;
}
export declare function serviceAccountV1SecretToTerraform(struct?: ServiceAccountV1Secret | cdktn.IResolvable): any;
export declare function serviceAccountV1SecretToHclTerraform(struct?: ServiceAccountV1Secret | cdktn.IResolvable): any;
export declare class ServiceAccountV1SecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceAccountV1Secret | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceAccountV1Secret | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class ServiceAccountV1SecretList extends cdktn.ComplexList {
    internalValue?: ServiceAccountV1Secret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceAccountV1SecretOutputReference;
}
export interface ServiceAccountV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#create ServiceAccountV1#create}
    */
    readonly create?: string;
}
export declare function serviceAccountV1TimeoutsToTerraform(struct?: ServiceAccountV1Timeouts | cdktn.IResolvable): any;
export declare function serviceAccountV1TimeoutsToHclTerraform(struct?: ServiceAccountV1Timeouts | cdktn.IResolvable): any;
export declare class ServiceAccountV1TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceAccountV1Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceAccountV1Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1 kubernetes_service_account_v1}
*/
export declare class ServiceAccountV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_service_account_v1";
    /**
    * Generates CDKTN code for importing a ServiceAccountV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceAccountV1 to import
    * @param importFromId The id of the existing ServiceAccountV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceAccountV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/service_account_v1 kubernetes_service_account_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceAccountV1Config
    */
    constructor(scope: Construct, id: string, config: ServiceAccountV1Config);
    private _automountServiceAccountToken?;
    get automountServiceAccountToken(): boolean | cdktn.IResolvable;
    set automountServiceAccountToken(value: boolean | cdktn.IResolvable);
    resetAutomountServiceAccountToken(): void;
    get automountServiceAccountTokenInput(): boolean | cdktn.IResolvable | undefined;
    get defaultSecretName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imagePullSecret;
    get imagePullSecret(): ServiceAccountV1ImagePullSecretList;
    putImagePullSecret(value: ServiceAccountV1ImagePullSecret[] | cdktn.IResolvable): void;
    resetImagePullSecret(): void;
    get imagePullSecretInput(): cdktn.IResolvable | ServiceAccountV1ImagePullSecret[] | undefined;
    private _metadata;
    get metadata(): ServiceAccountV1MetadataOutputReference;
    putMetadata(value: ServiceAccountV1Metadata): void;
    get metadataInput(): ServiceAccountV1Metadata | undefined;
    private _secret;
    get secret(): ServiceAccountV1SecretList;
    putSecret(value: ServiceAccountV1Secret[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | ServiceAccountV1Secret[] | undefined;
    private _timeouts;
    get timeouts(): ServiceAccountV1TimeoutsOutputReference;
    putTimeouts(value: ServiceAccountV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ServiceAccountV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
