/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EndpointsV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#id EndpointsV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#metadata EndpointsV1#metadata}
    */
    readonly metadata: EndpointsV1Metadata;
    /**
    * subset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#subset EndpointsV1#subset}
    */
    readonly subset?: EndpointsV1Subset[] | cdktn.IResolvable;
}
export interface EndpointsV1Metadata {
    /**
    * An unstructured key value map stored with the endpoints that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#annotations EndpointsV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#generate_name EndpointsV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the endpoints. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#labels EndpointsV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the endpoints, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#name EndpointsV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the endpoints must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#namespace EndpointsV1#namespace}
    */
    readonly namespace?: string;
}
export declare function endpointsV1MetadataToTerraform(struct?: EndpointsV1MetadataOutputReference | EndpointsV1Metadata): any;
export declare function endpointsV1MetadataToHclTerraform(struct?: EndpointsV1MetadataOutputReference | EndpointsV1Metadata): any;
export declare class EndpointsV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EndpointsV1Metadata | undefined;
    set internalValue(value: EndpointsV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface EndpointsV1SubsetAddress {
    /**
    * The Hostname of this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#hostname EndpointsV1#hostname}
    */
    readonly hostname?: string;
    /**
    * The IP of this endpoint. May not be loopback (127.0.0.0/8), link-local (169.254.0.0/16), or link-local multicast ((224.0.0.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#ip EndpointsV1#ip}
    */
    readonly ip: string;
    /**
    * Node hosting this endpoint. This can be used to determine endpoints local to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#node_name EndpointsV1#node_name}
    */
    readonly nodeName?: string;
}
export declare function endpointsV1SubsetAddressToTerraform(struct?: EndpointsV1SubsetAddress | cdktn.IResolvable): any;
export declare function endpointsV1SubsetAddressToHclTerraform(struct?: EndpointsV1SubsetAddress | cdktn.IResolvable): any;
export declare class EndpointsV1SubsetAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsV1SubsetAddress | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsV1SubsetAddress | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
}
export declare class EndpointsV1SubsetAddressList extends cdktn.ComplexList {
    internalValue?: EndpointsV1SubsetAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsV1SubsetAddressOutputReference;
}
export interface EndpointsV1SubsetNotReadyAddress {
    /**
    * The Hostname of this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#hostname EndpointsV1#hostname}
    */
    readonly hostname?: string;
    /**
    * The IP of this endpoint. May not be loopback (127.0.0.0/8), link-local (169.254.0.0/16), or link-local multicast ((224.0.0.0/24).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#ip EndpointsV1#ip}
    */
    readonly ip: string;
    /**
    * Node hosting this endpoint. This can be used to determine endpoints local to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#node_name EndpointsV1#node_name}
    */
    readonly nodeName?: string;
}
export declare function endpointsV1SubsetNotReadyAddressToTerraform(struct?: EndpointsV1SubsetNotReadyAddress | cdktn.IResolvable): any;
export declare function endpointsV1SubsetNotReadyAddressToHclTerraform(struct?: EndpointsV1SubsetNotReadyAddress | cdktn.IResolvable): any;
export declare class EndpointsV1SubsetNotReadyAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsV1SubsetNotReadyAddress | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsV1SubsetNotReadyAddress | cdktn.IResolvable | undefined);
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
}
export declare class EndpointsV1SubsetNotReadyAddressList extends cdktn.ComplexList {
    internalValue?: EndpointsV1SubsetNotReadyAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsV1SubsetNotReadyAddressOutputReference;
}
export interface EndpointsV1SubsetPort {
    /**
    * The name of this port within the endpoint. Must be a DNS_LABEL. Optional if only one Port is defined on this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#name EndpointsV1#name}
    */
    readonly name?: string;
    /**
    * The port that will be exposed by this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#port EndpointsV1#port}
    */
    readonly port: number;
    /**
    * The IP protocol for this port. Supports `TCP` and `UDP`. Default is `TCP`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#protocol EndpointsV1#protocol}
    */
    readonly protocol?: string;
}
export declare function endpointsV1SubsetPortToTerraform(struct?: EndpointsV1SubsetPort | cdktn.IResolvable): any;
export declare function endpointsV1SubsetPortToHclTerraform(struct?: EndpointsV1SubsetPort | cdktn.IResolvable): any;
export declare class EndpointsV1SubsetPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsV1SubsetPort | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsV1SubsetPort | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class EndpointsV1SubsetPortList extends cdktn.ComplexList {
    internalValue?: EndpointsV1SubsetPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsV1SubsetPortOutputReference;
}
export interface EndpointsV1Subset {
    /**
    * address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#address EndpointsV1#address}
    */
    readonly address?: EndpointsV1SubsetAddress[] | cdktn.IResolvable;
    /**
    * not_ready_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#not_ready_address EndpointsV1#not_ready_address}
    */
    readonly notReadyAddress?: EndpointsV1SubsetNotReadyAddress[] | cdktn.IResolvable;
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#port EndpointsV1#port}
    */
    readonly port?: EndpointsV1SubsetPort[] | cdktn.IResolvable;
}
export declare function endpointsV1SubsetToTerraform(struct?: EndpointsV1Subset | cdktn.IResolvable): any;
export declare function endpointsV1SubsetToHclTerraform(struct?: EndpointsV1Subset | cdktn.IResolvable): any;
export declare class EndpointsV1SubsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EndpointsV1Subset | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointsV1Subset | cdktn.IResolvable | undefined);
    private _address;
    get address(): EndpointsV1SubsetAddressList;
    putAddress(value: EndpointsV1SubsetAddress[] | cdktn.IResolvable): void;
    resetAddress(): void;
    get addressInput(): cdktn.IResolvable | EndpointsV1SubsetAddress[] | undefined;
    private _notReadyAddress;
    get notReadyAddress(): EndpointsV1SubsetNotReadyAddressList;
    putNotReadyAddress(value: EndpointsV1SubsetNotReadyAddress[] | cdktn.IResolvable): void;
    resetNotReadyAddress(): void;
    get notReadyAddressInput(): cdktn.IResolvable | EndpointsV1SubsetNotReadyAddress[] | undefined;
    private _port;
    get port(): EndpointsV1SubsetPortList;
    putPort(value: EndpointsV1SubsetPort[] | cdktn.IResolvable): void;
    resetPort(): void;
    get portInput(): cdktn.IResolvable | EndpointsV1SubsetPort[] | undefined;
}
export declare class EndpointsV1SubsetList extends cdktn.ComplexList {
    internalValue?: EndpointsV1Subset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EndpointsV1SubsetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1 kubernetes_endpoints_v1}
*/
export declare class EndpointsV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_endpoints_v1";
    /**
    * Generates CDKTN code for importing a EndpointsV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EndpointsV1 to import
    * @param importFromId The id of the existing EndpointsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EndpointsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/endpoints_v1 kubernetes_endpoints_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EndpointsV1Config
    */
    constructor(scope: Construct, id: string, config: EndpointsV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): EndpointsV1MetadataOutputReference;
    putMetadata(value: EndpointsV1Metadata): void;
    get metadataInput(): EndpointsV1Metadata | undefined;
    private _subset;
    get subset(): EndpointsV1SubsetList;
    putSubset(value: EndpointsV1Subset[] | cdktn.IResolvable): void;
    resetSubset(): void;
    get subsetInput(): cdktn.IResolvable | EndpointsV1Subset[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
