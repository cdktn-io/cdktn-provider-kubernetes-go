/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesServerVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/server_version#id DataKubernetesServerVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/server_version kubernetes_server_version}
*/
export declare class DataKubernetesServerVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_server_version";
    /**
    * Generates CDKTN code for importing a DataKubernetesServerVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesServerVersion to import
    * @param importFromId The id of the existing DataKubernetesServerVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/server_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesServerVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/data-sources/server_version kubernetes_server_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesServerVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataKubernetesServerVersionConfig);
    get buildDate(): string;
    get compiler(): string;
    get gitCommit(): string;
    get gitTreeState(): string;
    get gitVersion(): string;
    get goVersion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get major(): string;
    get minor(): string;
    get platform(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
