/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { DaemonsetMetadata, DaemonsetMetadataOutputReference, DaemonsetSpec, DaemonsetSpecOutputReference, DaemonsetTimeouts, DaemonsetTimeoutsOutputReference } from './index-structs';
export * from './index-structs';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DaemonsetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset#id Daemonset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Wait for the rollout of the deployment to complete. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset#wait_for_rollout Daemonset#wait_for_rollout}
    */
    readonly waitForRollout?: boolean | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset#metadata Daemonset#metadata}
    */
    readonly metadata: DaemonsetMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset#spec Daemonset#spec}
    */
    readonly spec: DaemonsetSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset#timeouts Daemonset#timeouts}
    */
    readonly timeouts?: DaemonsetTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset kubernetes_daemonset}
*/
export declare class Daemonset extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_daemonset";
    /**
    * Generates CDKTN code for importing a Daemonset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Daemonset to import
    * @param importFromId The id of the existing Daemonset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Daemonset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/daemonset kubernetes_daemonset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DaemonsetConfig
    */
    constructor(scope: Construct, id: string, config: DaemonsetConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _waitForRollout?;
    get waitForRollout(): boolean | cdktn.IResolvable;
    set waitForRollout(value: boolean | cdktn.IResolvable);
    resetWaitForRollout(): void;
    get waitForRolloutInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): DaemonsetMetadataOutputReference;
    putMetadata(value: DaemonsetMetadata): void;
    get metadataInput(): DaemonsetMetadata | undefined;
    private _spec;
    get spec(): DaemonsetSpecOutputReference;
    putSpec(value: DaemonsetSpec): void;
    get specInput(): DaemonsetSpec | undefined;
    private _timeouts;
    get timeouts(): DaemonsetTimeoutsOutputReference;
    putTimeouts(value: DaemonsetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DaemonsetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
