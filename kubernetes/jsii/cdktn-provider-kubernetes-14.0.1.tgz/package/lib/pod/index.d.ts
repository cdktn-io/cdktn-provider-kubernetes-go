/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { PodMetadata, PodMetadataOutputReference, PodSpec, PodSpecOutputReference, PodTimeouts, PodTimeoutsOutputReference } from './index-structs';
export * from './index-structs';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PodConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod#id Pod#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of the pod phases that indicate whether it was successfully created. Options: "Pending", "Running", "Succeeded", "Failed", "Unknown". Default: "Running". More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#pod-phase
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod#target_state Pod#target_state}
    */
    readonly targetState?: string[];
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod#metadata Pod#metadata}
    */
    readonly metadata: PodMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod#spec Pod#spec}
    */
    readonly spec: PodSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod#timeouts Pod#timeouts}
    */
    readonly timeouts?: PodTimeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod kubernetes_pod}
*/
export declare class Pod extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_pod";
    /**
    * Generates CDKTN code for importing a Pod resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Pod to import
    * @param importFromId The id of the existing Pod that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Pod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/pod kubernetes_pod} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PodConfig
    */
    constructor(scope: Construct, id: string, config: PodConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _targetState?;
    get targetState(): string[];
    set targetState(value: string[]);
    resetTargetState(): void;
    get targetStateInput(): string[] | undefined;
    private _metadata;
    get metadata(): PodMetadataOutputReference;
    putMetadata(value: PodMetadata): void;
    get metadataInput(): PodMetadata | undefined;
    private _spec;
    get spec(): PodSpecOutputReference;
    putSpec(value: PodSpec): void;
    get specInput(): PodSpec | undefined;
    private _timeouts;
    get timeouts(): PodTimeoutsOutputReference;
    putTimeouts(value: PodTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PodTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
