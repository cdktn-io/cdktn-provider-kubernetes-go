/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFields | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreference | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchExpressionsList;
    private _matchFields;
    get matchFields(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceMatchFieldsList;
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined);
    private _preference;
    get preference(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionPreferenceList;
    get weight(): number;
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFields | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTerm | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchExpressionsList;
    private _matchFields;
    get matchFields(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermMatchFieldsList;
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined);
    private _nodeSelectorTerm;
    get nodeSelectorTerm(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionNodeSelectorTermList;
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodSpecAffinityNodeAffinity {
}
export declare function dataKubernetesPodSpecAffinityNodeAffinityToTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinity): any;
export declare function dataKubernetesPodSpecAffinityNodeAffinityToHclTerraform(struct?: DataKubernetesPodSpecAffinityNodeAffinity): any;
export declare class DataKubernetesPodSpecAffinityNodeAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityNodeAffinity | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityNodeAffinity | undefined);
    private _preferredDuringSchedulingIgnoredDuringExecution;
    get preferredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodSpecAffinityNodeAffinityPreferredDuringSchedulingIgnoredDuringExecutionList;
    private _requiredDuringSchedulingIgnoredDuringExecution;
    get requiredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodSpecAffinityNodeAffinityRequiredDuringSchedulingIgnoredDuringExecutionList;
}
export declare class DataKubernetesPodSpecAffinityNodeAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityNodeAffinityOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined);
    private _podAffinityTerm;
    get podAffinityTerm(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList;
    get weight(): number;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAffinity {
}
export declare function dataKubernetesPodSpecAffinityPodAffinityToTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinity): any;
export declare function dataKubernetesPodSpecAffinityPodAffinityToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAffinity): any;
export declare class DataKubernetesPodSpecAffinityPodAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAffinity | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAffinity | undefined);
    private _preferredDuringSchedulingIgnoredDuringExecution;
    get preferredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodSpecAffinityPodAffinityPreferredDuringSchedulingIgnoredDuringExecutionList;
    private _requiredDuringSchedulingIgnoredDuringExecution;
    get requiredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodSpecAffinityPodAffinityRequiredDuringSchedulingIgnoredDuringExecutionList;
}
export declare class DataKubernetesPodSpecAffinityPodAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAffinityOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTerm | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecution | undefined);
    private _podAffinityTerm;
    get podAffinityTerm(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionPodAffinityTermList;
    get weight(): number;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressions | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelector | undefined);
    private _matchExpressions;
    get matchExpressions(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorMatchExpressionsList;
    private _matchLabels;
    get matchLabels(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecution | undefined);
    private _labelSelector;
    get labelSelector(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionLabelSelectorList;
    private _namespaceSelector;
    get namespaceSelector(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionNamespaceSelectorList;
    get namespaces(): string[];
    get topologyKey(): string;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionOutputReference;
}
export interface DataKubernetesPodSpecAffinityPodAntiAffinity {
}
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityToTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinity): any;
export declare function dataKubernetesPodSpecAffinityPodAntiAffinityToHclTerraform(struct?: DataKubernetesPodSpecAffinityPodAntiAffinity): any;
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinityPodAntiAffinity | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinityPodAntiAffinity | undefined);
    private _preferredDuringSchedulingIgnoredDuringExecution;
    get preferredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodSpecAffinityPodAntiAffinityPreferredDuringSchedulingIgnoredDuringExecutionList;
    private _requiredDuringSchedulingIgnoredDuringExecution;
    get requiredDuringSchedulingIgnoredDuringExecution(): DataKubernetesPodSpecAffinityPodAntiAffinityRequiredDuringSchedulingIgnoredDuringExecutionList;
}
export declare class DataKubernetesPodSpecAffinityPodAntiAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityPodAntiAffinityOutputReference;
}
export interface DataKubernetesPodSpecAffinity {
}
export declare function dataKubernetesPodSpecAffinityToTerraform(struct?: DataKubernetesPodSpecAffinity): any;
export declare function dataKubernetesPodSpecAffinityToHclTerraform(struct?: DataKubernetesPodSpecAffinity): any;
export declare class DataKubernetesPodSpecAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecAffinity | undefined;
    set internalValue(value: DataKubernetesPodSpecAffinity | undefined);
    private _nodeAffinity;
    get nodeAffinity(): DataKubernetesPodSpecAffinityNodeAffinityList;
    private _podAffinity;
    get podAffinity(): DataKubernetesPodSpecAffinityPodAffinityList;
    private _podAntiAffinity;
    get podAntiAffinity(): DataKubernetesPodSpecAffinityPodAntiAffinityList;
}
export declare class DataKubernetesPodSpecAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecAffinityOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRef {
}
export declare function dataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRefToTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRef): any;
export declare function dataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRefToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRef): any;
export declare class DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRef | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRefOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvValueFromFieldRef {
}
export declare function dataKubernetesPodSpecContainerEnvValueFromFieldRefToTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromFieldRef): any;
export declare function dataKubernetesPodSpecContainerEnvValueFromFieldRefToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromFieldRef): any;
export declare class DataKubernetesPodSpecContainerEnvValueFromFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvValueFromFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvValueFromFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodSpecContainerEnvValueFromFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvValueFromFieldRefOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvValueFromResourceFieldRef {
}
export declare function dataKubernetesPodSpecContainerEnvValueFromResourceFieldRefToTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromResourceFieldRef): any;
export declare function dataKubernetesPodSpecContainerEnvValueFromResourceFieldRefToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromResourceFieldRef): any;
export declare class DataKubernetesPodSpecContainerEnvValueFromResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvValueFromResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvValueFromResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodSpecContainerEnvValueFromResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvValueFromResourceFieldRefOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvValueFromSecretKeyRef {
}
export declare function dataKubernetesPodSpecContainerEnvValueFromSecretKeyRefToTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromSecretKeyRef): any;
export declare function dataKubernetesPodSpecContainerEnvValueFromSecretKeyRefToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFromSecretKeyRef): any;
export declare class DataKubernetesPodSpecContainerEnvValueFromSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvValueFromSecretKeyRef | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvValueFromSecretKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecContainerEnvValueFromSecretKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvValueFromSecretKeyRefOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvValueFrom {
}
export declare function dataKubernetesPodSpecContainerEnvValueFromToTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFrom): any;
export declare function dataKubernetesPodSpecContainerEnvValueFromToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvValueFrom): any;
export declare class DataKubernetesPodSpecContainerEnvValueFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvValueFrom | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvValueFrom | undefined);
    private _configMapKeyRef;
    get configMapKeyRef(): DataKubernetesPodSpecContainerEnvValueFromConfigMapKeyRefList;
    private _fieldRef;
    get fieldRef(): DataKubernetesPodSpecContainerEnvValueFromFieldRefList;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodSpecContainerEnvValueFromResourceFieldRefList;
    private _secretKeyRef;
    get secretKeyRef(): DataKubernetesPodSpecContainerEnvValueFromSecretKeyRefList;
}
export declare class DataKubernetesPodSpecContainerEnvValueFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvValueFromOutputReference;
}
export interface DataKubernetesPodSpecContainerEnv {
}
export declare function dataKubernetesPodSpecContainerEnvToTerraform(struct?: DataKubernetesPodSpecContainerEnv): any;
export declare function dataKubernetesPodSpecContainerEnvToHclTerraform(struct?: DataKubernetesPodSpecContainerEnv): any;
export declare class DataKubernetesPodSpecContainerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnv | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnv | undefined);
    get name(): string;
    get value(): string;
    private _valueFrom;
    get valueFrom(): DataKubernetesPodSpecContainerEnvValueFromList;
}
export declare class DataKubernetesPodSpecContainerEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvFromConfigMapRef {
}
export declare function dataKubernetesPodSpecContainerEnvFromConfigMapRefToTerraform(struct?: DataKubernetesPodSpecContainerEnvFromConfigMapRef): any;
export declare function dataKubernetesPodSpecContainerEnvFromConfigMapRefToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvFromConfigMapRef): any;
export declare class DataKubernetesPodSpecContainerEnvFromConfigMapRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvFromConfigMapRef | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvFromConfigMapRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecContainerEnvFromConfigMapRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvFromConfigMapRefOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvFromSecretRef {
}
export declare function dataKubernetesPodSpecContainerEnvFromSecretRefToTerraform(struct?: DataKubernetesPodSpecContainerEnvFromSecretRef): any;
export declare function dataKubernetesPodSpecContainerEnvFromSecretRefToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvFromSecretRef): any;
export declare class DataKubernetesPodSpecContainerEnvFromSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvFromSecretRef | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvFromSecretRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecContainerEnvFromSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvFromSecretRefOutputReference;
}
export interface DataKubernetesPodSpecContainerEnvFrom {
}
export declare function dataKubernetesPodSpecContainerEnvFromToTerraform(struct?: DataKubernetesPodSpecContainerEnvFrom): any;
export declare function dataKubernetesPodSpecContainerEnvFromToHclTerraform(struct?: DataKubernetesPodSpecContainerEnvFrom): any;
export declare class DataKubernetesPodSpecContainerEnvFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerEnvFrom | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerEnvFrom | undefined);
    private _configMapRef;
    get configMapRef(): DataKubernetesPodSpecContainerEnvFromConfigMapRefList;
    get prefix(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodSpecContainerEnvFromSecretRefList;
}
export declare class DataKubernetesPodSpecContainerEnvFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerEnvFromOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePostStartExec {
}
export declare function dataKubernetesPodSpecContainerLifecyclePostStartExecToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartExec): any;
export declare function dataKubernetesPodSpecContainerLifecyclePostStartExecToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartExec): any;
export declare class DataKubernetesPodSpecContainerLifecyclePostStartExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePostStartExec | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePostStartExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecContainerLifecyclePostStartExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePostStartExecOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePostStartHttpGet {
}
export declare function dataKubernetesPodSpecContainerLifecyclePostStartHttpGetToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartHttpGet): any;
export declare function dataKubernetesPodSpecContainerLifecyclePostStartHttpGetToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartHttpGet): any;
export declare class DataKubernetesPodSpecContainerLifecyclePostStartHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePostStartHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePostStartHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecContainerLifecyclePostStartHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecContainerLifecyclePostStartHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePostStartHttpGetOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePostStartTcpSocket {
}
export declare function dataKubernetesPodSpecContainerLifecyclePostStartTcpSocketToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartTcpSocket): any;
export declare function dataKubernetesPodSpecContainerLifecyclePostStartTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStartTcpSocket): any;
export declare class DataKubernetesPodSpecContainerLifecyclePostStartTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePostStartTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePostStartTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecContainerLifecyclePostStartTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePostStartTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePostStart {
}
export declare function dataKubernetesPodSpecContainerLifecyclePostStartToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStart): any;
export declare function dataKubernetesPodSpecContainerLifecyclePostStartToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePostStart): any;
export declare class DataKubernetesPodSpecContainerLifecyclePostStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePostStart | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePostStart | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecContainerLifecyclePostStartExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecContainerLifecyclePostStartHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecContainerLifecyclePostStartTcpSocketList;
}
export declare class DataKubernetesPodSpecContainerLifecyclePostStartList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePostStartOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePreStopExec {
}
export declare function dataKubernetesPodSpecContainerLifecyclePreStopExecToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopExec): any;
export declare function dataKubernetesPodSpecContainerLifecyclePreStopExecToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopExec): any;
export declare class DataKubernetesPodSpecContainerLifecyclePreStopExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePreStopExec | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePreStopExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecContainerLifecyclePreStopExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePreStopExecOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePreStopHttpGet {
}
export declare function dataKubernetesPodSpecContainerLifecyclePreStopHttpGetToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopHttpGet): any;
export declare function dataKubernetesPodSpecContainerLifecyclePreStopHttpGetToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopHttpGet): any;
export declare class DataKubernetesPodSpecContainerLifecyclePreStopHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePreStopHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePreStopHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecContainerLifecyclePreStopHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecContainerLifecyclePreStopHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePreStopHttpGetOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePreStopTcpSocket {
}
export declare function dataKubernetesPodSpecContainerLifecyclePreStopTcpSocketToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopTcpSocket): any;
export declare function dataKubernetesPodSpecContainerLifecyclePreStopTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStopTcpSocket): any;
export declare class DataKubernetesPodSpecContainerLifecyclePreStopTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePreStopTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePreStopTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecContainerLifecyclePreStopTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePreStopTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecyclePreStop {
}
export declare function dataKubernetesPodSpecContainerLifecyclePreStopToTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStop): any;
export declare function dataKubernetesPodSpecContainerLifecyclePreStopToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecyclePreStop): any;
export declare class DataKubernetesPodSpecContainerLifecyclePreStopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecyclePreStop | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecyclePreStop | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecContainerLifecyclePreStopExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecContainerLifecyclePreStopHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecContainerLifecyclePreStopTcpSocketList;
}
export declare class DataKubernetesPodSpecContainerLifecyclePreStopList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecyclePreStopOutputReference;
}
export interface DataKubernetesPodSpecContainerLifecycle {
}
export declare function dataKubernetesPodSpecContainerLifecycleToTerraform(struct?: DataKubernetesPodSpecContainerLifecycle): any;
export declare function dataKubernetesPodSpecContainerLifecycleToHclTerraform(struct?: DataKubernetesPodSpecContainerLifecycle): any;
export declare class DataKubernetesPodSpecContainerLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLifecycle | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLifecycle | undefined);
    private _postStart;
    get postStart(): DataKubernetesPodSpecContainerLifecyclePostStartList;
    private _preStop;
    get preStop(): DataKubernetesPodSpecContainerLifecyclePreStopList;
}
export declare class DataKubernetesPodSpecContainerLifecycleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLifecycleOutputReference;
}
export interface DataKubernetesPodSpecContainerLivenessProbeExec {
}
export declare function dataKubernetesPodSpecContainerLivenessProbeExecToTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeExec): any;
export declare function dataKubernetesPodSpecContainerLivenessProbeExecToHclTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeExec): any;
export declare class DataKubernetesPodSpecContainerLivenessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLivenessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLivenessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecContainerLivenessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLivenessProbeExecOutputReference;
}
export interface DataKubernetesPodSpecContainerLivenessProbeGrpc {
}
export declare function dataKubernetesPodSpecContainerLivenessProbeGrpcToTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeGrpc): any;
export declare function dataKubernetesPodSpecContainerLivenessProbeGrpcToHclTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeGrpc): any;
export declare class DataKubernetesPodSpecContainerLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLivenessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLivenessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodSpecContainerLivenessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLivenessProbeGrpcOutputReference;
}
export interface DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecContainerLivenessProbeHttpGet {
}
export declare function dataKubernetesPodSpecContainerLivenessProbeHttpGetToTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeHttpGet): any;
export declare function dataKubernetesPodSpecContainerLivenessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeHttpGet): any;
export declare class DataKubernetesPodSpecContainerLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLivenessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLivenessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecContainerLivenessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecContainerLivenessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLivenessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodSpecContainerLivenessProbeTcpSocket {
}
export declare function dataKubernetesPodSpecContainerLivenessProbeTcpSocketToTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeTcpSocket): any;
export declare function dataKubernetesPodSpecContainerLivenessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbeTcpSocket): any;
export declare class DataKubernetesPodSpecContainerLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLivenessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLivenessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecContainerLivenessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLivenessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecContainerLivenessProbe {
}
export declare function dataKubernetesPodSpecContainerLivenessProbeToTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbe): any;
export declare function dataKubernetesPodSpecContainerLivenessProbeToHclTerraform(struct?: DataKubernetesPodSpecContainerLivenessProbe): any;
export declare class DataKubernetesPodSpecContainerLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerLivenessProbe | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerLivenessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecContainerLivenessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodSpecContainerLivenessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecContainerLivenessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecContainerLivenessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodSpecContainerLivenessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerLivenessProbeOutputReference;
}
export interface DataKubernetesPodSpecContainerPort {
}
export declare function dataKubernetesPodSpecContainerPortToTerraform(struct?: DataKubernetesPodSpecContainerPort): any;
export declare function dataKubernetesPodSpecContainerPortToHclTerraform(struct?: DataKubernetesPodSpecContainerPort): any;
export declare class DataKubernetesPodSpecContainerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerPort | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerPort | undefined);
    get containerPort(): number;
    get hostIp(): string;
    get hostPort(): number;
    get name(): string;
    get protocol(): string;
}
export declare class DataKubernetesPodSpecContainerPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerPortOutputReference;
}
export interface DataKubernetesPodSpecContainerReadinessProbeExec {
}
export declare function dataKubernetesPodSpecContainerReadinessProbeExecToTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeExec): any;
export declare function dataKubernetesPodSpecContainerReadinessProbeExecToHclTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeExec): any;
export declare class DataKubernetesPodSpecContainerReadinessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerReadinessProbeExec | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerReadinessProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecContainerReadinessProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerReadinessProbeExecOutputReference;
}
export interface DataKubernetesPodSpecContainerReadinessProbeGrpc {
}
export declare function dataKubernetesPodSpecContainerReadinessProbeGrpcToTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeGrpc): any;
export declare function dataKubernetesPodSpecContainerReadinessProbeGrpcToHclTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeGrpc): any;
export declare class DataKubernetesPodSpecContainerReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerReadinessProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerReadinessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodSpecContainerReadinessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerReadinessProbeGrpcOutputReference;
}
export interface DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecContainerReadinessProbeHttpGet {
}
export declare function dataKubernetesPodSpecContainerReadinessProbeHttpGetToTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeHttpGet): any;
export declare function dataKubernetesPodSpecContainerReadinessProbeHttpGetToHclTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeHttpGet): any;
export declare class DataKubernetesPodSpecContainerReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerReadinessProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerReadinessProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecContainerReadinessProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecContainerReadinessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerReadinessProbeHttpGetOutputReference;
}
export interface DataKubernetesPodSpecContainerReadinessProbeTcpSocket {
}
export declare function dataKubernetesPodSpecContainerReadinessProbeTcpSocketToTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeTcpSocket): any;
export declare function dataKubernetesPodSpecContainerReadinessProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbeTcpSocket): any;
export declare class DataKubernetesPodSpecContainerReadinessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerReadinessProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerReadinessProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecContainerReadinessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerReadinessProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecContainerReadinessProbe {
}
export declare function dataKubernetesPodSpecContainerReadinessProbeToTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbe): any;
export declare function dataKubernetesPodSpecContainerReadinessProbeToHclTerraform(struct?: DataKubernetesPodSpecContainerReadinessProbe): any;
export declare class DataKubernetesPodSpecContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerReadinessProbe | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerReadinessProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecContainerReadinessProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodSpecContainerReadinessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecContainerReadinessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecContainerReadinessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodSpecContainerReadinessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerReadinessProbeOutputReference;
}
export interface DataKubernetesPodSpecContainerResources {
}
export declare function dataKubernetesPodSpecContainerResourcesToTerraform(struct?: DataKubernetesPodSpecContainerResources): any;
export declare function dataKubernetesPodSpecContainerResourcesToHclTerraform(struct?: DataKubernetesPodSpecContainerResources): any;
export declare class DataKubernetesPodSpecContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerResources | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
    private _requests;
    get requests(): cdktn.StringMap;
}
export declare class DataKubernetesPodSpecContainerResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerResourcesOutputReference;
}
export interface DataKubernetesPodSpecContainerSecurityContextCapabilities {
}
export declare function dataKubernetesPodSpecContainerSecurityContextCapabilitiesToTerraform(struct?: DataKubernetesPodSpecContainerSecurityContextCapabilities): any;
export declare function dataKubernetesPodSpecContainerSecurityContextCapabilitiesToHclTerraform(struct?: DataKubernetesPodSpecContainerSecurityContextCapabilities): any;
export declare class DataKubernetesPodSpecContainerSecurityContextCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerSecurityContextCapabilities | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerSecurityContextCapabilities | undefined);
    get add(): string[];
    get drop(): string[];
}
export declare class DataKubernetesPodSpecContainerSecurityContextCapabilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerSecurityContextCapabilitiesOutputReference;
}
export interface DataKubernetesPodSpecContainerSecurityContextSeLinuxOptions {
}
export declare function dataKubernetesPodSpecContainerSecurityContextSeLinuxOptionsToTerraform(struct?: DataKubernetesPodSpecContainerSecurityContextSeLinuxOptions): any;
export declare function dataKubernetesPodSpecContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: DataKubernetesPodSpecContainerSecurityContextSeLinuxOptions): any;
export declare class DataKubernetesPodSpecContainerSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerSecurityContextSeLinuxOptions | undefined);
    get level(): string;
    get role(): string;
    get type(): string;
    get user(): string;
}
export declare class DataKubernetesPodSpecContainerSecurityContextSeLinuxOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerSecurityContextSeLinuxOptionsOutputReference;
}
export interface DataKubernetesPodSpecContainerSecurityContextSeccompProfile {
}
export declare function dataKubernetesPodSpecContainerSecurityContextSeccompProfileToTerraform(struct?: DataKubernetesPodSpecContainerSecurityContextSeccompProfile): any;
export declare function dataKubernetesPodSpecContainerSecurityContextSeccompProfileToHclTerraform(struct?: DataKubernetesPodSpecContainerSecurityContextSeccompProfile): any;
export declare class DataKubernetesPodSpecContainerSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerSecurityContextSeccompProfile | undefined);
    get localhostProfile(): string;
    get type(): string;
}
export declare class DataKubernetesPodSpecContainerSecurityContextSeccompProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerSecurityContextSeccompProfileOutputReference;
}
export interface DataKubernetesPodSpecContainerSecurityContext {
}
export declare function dataKubernetesPodSpecContainerSecurityContextToTerraform(struct?: DataKubernetesPodSpecContainerSecurityContext): any;
export declare function dataKubernetesPodSpecContainerSecurityContextToHclTerraform(struct?: DataKubernetesPodSpecContainerSecurityContext): any;
export declare class DataKubernetesPodSpecContainerSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerSecurityContext | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerSecurityContext | undefined);
    get allowPrivilegeEscalation(): cdktn.IResolvable;
    private _capabilities;
    get capabilities(): DataKubernetesPodSpecContainerSecurityContextCapabilitiesList;
    get privileged(): cdktn.IResolvable;
    get readOnlyRootFilesystem(): cdktn.IResolvable;
    get runAsGroup(): string;
    get runAsNonRoot(): cdktn.IResolvable;
    get runAsUser(): string;
    private _seLinuxOptions;
    get seLinuxOptions(): DataKubernetesPodSpecContainerSecurityContextSeLinuxOptionsList;
    private _seccompProfile;
    get seccompProfile(): DataKubernetesPodSpecContainerSecurityContextSeccompProfileList;
}
export declare class DataKubernetesPodSpecContainerSecurityContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerSecurityContextOutputReference;
}
export interface DataKubernetesPodSpecContainerStartupProbeExec {
}
export declare function dataKubernetesPodSpecContainerStartupProbeExecToTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeExec): any;
export declare function dataKubernetesPodSpecContainerStartupProbeExecToHclTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeExec): any;
export declare class DataKubernetesPodSpecContainerStartupProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerStartupProbeExec | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerStartupProbeExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecContainerStartupProbeExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerStartupProbeExecOutputReference;
}
export interface DataKubernetesPodSpecContainerStartupProbeGrpc {
}
export declare function dataKubernetesPodSpecContainerStartupProbeGrpcToTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeGrpc): any;
export declare function dataKubernetesPodSpecContainerStartupProbeGrpcToHclTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeGrpc): any;
export declare class DataKubernetesPodSpecContainerStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerStartupProbeGrpc | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerStartupProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataKubernetesPodSpecContainerStartupProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerStartupProbeGrpcOutputReference;
}
export interface DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecContainerStartupProbeHttpGet {
}
export declare function dataKubernetesPodSpecContainerStartupProbeHttpGetToTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeHttpGet): any;
export declare function dataKubernetesPodSpecContainerStartupProbeHttpGetToHclTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeHttpGet): any;
export declare class DataKubernetesPodSpecContainerStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerStartupProbeHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerStartupProbeHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecContainerStartupProbeHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecContainerStartupProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerStartupProbeHttpGetOutputReference;
}
export interface DataKubernetesPodSpecContainerStartupProbeTcpSocket {
}
export declare function dataKubernetesPodSpecContainerStartupProbeTcpSocketToTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeTcpSocket): any;
export declare function dataKubernetesPodSpecContainerStartupProbeTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecContainerStartupProbeTcpSocket): any;
export declare class DataKubernetesPodSpecContainerStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerStartupProbeTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerStartupProbeTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecContainerStartupProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerStartupProbeTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecContainerStartupProbe {
}
export declare function dataKubernetesPodSpecContainerStartupProbeToTerraform(struct?: DataKubernetesPodSpecContainerStartupProbe): any;
export declare function dataKubernetesPodSpecContainerStartupProbeToHclTerraform(struct?: DataKubernetesPodSpecContainerStartupProbe): any;
export declare class DataKubernetesPodSpecContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerStartupProbe | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerStartupProbe | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecContainerStartupProbeExecList;
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataKubernetesPodSpecContainerStartupProbeGrpcList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecContainerStartupProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    get successThreshold(): number;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecContainerStartupProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataKubernetesPodSpecContainerStartupProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerStartupProbeOutputReference;
}
export interface DataKubernetesPodSpecContainerVolumeDevice {
}
export declare function dataKubernetesPodSpecContainerVolumeDeviceToTerraform(struct?: DataKubernetesPodSpecContainerVolumeDevice): any;
export declare function dataKubernetesPodSpecContainerVolumeDeviceToHclTerraform(struct?: DataKubernetesPodSpecContainerVolumeDevice): any;
export declare class DataKubernetesPodSpecContainerVolumeDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerVolumeDevice | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerVolumeDevice | undefined);
    get devicePath(): string;
    get name(): string;
}
export declare class DataKubernetesPodSpecContainerVolumeDeviceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerVolumeDeviceOutputReference;
}
export interface DataKubernetesPodSpecContainerVolumeMount {
}
export declare function dataKubernetesPodSpecContainerVolumeMountToTerraform(struct?: DataKubernetesPodSpecContainerVolumeMount): any;
export declare function dataKubernetesPodSpecContainerVolumeMountToHclTerraform(struct?: DataKubernetesPodSpecContainerVolumeMount): any;
export declare class DataKubernetesPodSpecContainerVolumeMountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainerVolumeMount | undefined;
    set internalValue(value: DataKubernetesPodSpecContainerVolumeMount | undefined);
    get mountPath(): string;
    get mountPropagation(): string;
    get name(): string;
    get readOnly(): cdktn.IResolvable;
    get subPath(): string;
    get subPathExpr(): string;
}
export declare class DataKubernetesPodSpecContainerVolumeMountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerVolumeMountOutputReference;
}
export interface DataKubernetesPodSpecContainer {
}
export declare function dataKubernetesPodSpecContainerToTerraform(struct?: DataKubernetesPodSpecContainer): any;
export declare function dataKubernetesPodSpecContainerToHclTerraform(struct?: DataKubernetesPodSpecContainer): any;
export declare class DataKubernetesPodSpecContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecContainer | undefined;
    set internalValue(value: DataKubernetesPodSpecContainer | undefined);
    get args(): string[];
    get command(): string[];
    private _env;
    get env(): DataKubernetesPodSpecContainerEnvList;
    private _envFrom;
    get envFrom(): DataKubernetesPodSpecContainerEnvFromList;
    get image(): string;
    get imagePullPolicy(): string;
    private _lifecycle;
    get lifecycle(): DataKubernetesPodSpecContainerLifecycleList;
    private _livenessProbe;
    get livenessProbe(): DataKubernetesPodSpecContainerLivenessProbeList;
    get name(): string;
    private _port;
    get port(): DataKubernetesPodSpecContainerPortList;
    private _readinessProbe;
    get readinessProbe(): DataKubernetesPodSpecContainerReadinessProbeList;
    private _resources;
    get resources(): DataKubernetesPodSpecContainerResourcesList;
    private _securityContext;
    get securityContext(): DataKubernetesPodSpecContainerSecurityContextList;
    private _startupProbe;
    get startupProbe(): DataKubernetesPodSpecContainerStartupProbeList;
    get stdin(): cdktn.IResolvable;
    get stdinOnce(): cdktn.IResolvable;
    get terminationMessagePath(): string;
    get terminationMessagePolicy(): string;
    get tty(): cdktn.IResolvable;
    private _volumeDevice;
    get volumeDevice(): DataKubernetesPodSpecContainerVolumeDeviceList;
    private _volumeMount;
    get volumeMount(): DataKubernetesPodSpecContainerVolumeMountList;
    get workingDir(): string;
}
export declare class DataKubernetesPodSpecContainerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecContainerOutputReference;
}
export interface DataKubernetesPodSpecDnsConfigOption {
}
export declare function dataKubernetesPodSpecDnsConfigOptionToTerraform(struct?: DataKubernetesPodSpecDnsConfigOption): any;
export declare function dataKubernetesPodSpecDnsConfigOptionToHclTerraform(struct?: DataKubernetesPodSpecDnsConfigOption): any;
export declare class DataKubernetesPodSpecDnsConfigOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecDnsConfigOption | undefined;
    set internalValue(value: DataKubernetesPodSpecDnsConfigOption | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecDnsConfigOptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecDnsConfigOptionOutputReference;
}
export interface DataKubernetesPodSpecDnsConfig {
}
export declare function dataKubernetesPodSpecDnsConfigToTerraform(struct?: DataKubernetesPodSpecDnsConfig): any;
export declare function dataKubernetesPodSpecDnsConfigToHclTerraform(struct?: DataKubernetesPodSpecDnsConfig): any;
export declare class DataKubernetesPodSpecDnsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecDnsConfig | undefined;
    set internalValue(value: DataKubernetesPodSpecDnsConfig | undefined);
    get nameservers(): string[];
    private _option;
    get option(): DataKubernetesPodSpecDnsConfigOptionList;
    get searches(): string[];
}
export declare class DataKubernetesPodSpecDnsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecDnsConfigOutputReference;
}
export interface DataKubernetesPodSpecHostAliases {
}
export declare function dataKubernetesPodSpecHostAliasesToTerraform(struct?: DataKubernetesPodSpecHostAliases): any;
export declare function dataKubernetesPodSpecHostAliasesToHclTerraform(struct?: DataKubernetesPodSpecHostAliases): any;
export declare class DataKubernetesPodSpecHostAliasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecHostAliases | undefined;
    set internalValue(value: DataKubernetesPodSpecHostAliases | undefined);
    get hostnames(): string[];
    get ip(): string;
}
export declare class DataKubernetesPodSpecHostAliasesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecHostAliasesOutputReference;
}
export interface DataKubernetesPodSpecImagePullSecrets {
}
export declare function dataKubernetesPodSpecImagePullSecretsToTerraform(struct?: DataKubernetesPodSpecImagePullSecrets): any;
export declare function dataKubernetesPodSpecImagePullSecretsToHclTerraform(struct?: DataKubernetesPodSpecImagePullSecrets): any;
export declare class DataKubernetesPodSpecImagePullSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecImagePullSecrets | undefined;
    set internalValue(value: DataKubernetesPodSpecImagePullSecrets | undefined);
    get name(): string;
}
export declare class DataKubernetesPodSpecImagePullSecretsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecImagePullSecretsOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRef {
}
export declare function dataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRefToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRef): any;
export declare function dataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRefToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRef): any;
export declare class DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRef | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRefOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvValueFromFieldRef {
}
export declare function dataKubernetesPodSpecInitContainerEnvValueFromFieldRefToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromFieldRef): any;
export declare function dataKubernetesPodSpecInitContainerEnvValueFromFieldRefToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromFieldRef): any;
export declare class DataKubernetesPodSpecInitContainerEnvValueFromFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvValueFromFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvValueFromFieldRef | undefined);
    get apiVersion(): string;
    get fieldPath(): string;
}
export declare class DataKubernetesPodSpecInitContainerEnvValueFromFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvValueFromFieldRefOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRef {
}
export declare function dataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRefToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRef): any;
export declare function dataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRefToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRef): any;
export declare class DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRef | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRef | undefined);
    get containerName(): string;
    get divisor(): string;
    get resource(): string;
}
export declare class DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRefOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRef {
}
export declare function dataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRefToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRef): any;
export declare function dataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRefToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRef): any;
export declare class DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRef | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRef | undefined);
    get key(): string;
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRefOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvValueFrom {
}
export declare function dataKubernetesPodSpecInitContainerEnvValueFromToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFrom): any;
export declare function dataKubernetesPodSpecInitContainerEnvValueFromToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvValueFrom): any;
export declare class DataKubernetesPodSpecInitContainerEnvValueFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvValueFrom | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvValueFrom | undefined);
    private _configMapKeyRef;
    get configMapKeyRef(): DataKubernetesPodSpecInitContainerEnvValueFromConfigMapKeyRefList;
    private _fieldRef;
    get fieldRef(): DataKubernetesPodSpecInitContainerEnvValueFromFieldRefList;
    private _resourceFieldRef;
    get resourceFieldRef(): DataKubernetesPodSpecInitContainerEnvValueFromResourceFieldRefList;
    private _secretKeyRef;
    get secretKeyRef(): DataKubernetesPodSpecInitContainerEnvValueFromSecretKeyRefList;
}
export declare class DataKubernetesPodSpecInitContainerEnvValueFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvValueFromOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnv {
}
export declare function dataKubernetesPodSpecInitContainerEnvToTerraform(struct?: DataKubernetesPodSpecInitContainerEnv): any;
export declare function dataKubernetesPodSpecInitContainerEnvToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnv): any;
export declare class DataKubernetesPodSpecInitContainerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnv | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnv | undefined);
    get name(): string;
    get value(): string;
    private _valueFrom;
    get valueFrom(): DataKubernetesPodSpecInitContainerEnvValueFromList;
}
export declare class DataKubernetesPodSpecInitContainerEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvFromConfigMapRef {
}
export declare function dataKubernetesPodSpecInitContainerEnvFromConfigMapRefToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvFromConfigMapRef): any;
export declare function dataKubernetesPodSpecInitContainerEnvFromConfigMapRefToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvFromConfigMapRef): any;
export declare class DataKubernetesPodSpecInitContainerEnvFromConfigMapRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvFromConfigMapRef | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvFromConfigMapRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecInitContainerEnvFromConfigMapRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvFromConfigMapRefOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvFromSecretRef {
}
export declare function dataKubernetesPodSpecInitContainerEnvFromSecretRefToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvFromSecretRef): any;
export declare function dataKubernetesPodSpecInitContainerEnvFromSecretRefToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvFromSecretRef): any;
export declare class DataKubernetesPodSpecInitContainerEnvFromSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvFromSecretRef | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvFromSecretRef | undefined);
    get name(): string;
    get optional(): cdktn.IResolvable;
}
export declare class DataKubernetesPodSpecInitContainerEnvFromSecretRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvFromSecretRefOutputReference;
}
export interface DataKubernetesPodSpecInitContainerEnvFrom {
}
export declare function dataKubernetesPodSpecInitContainerEnvFromToTerraform(struct?: DataKubernetesPodSpecInitContainerEnvFrom): any;
export declare function dataKubernetesPodSpecInitContainerEnvFromToHclTerraform(struct?: DataKubernetesPodSpecInitContainerEnvFrom): any;
export declare class DataKubernetesPodSpecInitContainerEnvFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerEnvFrom | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerEnvFrom | undefined);
    private _configMapRef;
    get configMapRef(): DataKubernetesPodSpecInitContainerEnvFromConfigMapRefList;
    get prefix(): string;
    private _secretRef;
    get secretRef(): DataKubernetesPodSpecInitContainerEnvFromSecretRefList;
}
export declare class DataKubernetesPodSpecInitContainerEnvFromList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerEnvFromOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePostStartExec {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartExecToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartExec): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartExecToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartExec): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePostStartExec | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePostStartExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePostStartExecOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeader {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeaderToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeaderToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeader): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeader | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeader | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeaderOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGet {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGet): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGet): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGet | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGet | undefined);
    get host(): string;
    private _httpHeader;
    get httpHeader(): DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetHttpHeaderList;
    get path(): string;
    get port(): string;
    get scheme(): string;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocket {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocketToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocket): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocketToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocket): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocket | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocket | undefined);
    get port(): string;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocketOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePostStart {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStart): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePostStartToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePostStart): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePostStart | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePostStart | undefined);
    private _exec;
    get exec(): DataKubernetesPodSpecInitContainerLifecyclePostStartExecList;
    private _httpGet;
    get httpGet(): DataKubernetesPodSpecInitContainerLifecyclePostStartHttpGetList;
    private _tcpSocket;
    get tcpSocket(): DataKubernetesPodSpecInitContainerLifecyclePostStartTcpSocketList;
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePostStartList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePostStartOutputReference;
}
export interface DataKubernetesPodSpecInitContainerLifecyclePreStopExec {
}
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopExecToTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopExec): any;
export declare function dataKubernetesPodSpecInitContainerLifecyclePreStopExecToHclTerraform(struct?: DataKubernetesPodSpecInitContainerLifecyclePreStopExec): any;
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataKubernetesPodSpecInitContainerLifecyclePreStopExec | undefined;
    set internalValue(value: DataKubernetesPodSpecInitContainerLifecyclePreStopExec | undefined);
    get command(): string[];
}
export declare class DataKubernetesPodSpecInitContainerLifecyclePreStopExecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataKubernetesPodSpecInitContainerLifecyclePreStopExecOutputReference;
}
