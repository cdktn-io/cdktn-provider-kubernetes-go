/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { ReplicationControllerV1SpecTemplateSpecInitContainerEnv, ReplicationControllerV1SpecTemplateSpecInitContainerEnvList, ReplicationControllerV1SpecTemplateSpecInitContainerEnvFrom, ReplicationControllerV1SpecTemplateSpecInitContainerEnvFromList, ReplicationControllerV1SpecTemplateSpecInitContainerLifecycle, ReplicationControllerV1SpecTemplateSpecInitContainerLifecycleOutputReference, ReplicationControllerV1SpecTemplateSpecInitContainerLivenessProbe, ReplicationControllerV1SpecTemplateSpecInitContainerLivenessProbeOutputReference, ReplicationControllerV1SpecTemplateSpecAffinity, ReplicationControllerV1SpecTemplateSpecAffinityOutputReference, ReplicationControllerV1SpecTemplateSpecContainer, ReplicationControllerV1SpecTemplateSpecContainerList, ReplicationControllerV1SpecTemplateSpecDnsConfig, ReplicationControllerV1SpecTemplateSpecDnsConfigOutputReference, ReplicationControllerV1SpecTemplateSpecHostAliases, ReplicationControllerV1SpecTemplateSpecHostAliasesList, ReplicationControllerV1SpecTemplateSpecImagePullSecrets, ReplicationControllerV1SpecTemplateSpecImagePullSecretsList, ReplicationControllerV1SpecTemplateMetadata, ReplicationControllerV1SpecTemplateMetadataOutputReference } from './structs0';
export interface ReplicationControllerV1SpecTemplateSpecInitContainerPort {
    /**
    * Number of port to expose on the pod's IP address. This must be a valid port number, 0 < x < 65536.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#container_port ReplicationControllerV1#container_port}
    */
    readonly containerPort: number;
    /**
    * What host IP to bind the external port to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_ip ReplicationControllerV1#host_ip}
    */
    readonly hostIp?: string;
    /**
    * Number of port to expose on the host. If specified, this must be a valid port number, 0 < x < 65536. If HostNetwork is specified, this must match ContainerPort. Most containers do not need this.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_port ReplicationControllerV1#host_port}
    */
    readonly hostPort?: number;
    /**
    * If specified, this must be an IANA_SVC_NAME and unique within the pod. Each named port in a pod must have a unique name. Name for the port that can be referred to by services
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Protocol for port. Must be UDP or TCP. Defaults to "TCP".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#protocol ReplicationControllerV1#protocol}
    */
    readonly protocol?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerPortToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerPortToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerPort | cdktn.IResolvable | undefined);
    private _containerPort?;
    get containerPort(): number;
    set containerPort(value: number);
    get containerPortInput(): number | undefined;
    private _hostIp?;
    get hostIp(): string;
    set hostIp(value: string);
    resetHostIp(): void;
    get hostIpInput(): string | undefined;
    private _hostPort?;
    get hostPort(): number;
    set hostPort(value: number);
    resetHostPort(): void;
    get hostPortInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerPortList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerPortOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec {
    /**
    * Command is the command line to execute inside the container, the working directory for the command is root ('/') in the container's filesystem. The command is simply exec'd, it is not run inside a shell, so traditional shell instructions. To use a shell, you need to explicitly call out to that shell. Exit status of 0 is treated as live/healthy and non-zero is unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#command ReplicationControllerV1#command}
    */
    readonly command?: string[];
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExecToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExecToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc {
    /**
    * Number of the port to access on the container. Number must be in the range 1 to 65535.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port: number;
    /**
    * Name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md). If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#service ReplicationControllerV1#service}
    */
    readonly service?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpcToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpcToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc | cdktn.IResolvable | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpcList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpcOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#value ReplicationControllerV1#value}
    */
    readonly value?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet {
    /**
    * Host name to connect to, defaults to the pod IP. You probably want to set "Host" in httpHeaders instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host ReplicationControllerV1#host}
    */
    readonly host?: string;
    /**
    * Path to access on the HTTP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
    /**
    * Name or number of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port?: string;
    /**
    * Scheme to use for connecting to the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#scheme ReplicationControllerV1#scheme}
    */
    readonly scheme?: string;
    /**
    * http_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#http_header ReplicationControllerV1#http_header}
    */
    readonly httpHeader?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _httpHeader;
    get httpHeader(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeaderList;
    putHttpHeader(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | cdktn.IResolvable): void;
    resetHttpHeader(): void;
    get httpHeaderInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetHttpHeader[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket {
    /**
    * Number or name of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket | cdktn.IResolvable | undefined);
    private _port?;
    get port(): string;
    set port(value: string);
    get portInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#failure_threshold ReplicationControllerV1#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before liveness probes are initiated. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#initial_delay_seconds ReplicationControllerV1#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#period_seconds ReplicationControllerV1#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Minimum consecutive successes for the probe to be considered successful after having failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#success_threshold ReplicationControllerV1#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * Number of seconds after which the probe times out. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#timeout_seconds ReplicationControllerV1#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * exec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#exec ReplicationControllerV1#exec}
    */
    readonly exec?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#grpc ReplicationControllerV1#grpc}
    */
    readonly grpc?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | cdktn.IResolvable;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#http_get ReplicationControllerV1#http_get}
    */
    readonly httpGet?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#tcp_socket ReplicationControllerV1#tcp_socket}
    */
    readonly tcpSocket?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerReadinessProbeToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _exec;
    get exec(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExecOutputReference;
    putExec(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec): void;
    resetExec(): void;
    get execInput(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeExec | undefined;
    private _grpc;
    get grpc(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpcList;
    putGrpc(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | cdktn.IResolvable): void;
    resetGrpc(): void;
    get grpcInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeGrpc[] | undefined;
    private _httpGet;
    get httpGet(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGetOutputReference;
    putHttpGet(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocketList;
    putTcpSocket(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | cdktn.IResolvable): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeTcpSocket[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerResources {
    /**
    * Describes the maximum amount of compute resources allowed. More info: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#limits ReplicationControllerV1#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Requests describes the minimum amount of compute resources required. If Requests is omitted for a container, it defaults to Limits if that is explicitly specified, otherwise to an implementation-defined value. More info: https://kubernetes.io/docs/concepts/configuration/manage-compute-resources-container/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#requests ReplicationControllerV1#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerResourcesToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerResourcesOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerResources): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerResourcesToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerResourcesOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerResources): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerResources | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerResources | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities {
    /**
    * Added capabilities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#add ReplicationControllerV1#add}
    */
    readonly add?: string[];
    /**
    * Removed capabilities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#drop ReplicationControllerV1#drop}
    */
    readonly drop?: string[];
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities | undefined);
    private _add?;
    get add(): string[];
    set add(value: string[]);
    resetAdd(): void;
    get addInput(): string[] | undefined;
    private _drop?;
    get drop(): string[];
    set drop(value: string[]);
    resetDrop(): void;
    get dropInput(): string[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions {
    /**
    * Level is SELinux level label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#level ReplicationControllerV1#level}
    */
    readonly level?: string;
    /**
    * Role is a SELinux role label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#role ReplicationControllerV1#role}
    */
    readonly role?: string;
    /**
    * Type is a SELinux type label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#type ReplicationControllerV1#type}
    */
    readonly type?: string;
    /**
    * User is a SELinux user label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#user ReplicationControllerV1#user}
    */
    readonly user?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile {
    /**
    * Localhost Profile indicates a profile defined in a file on the node should be used. The profile must be preconfigured on the node to work.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#localhost_profile ReplicationControllerV1#localhost_profile}
    */
    readonly localhostProfile?: string;
    /**
    * Type indicates which kind of seccomp profile will be applied. Valid options are: Localhost, RuntimeDefault, Unconfined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#type ReplicationControllerV1#type}
    */
    readonly type?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile | undefined);
    private _localhostProfile?;
    get localhostProfile(): string;
    set localhostProfile(value: string);
    resetLocalhostProfile(): void;
    get localhostProfileInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext {
    /**
    * AllowPrivilegeEscalation controls whether a process can gain more privileges than its parent process. This bool directly controls if the no_new_privs flag will be set on the container process. AllowPrivilegeEscalation is true always when the container is: 1) run as Privileged 2) has CAP_SYS_ADMIN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#allow_privilege_escalation ReplicationControllerV1#allow_privilege_escalation}
    */
    readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
    /**
    * Run container in privileged mode. Processes in privileged containers are essentially equivalent to root on the host. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#privileged ReplicationControllerV1#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Whether this container has a read-only root filesystem. Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only_root_filesystem ReplicationControllerV1#read_only_root_filesystem}
    */
    readonly readOnlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * The GID to run the entrypoint of the container process. Uses runtime default if unset. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_group ReplicationControllerV1#run_as_group}
    */
    readonly runAsGroup?: string;
    /**
    * Indicates that the container must run as a non-root user. If true, the Kubelet will validate the image at runtime to ensure that it does not run as UID 0 (root) and fail to start the container if it does. If unset or false, no such validation will be performed. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_non_root ReplicationControllerV1#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * The UID to run the entrypoint of the container process. Defaults to user specified in image metadata if unspecified. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_user ReplicationControllerV1#run_as_user}
    */
    readonly runAsUser?: string;
    /**
    * capabilities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#capabilities ReplicationControllerV1#capabilities}
    */
    readonly capabilities?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities;
    /**
    * se_linux_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#se_linux_options ReplicationControllerV1#se_linux_options}
    */
    readonly seLinuxOptions?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions;
    /**
    * seccomp_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#seccomp_profile ReplicationControllerV1#seccomp_profile}
    */
    readonly seccompProfile?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerSecurityContextToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext | undefined);
    private _allowPrivilegeEscalation?;
    get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
    set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
    resetAllowPrivilegeEscalation(): void;
    get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readOnlyRootFilesystem?;
    get readOnlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readOnlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadOnlyRootFilesystem(): void;
    get readOnlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsGroup?;
    get runAsGroup(): string;
    set runAsGroup(value: string);
    resetRunAsGroup(): void;
    get runAsGroupInput(): string | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): string;
    set runAsUser(value: string);
    resetRunAsUser(): void;
    get runAsUserInput(): string | undefined;
    private _capabilities;
    get capabilities(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilitiesOutputReference;
    putCapabilities(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities): void;
    resetCapabilities(): void;
    get capabilitiesInput(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextCapabilities | undefined;
    private _seLinuxOptions;
    get seLinuxOptions(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptionsOutputReference;
    putSeLinuxOptions(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions): void;
    resetSeLinuxOptions(): void;
    get seLinuxOptionsInput(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeLinuxOptions | undefined;
    private _seccompProfile;
    get seccompProfile(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfileOutputReference;
    putSeccompProfile(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile): void;
    resetSeccompProfile(): void;
    get seccompProfileInput(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextSeccompProfile | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec {
    /**
    * Command is the command line to execute inside the container, the working directory for the command is root ('/') in the container's filesystem. The command is simply exec'd, it is not run inside a shell, so traditional shell instructions. To use a shell, you need to explicitly call out to that shell. Exit status of 0 is treated as live/healthy and non-zero is unhealthy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#command ReplicationControllerV1#command}
    */
    readonly command?: string[];
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeExecToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeExecToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc {
    /**
    * Number of the port to access on the container. Number must be in the range 1 to 65535.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port: number;
    /**
    * Name of the service to place in the gRPC HealthCheckRequest (see https://github.com/grpc/grpc/blob/master/doc/health-checking.md). If this is not specified, the default behavior is defined by gRPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#service ReplicationControllerV1#service}
    */
    readonly service?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpcToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpcToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc | cdktn.IResolvable | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpcList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpcOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader {
    /**
    * The header field name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * The header field value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#value ReplicationControllerV1#value}
    */
    readonly value?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet {
    /**
    * Host name to connect to, defaults to the pod IP. You probably want to set "Host" in httpHeaders instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host ReplicationControllerV1#host}
    */
    readonly host?: string;
    /**
    * Path to access on the HTTP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
    /**
    * Name or number of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port?: string;
    /**
    * Scheme to use for connecting to the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#scheme ReplicationControllerV1#scheme}
    */
    readonly scheme?: string;
    /**
    * http_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#http_header ReplicationControllerV1#http_header}
    */
    readonly httpHeader?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _httpHeader;
    get httpHeader(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeaderList;
    putHttpHeader(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | cdktn.IResolvable): void;
    resetHttpHeader(): void;
    get httpHeaderInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetHttpHeader[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket {
    /**
    * Number or name of the port to access on the container. Number must be in the range 1 to 65535. Name must be an IANA_SVC_NAME.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocketToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocketToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket | cdktn.IResolvable | undefined);
    private _port?;
    get port(): string;
    set port(value: string);
    get portInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocketList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocketOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe {
    /**
    * Minimum consecutive failures for the probe to be considered failed after having succeeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#failure_threshold ReplicationControllerV1#failure_threshold}
    */
    readonly failureThreshold?: number;
    /**
    * Number of seconds after the container has started before liveness probes are initiated. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#initial_delay_seconds ReplicationControllerV1#initial_delay_seconds}
    */
    readonly initialDelaySeconds?: number;
    /**
    * How often (in seconds) to perform the probe
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#period_seconds ReplicationControllerV1#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * Minimum consecutive successes for the probe to be considered successful after having failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#success_threshold ReplicationControllerV1#success_threshold}
    */
    readonly successThreshold?: number;
    /**
    * Number of seconds after which the probe times out. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#timeout_seconds ReplicationControllerV1#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * exec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#exec ReplicationControllerV1#exec}
    */
    readonly exec?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec;
    /**
    * grpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#grpc ReplicationControllerV1#grpc}
    */
    readonly grpc?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | cdktn.IResolvable;
    /**
    * http_get block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#http_get ReplicationControllerV1#http_get}
    */
    readonly httpGet?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet;
    /**
    * tcp_socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#tcp_socket ReplicationControllerV1#tcp_socket}
    */
    readonly tcpSocket?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerStartupProbeToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeOutputReference | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe | undefined);
    private _failureThreshold?;
    get failureThreshold(): number;
    set failureThreshold(value: number);
    resetFailureThreshold(): void;
    get failureThresholdInput(): number | undefined;
    private _initialDelaySeconds?;
    get initialDelaySeconds(): number;
    set initialDelaySeconds(value: number);
    resetInitialDelaySeconds(): void;
    get initialDelaySecondsInput(): number | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _successThreshold?;
    get successThreshold(): number;
    set successThreshold(value: number);
    resetSuccessThreshold(): void;
    get successThresholdInput(): number | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _exec;
    get exec(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExecOutputReference;
    putExec(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec): void;
    resetExec(): void;
    get execInput(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeExec | undefined;
    private _grpc;
    get grpc(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpcList;
    putGrpc(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | cdktn.IResolvable): void;
    resetGrpc(): void;
    get grpcInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeGrpc[] | undefined;
    private _httpGet;
    get httpGet(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGetOutputReference;
    putHttpGet(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet): void;
    resetHttpGet(): void;
    get httpGetInput(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeHttpGet | undefined;
    private _tcpSocket;
    get tcpSocket(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocketList;
    putTcpSocket(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | cdktn.IResolvable): void;
    resetTcpSocket(): void;
    get tcpSocketInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeTcpSocket[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice {
    /**
    * Path within the container at which the volume device should be attached. For example '/dev/xvda'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#device_path ReplicationControllerV1#device_path}
    */
    readonly devicePath: string;
    /**
    * This must match the Name of a PersistentVolumeClaim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerVolumeDeviceToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerVolumeDeviceToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice | cdktn.IResolvable | undefined);
    private _devicePath?;
    get devicePath(): string;
    set devicePath(value: string);
    get devicePathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDeviceList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDeviceOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount {
    /**
    * Path within the container at which the volume should be mounted. Must not contain ':'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mount_path ReplicationControllerV1#mount_path}
    */
    readonly mountPath: string;
    /**
    * Mount propagation mode. mount_propagation determines how mounts are propagated from the host to container and the other way around. Valid values are None (default), HostToContainer and Bidirectional.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mount_propagation ReplicationControllerV1#mount_propagation}
    */
    readonly mountPropagation?: string;
    /**
    * This must match the Name of a Volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name: string;
    /**
    * Mounted read-only if true, read-write otherwise (false or unspecified). Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Path within the volume from which the container's volume should be mounted. Defaults to "" (volume's root).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#sub_path ReplicationControllerV1#sub_path}
    */
    readonly subPath?: string;
    /**
    * Dynamic path within the volume from which the container's volume should be mounted. Defaults to "" (volume's root).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#sub_path_expr ReplicationControllerV1#sub_path_expr}
    */
    readonly subPathExpr?: string;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerVolumeMountToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerVolumeMountToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
    private _mountPropagation?;
    get mountPropagation(): string;
    set mountPropagation(value: string);
    resetMountPropagation(): void;
    get mountPropagationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
    private _subPathExpr?;
    get subPathExpr(): string;
    set subPathExpr(value: string);
    resetSubPathExpr(): void;
    get subPathExprInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMountList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMountOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecInitContainer {
    /**
    * Arguments to the entrypoint. The docker image's CMD is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. Cannot be updated. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#args ReplicationControllerV1#args}
    */
    readonly args?: string[];
    /**
    * Entrypoint array. Not executed within a shell. The docker image's ENTRYPOINT is used if this is not provided. Variable references $(VAR_NAME) are expanded using the container's environment. If a variable cannot be resolved, the reference in the input string will be unchanged. The $(VAR_NAME) syntax can be escaped with a double $$, ie: $$(VAR_NAME). Escaped references will never be expanded, regardless of whether the variable exists or not. Cannot be updated. More info: https://kubernetes.io/docs/tasks/inject-data-application/define-command-argument-container/#running-a-command-in-a-shell
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#command ReplicationControllerV1#command}
    */
    readonly command?: string[];
    /**
    * Docker image name. More info: https://kubernetes.io/docs/concepts/containers/images/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#image ReplicationControllerV1#image}
    */
    readonly image?: string;
    /**
    * Image pull policy. One of Always, Never, IfNotPresent. Defaults to Always if :latest tag is specified, or IfNotPresent otherwise. Cannot be updated. More info: https://kubernetes.io/docs/concepts/containers/images/#updating-images
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#image_pull_policy ReplicationControllerV1#image_pull_policy}
    */
    readonly imagePullPolicy?: string;
    /**
    * Name of the container specified as a DNS_LABEL. Each container in a pod must have a unique name (DNS_LABEL). Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name: string;
    /**
    * Whether this container should allocate a buffer for stdin in the container runtime. If this is not set, reads from stdin in the container will always result in EOF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#stdin ReplicationControllerV1#stdin}
    */
    readonly stdin?: boolean | cdktn.IResolvable;
    /**
    * Whether the container runtime should close the stdin channel after it has been opened by a single attach. When stdin is true the stdin stream will remain open across multiple attach sessions. If stdinOnce is set to true, stdin is opened on container start, is empty until the first client attaches to stdin, and then remains open and accepts data until the client disconnects, at which time stdin is closed and remains closed until the container is restarted. If this flag is false, a container processes that reads from stdin will never receive an EOF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#stdin_once ReplicationControllerV1#stdin_once}
    */
    readonly stdinOnce?: boolean | cdktn.IResolvable;
    /**
    * Optional: Path at which the file to which the container's termination message will be written is mounted into the container's filesystem. Message written is intended to be brief final status, such as an assertion failure message. Defaults to /dev/termination-log. Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#termination_message_path ReplicationControllerV1#termination_message_path}
    */
    readonly terminationMessagePath?: string;
    /**
    * Optional: Indicate how the termination message should be populated. File will use the contents of terminationMessagePath to populate the container status message on both success and failure. FallbackToLogsOnError will use the last chunk of container log output if the termination message file is empty and the container exited with an error. The log output is limited to 2048 bytes or 80 lines, whichever is smaller. Defaults to File. Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#termination_message_policy ReplicationControllerV1#termination_message_policy}
    */
    readonly terminationMessagePolicy?: string;
    /**
    * Whether this container should allocate a TTY for itself
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#tty ReplicationControllerV1#tty}
    */
    readonly tty?: boolean | cdktn.IResolvable;
    /**
    * Container's working directory. If not specified, the container runtime's default will be used, which might be configured in the container image. Cannot be updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#working_dir ReplicationControllerV1#working_dir}
    */
    readonly workingDir?: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#env ReplicationControllerV1#env}
    */
    readonly env?: ReplicationControllerV1SpecTemplateSpecInitContainerEnv[] | cdktn.IResolvable;
    /**
    * env_from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#env_from ReplicationControllerV1#env_from}
    */
    readonly envFrom?: ReplicationControllerV1SpecTemplateSpecInitContainerEnvFrom[] | cdktn.IResolvable;
    /**
    * lifecycle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#lifecycle ReplicationControllerV1#lifecycle}
    */
    readonly lifecycle?: ReplicationControllerV1SpecTemplateSpecInitContainerLifecycle;
    /**
    * liveness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#liveness_probe ReplicationControllerV1#liveness_probe}
    */
    readonly livenessProbe?: ReplicationControllerV1SpecTemplateSpecInitContainerLivenessProbe;
    /**
    * port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#port ReplicationControllerV1#port}
    */
    readonly port?: ReplicationControllerV1SpecTemplateSpecInitContainerPort[] | cdktn.IResolvable;
    /**
    * readiness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#readiness_probe ReplicationControllerV1#readiness_probe}
    */
    readonly readinessProbe?: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#resources ReplicationControllerV1#resources}
    */
    readonly resources?: ReplicationControllerV1SpecTemplateSpecInitContainerResources;
    /**
    * security_context block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#security_context ReplicationControllerV1#security_context}
    */
    readonly securityContext?: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext;
    /**
    * startup_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#startup_probe ReplicationControllerV1#startup_probe}
    */
    readonly startupProbe?: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe;
    /**
    * volume_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_device ReplicationControllerV1#volume_device}
    */
    readonly volumeDevice?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice[] | cdktn.IResolvable;
    /**
    * volume_mount block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_mount ReplicationControllerV1#volume_mount}
    */
    readonly volumeMount?: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecInitContainerToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainer | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecInitContainerToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecInitContainer | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecInitContainer | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecInitContainer | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imagePullPolicy?;
    get imagePullPolicy(): string;
    set imagePullPolicy(value: string);
    resetImagePullPolicy(): void;
    get imagePullPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _stdin?;
    get stdin(): boolean | cdktn.IResolvable;
    set stdin(value: boolean | cdktn.IResolvable);
    resetStdin(): void;
    get stdinInput(): boolean | cdktn.IResolvable | undefined;
    private _stdinOnce?;
    get stdinOnce(): boolean | cdktn.IResolvable;
    set stdinOnce(value: boolean | cdktn.IResolvable);
    resetStdinOnce(): void;
    get stdinOnceInput(): boolean | cdktn.IResolvable | undefined;
    private _terminationMessagePath?;
    get terminationMessagePath(): string;
    set terminationMessagePath(value: string);
    resetTerminationMessagePath(): void;
    get terminationMessagePathInput(): string | undefined;
    private _terminationMessagePolicy?;
    get terminationMessagePolicy(): string;
    set terminationMessagePolicy(value: string);
    resetTerminationMessagePolicy(): void;
    get terminationMessagePolicyInput(): string | undefined;
    private _tty?;
    get tty(): boolean | cdktn.IResolvable;
    set tty(value: boolean | cdktn.IResolvable);
    resetTty(): void;
    get ttyInput(): boolean | cdktn.IResolvable | undefined;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    private _env;
    get env(): ReplicationControllerV1SpecTemplateSpecInitContainerEnvList;
    putEnv(value: ReplicationControllerV1SpecTemplateSpecInitContainerEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerEnv[] | undefined;
    private _envFrom;
    get envFrom(): ReplicationControllerV1SpecTemplateSpecInitContainerEnvFromList;
    putEnvFrom(value: ReplicationControllerV1SpecTemplateSpecInitContainerEnvFrom[] | cdktn.IResolvable): void;
    resetEnvFrom(): void;
    get envFromInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerEnvFrom[] | undefined;
    private _lifecycle;
    get lifecycle(): ReplicationControllerV1SpecTemplateSpecInitContainerLifecycleOutputReference;
    putLifecycle(value: ReplicationControllerV1SpecTemplateSpecInitContainerLifecycle): void;
    resetLifecycle(): void;
    get lifecycleInput(): ReplicationControllerV1SpecTemplateSpecInitContainerLifecycle | undefined;
    private _livenessProbe;
    get livenessProbe(): ReplicationControllerV1SpecTemplateSpecInitContainerLivenessProbeOutputReference;
    putLivenessProbe(value: ReplicationControllerV1SpecTemplateSpecInitContainerLivenessProbe): void;
    resetLivenessProbe(): void;
    get livenessProbeInput(): ReplicationControllerV1SpecTemplateSpecInitContainerLivenessProbe | undefined;
    private _port;
    get port(): ReplicationControllerV1SpecTemplateSpecInitContainerPortList;
    putPort(value: ReplicationControllerV1SpecTemplateSpecInitContainerPort[] | cdktn.IResolvable): void;
    resetPort(): void;
    get portInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerPort[] | undefined;
    private _readinessProbe;
    get readinessProbe(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbeOutputReference;
    putReadinessProbe(value: ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe): void;
    resetReadinessProbe(): void;
    get readinessProbeInput(): ReplicationControllerV1SpecTemplateSpecInitContainerReadinessProbe | undefined;
    private _resources;
    get resources(): ReplicationControllerV1SpecTemplateSpecInitContainerResourcesOutputReference;
    putResources(value: ReplicationControllerV1SpecTemplateSpecInitContainerResources): void;
    resetResources(): void;
    get resourcesInput(): ReplicationControllerV1SpecTemplateSpecInitContainerResources | undefined;
    private _securityContext;
    get securityContext(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContextOutputReference;
    putSecurityContext(value: ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): ReplicationControllerV1SpecTemplateSpecInitContainerSecurityContext | undefined;
    private _startupProbe;
    get startupProbe(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbeOutputReference;
    putStartupProbe(value: ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe): void;
    resetStartupProbe(): void;
    get startupProbeInput(): ReplicationControllerV1SpecTemplateSpecInitContainerStartupProbe | undefined;
    private _volumeDevice;
    get volumeDevice(): ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDeviceList;
    putVolumeDevice(value: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice[] | cdktn.IResolvable): void;
    resetVolumeDevice(): void;
    get volumeDeviceInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerVolumeDevice[] | undefined;
    private _volumeMount;
    get volumeMount(): ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMountList;
    putVolumeMount(value: ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount[] | cdktn.IResolvable): void;
    resetVolumeMount(): void;
    get volumeMountInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainerVolumeMount[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecInitContainerList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecInitContainer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecInitContainerOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecOs {
    /**
    * Name is the name of the operating system. The currently supported values are linux and windows.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name: string;
}
export declare function replicationControllerV1SpecTemplateSpecOsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecOsOutputReference | ReplicationControllerV1SpecTemplateSpecOs): any;
export declare function replicationControllerV1SpecTemplateSpecOsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecOsOutputReference | ReplicationControllerV1SpecTemplateSpecOs): any;
export declare class ReplicationControllerV1SpecTemplateSpecOsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecOs | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecOs | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecReadinessGate {
    /**
    * refers to a condition in the pod's condition list with matching type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#condition_type ReplicationControllerV1#condition_type}
    */
    readonly conditionType: string;
}
export declare function replicationControllerV1SpecTemplateSpecReadinessGateToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecReadinessGate | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecReadinessGateToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecReadinessGate | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecReadinessGateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecReadinessGate | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecReadinessGate | cdktn.IResolvable | undefined);
    private _conditionType?;
    get conditionType(): string;
    set conditionType(value: string);
    get conditionTypeInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecReadinessGateList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecReadinessGate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecReadinessGateOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions {
    /**
    * Level is SELinux level label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#level ReplicationControllerV1#level}
    */
    readonly level?: string;
    /**
    * Role is a SELinux role label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#role ReplicationControllerV1#role}
    */
    readonly role?: string;
    /**
    * Type is a SELinux type label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#type ReplicationControllerV1#type}
    */
    readonly type?: string;
    /**
    * User is a SELinux user label that applies to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#user ReplicationControllerV1#user}
    */
    readonly user?: string;
}
export declare function replicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptionsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions): any;
export declare function replicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptionsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions): any;
export declare class ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile {
    /**
    * Localhost Profile indicates a profile defined in a file on the node should be used. The profile must be preconfigured on the node to work.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#localhost_profile ReplicationControllerV1#localhost_profile}
    */
    readonly localhostProfile?: string;
    /**
    * Type indicates which kind of seccomp profile will be applied. Valid options are: Localhost, RuntimeDefault, Unconfined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#type ReplicationControllerV1#type}
    */
    readonly type?: string;
}
export declare function replicationControllerV1SpecTemplateSpecSecurityContextSeccompProfileToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile): any;
export declare function replicationControllerV1SpecTemplateSpecSecurityContextSeccompProfileToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile): any;
export declare class ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile | undefined);
    private _localhostProfile?;
    get localhostProfile(): string;
    set localhostProfile(value: string);
    resetLocalhostProfile(): void;
    get localhostProfileInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl {
    /**
    * Name of a property to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name: string;
    /**
    * Value of a property to set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#value ReplicationControllerV1#value}
    */
    readonly value: string;
}
export declare function replicationControllerV1SpecTemplateSpecSecurityContextSysctlToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecSecurityContextSysctlToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecSecurityContextSysctlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecSecurityContextSysctlList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecSecurityContextSysctlOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions {
    /**
    * GMSACredentialSpec is where the GMSA admission webhook inlines the contents of the GMSA credential spec named by the GMSACredentialSpecName field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#gmsa_credential_spec ReplicationControllerV1#gmsa_credential_spec}
    */
    readonly gmsaCredentialSpec?: string;
    /**
    * GMSACredentialSpecName is the name of the GMSA credential spec to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#gmsa_credential_spec_name ReplicationControllerV1#gmsa_credential_spec_name}
    */
    readonly gmsaCredentialSpecName?: string;
    /**
    * HostProcess determines if a container should be run as a 'Host Process' container. Default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_process ReplicationControllerV1#host_process}
    */
    readonly hostProcess?: boolean | cdktn.IResolvable;
    /**
    * The UserName in Windows to run the entrypoint of the container process. Defaults to the user specified in image metadata if unspecified. May also be set in PodSecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_username ReplicationControllerV1#run_as_username}
    */
    readonly runAsUsername?: string;
}
export declare function replicationControllerV1SpecTemplateSpecSecurityContextWindowsOptionsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions): any;
export declare function replicationControllerV1SpecTemplateSpecSecurityContextWindowsOptionsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions): any;
export declare class ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions | undefined);
    private _gmsaCredentialSpec?;
    get gmsaCredentialSpec(): string;
    set gmsaCredentialSpec(value: string);
    resetGmsaCredentialSpec(): void;
    get gmsaCredentialSpecInput(): string | undefined;
    private _gmsaCredentialSpecName?;
    get gmsaCredentialSpecName(): string;
    set gmsaCredentialSpecName(value: string);
    resetGmsaCredentialSpecName(): void;
    get gmsaCredentialSpecNameInput(): string | undefined;
    private _hostProcess?;
    get hostProcess(): boolean | cdktn.IResolvable;
    set hostProcess(value: boolean | cdktn.IResolvable);
    resetHostProcess(): void;
    get hostProcessInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUsername?;
    get runAsUsername(): string;
    set runAsUsername(value: string);
    resetRunAsUsername(): void;
    get runAsUsernameInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecSecurityContext {
    /**
    * A special supplemental group that applies to all containers in a pod. Some volume types allow the Kubelet to change the ownership of that volume to be owned by the pod: 1. The owning GID will be the FSGroup 2. The setgid bit is set (new files created in the volume will be owned by FSGroup) 3. The permission bits are OR'd with rw-rw---- If unset, the Kubelet will not modify the ownership and permissions of any volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_group ReplicationControllerV1#fs_group}
    */
    readonly fsGroup?: string;
    /**
    * fsGroupChangePolicy defines behavior of changing ownership and permission of the volume before being exposed inside Pod. This field will only apply to volume types which support fsGroup based ownership(and permissions). It will have no effect on ephemeral volume types such as: secret, configmaps and emptydir.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_group_change_policy ReplicationControllerV1#fs_group_change_policy}
    */
    readonly fsGroupChangePolicy?: string;
    /**
    * The GID to run the entrypoint of the container process. Uses runtime default if unset. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_group ReplicationControllerV1#run_as_group}
    */
    readonly runAsGroup?: string;
    /**
    * Indicates that the container must run as a non-root user. If true, the Kubelet will validate the image at runtime to ensure that it does not run as UID 0 (root) and fail to start the container if it does. If unset or false, no such validation will be performed. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_non_root ReplicationControllerV1#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * The UID to run the entrypoint of the container process. Defaults to user specified in image metadata if unspecified. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#run_as_user ReplicationControllerV1#run_as_user}
    */
    readonly runAsUser?: string;
    /**
    * A list of groups applied to the first process run in each container, in addition to the container's primary GID. If unspecified, no groups will be added to any container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#supplemental_groups ReplicationControllerV1#supplemental_groups}
    */
    readonly supplementalGroups?: number[];
    /**
    * se_linux_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#se_linux_options ReplicationControllerV1#se_linux_options}
    */
    readonly seLinuxOptions?: ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions;
    /**
    * seccomp_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#seccomp_profile ReplicationControllerV1#seccomp_profile}
    */
    readonly seccompProfile?: ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile;
    /**
    * sysctl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#sysctl ReplicationControllerV1#sysctl}
    */
    readonly sysctl?: ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl[] | cdktn.IResolvable;
    /**
    * windows_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#windows_options ReplicationControllerV1#windows_options}
    */
    readonly windowsOptions?: ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions;
}
export declare function replicationControllerV1SpecTemplateSpecSecurityContextToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContext): any;
export declare function replicationControllerV1SpecTemplateSpecSecurityContextToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecSecurityContextOutputReference | ReplicationControllerV1SpecTemplateSpecSecurityContext): any;
export declare class ReplicationControllerV1SpecTemplateSpecSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecSecurityContext | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecSecurityContext | undefined);
    private _fsGroup?;
    get fsGroup(): string;
    set fsGroup(value: string);
    resetFsGroup(): void;
    get fsGroupInput(): string | undefined;
    private _fsGroupChangePolicy?;
    get fsGroupChangePolicy(): string;
    set fsGroupChangePolicy(value: string);
    resetFsGroupChangePolicy(): void;
    get fsGroupChangePolicyInput(): string | undefined;
    private _runAsGroup?;
    get runAsGroup(): string;
    set runAsGroup(value: string);
    resetRunAsGroup(): void;
    get runAsGroupInput(): string | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): string;
    set runAsUser(value: string);
    resetRunAsUser(): void;
    get runAsUserInput(): string | undefined;
    private _supplementalGroups?;
    get supplementalGroups(): number[];
    set supplementalGroups(value: number[]);
    resetSupplementalGroups(): void;
    get supplementalGroupsInput(): number[] | undefined;
    private _seLinuxOptions;
    get seLinuxOptions(): ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptionsOutputReference;
    putSeLinuxOptions(value: ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions): void;
    resetSeLinuxOptions(): void;
    get seLinuxOptionsInput(): ReplicationControllerV1SpecTemplateSpecSecurityContextSeLinuxOptions | undefined;
    private _seccompProfile;
    get seccompProfile(): ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfileOutputReference;
    putSeccompProfile(value: ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile): void;
    resetSeccompProfile(): void;
    get seccompProfileInput(): ReplicationControllerV1SpecTemplateSpecSecurityContextSeccompProfile | undefined;
    private _sysctl;
    get sysctl(): ReplicationControllerV1SpecTemplateSpecSecurityContextSysctlList;
    putSysctl(value: ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl[] | cdktn.IResolvable): void;
    resetSysctl(): void;
    get sysctlInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecSecurityContextSysctl[] | undefined;
    private _windowsOptions;
    get windowsOptions(): ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptionsOutputReference;
    putWindowsOptions(value: ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions): void;
    resetWindowsOptions(): void;
    get windowsOptionsInput(): ReplicationControllerV1SpecTemplateSpecSecurityContextWindowsOptions | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecToleration {
    /**
    * Effect indicates the taint effect to match. Empty means match all taint effects. When specified, allowed values are NoSchedule, PreferNoSchedule and NoExecute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#effect ReplicationControllerV1#effect}
    */
    readonly effect?: string;
    /**
    * Key is the taint key that the toleration applies to. Empty means match all taint keys. If the key is empty, operator must be Exists; this combination means to match all values and all keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * Operator represents a key's relationship to the value. Valid operators are Exists and Equal. Defaults to Equal. Exists is equivalent to wildcard for value, so that a pod can tolerate all taints of a particular category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#operator ReplicationControllerV1#operator}
    */
    readonly operator?: string;
    /**
    * TolerationSeconds represents the period of time the toleration (which must be of effect NoExecute, otherwise this field is ignored) tolerates the taint. By default, it is not set, which means tolerate the taint forever (do not evict). Zero and negative values will be treated as 0 (evict immediately) by the system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#toleration_seconds ReplicationControllerV1#toleration_seconds}
    */
    readonly tolerationSeconds?: string;
    /**
    * Value is the taint value the toleration matches to. If the operator is Exists, the value should be empty, otherwise just a regular string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#value ReplicationControllerV1#value}
    */
    readonly value?: string;
}
export declare function replicationControllerV1SpecTemplateSpecTolerationToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecToleration | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecTolerationToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecToleration | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecTolerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecToleration | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecToleration | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    resetEffect(): void;
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _tolerationSeconds?;
    get tolerationSeconds(): string;
    set tolerationSeconds(value: string);
    resetTolerationSeconds(): void;
    get tolerationSecondsInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecTolerationList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecToleration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecTolerationOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#operator ReplicationControllerV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#values ReplicationControllerV1#values}
    */
    readonly values?: string[];
}
export declare function replicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#match_labels ReplicationControllerV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#match_expressions ReplicationControllerV1#match_expressions}
    */
    readonly matchExpressions?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressionsList;
    putMatchExpressions(value: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorMatchExpressions[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint {
    /**
    * is a set of pod label keys to select the pods over which spreading will be calculated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#match_label_keys ReplicationControllerV1#match_label_keys}
    */
    readonly matchLabelKeys?: string[];
    /**
    * describes the degree to which pods may be unevenly distributed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#max_skew ReplicationControllerV1#max_skew}
    */
    readonly maxSkew?: number;
    /**
    * indicates a minimum number of eligible domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#min_domains ReplicationControllerV1#min_domains}
    */
    readonly minDomains?: number;
    /**
    * indicates how we will treat Pod's nodeAffinity/nodeSelector when calculating pod topology spread skew.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#node_affinity_policy ReplicationControllerV1#node_affinity_policy}
    */
    readonly nodeAffinityPolicy?: string;
    /**
    * indicates how we will treat node taints when calculating pod topology spread skew.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#node_taints_policy ReplicationControllerV1#node_taints_policy}
    */
    readonly nodeTaintsPolicy?: string;
    /**
    * the key of node labels. Nodes that have a label with this key and identical values are considered to be in the same topology.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#topology_key ReplicationControllerV1#topology_key}
    */
    readonly topologyKey?: string;
    /**
    * indicates how to deal with a pod if it doesn't satisfy the spread constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#when_unsatisfiable ReplicationControllerV1#when_unsatisfiable}
    */
    readonly whenUnsatisfiable?: string;
    /**
    * label_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#label_selector ReplicationControllerV1#label_selector}
    */
    readonly labelSelector?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecTopologySpreadConstraintToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecTopologySpreadConstraintToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint | cdktn.IResolvable | undefined);
    private _matchLabelKeys?;
    get matchLabelKeys(): string[];
    set matchLabelKeys(value: string[]);
    resetMatchLabelKeys(): void;
    get matchLabelKeysInput(): string[] | undefined;
    private _maxSkew?;
    get maxSkew(): number;
    set maxSkew(value: number);
    resetMaxSkew(): void;
    get maxSkewInput(): number | undefined;
    private _minDomains?;
    get minDomains(): number;
    set minDomains(value: number);
    resetMinDomains(): void;
    get minDomainsInput(): number | undefined;
    private _nodeAffinityPolicy?;
    get nodeAffinityPolicy(): string;
    set nodeAffinityPolicy(value: string);
    resetNodeAffinityPolicy(): void;
    get nodeAffinityPolicyInput(): string | undefined;
    private _nodeTaintsPolicy?;
    get nodeTaintsPolicy(): string;
    set nodeTaintsPolicy(value: string);
    resetNodeTaintsPolicy(): void;
    get nodeTaintsPolicyInput(): string | undefined;
    private _topologyKey?;
    get topologyKey(): string;
    set topologyKey(value: string);
    resetTopologyKey(): void;
    get topologyKeyInput(): string | undefined;
    private _whenUnsatisfiable?;
    get whenUnsatisfiable(): string;
    set whenUnsatisfiable(value: string);
    resetWhenUnsatisfiable(): void;
    get whenUnsatisfiableInput(): string | undefined;
    private _labelSelector;
    get labelSelector(): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelectorList;
    putLabelSelector(value: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | cdktn.IResolvable): void;
    resetLabelSelector(): void;
    get labelSelectorInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintLabelSelector[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#partition ReplicationControllerV1#partition}
    */
    readonly partition?: number;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Unique ID of the persistent disk resource in AWS (Amazon EBS volume). More info: https://kubernetes.io/docs/concepts/storage/volumes#awselasticblockstore
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_id ReplicationControllerV1#volume_id}
    */
    readonly volumeId: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStoreToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStoreToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk {
    /**
    * Host Caching mode: None, Read Only, Read Write.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#caching_mode ReplicationControllerV1#caching_mode}
    */
    readonly cachingMode: string;
    /**
    * The URI the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#data_disk_uri ReplicationControllerV1#data_disk_uri}
    */
    readonly dataDiskUri: string;
    /**
    * The Name of the data disk in the blob storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#disk_name ReplicationControllerV1#disk_name}
    */
    readonly diskName: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The type for the data disk. Expected values: Shared, Dedicated, Managed. Defaults to Shared
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#kind ReplicationControllerV1#kind}
    */
    readonly kind?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeAzureDiskToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeAzureDiskOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeAzureDiskToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeAzureDiskOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeAzureDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk | undefined);
    private _cachingMode?;
    get cachingMode(): string;
    set cachingMode(value: string);
    get cachingModeInput(): string | undefined;
    private _dataDiskUri?;
    get dataDiskUri(): string;
    set dataDiskUri(value: string);
    get dataDiskUriInput(): string | undefined;
    private _diskName?;
    get diskName(): string;
    set diskName(value: string);
    get diskNameInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeAzureFile {
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The name of secret that contains Azure Storage Account Name and Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_name ReplicationControllerV1#secret_name}
    */
    readonly secretName: string;
    /**
    * The namespace of the secret that contains Azure Storage Account Name and Key. For Kubernetes up to 1.18.x the default is the same as the Pod. For Kubernetes 1.19.x and later the default is "default" namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_namespace ReplicationControllerV1#secret_namespace}
    */
    readonly secretNamespace?: string;
    /**
    * Share Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#share_name ReplicationControllerV1#share_name}
    */
    readonly shareName: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeAzureFileToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeAzureFileOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeAzureFile): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeAzureFileToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeAzureFileOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeAzureFile): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeAzureFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeAzureFile | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeAzureFile | undefined);
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _secretNamespace?;
    get secretNamespace(): string;
    set secretNamespace(value: string);
    resetSecretNamespace(): void;
    get secretNamespaceInput(): string | undefined;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    get shareNameInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#namespace ReplicationControllerV1#namespace}
    */
    readonly namespace?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeCephFsSecretRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeCephFsSecretRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeCephFs {
    /**
    * Monitors is a collection of Ceph monitors. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#monitors ReplicationControllerV1#monitors}
    */
    readonly monitors: string[];
    /**
    * Used as the mounted root, rather than the full Ceph tree, default is /
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to `false` (read/write). More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * The path to key ring for User, default is `/etc/ceph/user.secret`. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_file ReplicationControllerV1#secret_file}
    */
    readonly secretFile?: string;
    /**
    * User is the rados user name, default is admin. More info: https://examples.k8s.io/volumes/cephfs/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#user ReplicationControllerV1#user}
    */
    readonly user?: string;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_ref ReplicationControllerV1#secret_ref}
    */
    readonly secretRef?: ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeCephFsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCephFsOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCephFs): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeCephFsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCephFsOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCephFs): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeCephFsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeCephFs | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeCephFs | undefined);
    private _monitors?;
    get monitors(): string[];
    set monitors(value: string[]);
    get monitorsInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretFile?;
    get secretFile(): string;
    set secretFile(value: string);
    resetSecretFile(): void;
    get secretFileInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _secretRef;
    get secretRef(): ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRefOutputReference;
    putSecretRef(value: ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeCephFsSecretRef | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeCinder {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write). More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Volume ID used to identify the volume in Cinder. More info: https://examples.k8s.io/mysql-cinder-pd/README.md
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_id ReplicationControllerV1#volume_id}
    */
    readonly volumeId: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeCinderToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCinderOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCinder): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeCinderToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCinderOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCinder): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeCinderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeCinder | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeCinder | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mode ReplicationControllerV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeConfigMapItemsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeConfigMapItemsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItemsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItemsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeConfigMap {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#default_mode ReplicationControllerV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Optional: Specify whether the ConfigMap or its keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#optional ReplicationControllerV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#items ReplicationControllerV1#items}
    */
    readonly items?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeConfigMapToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeConfigMap): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeConfigMapToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeConfigMap): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeConfigMap | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeConfigMap | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItemsList;
    putItems(value: ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeConfigMapItems[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeCsi {
    /**
    * the name of the volume driver to use. More info: https://kubernetes.io/docs/concepts/storage/volumes/#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#driver ReplicationControllerV1#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Whether to set the read-only property in VolumeMounts to "true". If omitted, the default is "false". More info: https://kubernetes.io/docs/concepts/storage/volumes#csi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Attributes of the volume to publish.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_attributes ReplicationControllerV1#volume_attributes}
    */
    readonly volumeAttributes?: {
        [key: string]: string;
    };
    /**
    * node_publish_secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#node_publish_secret_ref ReplicationControllerV1#node_publish_secret_ref}
    */
    readonly nodePublishSecretRef?: ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeCsiToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCsiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCsi): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeCsiToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeCsiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeCsi): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeCsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeCsi | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeCsi | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeAttributes?;
    get volumeAttributes(): {
        [key: string]: string;
    };
    set volumeAttributes(value: {
        [key: string]: string;
    });
    resetVolumeAttributes(): void;
    get volumeAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _nodePublishSecretRef;
    get nodePublishSecretRef(): ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRefOutputReference;
    putNodePublishSecretRef(value: ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef): void;
    resetNodePublishSecretRef(): void;
    get nodePublishSecretRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeCsiNodePublishSecretRef | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef {
    /**
    * Version of the schema the FieldPath is written in terms of, defaults to "v1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#api_version ReplicationControllerV1#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Path of the field to select in the specified API version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#field_path ReplicationControllerV1#field_path}
    */
    readonly fieldPath?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#container_name ReplicationControllerV1#container_name}
    */
    readonly containerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#divisor ReplicationControllerV1#divisor}
    */
    readonly divisor?: string;
    /**
    * Resource to select
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#resource ReplicationControllerV1#resource}
    */
    readonly resource: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef | undefined);
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    get containerNameInput(): string | undefined;
    private _divisor?;
    get divisor(): string;
    set divisor(value: string);
    resetDivisor(): void;
    get divisorInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems {
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mode ReplicationControllerV1#mode}
    */
    readonly mode?: string;
    /**
    * Path is the relative path name of the file to be created. Must not be absolute or contain the '..' path. Must be utf-8 encoded. The first item of the relative path must not start with '..'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path: string;
    /**
    * field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#field_ref ReplicationControllerV1#field_ref}
    */
    readonly fieldRef: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef;
    /**
    * resource_field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#resource_field_ref ReplicationControllerV1#resource_field_ref}
    */
    readonly resourceFieldRef?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _fieldRef;
    get fieldRef(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRefOutputReference;
    putFieldRef(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef): void;
    get fieldRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsFieldRef | undefined;
    private _resourceFieldRef;
    get resourceFieldRef(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRefOutputReference;
    putResourceFieldRef(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef): void;
    resetResourceFieldRef(): void;
    get resourceFieldRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsResourceFieldRef | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#default_mode ReplicationControllerV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#items ReplicationControllerV1#items}
    */
    readonly items?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeDownwardApiToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _items;
    get items(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItemsList;
    putItems(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiItems[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir {
    /**
    * What type of storage medium should back this directory. The default is "" which means to use the node's default medium. Must be one of ["" "Memory" "HugePages" "HugePages-2Mi" "HugePages-1Gi"]. More info: https://kubernetes.io/docs/concepts/storage/volumes#emptydir
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#medium ReplicationControllerV1#medium}
    */
    readonly medium?: string;
    /**
    * Total amount of local storage required for this EmptyDir volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#size_limit ReplicationControllerV1#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEmptyDirToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEmptyDirOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEmptyDirToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEmptyDirOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata {
    /**
    * An unstructured key value map stored with the persistent volume claim that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#annotations ReplicationControllerV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the persistent volume claim. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#labels ReplicationControllerV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources {
    /**
    * Map describing the maximum amount of compute resources allowed. More info: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#limits ReplicationControllerV1#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Map describing the minimum amount of compute resources required. If this is omitted for a container, it defaults to `limits` if that is explicitly specified, otherwise to an implementation-defined value. More info: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#requests ReplicationControllerV1#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#operator ReplicationControllerV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#values ReplicationControllerV1#values}
    */
    readonly values?: string[];
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#match_labels ReplicationControllerV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#match_expressions ReplicationControllerV1#match_expressions}
    */
    readonly matchExpressions?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressionsList;
    putMatchExpressions(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorMatchExpressions[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec {
    /**
    * A set of the desired access modes the volume should have. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes#access-modes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#access_modes ReplicationControllerV1#access_modes}
    */
    readonly accessModes: string[];
    /**
    * Name of the storage class requested by the claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#storage_class_name ReplicationControllerV1#storage_class_name}
    */
    readonly storageClassName?: string;
    /**
    * Defines what type of volume is required by the claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_mode ReplicationControllerV1#volume_mode}
    */
    readonly volumeMode?: string;
    /**
    * The binding reference to the PersistentVolume backing this claim.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_name ReplicationControllerV1#volume_name}
    */
    readonly volumeName?: string;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#resources ReplicationControllerV1#resources}
    */
    readonly resources: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources;
    /**
    * selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#selector ReplicationControllerV1#selector}
    */
    readonly selector?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined);
    private _accessModes?;
    get accessModes(): string[];
    set accessModes(value: string[]);
    get accessModesInput(): string[] | undefined;
    private _storageClassName?;
    get storageClassName(): string;
    set storageClassName(value: string);
    resetStorageClassName(): void;
    get storageClassNameInput(): string | undefined;
    private _volumeMode?;
    get volumeMode(): string;
    set volumeMode(value: string);
    resetVolumeMode(): void;
    get volumeModeInput(): string | undefined;
    private _volumeName?;
    get volumeName(): string;
    set volumeName(value: string);
    resetVolumeName(): void;
    get volumeNameInput(): string | undefined;
    private _resources;
    get resources(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResourcesOutputReference;
    putResources(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources): void;
    get resourcesInput(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecResources | undefined;
    private _selector;
    get selector(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelectorOutputReference;
    putSelector(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector): void;
    resetSelector(): void;
    get selectorInput(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecSelector | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate {
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#metadata ReplicationControllerV1#metadata}
    */
    readonly metadata?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#spec ReplicationControllerV1#spec}
    */
    readonly spec: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate | undefined);
    private _metadata;
    get metadata(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadataOutputReference;
    putMetadata(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata): void;
    resetMetadata(): void;
    get metadataInput(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateMetadata | undefined;
    private _spec;
    get spec(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpecOutputReference;
    putSpec(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec): void;
    get specInput(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateSpec | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeEphemeral {
    /**
    * volume_claim_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_claim_template ReplicationControllerV1#volume_claim_template}
    */
    readonly volumeClaimTemplate: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeral): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeEphemeralToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeEphemeral): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeEphemeralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeral | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeral | undefined);
    private _volumeClaimTemplate;
    get volumeClaimTemplate(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplateOutputReference;
    putVolumeClaimTemplate(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate): void;
    get volumeClaimTemplateInput(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralVolumeClaimTemplate | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeFc {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * FC target lun number
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#lun ReplicationControllerV1#lun}
    */
    readonly lun: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * FC target worldwide names (WWNs)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#target_ww_ns ReplicationControllerV1#target_ww_ns}
    */
    readonly targetWwNs: string[];
}
export declare function replicationControllerV1SpecTemplateSpecVolumeFcToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFcOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFc): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeFcToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFcOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFc): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeFcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeFc | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeFc | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetWwNs?;
    get targetWwNs(): string[];
    set targetWwNs(value: string[]);
    get targetWwNsInput(): string[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#namespace ReplicationControllerV1#namespace}
    */
    readonly namespace?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume {
    /**
    * Driver is the name of the driver to use for this volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#driver ReplicationControllerV1#driver}
    */
    readonly driver: string;
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". The default filesystem depends on FlexVolume script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Extra command options if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#options ReplicationControllerV1#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false (read/write).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_ref ReplicationControllerV1#secret_ref}
    */
    readonly secretRef?: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeFlexVolumeToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeFlexVolumeToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume | undefined);
    private _driver?;
    get driver(): string;
    set driver(value: string);
    get driverInput(): string | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRefOutputReference;
    putSecretRef(value: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeSecretRef | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeFlocker {
    /**
    * Name of the dataset stored as metadata -> name on the dataset for Flocker should be considered as deprecated
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#dataset_name ReplicationControllerV1#dataset_name}
    */
    readonly datasetName?: string;
    /**
    * UUID of the dataset. This is unique identifier of a Flocker dataset
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#dataset_uuid ReplicationControllerV1#dataset_uuid}
    */
    readonly datasetUuid?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeFlockerToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFlockerOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFlocker): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeFlockerToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeFlockerOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeFlocker): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeFlockerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeFlocker | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeFlocker | undefined);
    private _datasetName?;
    get datasetName(): string;
    set datasetName(value: string);
    resetDatasetName(): void;
    get datasetNameInput(): string | undefined;
    private _datasetUuid?;
    get datasetUuid(): string;
    set datasetUuid(value: string);
    resetDatasetUuid(): void;
    get datasetUuidInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * The partition in the volume that you want to mount. If omitted, the default is to mount by volume name. Examples: For volume /dev/sda1, you specify the partition as "1". Similarly, the volume partition for /dev/sda is "0" (or you can leave the property empty). More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#partition ReplicationControllerV1#partition}
    */
    readonly partition?: number;
    /**
    * Unique name of the PD resource in GCE. Used to identify the disk in GCE. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#pd_name ReplicationControllerV1#pd_name}
    */
    readonly pdName: string;
    /**
    * Whether to force the ReadOnly setting in VolumeMounts. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#gcepersistentdisk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeGcePersistentDiskToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeGcePersistentDiskToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _partition?;
    get partition(): number;
    set partition(value: number);
    resetPartition(): void;
    get partitionInput(): number | undefined;
    private _pdName?;
    get pdName(): string;
    set pdName(value: string);
    get pdNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeGitRepo {
    /**
    * Target directory name. Must not contain or start with '..'. If '.' is supplied, the volume directory will be the git repository. Otherwise, if specified, the volume will contain the git repository in the subdirectory with the given name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#directory ReplicationControllerV1#directory}
    */
    readonly directory?: string;
    /**
    * Repository URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#repository ReplicationControllerV1#repository}
    */
    readonly repository?: string;
    /**
    * Commit hash for the specified revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#revision ReplicationControllerV1#revision}
    */
    readonly revision?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeGitRepoToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeGitRepoOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeGitRepo): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeGitRepoToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeGitRepoOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeGitRepo): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeGitRepoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeGitRepo | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeGitRepo | undefined);
    private _directory?;
    get directory(): string;
    set directory(value: string);
    resetDirectory(): void;
    get directoryInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _revision?;
    get revision(): string;
    set revision(value: string);
    resetRevision(): void;
    get revisionInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs {
    /**
    * The endpoint name that details Glusterfs topology. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#endpoints_name ReplicationControllerV1#endpoints_name}
    */
    readonly endpointsName: string;
    /**
    * The Glusterfs volume path. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path: string;
    /**
    * Whether to force the Glusterfs volume to be mounted with read-only permissions. Defaults to false. More info: https://examples.k8s.io/volumes/glusterfs/README.md#create-a-pod
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeGlusterfsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeGlusterfsOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeGlusterfsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeGlusterfsOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeGlusterfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs | undefined);
    private _endpointsName?;
    get endpointsName(): string;
    set endpointsName(value: string);
    get endpointsNameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeHostPath {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#hostpath
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
    /**
    * Type for HostPath volume. Allowed values are "" (default), DirectoryOrCreate, Directory, FileOrCreate, File, Socket, CharDevice and BlockDevice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#type ReplicationControllerV1#type}
    */
    readonly type?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeHostPathToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeHostPathOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeHostPath): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeHostPathToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeHostPathOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeHostPath): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeHostPath | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeHostPath | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeIscsi {
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#iscsi
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Target iSCSI Qualified Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#iqn ReplicationControllerV1#iqn}
    */
    readonly iqn: string;
    /**
    * iSCSI interface name that uses an iSCSI transport. Defaults to 'default' (tcp).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#iscsi_interface ReplicationControllerV1#iscsi_interface}
    */
    readonly iscsiInterface?: string;
    /**
    * iSCSI target lun number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#lun ReplicationControllerV1#lun}
    */
    readonly lun?: number;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * iSCSI target portal. The portal is either an IP or ip_addr:port if the port is other than default (typically TCP ports 860 and 3260).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#target_portal ReplicationControllerV1#target_portal}
    */
    readonly targetPortal: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeIscsiToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeIscsiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeIscsi): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeIscsiToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeIscsiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeIscsi): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeIscsiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeIscsi | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeIscsi | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _iqn?;
    get iqn(): string;
    set iqn(value: string);
    get iqnInput(): string | undefined;
    private _iscsiInterface?;
    get iscsiInterface(): string;
    set iscsiInterface(value: string);
    resetIscsiInterface(): void;
    get iscsiInterfaceInput(): string | undefined;
    private _lun?;
    get lun(): number;
    set lun(value: number);
    resetLun(): void;
    get lunInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _targetPortal?;
    get targetPortal(): string;
    set targetPortal(value: string);
    get targetPortalInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeLocal {
    /**
    * Path of the directory on the host. More info: https://kubernetes.io/docs/concepts/storage/volumes#local
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeLocalToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeLocalOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeLocal): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeLocalToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeLocalOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeLocal): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeLocalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeLocal | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeLocal | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeNfs {
    /**
    * Path that is exported by the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path: string;
    /**
    * Whether to force the NFS export to be mounted with read-only permissions. Defaults to false. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Server is the hostname or IP address of the NFS server. More info: https://kubernetes.io/docs/concepts/storage/volumes#nfs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#server ReplicationControllerV1#server}
    */
    readonly server: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeNfsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeNfsOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeNfs): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeNfsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeNfsOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeNfs): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeNfs | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeNfs | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim {
    /**
    * ClaimName is the name of a PersistentVolumeClaim in the same
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#claim_name ReplicationControllerV1#claim_name}
    */
    readonly claimName?: string;
    /**
    * Will force the ReadOnly setting in VolumeMounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaimToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference | ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim): any;
export declare function replicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaimToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference | ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim | undefined);
    private _claimName?;
    get claimName(): string;
    set claimName(value: string);
    resetClaimName(): void;
    get claimNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * ID that identifies Photon Controller persistent disk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#pd_id ReplicationControllerV1#pd_id}
    */
    readonly pdId: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumePhotonPersistentDiskToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference | ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk): any;
export declare function replicationControllerV1SpecTemplateSpecVolumePhotonPersistentDiskToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference | ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _pdId?;
    get pdId(): string;
    set pdId(value: string);
    get pdIdInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mode ReplicationControllerV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Optional: Specify whether the ConfigMap or it's keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#optional ReplicationControllerV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#items ReplicationControllerV1#items}
    */
    readonly items?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItemsList;
    putItems(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapItems[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef {
    /**
    * Version of the schema the FieldPath is written in terms of, defaults to 'v1'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#api_version ReplicationControllerV1#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Path of the field to select in the specified API version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#field_path ReplicationControllerV1#field_path}
    */
    readonly fieldPath?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _fieldPath?;
    get fieldPath(): string;
    set fieldPath(value: string);
    resetFieldPath(): void;
    get fieldPathInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#container_name ReplicationControllerV1#container_name}
    */
    readonly containerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#divisor ReplicationControllerV1#divisor}
    */
    readonly divisor?: string;
    /**
    * Resource to select
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#resource ReplicationControllerV1#resource}
    */
    readonly resource: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined);
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    get containerNameInput(): string | undefined;
    private _divisor?;
    get divisor(): string;
    set divisor(value: string);
    resetDivisor(): void;
    get divisorInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    get resourceInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems {
    /**
    * Mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mode ReplicationControllerV1#mode}
    */
    readonly mode?: string;
    /**
    * Path is the relative path name of the file to be created. Must not be absolute or contain the '..' path. Must be utf-8 encoded. The first item of the relative path must not start with '..'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path: string;
    /**
    * field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#field_ref ReplicationControllerV1#field_ref}
    */
    readonly fieldRef?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef;
    /**
    * resource_field_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#resource_field_ref ReplicationControllerV1#resource_field_ref}
    */
    readonly resourceFieldRef?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _fieldRef;
    get fieldRef(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRefOutputReference;
    putFieldRef(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef): void;
    resetFieldRef(): void;
    get fieldRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsFieldRef | undefined;
    private _resourceFieldRef;
    get resourceFieldRef(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRefOutputReference;
    putResourceFieldRef(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef): void;
    resetResourceFieldRef(): void;
    get resourceFieldRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsResourceFieldRef | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi {
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#items ReplicationControllerV1#items}
    */
    readonly items?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi | undefined);
    private _items;
    get items(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItemsList;
    putItems(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiItems[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mode ReplicationControllerV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret {
    /**
    * Name of the secret in the pod's namespace to use. More info: https://kubernetes.io/docs/concepts/storage/volumes#secrets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Optional: Specify whether the Secret or it's keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#optional ReplicationControllerV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#items ReplicationControllerV1#items}
    */
    readonly items?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItemsList;
    putItems(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretItems[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken {
    /**
    * Audience is the intended audience of the token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#audience ReplicationControllerV1#audience}
    */
    readonly audience?: string;
    /**
    * ExpirationSeconds is the expected duration of validity of the service account token. It defaults to 1 hour and must be at least 10 minutes (600 seconds).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#expiration_seconds ReplicationControllerV1#expiration_seconds}
    */
    readonly expirationSeconds?: number;
    /**
    * Path specifies a relative path to the mount point of the projected volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _expirationSeconds?;
    get expirationSeconds(): number;
    set expirationSeconds(value: number);
    resetExpirationSeconds(): void;
    get expirationSecondsInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources {
    /**
    * config_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#config_map ReplicationControllerV1#config_map}
    */
    readonly configMap?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | cdktn.IResolvable;
    /**
    * downward_api block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#downward_api ReplicationControllerV1#downward_api}
    */
    readonly downwardApi?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret ReplicationControllerV1#secret}
    */
    readonly secret?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | cdktn.IResolvable;
    /**
    * service_account_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#service_account_token ReplicationControllerV1#service_account_token}
    */
    readonly serviceAccountToken?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedSourcesToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources | cdktn.IResolvable | undefined);
    private _configMap;
    get configMap(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMapList;
    putConfigMap(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | cdktn.IResolvable): void;
    resetConfigMap(): void;
    get configMapInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesConfigMap[] | undefined;
    private _downwardApi;
    get downwardApi(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApiOutputReference;
    putDownwardApi(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi): void;
    resetDownwardApi(): void;
    get downwardApiInput(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesDownwardApi | undefined;
    private _secret;
    get secret(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecretList;
    putSecret(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesSecret[] | undefined;
    private _serviceAccountToken;
    get serviceAccountToken(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountTokenOutputReference;
    putServiceAccountToken(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken): void;
    resetServiceAccountToken(): void;
    get serviceAccountTokenInput(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesServiceAccountToken | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeProjected {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#default_mode ReplicationControllerV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#sources ReplicationControllerV1#sources}
    */
    readonly sources: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeProjectedToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeProjected | cdktn.IResolvable | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _sources;
    get sources(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedSourcesList;
    putSources(value: ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources[] | cdktn.IResolvable): void;
    get sourcesInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjectedSources[] | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeProjectedList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeProjected[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeProjectedOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeQuobyte {
    /**
    * Group to map volume access to Default is no group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#group ReplicationControllerV1#group}
    */
    readonly group?: string;
    /**
    * Whether to force the Quobyte volume to be mounted with read-only permissions. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Registry represents a single or multiple Quobyte Registry services specified as a string as host:port pair (multiple entries are separated with commas) which acts as the central registry for volumes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#registry ReplicationControllerV1#registry}
    */
    readonly registry: string;
    /**
    * User to map volume access to Defaults to serivceaccount user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#user ReplicationControllerV1#user}
    */
    readonly user?: string;
    /**
    * Volume is a string that references an already created Quobyte volume by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume ReplicationControllerV1#volume}
    */
    readonly volume: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeQuobyteToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeQuobyteOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeQuobyte): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeQuobyteToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeQuobyteOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeQuobyte): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeQuobyteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeQuobyte | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeQuobyte | undefined);
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _registry?;
    get registry(): string;
    set registry(value: string);
    get registryInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _volume?;
    get volume(): string;
    set volume(value: string);
    get volumeInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef {
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * Name of the referent. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#namespace ReplicationControllerV1#namespace}
    */
    readonly namespace?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeRbdSecretRefToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeRbdSecretRefToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRefOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeRbd {
    /**
    * A collection of Ceph monitors. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#ceph_monitors ReplicationControllerV1#ceph_monitors}
    */
    readonly cephMonitors: string[];
    /**
    * Filesystem type of the volume that you want to mount. Tip: Ensure that the filesystem type is supported by the host operating system. Examples: "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified. More info: https://kubernetes.io/docs/concepts/storage/volumes#rbd
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Keyring is the path to key ring for RBDUser. Default is /etc/ceph/keyring. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#keyring ReplicationControllerV1#keyring}
    */
    readonly keyring?: string;
    /**
    * The rados user name. Default is admin. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#rados_user ReplicationControllerV1#rados_user}
    */
    readonly radosUser?: string;
    /**
    * The rados image name. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#rbd_image ReplicationControllerV1#rbd_image}
    */
    readonly rbdImage: string;
    /**
    * The rados pool name. Default is rbd. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#rbd_pool ReplicationControllerV1#rbd_pool}
    */
    readonly rbdPool?: string;
    /**
    * Whether to force the read-only setting in VolumeMounts. Defaults to false. More info: https://examples.k8s.io/volumes/rbd/README.md#how-to-use-it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#read_only ReplicationControllerV1#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * secret_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_ref ReplicationControllerV1#secret_ref}
    */
    readonly secretRef?: ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeRbdToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeRbdOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeRbd): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeRbdToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeRbdOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeRbd): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeRbdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeRbd | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeRbd | undefined);
    private _cephMonitors?;
    get cephMonitors(): string[];
    set cephMonitors(value: string[]);
    get cephMonitorsInput(): string[] | undefined;
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _keyring?;
    get keyring(): string;
    set keyring(value: string);
    resetKeyring(): void;
    get keyringInput(): string | undefined;
    private _radosUser?;
    get radosUser(): string;
    set radosUser(value: string);
    resetRadosUser(): void;
    get radosUserInput(): string | undefined;
    private _rbdImage?;
    get rbdImage(): string;
    set rbdImage(value: string);
    get rbdImageInput(): string | undefined;
    private _rbdPool?;
    get rbdPool(): string;
    set rbdPool(value: string);
    resetRbdPool(): void;
    get rbdPoolInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _secretRef;
    get secretRef(): ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRefOutputReference;
    putSecretRef(value: ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef): void;
    resetSecretRef(): void;
    get secretRefInput(): ReplicationControllerV1SpecTemplateSpecVolumeRbdSecretRef | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeSecretItems {
    /**
    * The key to project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#key ReplicationControllerV1#key}
    */
    readonly key?: string;
    /**
    * Optional: mode bits to use on this file, must be a value between 0 and 0777. If not specified, the volume defaultMode will be used. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#mode ReplicationControllerV1#mode}
    */
    readonly mode?: string;
    /**
    * The relative path of the file to map the key to. May not be an absolute path. May not contain the path element '..'. May not start with the string '..'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#path ReplicationControllerV1#path}
    */
    readonly path?: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeSecretItemsToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeSecretItemsToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeSecretItems | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeSecretItemsList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolumeSecretItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeSecretItemsOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeSecret {
    /**
    * Optional: mode bits to use on created files by default. Must be a value between 0 and 0777. Defaults to 0644. Directories within the path are not affected by this setting. This might be in conflict with other options that affect the file mode, like fsGroup, and the result can be other mode bits set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#default_mode ReplicationControllerV1#default_mode}
    */
    readonly defaultMode?: string;
    /**
    * Optional: Specify whether the Secret or its keys must be defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#optional ReplicationControllerV1#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * Name of the secret in the pod's namespace to use. More info: https://kubernetes.io/docs/concepts/storage/volumes#secrets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret_name ReplicationControllerV1#secret_name}
    */
    readonly secretName?: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#items ReplicationControllerV1#items}
    */
    readonly items?: ReplicationControllerV1SpecTemplateSpecVolumeSecretItems[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeSecretToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeSecretOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeSecret): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeSecretToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeSecretOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeSecret): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeSecret | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeSecret | undefined);
    private _defaultMode?;
    get defaultMode(): string;
    set defaultMode(value: string);
    resetDefaultMode(): void;
    get defaultModeInput(): string | undefined;
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
    private _items;
    get items(): ReplicationControllerV1SpecTemplateSpecVolumeSecretItemsList;
    putItems(value: ReplicationControllerV1SpecTemplateSpecVolumeSecretItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeSecretItems[] | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume {
    /**
    * Filesystem type to mount. Must be a filesystem type supported by the host operating system. Ex. "ext4", "xfs", "ntfs". Implicitly inferred to be "ext4" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fs_type ReplicationControllerV1#fs_type}
    */
    readonly fsType?: string;
    /**
    * Path that identifies vSphere volume vmdk
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume_path ReplicationControllerV1#volume_path}
    */
    readonly volumePath: string;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeVsphereVolumeToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolumeOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeVsphereVolumeToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolumeOutputReference | ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume | undefined);
    private _fsType?;
    get fsType(): string;
    set fsType(value: string);
    resetFsType(): void;
    get fsTypeInput(): string | undefined;
    private _volumePath?;
    get volumePath(): string;
    set volumePath(value: string);
    get volumePathInput(): string | undefined;
}
export interface ReplicationControllerV1SpecTemplateSpecVolume {
    /**
    * Volume's name. Must be a DNS_LABEL and unique within the pod. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#name ReplicationControllerV1#name}
    */
    readonly name?: string;
    /**
    * aws_elastic_block_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#aws_elastic_block_store ReplicationControllerV1#aws_elastic_block_store}
    */
    readonly awsElasticBlockStore?: ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore;
    /**
    * azure_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#azure_disk ReplicationControllerV1#azure_disk}
    */
    readonly azureDisk?: ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk;
    /**
    * azure_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#azure_file ReplicationControllerV1#azure_file}
    */
    readonly azureFile?: ReplicationControllerV1SpecTemplateSpecVolumeAzureFile;
    /**
    * ceph_fs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#ceph_fs ReplicationControllerV1#ceph_fs}
    */
    readonly cephFs?: ReplicationControllerV1SpecTemplateSpecVolumeCephFs;
    /**
    * cinder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#cinder ReplicationControllerV1#cinder}
    */
    readonly cinder?: ReplicationControllerV1SpecTemplateSpecVolumeCinder;
    /**
    * config_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#config_map ReplicationControllerV1#config_map}
    */
    readonly configMap?: ReplicationControllerV1SpecTemplateSpecVolumeConfigMap;
    /**
    * csi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#csi ReplicationControllerV1#csi}
    */
    readonly csi?: ReplicationControllerV1SpecTemplateSpecVolumeCsi;
    /**
    * downward_api block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#downward_api ReplicationControllerV1#downward_api}
    */
    readonly downwardApi?: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi;
    /**
    * empty_dir block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#empty_dir ReplicationControllerV1#empty_dir}
    */
    readonly emptyDir?: ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir;
    /**
    * ephemeral block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#ephemeral ReplicationControllerV1#ephemeral}
    */
    readonly ephemeral?: ReplicationControllerV1SpecTemplateSpecVolumeEphemeral;
    /**
    * fc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#fc ReplicationControllerV1#fc}
    */
    readonly fc?: ReplicationControllerV1SpecTemplateSpecVolumeFc;
    /**
    * flex_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#flex_volume ReplicationControllerV1#flex_volume}
    */
    readonly flexVolume?: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume;
    /**
    * flocker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#flocker ReplicationControllerV1#flocker}
    */
    readonly flocker?: ReplicationControllerV1SpecTemplateSpecVolumeFlocker;
    /**
    * gce_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#gce_persistent_disk ReplicationControllerV1#gce_persistent_disk}
    */
    readonly gcePersistentDisk?: ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk;
    /**
    * git_repo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#git_repo ReplicationControllerV1#git_repo}
    */
    readonly gitRepo?: ReplicationControllerV1SpecTemplateSpecVolumeGitRepo;
    /**
    * glusterfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#glusterfs ReplicationControllerV1#glusterfs}
    */
    readonly glusterfs?: ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs;
    /**
    * host_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_path ReplicationControllerV1#host_path}
    */
    readonly hostPath?: ReplicationControllerV1SpecTemplateSpecVolumeHostPath;
    /**
    * iscsi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#iscsi ReplicationControllerV1#iscsi}
    */
    readonly iscsi?: ReplicationControllerV1SpecTemplateSpecVolumeIscsi;
    /**
    * local block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#local ReplicationControllerV1#local}
    */
    readonly local?: ReplicationControllerV1SpecTemplateSpecVolumeLocal;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#nfs ReplicationControllerV1#nfs}
    */
    readonly nfs?: ReplicationControllerV1SpecTemplateSpecVolumeNfs;
    /**
    * persistent_volume_claim block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#persistent_volume_claim ReplicationControllerV1#persistent_volume_claim}
    */
    readonly persistentVolumeClaim?: ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim;
    /**
    * photon_persistent_disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#photon_persistent_disk ReplicationControllerV1#photon_persistent_disk}
    */
    readonly photonPersistentDisk?: ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk;
    /**
    * projected block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#projected ReplicationControllerV1#projected}
    */
    readonly projected?: ReplicationControllerV1SpecTemplateSpecVolumeProjected[] | cdktn.IResolvable;
    /**
    * quobyte block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#quobyte ReplicationControllerV1#quobyte}
    */
    readonly quobyte?: ReplicationControllerV1SpecTemplateSpecVolumeQuobyte;
    /**
    * rbd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#rbd ReplicationControllerV1#rbd}
    */
    readonly rbd?: ReplicationControllerV1SpecTemplateSpecVolumeRbd;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#secret ReplicationControllerV1#secret}
    */
    readonly secret?: ReplicationControllerV1SpecTemplateSpecVolumeSecret;
    /**
    * vsphere_volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#vsphere_volume ReplicationControllerV1#vsphere_volume}
    */
    readonly vsphereVolume?: ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume;
}
export declare function replicationControllerV1SpecTemplateSpecVolumeToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolume | cdktn.IResolvable): any;
export declare function replicationControllerV1SpecTemplateSpecVolumeToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecVolume | cdktn.IResolvable): any;
export declare class ReplicationControllerV1SpecTemplateSpecVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReplicationControllerV1SpecTemplateSpecVolume | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpecVolume | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _awsElasticBlockStore;
    get awsElasticBlockStore(): ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStoreOutputReference;
    putAwsElasticBlockStore(value: ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore): void;
    resetAwsElasticBlockStore(): void;
    get awsElasticBlockStoreInput(): ReplicationControllerV1SpecTemplateSpecVolumeAwsElasticBlockStore | undefined;
    private _azureDisk;
    get azureDisk(): ReplicationControllerV1SpecTemplateSpecVolumeAzureDiskOutputReference;
    putAzureDisk(value: ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk): void;
    resetAzureDisk(): void;
    get azureDiskInput(): ReplicationControllerV1SpecTemplateSpecVolumeAzureDisk | undefined;
    private _azureFile;
    get azureFile(): ReplicationControllerV1SpecTemplateSpecVolumeAzureFileOutputReference;
    putAzureFile(value: ReplicationControllerV1SpecTemplateSpecVolumeAzureFile): void;
    resetAzureFile(): void;
    get azureFileInput(): ReplicationControllerV1SpecTemplateSpecVolumeAzureFile | undefined;
    private _cephFs;
    get cephFs(): ReplicationControllerV1SpecTemplateSpecVolumeCephFsOutputReference;
    putCephFs(value: ReplicationControllerV1SpecTemplateSpecVolumeCephFs): void;
    resetCephFs(): void;
    get cephFsInput(): ReplicationControllerV1SpecTemplateSpecVolumeCephFs | undefined;
    private _cinder;
    get cinder(): ReplicationControllerV1SpecTemplateSpecVolumeCinderOutputReference;
    putCinder(value: ReplicationControllerV1SpecTemplateSpecVolumeCinder): void;
    resetCinder(): void;
    get cinderInput(): ReplicationControllerV1SpecTemplateSpecVolumeCinder | undefined;
    private _configMap;
    get configMap(): ReplicationControllerV1SpecTemplateSpecVolumeConfigMapOutputReference;
    putConfigMap(value: ReplicationControllerV1SpecTemplateSpecVolumeConfigMap): void;
    resetConfigMap(): void;
    get configMapInput(): ReplicationControllerV1SpecTemplateSpecVolumeConfigMap | undefined;
    private _csi;
    get csi(): ReplicationControllerV1SpecTemplateSpecVolumeCsiOutputReference;
    putCsi(value: ReplicationControllerV1SpecTemplateSpecVolumeCsi): void;
    resetCsi(): void;
    get csiInput(): ReplicationControllerV1SpecTemplateSpecVolumeCsi | undefined;
    private _downwardApi;
    get downwardApi(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApiOutputReference;
    putDownwardApi(value: ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi): void;
    resetDownwardApi(): void;
    get downwardApiInput(): ReplicationControllerV1SpecTemplateSpecVolumeDownwardApi | undefined;
    private _emptyDir;
    get emptyDir(): ReplicationControllerV1SpecTemplateSpecVolumeEmptyDirOutputReference;
    putEmptyDir(value: ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): ReplicationControllerV1SpecTemplateSpecVolumeEmptyDir | undefined;
    private _ephemeral;
    get ephemeral(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeralOutputReference;
    putEphemeral(value: ReplicationControllerV1SpecTemplateSpecVolumeEphemeral): void;
    resetEphemeral(): void;
    get ephemeralInput(): ReplicationControllerV1SpecTemplateSpecVolumeEphemeral | undefined;
    private _fc;
    get fc(): ReplicationControllerV1SpecTemplateSpecVolumeFcOutputReference;
    putFc(value: ReplicationControllerV1SpecTemplateSpecVolumeFc): void;
    resetFc(): void;
    get fcInput(): ReplicationControllerV1SpecTemplateSpecVolumeFc | undefined;
    private _flexVolume;
    get flexVolume(): ReplicationControllerV1SpecTemplateSpecVolumeFlexVolumeOutputReference;
    putFlexVolume(value: ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume): void;
    resetFlexVolume(): void;
    get flexVolumeInput(): ReplicationControllerV1SpecTemplateSpecVolumeFlexVolume | undefined;
    private _flocker;
    get flocker(): ReplicationControllerV1SpecTemplateSpecVolumeFlockerOutputReference;
    putFlocker(value: ReplicationControllerV1SpecTemplateSpecVolumeFlocker): void;
    resetFlocker(): void;
    get flockerInput(): ReplicationControllerV1SpecTemplateSpecVolumeFlocker | undefined;
    private _gcePersistentDisk;
    get gcePersistentDisk(): ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDiskOutputReference;
    putGcePersistentDisk(value: ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk): void;
    resetGcePersistentDisk(): void;
    get gcePersistentDiskInput(): ReplicationControllerV1SpecTemplateSpecVolumeGcePersistentDisk | undefined;
    private _gitRepo;
    get gitRepo(): ReplicationControllerV1SpecTemplateSpecVolumeGitRepoOutputReference;
    putGitRepo(value: ReplicationControllerV1SpecTemplateSpecVolumeGitRepo): void;
    resetGitRepo(): void;
    get gitRepoInput(): ReplicationControllerV1SpecTemplateSpecVolumeGitRepo | undefined;
    private _glusterfs;
    get glusterfs(): ReplicationControllerV1SpecTemplateSpecVolumeGlusterfsOutputReference;
    putGlusterfs(value: ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs): void;
    resetGlusterfs(): void;
    get glusterfsInput(): ReplicationControllerV1SpecTemplateSpecVolumeGlusterfs | undefined;
    private _hostPath;
    get hostPath(): ReplicationControllerV1SpecTemplateSpecVolumeHostPathOutputReference;
    putHostPath(value: ReplicationControllerV1SpecTemplateSpecVolumeHostPath): void;
    resetHostPath(): void;
    get hostPathInput(): ReplicationControllerV1SpecTemplateSpecVolumeHostPath | undefined;
    private _iscsi;
    get iscsi(): ReplicationControllerV1SpecTemplateSpecVolumeIscsiOutputReference;
    putIscsi(value: ReplicationControllerV1SpecTemplateSpecVolumeIscsi): void;
    resetIscsi(): void;
    get iscsiInput(): ReplicationControllerV1SpecTemplateSpecVolumeIscsi | undefined;
    private _local;
    get local(): ReplicationControllerV1SpecTemplateSpecVolumeLocalOutputReference;
    putLocal(value: ReplicationControllerV1SpecTemplateSpecVolumeLocal): void;
    resetLocal(): void;
    get localInput(): ReplicationControllerV1SpecTemplateSpecVolumeLocal | undefined;
    private _nfs;
    get nfs(): ReplicationControllerV1SpecTemplateSpecVolumeNfsOutputReference;
    putNfs(value: ReplicationControllerV1SpecTemplateSpecVolumeNfs): void;
    resetNfs(): void;
    get nfsInput(): ReplicationControllerV1SpecTemplateSpecVolumeNfs | undefined;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaimOutputReference;
    putPersistentVolumeClaim(value: ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim): void;
    resetPersistentVolumeClaim(): void;
    get persistentVolumeClaimInput(): ReplicationControllerV1SpecTemplateSpecVolumePersistentVolumeClaim | undefined;
    private _photonPersistentDisk;
    get photonPersistentDisk(): ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDiskOutputReference;
    putPhotonPersistentDisk(value: ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk): void;
    resetPhotonPersistentDisk(): void;
    get photonPersistentDiskInput(): ReplicationControllerV1SpecTemplateSpecVolumePhotonPersistentDisk | undefined;
    private _projected;
    get projected(): ReplicationControllerV1SpecTemplateSpecVolumeProjectedList;
    putProjected(value: ReplicationControllerV1SpecTemplateSpecVolumeProjected[] | cdktn.IResolvable): void;
    resetProjected(): void;
    get projectedInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolumeProjected[] | undefined;
    private _quobyte;
    get quobyte(): ReplicationControllerV1SpecTemplateSpecVolumeQuobyteOutputReference;
    putQuobyte(value: ReplicationControllerV1SpecTemplateSpecVolumeQuobyte): void;
    resetQuobyte(): void;
    get quobyteInput(): ReplicationControllerV1SpecTemplateSpecVolumeQuobyte | undefined;
    private _rbd;
    get rbd(): ReplicationControllerV1SpecTemplateSpecVolumeRbdOutputReference;
    putRbd(value: ReplicationControllerV1SpecTemplateSpecVolumeRbd): void;
    resetRbd(): void;
    get rbdInput(): ReplicationControllerV1SpecTemplateSpecVolumeRbd | undefined;
    private _secret;
    get secret(): ReplicationControllerV1SpecTemplateSpecVolumeSecretOutputReference;
    putSecret(value: ReplicationControllerV1SpecTemplateSpecVolumeSecret): void;
    resetSecret(): void;
    get secretInput(): ReplicationControllerV1SpecTemplateSpecVolumeSecret | undefined;
    private _vsphereVolume;
    get vsphereVolume(): ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolumeOutputReference;
    putVsphereVolume(value: ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume): void;
    resetVsphereVolume(): void;
    get vsphereVolumeInput(): ReplicationControllerV1SpecTemplateSpecVolumeVsphereVolume | undefined;
}
export declare class ReplicationControllerV1SpecTemplateSpecVolumeList extends cdktn.ComplexList {
    internalValue?: ReplicationControllerV1SpecTemplateSpecVolume[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReplicationControllerV1SpecTemplateSpecVolumeOutputReference;
}
export interface ReplicationControllerV1SpecTemplateSpec {
    /**
    * Optional duration in seconds the pod may be active on the node relative to StartTime before the system will actively try to mark it failed and kill associated containers. Value must be a positive integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#active_deadline_seconds ReplicationControllerV1#active_deadline_seconds}
    */
    readonly activeDeadlineSeconds?: number;
    /**
    * AutomountServiceAccountToken indicates whether a service account token should be automatically mounted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#automount_service_account_token ReplicationControllerV1#automount_service_account_token}
    */
    readonly automountServiceAccountToken?: boolean | cdktn.IResolvable;
    /**
    * Set DNS policy for containers within the pod. Valid values are 'ClusterFirstWithHostNet', 'ClusterFirst', 'Default' or 'None'. DNS parameters given in DNSConfig will be merged with the policy selected with DNSPolicy. To have DNS options set along with hostNetwork, you have to specify DNS policy explicitly to 'ClusterFirstWithHostNet'. Defaults to 'ClusterFirst'. More info: https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#dns_policy ReplicationControllerV1#dns_policy}
    */
    readonly dnsPolicy?: string;
    /**
    * Enables generating environment variables for service discovery. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#enable_service_links ReplicationControllerV1#enable_service_links}
    */
    readonly enableServiceLinks?: boolean | cdktn.IResolvable;
    /**
    * Use the host's ipc namespace. Optional: Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_ipc ReplicationControllerV1#host_ipc}
    */
    readonly hostIpc?: boolean | cdktn.IResolvable;
    /**
    * Host networking requested for this pod. Use the host's network namespace. If this option is set, the ports that will be used must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_network ReplicationControllerV1#host_network}
    */
    readonly hostNetwork?: boolean | cdktn.IResolvable;
    /**
    * Use the host's pid namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_pid ReplicationControllerV1#host_pid}
    */
    readonly hostPid?: boolean | cdktn.IResolvable;
    /**
    * Specifies the hostname of the Pod If not specified, the pod's hostname will be set to a system-defined value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#hostname ReplicationControllerV1#hostname}
    */
    readonly hostname?: string;
    /**
    * NodeName is a request to schedule this pod onto a specific node. If it is non-empty, the scheduler simply schedules this pod onto that node, assuming that it fits resource requirements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#node_name ReplicationControllerV1#node_name}
    */
    readonly nodeName?: string;
    /**
    * NodeSelector is a selector which must be true for the pod to fit on a node. Selector which must match a node's labels for the pod to be scheduled on that node. More info: https://kubernetes.io/docs/concepts/configuration/assign-pod-node/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#node_selector ReplicationControllerV1#node_selector}
    */
    readonly nodeSelector?: {
        [key: string]: string;
    };
    /**
    * If specified, indicates the pod's priority. "system-node-critical" and "system-cluster-critical" are two special keywords which indicate the highest priorities with the former being the highest priority. Any other name must be defined by creating a PriorityClass object with that name. If not specified, the pod priority will be default or zero if there is no default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#priority_class_name ReplicationControllerV1#priority_class_name}
    */
    readonly priorityClassName?: string;
    /**
    * Restart policy for all containers within the pod. One of Always, OnFailure, Never. More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#restart-policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#restart_policy ReplicationControllerV1#restart_policy}
    */
    readonly restartPolicy?: string;
    /**
    * RuntimeClassName is a feature for selecting the container runtime configuration. The container runtime configuration is used to run a Pod's containers. More info: https://kubernetes.io/docs/concepts/containers/runtime-class
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#runtime_class_name ReplicationControllerV1#runtime_class_name}
    */
    readonly runtimeClassName?: string;
    /**
    * If specified, the pod will be dispatched by specified scheduler. If not specified, the pod will be dispatched by default scheduler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#scheduler_name ReplicationControllerV1#scheduler_name}
    */
    readonly schedulerName?: string;
    /**
    * ServiceAccountName is the name of the ServiceAccount to use to run this pod. More info: http://releases.k8s.io/HEAD/docs/design/service_accounts.md.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#service_account_name ReplicationControllerV1#service_account_name}
    */
    readonly serviceAccountName?: string;
    /**
    * Share a single process namespace between all of the containers in a pod. When this is set containers will be able to view and signal processes from other containers in the same pod, and the first process in each container will not be assigned PID 1. HostPID and ShareProcessNamespace cannot both be set. Optional: Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#share_process_namespace ReplicationControllerV1#share_process_namespace}
    */
    readonly shareProcessNamespace?: boolean | cdktn.IResolvable;
    /**
    * If specified, the fully qualified Pod hostname will be "...svc.". If not specified, the pod will not have a domainname at all..
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#subdomain ReplicationControllerV1#subdomain}
    */
    readonly subdomain?: string;
    /**
    * Optional duration in seconds the pod needs to terminate gracefully. May be decreased in delete request. Value must be non-negative integer. The value zero indicates delete immediately. If this value is nil, the default grace period will be used instead. The grace period is the duration in seconds after the processes running in the pod are sent a termination signal and the time when the processes are forcibly halted with a kill signal. Set this value longer than the expected cleanup time for your process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#termination_grace_period_seconds ReplicationControllerV1#termination_grace_period_seconds}
    */
    readonly terminationGracePeriodSeconds?: number;
    /**
    * affinity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#affinity ReplicationControllerV1#affinity}
    */
    readonly affinity?: ReplicationControllerV1SpecTemplateSpecAffinity;
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#container ReplicationControllerV1#container}
    */
    readonly container?: ReplicationControllerV1SpecTemplateSpecContainer[] | cdktn.IResolvable;
    /**
    * dns_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#dns_config ReplicationControllerV1#dns_config}
    */
    readonly dnsConfig?: ReplicationControllerV1SpecTemplateSpecDnsConfig;
    /**
    * host_aliases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#host_aliases ReplicationControllerV1#host_aliases}
    */
    readonly hostAliases?: ReplicationControllerV1SpecTemplateSpecHostAliases[] | cdktn.IResolvable;
    /**
    * image_pull_secrets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#image_pull_secrets ReplicationControllerV1#image_pull_secrets}
    */
    readonly imagePullSecrets?: ReplicationControllerV1SpecTemplateSpecImagePullSecrets[] | cdktn.IResolvable;
    /**
    * init_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#init_container ReplicationControllerV1#init_container}
    */
    readonly initContainer?: ReplicationControllerV1SpecTemplateSpecInitContainer[] | cdktn.IResolvable;
    /**
    * os block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#os ReplicationControllerV1#os}
    */
    readonly os?: ReplicationControllerV1SpecTemplateSpecOs;
    /**
    * readiness_gate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#readiness_gate ReplicationControllerV1#readiness_gate}
    */
    readonly readinessGate?: ReplicationControllerV1SpecTemplateSpecReadinessGate[] | cdktn.IResolvable;
    /**
    * security_context block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#security_context ReplicationControllerV1#security_context}
    */
    readonly securityContext?: ReplicationControllerV1SpecTemplateSpecSecurityContext;
    /**
    * toleration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#toleration ReplicationControllerV1#toleration}
    */
    readonly toleration?: ReplicationControllerV1SpecTemplateSpecToleration[] | cdktn.IResolvable;
    /**
    * topology_spread_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#topology_spread_constraint ReplicationControllerV1#topology_spread_constraint}
    */
    readonly topologySpreadConstraint?: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint[] | cdktn.IResolvable;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#volume ReplicationControllerV1#volume}
    */
    readonly volume?: ReplicationControllerV1SpecTemplateSpecVolume[] | cdktn.IResolvable;
}
export declare function replicationControllerV1SpecTemplateSpecToTerraform(struct?: ReplicationControllerV1SpecTemplateSpecOutputReference | ReplicationControllerV1SpecTemplateSpec): any;
export declare function replicationControllerV1SpecTemplateSpecToHclTerraform(struct?: ReplicationControllerV1SpecTemplateSpecOutputReference | ReplicationControllerV1SpecTemplateSpec): any;
export declare class ReplicationControllerV1SpecTemplateSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplateSpec | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplateSpec | undefined);
    private _activeDeadlineSeconds?;
    get activeDeadlineSeconds(): number;
    set activeDeadlineSeconds(value: number);
    resetActiveDeadlineSeconds(): void;
    get activeDeadlineSecondsInput(): number | undefined;
    private _automountServiceAccountToken?;
    get automountServiceAccountToken(): boolean | cdktn.IResolvable;
    set automountServiceAccountToken(value: boolean | cdktn.IResolvable);
    resetAutomountServiceAccountToken(): void;
    get automountServiceAccountTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _dnsPolicy?;
    get dnsPolicy(): string;
    set dnsPolicy(value: string);
    resetDnsPolicy(): void;
    get dnsPolicyInput(): string | undefined;
    private _enableServiceLinks?;
    get enableServiceLinks(): boolean | cdktn.IResolvable;
    set enableServiceLinks(value: boolean | cdktn.IResolvable);
    resetEnableServiceLinks(): void;
    get enableServiceLinksInput(): boolean | cdktn.IResolvable | undefined;
    private _hostIpc?;
    get hostIpc(): boolean | cdktn.IResolvable;
    set hostIpc(value: boolean | cdktn.IResolvable);
    resetHostIpc(): void;
    get hostIpcInput(): boolean | cdktn.IResolvable | undefined;
    private _hostNetwork?;
    get hostNetwork(): boolean | cdktn.IResolvable;
    set hostNetwork(value: boolean | cdktn.IResolvable);
    resetHostNetwork(): void;
    get hostNetworkInput(): boolean | cdktn.IResolvable | undefined;
    private _hostPid?;
    get hostPid(): boolean | cdktn.IResolvable;
    set hostPid(value: boolean | cdktn.IResolvable);
    resetHostPid(): void;
    get hostPidInput(): boolean | cdktn.IResolvable | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _nodeName?;
    get nodeName(): string;
    set nodeName(value: string);
    resetNodeName(): void;
    get nodeNameInput(): string | undefined;
    private _nodeSelector?;
    get nodeSelector(): {
        [key: string]: string;
    };
    set nodeSelector(value: {
        [key: string]: string;
    });
    resetNodeSelector(): void;
    get nodeSelectorInput(): {
        [key: string]: string;
    } | undefined;
    private _priorityClassName?;
    get priorityClassName(): string;
    set priorityClassName(value: string);
    resetPriorityClassName(): void;
    get priorityClassNameInput(): string | undefined;
    private _restartPolicy?;
    get restartPolicy(): string;
    set restartPolicy(value: string);
    resetRestartPolicy(): void;
    get restartPolicyInput(): string | undefined;
    private _runtimeClassName?;
    get runtimeClassName(): string;
    set runtimeClassName(value: string);
    resetRuntimeClassName(): void;
    get runtimeClassNameInput(): string | undefined;
    private _schedulerName?;
    get schedulerName(): string;
    set schedulerName(value: string);
    resetSchedulerName(): void;
    get schedulerNameInput(): string | undefined;
    private _serviceAccountName?;
    get serviceAccountName(): string;
    set serviceAccountName(value: string);
    resetServiceAccountName(): void;
    get serviceAccountNameInput(): string | undefined;
    private _shareProcessNamespace?;
    get shareProcessNamespace(): boolean | cdktn.IResolvable;
    set shareProcessNamespace(value: boolean | cdktn.IResolvable);
    resetShareProcessNamespace(): void;
    get shareProcessNamespaceInput(): boolean | cdktn.IResolvable | undefined;
    private _subdomain?;
    get subdomain(): string;
    set subdomain(value: string);
    resetSubdomain(): void;
    get subdomainInput(): string | undefined;
    private _terminationGracePeriodSeconds?;
    get terminationGracePeriodSeconds(): number;
    set terminationGracePeriodSeconds(value: number);
    resetTerminationGracePeriodSeconds(): void;
    get terminationGracePeriodSecondsInput(): number | undefined;
    private _affinity;
    get affinity(): ReplicationControllerV1SpecTemplateSpecAffinityOutputReference;
    putAffinity(value: ReplicationControllerV1SpecTemplateSpecAffinity): void;
    resetAffinity(): void;
    get affinityInput(): ReplicationControllerV1SpecTemplateSpecAffinity | undefined;
    private _container;
    get container(): ReplicationControllerV1SpecTemplateSpecContainerList;
    putContainer(value: ReplicationControllerV1SpecTemplateSpecContainer[] | cdktn.IResolvable): void;
    resetContainer(): void;
    get containerInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecContainer[] | undefined;
    private _dnsConfig;
    get dnsConfig(): ReplicationControllerV1SpecTemplateSpecDnsConfigOutputReference;
    putDnsConfig(value: ReplicationControllerV1SpecTemplateSpecDnsConfig): void;
    resetDnsConfig(): void;
    get dnsConfigInput(): ReplicationControllerV1SpecTemplateSpecDnsConfig | undefined;
    private _hostAliases;
    get hostAliases(): ReplicationControllerV1SpecTemplateSpecHostAliasesList;
    putHostAliases(value: ReplicationControllerV1SpecTemplateSpecHostAliases[] | cdktn.IResolvable): void;
    resetHostAliases(): void;
    get hostAliasesInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecHostAliases[] | undefined;
    private _imagePullSecrets;
    get imagePullSecrets(): ReplicationControllerV1SpecTemplateSpecImagePullSecretsList;
    putImagePullSecrets(value: ReplicationControllerV1SpecTemplateSpecImagePullSecrets[] | cdktn.IResolvable): void;
    resetImagePullSecrets(): void;
    get imagePullSecretsInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecImagePullSecrets[] | undefined;
    private _initContainer;
    get initContainer(): ReplicationControllerV1SpecTemplateSpecInitContainerList;
    putInitContainer(value: ReplicationControllerV1SpecTemplateSpecInitContainer[] | cdktn.IResolvable): void;
    resetInitContainer(): void;
    get initContainerInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecInitContainer[] | undefined;
    private _os;
    get os(): ReplicationControllerV1SpecTemplateSpecOsOutputReference;
    putOs(value: ReplicationControllerV1SpecTemplateSpecOs): void;
    resetOs(): void;
    get osInput(): ReplicationControllerV1SpecTemplateSpecOs | undefined;
    private _readinessGate;
    get readinessGate(): ReplicationControllerV1SpecTemplateSpecReadinessGateList;
    putReadinessGate(value: ReplicationControllerV1SpecTemplateSpecReadinessGate[] | cdktn.IResolvable): void;
    resetReadinessGate(): void;
    get readinessGateInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecReadinessGate[] | undefined;
    private _securityContext;
    get securityContext(): ReplicationControllerV1SpecTemplateSpecSecurityContextOutputReference;
    putSecurityContext(value: ReplicationControllerV1SpecTemplateSpecSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): ReplicationControllerV1SpecTemplateSpecSecurityContext | undefined;
    private _toleration;
    get toleration(): ReplicationControllerV1SpecTemplateSpecTolerationList;
    putToleration(value: ReplicationControllerV1SpecTemplateSpecToleration[] | cdktn.IResolvable): void;
    resetToleration(): void;
    get tolerationInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecToleration[] | undefined;
    private _topologySpreadConstraint;
    get topologySpreadConstraint(): ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraintList;
    putTopologySpreadConstraint(value: ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint[] | cdktn.IResolvable): void;
    resetTopologySpreadConstraint(): void;
    get topologySpreadConstraintInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecTopologySpreadConstraint[] | undefined;
    private _volume;
    get volume(): ReplicationControllerV1SpecTemplateSpecVolumeList;
    putVolume(value: ReplicationControllerV1SpecTemplateSpecVolume[] | cdktn.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | ReplicationControllerV1SpecTemplateSpecVolume[] | undefined;
}
export interface ReplicationControllerV1SpecTemplate {
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#metadata ReplicationControllerV1#metadata}
    */
    readonly metadata: ReplicationControllerV1SpecTemplateMetadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#spec ReplicationControllerV1#spec}
    */
    readonly spec: ReplicationControllerV1SpecTemplateSpec;
}
export declare function replicationControllerV1SpecTemplateToTerraform(struct?: ReplicationControllerV1SpecTemplateOutputReference | ReplicationControllerV1SpecTemplate): any;
export declare function replicationControllerV1SpecTemplateToHclTerraform(struct?: ReplicationControllerV1SpecTemplateOutputReference | ReplicationControllerV1SpecTemplate): any;
export declare class ReplicationControllerV1SpecTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1SpecTemplate | undefined;
    set internalValue(value: ReplicationControllerV1SpecTemplate | undefined);
    private _metadata;
    get metadata(): ReplicationControllerV1SpecTemplateMetadataOutputReference;
    putMetadata(value: ReplicationControllerV1SpecTemplateMetadata): void;
    get metadataInput(): ReplicationControllerV1SpecTemplateMetadata | undefined;
    private _spec;
    get spec(): ReplicationControllerV1SpecTemplateSpecOutputReference;
    putSpec(value: ReplicationControllerV1SpecTemplateSpec): void;
    get specInput(): ReplicationControllerV1SpecTemplateSpec | undefined;
}
export interface ReplicationControllerV1Spec {
    /**
    * Minimum number of seconds for which a newly created pod should be ready without any of its container crashing, for it to be considered available. Defaults to 0 (pod will be considered available as soon as it is ready)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#min_ready_seconds ReplicationControllerV1#min_ready_seconds}
    */
    readonly minReadySeconds?: number;
    /**
    * The number of desired replicas. Defaults to 1. More info: https://kubernetes.io/docs/concepts/workloads/controllers/replicationcontroller#what-is-a-replicationcontroller
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#replicas ReplicationControllerV1#replicas}
    */
    readonly replicas?: number;
    /**
    * A label query over pods that should match the Replicas count. If Selector is empty, it is defaulted to the labels present on the Pod template. Label keys and values that must match in order to be controlled by this replication controller, if empty defaulted to labels on Pod template. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#label-selectors
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#selector ReplicationControllerV1#selector}
    */
    readonly selector: {
        [key: string]: string;
    };
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#template ReplicationControllerV1#template}
    */
    readonly template: ReplicationControllerV1SpecTemplate;
}
export declare function replicationControllerV1SpecToTerraform(struct?: ReplicationControllerV1SpecOutputReference | ReplicationControllerV1Spec): any;
export declare function replicationControllerV1SpecToHclTerraform(struct?: ReplicationControllerV1SpecOutputReference | ReplicationControllerV1Spec): any;
export declare class ReplicationControllerV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1Spec | undefined;
    set internalValue(value: ReplicationControllerV1Spec | undefined);
    private _minReadySeconds?;
    get minReadySeconds(): number;
    set minReadySeconds(value: number);
    resetMinReadySeconds(): void;
    get minReadySecondsInput(): number | undefined;
    private _replicas?;
    get replicas(): number;
    set replicas(value: number);
    resetReplicas(): void;
    get replicasInput(): number | undefined;
    private _selector?;
    get selector(): {
        [key: string]: string;
    };
    set selector(value: {
        [key: string]: string;
    });
    get selectorInput(): {
        [key: string]: string;
    } | undefined;
    private _template;
    get template(): ReplicationControllerV1SpecTemplateOutputReference;
    putTemplate(value: ReplicationControllerV1SpecTemplate): void;
    get templateInput(): ReplicationControllerV1SpecTemplate | undefined;
}
export interface ReplicationControllerV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#create ReplicationControllerV1#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#delete ReplicationControllerV1#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/2.38.0/docs/resources/replication_controller_v1#update ReplicationControllerV1#update}
    */
    readonly update?: string;
}
export declare function replicationControllerV1TimeoutsToTerraform(struct?: ReplicationControllerV1Timeouts | cdktn.IResolvable): any;
export declare function replicationControllerV1TimeoutsToHclTerraform(struct?: ReplicationControllerV1Timeouts | cdktn.IResolvable): any;
export declare class ReplicationControllerV1TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReplicationControllerV1Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ReplicationControllerV1Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
