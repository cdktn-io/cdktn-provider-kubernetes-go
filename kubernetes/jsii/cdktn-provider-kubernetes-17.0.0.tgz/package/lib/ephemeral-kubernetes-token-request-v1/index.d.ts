/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralKubernetesTokenRequestV1Config extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * ExpirationTimestamp is the time of expiration of the returned token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#expiration_timestamp EphemeralKubernetesTokenRequestV1#expiration_timestamp}
    */
    readonly expirationTimestamp?: string;
    /**
    * Token is the opaque bearer token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#token EphemeralKubernetesTokenRequestV1#token}
    */
    readonly token?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#metadata EphemeralKubernetesTokenRequestV1#metadata}
    */
    readonly metadata: EphemeralKubernetesTokenRequestV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#spec EphemeralKubernetesTokenRequestV1#spec}
    */
    readonly spec?: EphemeralKubernetesTokenRequestV1Spec;
}
export interface EphemeralKubernetesTokenRequestV1Metadata {
    /**
    * Name must be unique within a namespace. Is required when creating resources, although some resources may allow a client to request the generation of an appropriate name automatically. Name is primarily intended for creation idempotence and configuration definition. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#name EphemeralKubernetesTokenRequestV1#name}
    */
    readonly name: string;
    /**
    * Namespace defines the space within which each name must be unique. An empty namespace is equivalent to the "default" namespace, but "default" is the canonical representation. Not all objects are required to be scoped to a namespace - the value of this field for those objects will be empty.
    *
    * Must be a DNS_LABEL. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#namespace EphemeralKubernetesTokenRequestV1#namespace}
    */
    readonly namespace: string;
}
export declare function ephemeralKubernetesTokenRequestV1MetadataToTerraform(struct?: EphemeralKubernetesTokenRequestV1Metadata | cdktn.IResolvable): any;
export declare function ephemeralKubernetesTokenRequestV1MetadataToHclTerraform(struct?: EphemeralKubernetesTokenRequestV1Metadata | cdktn.IResolvable): any;
export declare class EphemeralKubernetesTokenRequestV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralKubernetesTokenRequestV1Metadata | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralKubernetesTokenRequestV1Metadata | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
}
export interface EphemeralKubernetesTokenRequestV1SpecBoundObjectRef {
    /**
    * API version of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#api_version EphemeralKubernetesTokenRequestV1#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Kind of the referent. Valid kinds are 'Pod' and 'Secret'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#kind EphemeralKubernetesTokenRequestV1#kind}
    */
    readonly kind?: string;
    /**
    * Name of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#name EphemeralKubernetesTokenRequestV1#name}
    */
    readonly name?: string;
    /**
    * UID of the referent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#uid EphemeralKubernetesTokenRequestV1#uid}
    */
    readonly uid?: string;
}
export declare function ephemeralKubernetesTokenRequestV1SpecBoundObjectRefToTerraform(struct?: EphemeralKubernetesTokenRequestV1SpecBoundObjectRef | cdktn.IResolvable): any;
export declare function ephemeralKubernetesTokenRequestV1SpecBoundObjectRefToHclTerraform(struct?: EphemeralKubernetesTokenRequestV1SpecBoundObjectRef | cdktn.IResolvable): any;
export declare class EphemeralKubernetesTokenRequestV1SpecBoundObjectRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralKubernetesTokenRequestV1SpecBoundObjectRef | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralKubernetesTokenRequestV1SpecBoundObjectRef | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _uid?;
    get uid(): string;
    set uid(value: string);
    resetUid(): void;
    get uidInput(): string | undefined;
}
export interface EphemeralKubernetesTokenRequestV1Spec {
    /**
    * Audiences are the intendend audiences of the token. A recipient of a token must identify themself with an identifier in the list of audiences of the token, and otherwise should reject the token. A token issued for multiple audiences may be used to authenticate against any of the audiences listed but implies a high degree of trust between the target audiences.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#audiences EphemeralKubernetesTokenRequestV1#audiences}
    */
    readonly audiences?: string[];
    /**
    * ExpirationSeconds is the requested duration of validity of the request. The token issuer may return a token with a different validity duration so a client needs to check the 'expiration' field in a response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#expiration_seconds EphemeralKubernetesTokenRequestV1#expiration_seconds}
    */
    readonly expirationSeconds?: number;
    /**
    * bound_object_ref block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1#bound_object_ref EphemeralKubernetesTokenRequestV1#bound_object_ref}
    */
    readonly boundObjectRef?: EphemeralKubernetesTokenRequestV1SpecBoundObjectRef;
}
export declare function ephemeralKubernetesTokenRequestV1SpecToTerraform(struct?: EphemeralKubernetesTokenRequestV1Spec | cdktn.IResolvable): any;
export declare function ephemeralKubernetesTokenRequestV1SpecToHclTerraform(struct?: EphemeralKubernetesTokenRequestV1Spec | cdktn.IResolvable): any;
export declare class EphemeralKubernetesTokenRequestV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralKubernetesTokenRequestV1Spec | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralKubernetesTokenRequestV1Spec | cdktn.IResolvable | undefined);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _expirationSeconds?;
    get expirationSeconds(): number;
    set expirationSeconds(value: number);
    resetExpirationSeconds(): void;
    get expirationSecondsInput(): number | undefined;
    private _boundObjectRef;
    get boundObjectRef(): EphemeralKubernetesTokenRequestV1SpecBoundObjectRefOutputReference;
    putBoundObjectRef(value: EphemeralKubernetesTokenRequestV1SpecBoundObjectRef): void;
    resetBoundObjectRef(): void;
    get boundObjectRefInput(): cdktn.IResolvable | EphemeralKubernetesTokenRequestV1SpecBoundObjectRef | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1 kubernetes_token_request_v1}
*/
export declare class EphemeralKubernetesTokenRequestV1 extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "kubernetes_token_request_v1";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/token_request_v1 kubernetes_token_request_v1} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralKubernetesTokenRequestV1Config
    */
    constructor(scope: Construct, id: string, config: EphemeralKubernetesTokenRequestV1Config);
    private _expirationTimestamp?;
    get expirationTimestamp(): string;
    set expirationTimestamp(value: string);
    resetExpirationTimestamp(): void;
    get expirationTimestampInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _metadata;
    get metadata(): EphemeralKubernetesTokenRequestV1MetadataOutputReference;
    putMetadata(value: EphemeralKubernetesTokenRequestV1Metadata): void;
    get metadataInput(): cdktn.IResolvable | EphemeralKubernetesTokenRequestV1Metadata | undefined;
    private _spec;
    get spec(): EphemeralKubernetesTokenRequestV1SpecOutputReference;
    putSpec(value: EphemeralKubernetesTokenRequestV1Spec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | EphemeralKubernetesTokenRequestV1Spec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
