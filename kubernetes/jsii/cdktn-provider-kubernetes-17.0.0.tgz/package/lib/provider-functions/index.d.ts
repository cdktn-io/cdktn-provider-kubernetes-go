/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
/**
* Provider-defined functions of the kubernetes provider.
*/
export declare class KubernetesProviderFunctions {
    private readonly providerLocalName;
    /**
    * @param providerLocalName The local name of the provider in required_providers; defaults to the registry short name. Override when the provider is declared under a different local name — aliases do not change the namespace, local names do.
    */
    constructor(providerLocalName: string);
    /**
    * Given a YAML text containing a Kubernetes manifest, will decode and return an object representation of that resource.
    * @param {string} manifest - The YAML text for a Kubernetes manifest
    * @returns {any}
    */
    manifestDecode(manifest: string): cdktn.IResolvable;
    /**
    * Given a YAML text containing a Kubernetes manifest with multiple resources, will decode the manifest and return a tuple of object representations for each resource.
    * @param {string} manifest - The YAML plaintext for a Kubernetes manifest
    * @returns {any}
    */
    manifestDecodeMulti(manifest: string): cdktn.IResolvable;
    /**
    * Given an object representation of a Kubernetes manifest, will encode and return a YAML string for that resource.
    * @param {any} manifest - The object representation of a Kubernetes manifest
    * @returns {string}
    */
    manifestEncode(manifest: any): string;
}
