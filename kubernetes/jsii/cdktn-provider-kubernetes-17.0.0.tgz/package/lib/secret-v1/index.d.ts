/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretV1Config extends cdktn.TerraformMetaArguments {
    /**
    * A map of the secret data in base64 encoding. Use this for binary data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#binary_data SecretV1#binary_data}
    */
    readonly binaryData?: {
        [key: string]: string;
    };
    /**
    * A write-only map of the secret data in base64 encoding. Use this for binary data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#binary_data_wo SecretV1#binary_data_wo}
    */
    readonly binaryDataWo?: {
        [key: string]: string;
    };
    /**
    * The current revision of the write-only "binary_data_wo" attribute. Incrementing this integer value will cause Terraform to update the write-only value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#binary_data_wo_revision SecretV1#binary_data_wo_revision}
    */
    readonly binaryDataWoRevision?: number;
    /**
    * A map of the secret data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#data SecretV1#data}
    */
    readonly data?: {
        [key: string]: string;
    };
    /**
    * A map write-only of the secret data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#data_wo SecretV1#data_wo}
    */
    readonly dataWo?: {
        [key: string]: string;
    };
    /**
    * The current revision of the write-only "data_wo" attribute. Incrementing this integer value will cause Terraform to update the write-only value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#data_wo_revision SecretV1#data_wo_revision}
    */
    readonly dataWoRevision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#id SecretV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Ensures that data stored in the Secret cannot be updated (only object metadata can be modified).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#immutable SecretV1#immutable}
    */
    readonly immutable?: boolean | cdktn.IResolvable;
    /**
    * Type of secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#type SecretV1#type}
    */
    readonly type?: string;
    /**
    * Terraform will wait for the service account token to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#wait_for_service_account_token SecretV1#wait_for_service_account_token}
    */
    readonly waitForServiceAccountToken?: boolean | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#metadata SecretV1#metadata}
    */
    readonly metadata: SecretV1Metadata;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#timeouts SecretV1#timeouts}
    */
    readonly timeouts?: SecretV1Timeouts;
}
export interface SecretV1Metadata {
    /**
    * An unstructured key value map stored with the secret that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#annotations SecretV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#generate_name SecretV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the secret. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#labels SecretV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the secret, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#name SecretV1#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the secret must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#namespace SecretV1#namespace}
    */
    readonly namespace?: string;
}
export declare function secretV1MetadataToTerraform(struct?: SecretV1MetadataOutputReference | SecretV1Metadata): any;
export declare function secretV1MetadataToHclTerraform(struct?: SecretV1MetadataOutputReference | SecretV1Metadata): any;
export declare class SecretV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretV1Metadata | undefined;
    set internalValue(value: SecretV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface SecretV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#create SecretV1#create}
    */
    readonly create?: string;
}
export declare function secretV1TimeoutsToTerraform(struct?: SecretV1Timeouts | cdktn.IResolvable): any;
export declare function secretV1TimeoutsToHclTerraform(struct?: SecretV1Timeouts | cdktn.IResolvable): any;
export declare class SecretV1TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretV1Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SecretV1Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1 kubernetes_secret_v1}
*/
export declare class SecretV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_secret_v1";
    /**
    * Generates CDKTN code for importing a SecretV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretV1 to import
    * @param importFromId The id of the existing SecretV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/resources/secret_v1 kubernetes_secret_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretV1Config
    */
    constructor(scope: Construct, id: string, config: SecretV1Config);
    private _binaryData?;
    get binaryData(): {
        [key: string]: string;
    };
    set binaryData(value: {
        [key: string]: string;
    });
    resetBinaryData(): void;
    get binaryDataInput(): {
        [key: string]: string;
    } | undefined;
    private _binaryDataWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get binaryDataWo(): {
        [key: string]: string;
    };
    set binaryDataWo(value: {
        [key: string]: string;
    });
    resetBinaryDataWo(): void;
    get binaryDataWoInput(): {
        [key: string]: string;
    } | undefined;
    private _binaryDataWoRevision?;
    get binaryDataWoRevision(): number;
    set binaryDataWoRevision(value: number);
    resetBinaryDataWoRevision(): void;
    get binaryDataWoRevisionInput(): number | undefined;
    private _data?;
    get data(): {
        [key: string]: string;
    };
    set data(value: {
        [key: string]: string;
    });
    resetData(): void;
    get dataInput(): {
        [key: string]: string;
    } | undefined;
    private _dataWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get dataWo(): {
        [key: string]: string;
    };
    set dataWo(value: {
        [key: string]: string;
    });
    resetDataWo(): void;
    get dataWoInput(): {
        [key: string]: string;
    } | undefined;
    private _dataWoRevision?;
    get dataWoRevision(): number;
    set dataWoRevision(value: number);
    resetDataWoRevision(): void;
    get dataWoRevisionInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _immutable?;
    get immutable(): boolean | cdktn.IResolvable;
    set immutable(value: boolean | cdktn.IResolvable);
    resetImmutable(): void;
    get immutableInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _waitForServiceAccountToken?;
    get waitForServiceAccountToken(): boolean | cdktn.IResolvable;
    set waitForServiceAccountToken(value: boolean | cdktn.IResolvable);
    resetWaitForServiceAccountToken(): void;
    get waitForServiceAccountTokenInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): SecretV1MetadataOutputReference;
    putMetadata(value: SecretV1Metadata): void;
    get metadataInput(): SecretV1Metadata | undefined;
    private _timeouts;
    get timeouts(): SecretV1TimeoutsOutputReference;
    putTimeouts(value: SecretV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SecretV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
