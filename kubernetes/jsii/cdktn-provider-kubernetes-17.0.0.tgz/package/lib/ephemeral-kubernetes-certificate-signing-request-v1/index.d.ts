/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralKubernetesCertificateSigningRequestV1Config extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Automatically approve the Certificate Signing Request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#auto_approve EphemeralKubernetesCertificateSigningRequestV1#auto_approve}
    */
    readonly autoApprove?: boolean | cdktn.IResolvable;
    /**
    * certificate is populated with an issued certificate by the signer after an Approved condition is present. This field is set via the /status subresource. Once populated, this field is immutable.
    *
    * If the certificate signing request is denied, a condition of type "Denied" is added and this field remains empty. If the signer cannot issue the certificate, a condition of type "Failed" is added and this field remains empty.
    *
    * Validation requirements:
    *  1. certificate must contain one or more PEM blocks.
    *  2. All PEM blocks must have the "CERTIFICATE" label, contain no headers, and the encoded data
    *   must be a BER-encoded ASN.1 Certificate structure as described in section 4 of RFC5280.
    *  3. Non-PEM content may appear before or after the "CERTIFICATE" PEM blocks and is unvalidated,
    *   to allow for explanatory text as described in section 5.2 of RFC7468.
    *
    * If more than one PEM block is present, and the definition of the requested spec.signerName does not indicate otherwise, the first block is the issued certificate, and subsequent blocks should be treated as intermediate certificates and presented in TLS handshakes.
    *
    * The certificate is encoded in PEM format.
    *
    * When serialized as JSON or YAML, the data is additionally base64-encoded, so it consists of:
    *
    *     base64(
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#certificate EphemeralKubernetesCertificateSigningRequestV1#certificate}
    */
    readonly certificate?: string;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#metadata EphemeralKubernetesCertificateSigningRequestV1#metadata}
    */
    readonly metadata: EphemeralKubernetesCertificateSigningRequestV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#spec EphemeralKubernetesCertificateSigningRequestV1#spec}
    */
    readonly spec?: EphemeralKubernetesCertificateSigningRequestV1Spec;
}
export interface EphemeralKubernetesCertificateSigningRequestV1Metadata {
    /**
    * Name must be unique within a namespace. Is required when creating resources, although some resources may allow a client to request the generation of an appropriate name automatically. Name is primarily intended for creation idempotence and configuration definition. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#name EphemeralKubernetesCertificateSigningRequestV1#name}
    */
    readonly name: string;
}
export declare function ephemeralKubernetesCertificateSigningRequestV1MetadataToTerraform(struct?: EphemeralKubernetesCertificateSigningRequestV1Metadata | cdktn.IResolvable): any;
export declare function ephemeralKubernetesCertificateSigningRequestV1MetadataToHclTerraform(struct?: EphemeralKubernetesCertificateSigningRequestV1Metadata | cdktn.IResolvable): any;
export declare class EphemeralKubernetesCertificateSigningRequestV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralKubernetesCertificateSigningRequestV1Metadata | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralKubernetesCertificateSigningRequestV1Metadata | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface EphemeralKubernetesCertificateSigningRequestV1Spec {
    /**
    * expirationSeconds is the requested duration of validity of the issued certificate. The certificate signer may issue a certificate with a different validity duration so a client must check the delta between the notBefore and and notAfter fields in the issued certificate to determine the actual duration.
    *
    * The v1.22+ in-tree implementations of the well-known Kubernetes signers will honor this field as long as the requested duration is not greater than the maximum duration they will honor per the --cluster-signing-duration CLI flag to the Kubernetes controller manager.
    *
    * Certificate signers may not honor this field for various reasons:
    *
    *   1. Old signer that is unaware of the field (such as the in-tree
    *      implementations prior to v1.22)
    *   2. Signer whose configured maximum is shorter than the requested duration
    *   3. Signer whose configured minimum is longer than the requested duration
    *
    * The minimum valid value for expirationSeconds is 600, i.e. 10 minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#expiration_seconds EphemeralKubernetesCertificateSigningRequestV1#expiration_seconds}
    */
    readonly expirationSeconds?: number;
    /**
    * request contains an x509 certificate signing request encoded in a "CERTIFICATE REQUEST" PEM block. When serialized as JSON or YAML, the data is additionally base64-encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#request EphemeralKubernetesCertificateSigningRequestV1#request}
    */
    readonly request: string;
    /**
    * signerName indicates the requested signer, and is a qualified name.
    *
    * List/watch requests for CertificateSigningRequests can filter on this field using a "spec.signerName=NAME" fieldSelector.
    *
    * Well-known Kubernetes signers are:
    *  1. "kubernetes.io/kube-apiserver-client": issues client certificates that can be used to authenticate to kube-apiserver.
    *   Requests for this signer are never auto-approved by kube-controller-manager, can be issued by the "csrsigning" controller in kube-controller-manager.
    *  2. "kubernetes.io/kube-apiserver-client-kubelet": issues client certificates that kubelets use to authenticate to kube-apiserver.
    *   Requests for this signer can be auto-approved by the "csrapproving" controller in kube-controller-manager, and can be issued by the "csrsigning" controller in kube-controller-manager.
    *  3. "kubernetes.io/kubelet-serving" issues serving certificates that kubelets use to serve TLS endpoints, which kube-apiserver can connect to securely.
    *   Requests for this signer are never auto-approved by kube-controller-manager, and can be issued by the "csrsigning" controller in kube-controller-manager.
    *
    * More details are available at https://k8s.io/docs/reference/access-authn-authz/certificate-signing-requests/#kubernetes-signers
    *
    * Custom signerNames can also be specified. The signer defines:
    *  1. Trust distribution: how trust (CA bundles) are distributed.
    *  2. Permitted subjects: and behavior when a disallowed subject is requested.
    *  3. Required, permitted, or forbidden x509 extensions in the request (including whether subjectAltNames are allowed, which types, restrictions on allowed values) and behavior when a disallowed extension is requested.
    *  4. Required, permitted, or forbidden key usages / extended key usages.
    *  5. Expiration/certificate lifetime: whether it is fixed by the signer, configurable by the admin.
    *  6. Whether or not requests for CA certificates are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#signer_name EphemeralKubernetesCertificateSigningRequestV1#signer_name}
    */
    readonly signerName: string;
    /**
    * usages specifies a set of key usages requested in the issued certificate.
    *
    * Requests for TLS client certificates typically request: "digital signature", "key encipherment", "client auth".
    *
    * Requests for TLS serving certificates typically request: "key encipherment", "digital signature", "server auth".
    *
    * Valid values are:
    *  "signing", "digital signature", "content commitment",
    *  "key encipherment", "key agreement", "data encipherment",
    *  "cert sign", "crl sign", "encipher only", "decipher only", "any",
    *  "server auth", "client auth",
    *  "code signing", "email protection", "s/mime",
    *  "ipsec end system", "ipsec tunnel", "ipsec user",
    *  "timestamping", "ocsp signing", "microsoft sgc", "netscape sgc"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1#usages EphemeralKubernetesCertificateSigningRequestV1#usages}
    */
    readonly usages?: string[];
}
export declare function ephemeralKubernetesCertificateSigningRequestV1SpecToTerraform(struct?: EphemeralKubernetesCertificateSigningRequestV1Spec | cdktn.IResolvable): any;
export declare function ephemeralKubernetesCertificateSigningRequestV1SpecToHclTerraform(struct?: EphemeralKubernetesCertificateSigningRequestV1Spec | cdktn.IResolvable): any;
export declare class EphemeralKubernetesCertificateSigningRequestV1SpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EphemeralKubernetesCertificateSigningRequestV1Spec | cdktn.IResolvable | undefined;
    set internalValue(value: EphemeralKubernetesCertificateSigningRequestV1Spec | cdktn.IResolvable | undefined);
    private _expirationSeconds?;
    get expirationSeconds(): number;
    set expirationSeconds(value: number);
    resetExpirationSeconds(): void;
    get expirationSecondsInput(): number | undefined;
    private _request?;
    get request(): string;
    set request(value: string);
    get requestInput(): string | undefined;
    private _signerName?;
    get signerName(): string;
    set signerName(value: string);
    get signerNameInput(): string | undefined;
    private _usages?;
    get usages(): string[];
    set usages(value: string[]);
    resetUsages(): void;
    get usagesInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1 kubernetes_certificate_signing_request_v1}
*/
export declare class EphemeralKubernetesCertificateSigningRequestV1 extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "kubernetes_certificate_signing_request_v1";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.2.1/docs/ephemeral-resources/certificate_signing_request_v1 kubernetes_certificate_signing_request_v1} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralKubernetesCertificateSigningRequestV1Config
    */
    constructor(scope: Construct, id: string, config: EphemeralKubernetesCertificateSigningRequestV1Config);
    private _autoApprove?;
    get autoApprove(): boolean | cdktn.IResolvable;
    set autoApprove(value: boolean | cdktn.IResolvable);
    resetAutoApprove(): void;
    get autoApproveInput(): boolean | cdktn.IResolvable | undefined;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _metadata;
    get metadata(): EphemeralKubernetesCertificateSigningRequestV1MetadataOutputReference;
    putMetadata(value: EphemeralKubernetesCertificateSigningRequestV1Metadata): void;
    get metadataInput(): cdktn.IResolvable | EphemeralKubernetesCertificateSigningRequestV1Metadata | undefined;
    private _spec;
    get spec(): EphemeralKubernetesCertificateSigningRequestV1SpecOutputReference;
    putSpec(value: EphemeralKubernetesCertificateSigningRequestV1Spec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | EphemeralKubernetesCertificateSigningRequestV1Spec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
