/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataKubernetesConfigMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#id DataKubernetesConfigMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Immutable, if set to true, ensures that data stored in the ConfigMap cannot be updated (only object metadata can be modified). If not set to true, the field can be modified at any time. Defaulted to nil.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#immutable DataKubernetesConfigMap#immutable}
    */
    readonly immutable?: boolean | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#metadata DataKubernetesConfigMap#metadata}
    */
    readonly metadata: DataKubernetesConfigMapMetadata;
}
export interface DataKubernetesConfigMapMetadata {
    /**
    * An unstructured key value map stored with the config_map that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#annotations DataKubernetesConfigMap#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the config_map. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#labels DataKubernetesConfigMap#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the config_map, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#name DataKubernetesConfigMap#name}
    */
    readonly name?: string;
    /**
    * Namespace defines the space within which name of the config_map must be unique.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#namespace DataKubernetesConfigMap#namespace}
    */
    readonly namespace?: string;
}
export declare function dataKubernetesConfigMapMetadataToTerraform(struct?: DataKubernetesConfigMapMetadataOutputReference | DataKubernetesConfigMapMetadata): any;
export declare function dataKubernetesConfigMapMetadataToHclTerraform(struct?: DataKubernetesConfigMapMetadataOutputReference | DataKubernetesConfigMapMetadata): any;
export declare class DataKubernetesConfigMapMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataKubernetesConfigMapMetadata | undefined;
    set internalValue(value: DataKubernetesConfigMapMetadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map kubernetes_config_map}
*/
export declare class DataKubernetesConfigMap extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "kubernetes_config_map";
    /**
    * Generates CDKTN code for importing a DataKubernetesConfigMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataKubernetesConfigMap to import
    * @param importFromId The id of the existing DataKubernetesConfigMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataKubernetesConfigMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/data-sources/config_map kubernetes_config_map} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataKubernetesConfigMapConfig
    */
    constructor(scope: Construct, id: string, config: DataKubernetesConfigMapConfig);
    private _binaryData;
    get binaryData(): cdktn.StringMap;
    private _data;
    get data(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _immutable?;
    get immutable(): boolean | cdktn.IResolvable;
    set immutable(value: boolean | cdktn.IResolvable);
    resetImmutable(): void;
    get immutableInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): DataKubernetesConfigMapMetadataOutputReference;
    putMetadata(value: DataKubernetesConfigMapMetadata): void;
    get metadataInput(): DataKubernetesConfigMapMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
