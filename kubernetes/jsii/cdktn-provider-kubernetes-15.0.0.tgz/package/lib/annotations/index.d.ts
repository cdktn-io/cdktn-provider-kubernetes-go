/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AnnotationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * A map of annotations to apply to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#annotations Annotations#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The apiVersion of the resource to annotate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#api_version Annotations#api_version}
    */
    readonly apiVersion: string;
    /**
    * Set the name of the field manager for the specified labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#field_manager Annotations#field_manager}
    */
    readonly fieldManager?: string;
    /**
    * Force overwriting annotations that were created or edited outside of Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#force Annotations#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#id Annotations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The kind of the resource to annotate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#kind Annotations#kind}
    */
    readonly kind: string;
    /**
    * A map of annotations to apply to the resource template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#template_annotations Annotations#template_annotations}
    */
    readonly templateAnnotations?: {
        [key: string]: string;
    };
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#metadata Annotations#metadata}
    */
    readonly metadata: AnnotationsMetadata;
}
export interface AnnotationsMetadata {
    /**
    * The name of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#name Annotations#name}
    */
    readonly name: string;
    /**
    * The namespace of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#namespace Annotations#namespace}
    */
    readonly namespace?: string;
}
export declare function annotationsMetadataToTerraform(struct?: AnnotationsMetadataOutputReference | AnnotationsMetadata): any;
export declare function annotationsMetadataToHclTerraform(struct?: AnnotationsMetadataOutputReference | AnnotationsMetadata): any;
export declare class AnnotationsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AnnotationsMetadata | undefined;
    set internalValue(value: AnnotationsMetadata | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations kubernetes_annotations}
*/
export declare class Annotations extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_annotations";
    /**
    * Generates CDKTN code for importing a Annotations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Annotations to import
    * @param importFromId The id of the existing Annotations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Annotations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/annotations kubernetes_annotations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AnnotationsConfig
    */
    constructor(scope: Construct, id: string, config: AnnotationsConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _fieldManager?;
    get fieldManager(): string;
    set fieldManager(value: string);
    resetFieldManager(): void;
    get fieldManagerInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _templateAnnotations?;
    get templateAnnotations(): {
        [key: string]: string;
    };
    set templateAnnotations(value: {
        [key: string]: string;
    });
    resetTemplateAnnotations(): void;
    get templateAnnotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _metadata;
    get metadata(): AnnotationsMetadataOutputReference;
    putMetadata(value: AnnotationsMetadata): void;
    get metadataInput(): AnnotationsMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
