/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { PodV1Metadata, PodV1MetadataOutputReference, PodV1Spec, PodV1SpecOutputReference, PodV1Timeouts, PodV1TimeoutsOutputReference } from './index-structs';
export * from './index-structs';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PodV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1#id PodV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of the pod phases that indicate whether it was successfully created. Options: "Pending", "Running", "Succeeded", "Failed", "Unknown". Default: "Running". More info: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#pod-phase
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1#target_state PodV1#target_state}
    */
    readonly targetState?: string[];
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1#metadata PodV1#metadata}
    */
    readonly metadata: PodV1Metadata;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1#spec PodV1#spec}
    */
    readonly spec: PodV1Spec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1#timeouts PodV1#timeouts}
    */
    readonly timeouts?: PodV1Timeouts;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1 kubernetes_pod_v1}
*/
export declare class PodV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_pod_v1";
    /**
    * Generates CDKTN code for importing a PodV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PodV1 to import
    * @param importFromId The id of the existing PodV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PodV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/pod_v1 kubernetes_pod_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PodV1Config
    */
    constructor(scope: Construct, id: string, config: PodV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _targetState?;
    get targetState(): string[];
    set targetState(value: string[]);
    resetTargetState(): void;
    get targetStateInput(): string[] | undefined;
    private _metadata;
    get metadata(): PodV1MetadataOutputReference;
    putMetadata(value: PodV1Metadata): void;
    get metadataInput(): PodV1Metadata | undefined;
    private _spec;
    get spec(): PodV1SpecOutputReference;
    putSpec(value: PodV1Spec): void;
    get specInput(): PodV1Spec | undefined;
    private _timeouts;
    get timeouts(): PodV1TimeoutsOutputReference;
    putTimeouts(value: PodV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PodV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
