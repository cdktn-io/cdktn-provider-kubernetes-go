/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClusterRoleV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#id ClusterRoleV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * aggregation_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#aggregation_rule ClusterRoleV1#aggregation_rule}
    */
    readonly aggregationRule?: ClusterRoleV1AggregationRule;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#metadata ClusterRoleV1#metadata}
    */
    readonly metadata: ClusterRoleV1Metadata;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#rule ClusterRoleV1#rule}
    */
    readonly rule?: ClusterRoleV1Rule[] | cdktn.IResolvable;
}
export interface ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions {
    /**
    * The label key that the selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#key ClusterRoleV1#key}
    */
    readonly key?: string;
    /**
    * A key's relationship to a set of values. Valid operators ard `In`, `NotIn`, `Exists` and `DoesNotExist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#operator ClusterRoleV1#operator}
    */
    readonly operator?: string;
    /**
    * An array of string values. If the operator is `In` or `NotIn`, the values array must be non-empty. If the operator is `Exists` or `DoesNotExist`, the values array must be empty. This array is replaced during a strategic merge patch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#values ClusterRoleV1#values}
    */
    readonly values?: string[];
}
export declare function clusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressionsToTerraform(struct?: ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable): any;
export declare function clusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressionsToHclTerraform(struct?: ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable): any;
export declare class ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressionsList extends cdktn.ComplexList {
    internalValue?: ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressionsOutputReference;
}
export interface ClusterRoleV1AggregationRuleClusterRoleSelectors {
    /**
    * A map of {key,value} pairs. A single {key,value} in the matchLabels map is equivalent to an element of `match_expressions`, whose key field is "key", the operator is "In", and the values array contains only "value". The requirements are ANDed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#match_labels ClusterRoleV1#match_labels}
    */
    readonly matchLabels?: {
        [key: string]: string;
    };
    /**
    * match_expressions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#match_expressions ClusterRoleV1#match_expressions}
    */
    readonly matchExpressions?: ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions[] | cdktn.IResolvable;
}
export declare function clusterRoleV1AggregationRuleClusterRoleSelectorsToTerraform(struct?: ClusterRoleV1AggregationRuleClusterRoleSelectors | cdktn.IResolvable): any;
export declare function clusterRoleV1AggregationRuleClusterRoleSelectorsToHclTerraform(struct?: ClusterRoleV1AggregationRuleClusterRoleSelectors | cdktn.IResolvable): any;
export declare class ClusterRoleV1AggregationRuleClusterRoleSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterRoleV1AggregationRuleClusterRoleSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterRoleV1AggregationRuleClusterRoleSelectors | cdktn.IResolvable | undefined);
    private _matchLabels?;
    get matchLabels(): {
        [key: string]: string;
    };
    set matchLabels(value: {
        [key: string]: string;
    });
    resetMatchLabels(): void;
    get matchLabelsInput(): {
        [key: string]: string;
    } | undefined;
    private _matchExpressions;
    get matchExpressions(): ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressionsList;
    putMatchExpressions(value: ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions[] | cdktn.IResolvable): void;
    resetMatchExpressions(): void;
    get matchExpressionsInput(): cdktn.IResolvable | ClusterRoleV1AggregationRuleClusterRoleSelectorsMatchExpressions[] | undefined;
}
export declare class ClusterRoleV1AggregationRuleClusterRoleSelectorsList extends cdktn.ComplexList {
    internalValue?: ClusterRoleV1AggregationRuleClusterRoleSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterRoleV1AggregationRuleClusterRoleSelectorsOutputReference;
}
export interface ClusterRoleV1AggregationRule {
    /**
    * cluster_role_selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#cluster_role_selectors ClusterRoleV1#cluster_role_selectors}
    */
    readonly clusterRoleSelectors?: ClusterRoleV1AggregationRuleClusterRoleSelectors[] | cdktn.IResolvable;
}
export declare function clusterRoleV1AggregationRuleToTerraform(struct?: ClusterRoleV1AggregationRuleOutputReference | ClusterRoleV1AggregationRule): any;
export declare function clusterRoleV1AggregationRuleToHclTerraform(struct?: ClusterRoleV1AggregationRuleOutputReference | ClusterRoleV1AggregationRule): any;
export declare class ClusterRoleV1AggregationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterRoleV1AggregationRule | undefined;
    set internalValue(value: ClusterRoleV1AggregationRule | undefined);
    private _clusterRoleSelectors;
    get clusterRoleSelectors(): ClusterRoleV1AggregationRuleClusterRoleSelectorsList;
    putClusterRoleSelectors(value: ClusterRoleV1AggregationRuleClusterRoleSelectors[] | cdktn.IResolvable): void;
    resetClusterRoleSelectors(): void;
    get clusterRoleSelectorsInput(): cdktn.IResolvable | ClusterRoleV1AggregationRuleClusterRoleSelectors[] | undefined;
}
export interface ClusterRoleV1Metadata {
    /**
    * An unstructured key value map stored with the clusterRole that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#annotations ClusterRoleV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#generate_name ClusterRoleV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the clusterRole. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#labels ClusterRoleV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the clusterRole, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#name ClusterRoleV1#name}
    */
    readonly name?: string;
}
export declare function clusterRoleV1MetadataToTerraform(struct?: ClusterRoleV1MetadataOutputReference | ClusterRoleV1Metadata): any;
export declare function clusterRoleV1MetadataToHclTerraform(struct?: ClusterRoleV1MetadataOutputReference | ClusterRoleV1Metadata): any;
export declare class ClusterRoleV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterRoleV1Metadata | undefined;
    set internalValue(value: ClusterRoleV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface ClusterRoleV1Rule {
    /**
    * APIGroups is the name of the APIGroup that contains the resources. If multiple API groups are specified, any action requested against one of the enumerated resources in any API group will be allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#api_groups ClusterRoleV1#api_groups}
    */
    readonly apiGroups?: string[];
    /**
    * NonResourceURLs is a set of partial urls that a user should have access to. *s are allowed, but only as the full, final step in the path Since non-resource URLs are not namespaced, this field is only applicable for ClusterRoles referenced from a ClusterRoleBinding. Rules can either apply to API resources (such as "pods" or "secrets") or non-resource URL paths (such as "/api"), but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#non_resource_urls ClusterRoleV1#non_resource_urls}
    */
    readonly nonResourceUrls?: string[];
    /**
    * ResourceNames is an optional white list of names that the rule applies to. An empty set means that everything is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#resource_names ClusterRoleV1#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * Resources is a list of resources this rule applies to. ResourceAll represents all resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#resources ClusterRoleV1#resources}
    */
    readonly resources?: string[];
    /**
    * Verbs is a list of Verbs that apply to ALL the ResourceKinds and AttributeRestrictions contained in this rule. VerbAll represents all kinds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#verbs ClusterRoleV1#verbs}
    */
    readonly verbs: string[];
}
export declare function clusterRoleV1RuleToTerraform(struct?: ClusterRoleV1Rule | cdktn.IResolvable): any;
export declare function clusterRoleV1RuleToHclTerraform(struct?: ClusterRoleV1Rule | cdktn.IResolvable): any;
export declare class ClusterRoleV1RuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterRoleV1Rule | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterRoleV1Rule | cdktn.IResolvable | undefined);
    private _apiGroups?;
    get apiGroups(): string[];
    set apiGroups(value: string[]);
    resetApiGroups(): void;
    get apiGroupsInput(): string[] | undefined;
    private _nonResourceUrls?;
    get nonResourceUrls(): string[];
    set nonResourceUrls(value: string[]);
    resetNonResourceUrls(): void;
    get nonResourceUrlsInput(): string[] | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _verbs?;
    get verbs(): string[];
    set verbs(value: string[]);
    get verbsInput(): string[] | undefined;
}
export declare class ClusterRoleV1RuleList extends cdktn.ComplexList {
    internalValue?: ClusterRoleV1Rule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterRoleV1RuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1 kubernetes_cluster_role_v1}
*/
export declare class ClusterRoleV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_cluster_role_v1";
    /**
    * Generates CDKTN code for importing a ClusterRoleV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClusterRoleV1 to import
    * @param importFromId The id of the existing ClusterRoleV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClusterRoleV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/cluster_role_v1 kubernetes_cluster_role_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClusterRoleV1Config
    */
    constructor(scope: Construct, id: string, config: ClusterRoleV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _aggregationRule;
    get aggregationRule(): ClusterRoleV1AggregationRuleOutputReference;
    putAggregationRule(value: ClusterRoleV1AggregationRule): void;
    resetAggregationRule(): void;
    get aggregationRuleInput(): ClusterRoleV1AggregationRule | undefined;
    private _metadata;
    get metadata(): ClusterRoleV1MetadataOutputReference;
    putMetadata(value: ClusterRoleV1Metadata): void;
    get metadataInput(): ClusterRoleV1Metadata | undefined;
    private _rule;
    get rule(): ClusterRoleV1RuleList;
    putRule(value: ClusterRoleV1Rule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | ClusterRoleV1Rule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
