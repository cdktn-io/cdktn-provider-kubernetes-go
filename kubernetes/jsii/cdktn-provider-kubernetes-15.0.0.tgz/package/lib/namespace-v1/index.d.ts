/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NamespaceV1Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#id NamespaceV1#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Terraform will wait for the default service account to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#wait_for_default_service_account NamespaceV1#wait_for_default_service_account}
    */
    readonly waitForDefaultServiceAccount?: boolean | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#metadata NamespaceV1#metadata}
    */
    readonly metadata: NamespaceV1Metadata;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#timeouts NamespaceV1#timeouts}
    */
    readonly timeouts?: NamespaceV1Timeouts;
}
export interface NamespaceV1Metadata {
    /**
    * An unstructured key value map stored with the namespace that may be used to store arbitrary metadata. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#annotations NamespaceV1#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Prefix, used by the server, to generate a unique name ONLY IF the `name` field has not been provided. This value will also be combined with a unique suffix. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#idempotency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#generate_name NamespaceV1#generate_name}
    */
    readonly generateName?: string;
    /**
    * Map of string keys and values that can be used to organize and categorize (scope and select) the namespace. May match selectors of replication controllers and services. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#labels NamespaceV1#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the namespace, must be unique. Cannot be updated. More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#name NamespaceV1#name}
    */
    readonly name?: string;
}
export declare function namespaceV1MetadataToTerraform(struct?: NamespaceV1MetadataOutputReference | NamespaceV1Metadata): any;
export declare function namespaceV1MetadataToHclTerraform(struct?: NamespaceV1MetadataOutputReference | NamespaceV1Metadata): any;
export declare class NamespaceV1MetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NamespaceV1Metadata | undefined;
    set internalValue(value: NamespaceV1Metadata | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _generateName?;
    get generateName(): string;
    set generateName(value: string);
    resetGenerateName(): void;
    get generateNameInput(): string | undefined;
    get generation(): number;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get resourceVersion(): string;
    get uid(): string;
}
export interface NamespaceV1Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#delete NamespaceV1#delete}
    */
    readonly delete?: string;
}
export declare function namespaceV1TimeoutsToTerraform(struct?: NamespaceV1Timeouts | cdktn.IResolvable): any;
export declare function namespaceV1TimeoutsToHclTerraform(struct?: NamespaceV1Timeouts | cdktn.IResolvable): any;
export declare class NamespaceV1TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NamespaceV1Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NamespaceV1Timeouts | cdktn.IResolvable | undefined);
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1 kubernetes_namespace_v1}
*/
export declare class NamespaceV1 extends cdktn.TerraformResource {
    static readonly tfResourceType = "kubernetes_namespace_v1";
    /**
    * Generates CDKTN code for importing a NamespaceV1 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NamespaceV1 to import
    * @param importFromId The id of the existing NamespaceV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NamespaceV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/kubernetes/3.1.0/docs/resources/namespace_v1 kubernetes_namespace_v1} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NamespaceV1Config
    */
    constructor(scope: Construct, id: string, config: NamespaceV1Config);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _waitForDefaultServiceAccount?;
    get waitForDefaultServiceAccount(): boolean | cdktn.IResolvable;
    set waitForDefaultServiceAccount(value: boolean | cdktn.IResolvable);
    resetWaitForDefaultServiceAccount(): void;
    get waitForDefaultServiceAccountInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): NamespaceV1MetadataOutputReference;
    putMetadata(value: NamespaceV1Metadata): void;
    get metadataInput(): NamespaceV1Metadata | undefined;
    private _timeouts;
    get timeouts(): NamespaceV1TimeoutsOutputReference;
    putTimeouts(value: NamespaceV1Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NamespaceV1Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
